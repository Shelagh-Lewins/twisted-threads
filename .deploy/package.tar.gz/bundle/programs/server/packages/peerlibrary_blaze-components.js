(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var Blaze = Package.blaze.Blaze;
var UI = Package.blaze.UI;
var Handlebars = Package.blaze.Handlebars;
var _ = Package.underscore._;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var ReactiveVar = Package['reactive-var'].ReactiveVar;
var EJSON = Package.ejson.EJSON;
var Spacebars = Package.spacebars.Spacebars;
var BaseComponent = Package['peerlibrary:base-component'].BaseComponent;
var BaseComponentDebug = Package['peerlibrary:base-component'].BaseComponentDebug;
var assert = Package['peerlibrary:assert'].assert;
var ReactiveField = Package['peerlibrary:reactive-field'].ReactiveField;
var ComputedField = Package['peerlibrary:computed-field'].ComputedField;
var DataLookup = Package['peerlibrary:data-lookup'].DataLookup;
var HTML = Package.htmljs.HTML;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var __coffeescriptShare, Template, AttributeHandler, ElementAttributesUpdater, BlazeComponent, BlazeComponentDebug;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/peerlibrary_blaze-components/template.coffee                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Template = Blaze.Template;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/peerlibrary_blaze-components/compatibility/templating.js                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/* This file is needed to backport this pull request: https://github.com/meteor/meteor/pull/5903
   If it is a copy of templating.js file wrapped into a condition.

   TODO: Remove this file eventually.
 */

if (!Blaze.Template.__checkName) {
  // Packages and apps add templates on to this object.

  /**
   * @summary The class for defining templates
   * @class
   * @instanceName Template.myTemplate
   */
  Template = Blaze.Template;

  var RESERVED_TEMPLATE_NAMES = "__proto__ name".split(" ");

  // Check for duplicate template names and illegal names that won't work.
  Template.__checkName = function (name) {
    // Some names can't be used for Templates. These include:
    //  - Properties Blaze sets on the Template object.
    //  - Properties that some browsers don't let the code to set.
    //    These are specified in RESERVED_TEMPLATE_NAMES.
    if (name in Template || _.contains(RESERVED_TEMPLATE_NAMES, name)) {
      if ((Template[name] instanceof Template) && name !== "body")
        throw new Error("There are multiple templates named '" + name + "'. Each template needs a unique name.");
      throw new Error("This template name is reserved: " + name);
    }
  };

  // XXX COMPAT WITH 0.8.3
  Template.__define__ = function (name, renderFunc) {
    Template.__checkName(name);
    Template[name] = new Template("Template." + name, renderFunc);
    // Exempt packages built pre-0.9.0 from warnings about using old
    // helper syntax, because we can.  It's not very useful to get a
    // warning about someone else's code (like a package on Atmosphere),
    // and this should at least put a bit of a dent in number of warnings
    // that come from packages that haven't been updated lately.
    Template[name]._NOWARN_OLDSTYLE_HELPERS = true;
  };

  // Define a template `Template.body` that renders its
  // `contentRenderFuncs`.  `<body>` tags (of which there may be
  // multiple) will have their contents added to it.

  /**
   * @summary The [template object](#templates_api) representing your `<body>`
   * tag.
   * @locus Client
   */
  Template.body = new Template('body', function () {
    var view = this;
    return _.map(Template.body.contentRenderFuncs, function (func) {
      return func.apply(view);
    });
  });
  Template.body.contentRenderFuncs = []; // array of Blaze.Views
  Template.body.view = null;

  Template.body.addContent = function (renderFunc) {
    Template.body.contentRenderFuncs.push(renderFunc);
  };

  // This function does not use `this` and so it may be called
  // as `Meteor.startup(Template.body.renderIntoDocument)`.
  Template.body.renderToDocument = function () {
    // Only do it once.
    if (Template.body.view)
      return;

    var view = Blaze.render(Template.body, document.body);
    Template.body.view = view;
  };

  // XXX COMPAT WITH 0.9.0
  UI.body = Template.body;

  // XXX COMPAT WITH 0.9.0
  // (<body> tags in packages built with 0.9.0)
  Template.__body__ = Template.body;
  Template.__body__.__contentParts = Template.body.contentViews;
  Template.__body__.__instantiate = Template.body.renderToDocument;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/peerlibrary_blaze-components/compatibility/template.dynamic.js                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //

Template.__checkName("__dynamicBackport");
Template["__dynamicBackport"] = new Template("Template.__dynamicBackport", (function() {
  var view = this;
  return [ Blaze.View("lookup:checkContext", function() {
    return Spacebars.mustache(view.lookup("checkContext"));
  }), "\n  ", Blaze.If(function() {
    return Spacebars.call(view.lookup("dataContextPresent"));
  }, function() {
    return [ "\n    ", Spacebars.include(view.lookupTemplate("__dynamicWithDataContext"), function() {
      return Blaze._InOuterTemplateScope(view, function() {
        return Spacebars.include(function() {
          return Spacebars.call(view.templateContentBlock);
        });
      });
    }), "\n  " ];
  }, function() {
    return [ "\n    \n    ", Blaze._TemplateWith(function() {
      return {
        template: Spacebars.call(view.lookup("template")),
        data: Spacebars.call(view.lookup(".."))
      };
    }, function() {
      return Spacebars.include(view.lookupTemplate("__dynamicWithDataContext"), function() {
        return Blaze._InOuterTemplateScope(view, function() {
          return Spacebars.include(function() {
            return Spacebars.call(view.templateContentBlock);
          });
        });
      });
    }), "\n  " ];
  }) ];
}));

Template.__checkName("__dynamicWithDataContextBackport");
Template["__dynamicWithDataContextBackport"] = new Template("Template.__dynamicWithDataContextBackport", (function() {
  var view = this;
  return Spacebars.With(function() {
    return Spacebars.dataMustache(view.lookup("chooseTemplate"), view.lookup("template"));
  }, function() {
    return [ "\n    \n    ", Blaze._TemplateWith(function() {
      return Spacebars.call(Spacebars.dot(view.lookup(".."), "data"));
    }, function() {
      return Spacebars.include(view.lookupTemplate(".."), function() {
        return Blaze._InOuterTemplateScope(view, function() {
          return Spacebars.include(function() {
            return Spacebars.call(view.templateContentBlock);
          });
        });
      });
    }), "\n  " ];
  });
}));

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/peerlibrary_blaze-components/compatibility/dynamic.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/* This file is needed to backport this pull request: https://github.com/meteor/meteor/pull/5903
   If it is a copy of dynamic.js file wrapped into a condition with renaming of backported templates.

   TODO: Remove this file eventually.
 */

if (!Blaze.Template.__dynamicWithDataContext) {
  Blaze.Template.__dynamicWithDataContext = Blaze.Template.__dynamicWithDataContextBackport;
  Blaze.Template.__dynamicWithDataContext.viewName = 'Template.__dynamicWithDataContext';
  Blaze.Template.__dynamic = Blaze.Template.__dynamicBackport;
  Blaze.Template.__dynamic.viewName = 'Template.__dynamic';

  var Template = Blaze.Template;

  /**
   * @isTemplate true
   * @memberOf Template
   * @function dynamic
   * @summary Choose a template to include dynamically, by name.
   * @locus Templates
   * @param {String} template The name of the template to include.
   * @param {Object} [data] Optional. The data context in which to include the
   * template.
   */

  Template.__dynamicWithDataContext.helpers({
    chooseTemplate: function (name) {
      return Blaze._getTemplate(name, function () {
        return Template.instance();
      });
    }
  });

  Template.__dynamic.helpers({
    dataContextPresent: function () {
      return _.has(this, "data");
    },
    checkContext: function () {
      if (!_.has(this, "template")) {
        throw new Error("Must specify name in the 'template' argument " +
          "to {{> Template.dynamic}}.");
      }

      _.each(this, function (v, k) {
        if (k !== "template" && k !== "data") {
          throw new Error("Invalid argument to {{> Template.dynamic}}: " +
            k);
        }
      });
    }
  });
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/peerlibrary_blaze-components/compatibility/lookup.js                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/* This file backports Blaze lookup.js from Meteor 1.2 so that required Blaze features to support Blaze
   Components are available also in older Meteor versions.
   It is a copy of lookup.js file from Meteor 1.2 with lexical scope lookup commented out.

   TODO: Remove this file eventually.
 */

// Check if we are not running Meteor 1.2+.
if (! Blaze._getTemplate) {
  // If `x` is a function, binds the value of `this` for that function
  // to the current data context.
  var bindDataContext = function (x) {
    if (typeof x === 'function') {
      return function () {
        var data = Blaze.getData();
        if (data == null)
          data = {};
        return x.apply(data, arguments);
      };
    }
    return x;
  };

  Blaze._getTemplateHelper = function (template, name, tmplInstanceFunc) {
    // XXX COMPAT WITH 0.9.3
    var isKnownOldStyleHelper = false;

    if (template.__helpers.has(name)) {
      var helper = template.__helpers.get(name);
      if (helper === Blaze._OLDSTYLE_HELPER) {
        isKnownOldStyleHelper = true;
      } else if (helper != null) {
        return wrapHelper(bindDataContext(helper), tmplInstanceFunc);
      } else {
        return null;
      }
    }

    // old-style helper
    if (name in template) {
      // Only warn once per helper
      if (!isKnownOldStyleHelper) {
        template.__helpers.set(name, Blaze._OLDSTYLE_HELPER);
        if (!template._NOWARN_OLDSTYLE_HELPERS) {
          Blaze._warn('Assigning helper with `' + template.viewName + '.' +
            name + ' = ...` is deprecated.  Use `' + template.viewName +
            '.helpers(...)` instead.');
        }
      }
      if (template[name] != null) {
        return wrapHelper(bindDataContext(template[name]), tmplInstanceFunc);
      }
    }

    return null;
  };

  var wrapHelper = function (f, templateFunc) {
    // XXX COMPAT WITH METEOR 1.0.3.2
    if (!Blaze.Template._withTemplateInstanceFunc) {
      return Blaze._wrapCatchingExceptions(f, 'template helper');
    }

    if (typeof f !== "function") {
      return f;
    }

    return function () {
      var self = this;
      var args = arguments;

      return Blaze.Template._withTemplateInstanceFunc(templateFunc, function () {
        return Blaze._wrapCatchingExceptions(f, 'template helper').apply(self, args);
      });
    };
  };

  // templateInstance argument is provided to be available for possible
  // alternative implementations of this function by 3rd party packages.
  Blaze._getTemplate = function (name, templateInstance) {
    if ((name in Blaze.Template) && (Blaze.Template[name] instanceof Blaze.Template)) {
      return Blaze.Template[name];
    }
    return null;
  };

  Blaze._getGlobalHelper = function (name, templateInstance) {
    if (Blaze._globalHelpers[name] != null) {
      return wrapHelper(bindDataContext(Blaze._globalHelpers[name]), templateInstance);
    }
    return null;
  };

  Blaze.View.prototype.lookup = function (name, _options) {
    var template = this.template;
    var lookupTemplate = _options && _options.template;
    var helper;
    var binding;
    var boundTmplInstance;
    var foundTemplate;

    if (this.templateInstance) {
      boundTmplInstance = _.bind(this.templateInstance, this);
    }

    // 0. looking up the parent data context with the special "../" syntax
    if (/^\./.test(name)) {
      // starts with a dot. must be a series of dots which maps to an
      // ancestor of the appropriate height.
      if (!/^(\.)+$/.test(name))
        throw new Error("id starting with dot must be a series of dots");

      return Blaze._parentData(name.length - 1, true /*_functionWrapped*/);

    }

    // 1. look up a helper on the current template
    if (template && ((helper = Blaze._getTemplateHelper(template, name, boundTmplInstance)) != null)) {
      return helper;
    }

    // 2. look up a binding by traversing the lexical view hierarchy inside the
    // current template
    /*if (template && (binding = Blaze._lexicalBindingLookup(Blaze.currentView, name)) != null) {
      return binding;
    }*/

    // 3. look up a template by name
    if (lookupTemplate && ((foundTemplate = Blaze._getTemplate(name, boundTmplInstance)) != null)) {
      return foundTemplate;
    }

    // 4. look up a global helper
    if ((helper = Blaze._getGlobalHelper(name, boundTmplInstance)) != null) {
      return helper;
    }

    // 5. look up in a data context
    return function () {
      var isCalledAsFunction = (arguments.length > 0);
      var data = Blaze.getData();
      var x = data && data[name];
      if (!x) {
        if (lookupTemplate) {
          throw new Error("No such template: " + name);
        } else if (isCalledAsFunction) {
          throw new Error("No such function: " + name);
        } /*else if (name.charAt(0) === '@' && ((x === null) ||
          (x === undefined))) {
          // Throw an error if the user tries to use a `@directive`
          // that doesn't exist.  We don't implement all directives
          // from Handlebars, so there's a potential for confusion
          // if we fail silently.  On the other hand, we want to
          // throw late in case some app or package wants to provide
          // a missing directive.
          throw new Error("Unsupported directive: " + name);
        }*/
      }
      if (!data) {
        return null;
      }
      if (typeof x !== 'function') {
        if (isCalledAsFunction) {
          throw new Error("Can't call non-function: " + x);
        }
        return x;
      }
      return x.apply(data, arguments);
    };
  };
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/peerlibrary_blaze-components/compatibility/attrs.js                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/* This file is needed to backport this pull request: https://github.com/meteor/meteor/pull/5893
   It is a copy of attrs.js file with the changes from the above pull request merged in.

   TODO: Remove this file eventually.
 */

var jsUrlsAllowed = false;
Blaze._allowJavascriptUrls = function () {
  jsUrlsAllowed = true;
};
Blaze._javascriptUrlsAllowed = function () {
  return jsUrlsAllowed;
};

// An AttributeHandler object is responsible for updating a particular attribute
// of a particular element.  AttributeHandler subclasses implement
// browser-specific logic for dealing with particular attributes across
// different browsers.
//
// To define a new type of AttributeHandler, use
// `var FooHandler = AttributeHandler.extend({ update: function ... })`
// where the `update` function takes arguments `(element, oldValue, value)`.
// The `element` argument is always the same between calls to `update` on
// the same instance.  `oldValue` and `value` are each either `null` or
// a Unicode string of the type that might be passed to the value argument
// of `setAttribute` (i.e. not an HTML string with character references).
// When an AttributeHandler is installed, an initial call to `update` is
// always made with `oldValue = null`.  The `update` method can access
// `this.name` if the AttributeHandler class is a generic one that applies
// to multiple attribute names.
//
// AttributeHandlers can store custom properties on `this`, as long as they
// don't use the names `element`, `name`, `value`, and `oldValue`.
//
// AttributeHandlers can't influence how attributes appear in rendered HTML,
// only how they are updated after materialization as DOM.

AttributeHandler = function (name, value) {
  this.name = name;
  this.value = value;
};
Blaze._AttributeHandler = AttributeHandler;

AttributeHandler.prototype.update = function (element, oldValue, value) {
  if (value === null) {
    if (oldValue !== null)
      element.removeAttribute(this.name);
  } else {
    element.setAttribute(this.name, value);
  }
};

AttributeHandler.extend = function (options) {
  var curType = this;
  var subType = function AttributeHandlerSubtype(/*arguments*/) {
    AttributeHandler.apply(this, arguments);
  };
  subType.prototype = new curType;
  subType.extend = curType.extend;
  if (options)
    _.extend(subType.prototype, options);
  return subType;
};

/// Apply the diff between the attributes of "oldValue" and "value" to "element."
//
// Each subclass must implement a parseValue method which takes a string
// as an input and returns a dict of attributes. The keys of the dict
// are unique identifiers (ie. css properties in the case of styles), and the
// values are the entire attribute which will be injected into the element.
//
// Extended below to support classes, SVG elements and styles.

Blaze._DiffingAttributeHandler = AttributeHandler.extend({
  update: function (element, oldValue, value) {
    if (!this.getCurrentValue || !this.setValue || !this.parseValue)
      throw new Error("Missing methods in subclass of 'DiffingAttributeHandler'");

    var oldAttrsMap = oldValue ? this.parseValue(oldValue) : {};
    var newAttrsMap = value ? this.parseValue(value) : {};

    // the current attributes on the element, which we will mutate.

    var attrString = this.getCurrentValue(element);
    var attrsMap = attrString ? this.parseValue(attrString) : {};

    _.each(_.keys(oldAttrsMap), function (t) {
      if (! (t in newAttrsMap))
        delete attrsMap[t];
    });

    _.each(_.keys(newAttrsMap), function (t) {
      attrsMap[t] = newAttrsMap[t];
    });

    this.setValue(element, _.values(attrsMap).join(' '));
  }
});

var ClassHandler = Blaze._DiffingAttributeHandler.extend({
  // @param rawValue {String}
  getCurrentValue: function (element) {
    return element.className;
  },
  setValue: function (element, className) {
    element.className = className;
  },
  parseValue: function (attrString) {
    var tokens = {};

    _.each(attrString.split(' '), function(token) {
      if (token)
        tokens[token] = token;
    });
    return tokens;
  }
});

var SVGClassHandler = ClassHandler.extend({
  getCurrentValue: function (element) {
    return element.className.baseVal;
  },
  setValue: function (element, className) {
    element.setAttribute('class', className);
  }
});

var StyleHandler = Blaze._DiffingAttributeHandler.extend({
  getCurrentValue: function (element) {
    return element.getAttribute('style');
  },
  setValue: function (element, style) {
    if (style === '') {
      element.removeAttribute('style');
    } else {
      element.setAttribute('style', style);
    }
  },

  // Parse a string to produce a map from property to attribute string.
  //
  // Example:
  // "color:red; foo:12px" produces a token {color: "color:red", foo:"foo:12px"}
  parseValue: function (attrString) {
    var tokens = {};

    // Regex for parsing a css attribute declaration, taken from css-parse:
    // https://github.com/reworkcss/css-parse/blob/7cef3658d0bba872cde05a85339034b187cb3397/index.js#L219
    var regex = /(\*?[-#\/\*\\\w]+(?:\[[0-9a-z_-]+\])?)\s*:\s*(?:\'(?:\\\'|.)*?\'|"(?:\\"|.)*?"|\([^\)]*?\)|[^};])+[;\s]*/g;
    var match = regex.exec(attrString);
    while (match) {
      // match[0] = entire matching string
      // match[1] = css property
      // Prefix the token to prevent conflicts with existing properties.

      // XXX No `String.trim` on Safari 4. Swap out $.trim if we want to
      // remove strong dep on jquery.
      tokens[' ' + match[1]] = match[0].trim ?
        match[0].trim() : $.trim(match[0]);

      match = regex.exec(attrString);
    }

    return tokens;
  }
});

var BooleanHandler = AttributeHandler.extend({
  update: function (element, oldValue, value) {
    var name = this.name;
    if (value == null) {
      if (oldValue != null)
        element[name] = false;
    } else {
      element[name] = true;
    }
  }
});

var DOMPropertyHandler = AttributeHandler.extend({
  update: function (element, oldValue, value) {
    var name = this.name;
    if (value !== element[name])
      element[name] = value;
  }
});

// attributes of the type 'xlink:something' should be set using
// the correct namespace in order to work
var XlinkHandler = AttributeHandler.extend({
  update: function(element, oldValue, value) {
    var NS = 'http://www.w3.org/1999/xlink';
    if (value === null) {
      if (oldValue !== null)
        element.removeAttributeNS(NS, this.name);
    } else {
      element.setAttributeNS(NS, this.name, this.value);
    }
  }
});

// cross-browser version of `instanceof SVGElement`
var isSVGElement = function (elem) {
  return 'ownerSVGElement' in elem;
};

var isUrlAttribute = function (tagName, attrName) {
  // Compiled from http://www.w3.org/TR/REC-html40/index/attributes.html
  // and
  // http://www.w3.org/html/wg/drafts/html/master/index.html#attributes-1
  var urlAttrs = {
    FORM: ['action'],
    BODY: ['background'],
    BLOCKQUOTE: ['cite'],
    Q: ['cite'],
    DEL: ['cite'],
    INS: ['cite'],
    OBJECT: ['classid', 'codebase', 'data', 'usemap'],
    APPLET: ['codebase'],
    A: ['href'],
    AREA: ['href'],
    LINK: ['href'],
    BASE: ['href'],
    IMG: ['longdesc', 'src', 'usemap'],
    FRAME: ['longdesc', 'src'],
    IFRAME: ['longdesc', 'src'],
    HEAD: ['profile'],
    SCRIPT: ['src'],
    INPUT: ['src', 'usemap', 'formaction'],
    BUTTON: ['formaction'],
    BASE: ['href'],
    MENUITEM: ['icon'],
    HTML: ['manifest'],
    VIDEO: ['poster']
  };

  if (attrName === 'itemid') {
    return true;
  }

  var urlAttrNames = urlAttrs[tagName] || [];
  return _.contains(urlAttrNames, attrName);
};

// To get the protocol for a URL, we let the browser normalize it for
// us, by setting it as the href for an anchor tag and then reading out
// the 'protocol' property.
if (Meteor.isClient) {
  var anchorForNormalization = document.createElement('A');
}

var getUrlProtocol = function (url) {
  if (Meteor.isClient) {
    anchorForNormalization.href = url;
    return (anchorForNormalization.protocol || "").toLowerCase();
  } else {
    throw new Error('getUrlProtocol not implemented on the server');
  }
};

// UrlHandler is an attribute handler for all HTML attributes that take
// URL values. It disallows javascript: URLs, unless
// Blaze._allowJavascriptUrls() has been called. To detect javascript:
// urls, we set the attribute on a dummy anchor element and then read
// out the 'protocol' property of the attribute.
var origUpdate = AttributeHandler.prototype.update;
var UrlHandler = AttributeHandler.extend({
  update: function (element, oldValue, value) {
    var self = this;
    var args = arguments;

    if (Blaze._javascriptUrlsAllowed()) {
      origUpdate.apply(self, args);
    } else {
      var isJavascriptProtocol = (getUrlProtocol(value) === "javascript:");
      if (isJavascriptProtocol) {
        Blaze._warn("URLs that use the 'javascript:' protocol are not " +
                    "allowed in URL attribute values. " +
                    "Call Blaze._allowJavascriptUrls() " +
                    "to enable them.");
        origUpdate.apply(self, [element, oldValue, null]);
      } else {
        origUpdate.apply(self, args);
      }
    }
  }
});

// XXX make it possible for users to register attribute handlers!
Blaze._makeAttributeHandler = function (elem, name, value) {
  // generally, use setAttribute but certain attributes need to be set
  // by directly setting a JavaScript property on the DOM element.
  if (name === 'class') {
    if (isSVGElement(elem)) {
      return new SVGClassHandler(name, value);
    } else {
      return new ClassHandler(name, value);
    }
  } else if (name === 'style') {
    return new StyleHandler(name, value);
  } else if ((elem.tagName === 'OPTION' && name === 'selected') ||
             (elem.tagName === 'INPUT' && name === 'checked')) {
    return new BooleanHandler(name, value);
  } else if ((elem.tagName === 'TEXTAREA' || elem.tagName === 'INPUT')
             && name === 'value') {
    // internally, TEXTAREAs tracks their value in the 'value'
    // attribute just like INPUTs.
    return new DOMPropertyHandler(name, value);
  } else if (name.substring(0,6) === 'xlink:') {
    return new XlinkHandler(name.substring(6), value);
  } else if (isUrlAttribute(elem.tagName, name)) {
    return new UrlHandler(name, value);
  } else {
    return new AttributeHandler(name, value);
  }

  // XXX will need one for 'style' on IE, though modern browsers
  // seem to handle setAttribute ok.
};


ElementAttributesUpdater = function (elem) {
  this.elem = elem;
  this.handlers = {};
};

// Update attributes on `elem` to the dictionary `attrs`, whose
// values are strings.
ElementAttributesUpdater.prototype.update = function(newAttrs) {
  var elem = this.elem;
  var handlers = this.handlers;

  for (var k in handlers) {
    if (! _.has(newAttrs, k)) {
      // remove attributes (and handlers) for attribute names
      // that don't exist as keys of `newAttrs` and so won't
      // be visited when traversing it.  (Attributes that
      // exist in the `newAttrs` object but are `null`
      // are handled later.)
      var handler = handlers[k];
      var oldValue = handler.value;
      handler.value = null;
      handler.update(elem, oldValue, null);
      delete handlers[k];
    }
  }

  for (var k in newAttrs) {
    var handler = null;
    var oldValue;
    var value = newAttrs[k];
    if (! _.has(handlers, k)) {
      if (value !== null) {
        // make new handler
        handler = Blaze._makeAttributeHandler(elem, k, value);
        handlers[k] = handler;
        oldValue = null;
      }
    } else {
      handler = handlers[k];
      oldValue = handler.value;
    }
    if (oldValue !== value) {
      handler.value = value;
      handler.update(elem, oldValue, value);
      if (value === null)
        delete handlers[k];
    }
  }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/peerlibrary_blaze-components/compatibility/materializer.js                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/* This file is needed to backport this pull request: https://github.com/meteor/meteor/pull/5893
   It is a copy of the materializer.js file and is needed because it references symbols from attrs.js.

   TODO: Remove this file eventually.
 */

// Turns HTMLjs into DOM nodes and DOMRanges.
//
// - `htmljs`: the value to materialize, which may be any of the htmljs
//   types (Tag, CharRef, Comment, Raw, array, string, boolean, number,
//   null, or undefined) or a View or Template (which will be used to
//   construct a View).
// - `intoArray`: the array of DOM nodes and DOMRanges to push the output
//   into (required)
// - `parentView`: the View we are materializing content for (optional)
// - `_existingWorkStack`: optional argument, only used for recursive
//   calls when there is some other _materializeDOM on the call stack.
//   If _materializeDOM called your function and passed in a workStack,
//   pass it back when you call _materializeDOM (such as from a workStack
//   task).
//
// Returns `intoArray`, which is especially useful if you pass in `[]`.
Blaze._materializeDOM = function (htmljs, intoArray, parentView,
                                  _existingWorkStack) {
  // In order to use fewer stack frames, materializeDOMInner can push
  // tasks onto `workStack`, and they will be popped off
  // and run, last first, after materializeDOMInner returns.  The
  // reason we use a stack instead of a queue is so that we recurse
  // depth-first, doing newer tasks first.
  var workStack = (_existingWorkStack || []);
  materializeDOMInner(htmljs, intoArray, parentView, workStack);

  if (! _existingWorkStack) {
    // We created the work stack, so we are responsible for finishing
    // the work.  Call each "task" function, starting with the top
    // of the stack.
    while (workStack.length) {
      // Note that running task() may push new items onto workStack.
      var task = workStack.pop();
      task();
    }
  }

  return intoArray;
};

var materializeDOMInner = function (htmljs, intoArray, parentView, workStack) {
  if (htmljs == null) {
    // null or undefined
    return;
  }

  switch (typeof htmljs) {
  case 'string': case 'boolean': case 'number':
    intoArray.push(document.createTextNode(String(htmljs)));
    return;
  case 'object':
    if (htmljs.htmljsType) {
      switch (htmljs.htmljsType) {
      case HTML.Tag.htmljsType:
        intoArray.push(materializeTag(htmljs, parentView, workStack));
        return;
      case HTML.CharRef.htmljsType:
        intoArray.push(document.createTextNode(htmljs.str));
        return;
      case HTML.Comment.htmljsType:
        intoArray.push(document.createComment(htmljs.sanitizedValue));
        return;
      case HTML.Raw.htmljsType:
        // Get an array of DOM nodes by using the browser's HTML parser
        // (like innerHTML).
        var nodes = Blaze._DOMBackend.parseHTML(htmljs.value);
        for (var i = 0; i < nodes.length; i++)
          intoArray.push(nodes[i]);
        return;
      }
    } else if (HTML.isArray(htmljs)) {
      for (var i = htmljs.length-1; i >= 0; i--) {
        workStack.push(_.bind(Blaze._materializeDOM, null,
                              htmljs[i], intoArray, parentView, workStack));
      }
      return;
    } else {
      if (htmljs instanceof Blaze.Template) {
        htmljs = htmljs.constructView();
        // fall through to Blaze.View case below
      }
      if (htmljs instanceof Blaze.View) {
        Blaze._materializeView(htmljs, parentView, workStack, intoArray);
        return;
      }
    }
  }

  throw new Error("Unexpected object in htmljs: " + htmljs);
};

var materializeTag = function (tag, parentView, workStack) {
  var tagName = tag.tagName;
  var elem;
  if ((HTML.isKnownSVGElement(tagName) || isSVGAnchor(tag))
      && document.createElementNS) {
    // inline SVG
    elem = document.createElementNS('http://www.w3.org/2000/svg', tagName);
  } else {
    // normal elements
    elem = document.createElement(tagName);
  }

  var rawAttrs = tag.attrs;
  var children = tag.children;
  if (tagName === 'textarea' && tag.children.length &&
      ! (rawAttrs && ('value' in rawAttrs))) {
    // Provide very limited support for TEXTAREA tags with children
    // rather than a "value" attribute.
    // Reactivity in the form of Views nested in the tag's children
    // won't work.  Compilers should compile textarea contents into
    // the "value" attribute of the tag, wrapped in a function if there
    // is reactivity.
    if (typeof rawAttrs === 'function' ||
        HTML.isArray(rawAttrs)) {
      throw new Error("Can't have reactive children of TEXTAREA node; " +
                      "use the 'value' attribute instead.");
    }
    rawAttrs = _.extend({}, rawAttrs || null);
    rawAttrs.value = Blaze._expand(children, parentView);
    children = [];
  }

  if (rawAttrs) {
    var attrUpdater = new ElementAttributesUpdater(elem);
    var updateAttributes = function () {
      var expandedAttrs = Blaze._expandAttributes(rawAttrs, parentView);
      var flattenedAttrs = HTML.flattenAttributes(expandedAttrs);
      var stringAttrs = {};
      for (var attrName in flattenedAttrs) {
        stringAttrs[attrName] = Blaze._toText(flattenedAttrs[attrName],
                                              parentView,
                                              HTML.TEXTMODE.STRING);
      }
      attrUpdater.update(stringAttrs);
    };
    var updaterComputation;
    if (parentView) {
      updaterComputation =
        parentView.autorun(updateAttributes, undefined, 'updater');
    } else {
      updaterComputation = Tracker.nonreactive(function () {
        return Tracker.autorun(function () {
          Tracker._withCurrentView(parentView, updateAttributes);
        });
      });
    }
    Blaze._DOMBackend.Teardown.onElementTeardown(elem, function attrTeardown() {
      updaterComputation.stop();
    });
  }

  if (children.length) {
    var childNodesAndRanges = [];
    // push this function first so that it's done last
    workStack.push(function () {
      for (var i = 0; i < childNodesAndRanges.length; i++) {
        var x = childNodesAndRanges[i];
        if (x instanceof Blaze._DOMRange)
          x.attach(elem);
        else
          elem.appendChild(x);
      }
    });
    // now push the task that calculates childNodesAndRanges
    workStack.push(_.bind(Blaze._materializeDOM, null,
                          children, childNodesAndRanges, parentView,
                          workStack));
  }

  return elem;
};


var isSVGAnchor = function (node) {
  // We generally aren't able to detect SVG <a> elements because
  // if "A" were in our list of known svg element names, then all
  // <a> nodes would be created using
  // `document.createElementNS`. But in the special case of <a
  // xlink:href="...">, we can at least detect that attribute and
  // create an SVG <a> tag in that case.
  //
  // However, we still have a general problem of knowing when to
  // use document.createElementNS and when to use
  // document.createElement; for example, font tags will always
  // be created as SVG elements which can cause other
  // problems. #1977
  return (node.tagName === "a" &&
          node.attrs &&
          node.attrs["xlink:href"] !== undefined);
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/peerlibrary_blaze-components/lib.coffee                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var ComponentsNamespaceReference,
    HTMLJSExpander,
    REQUIRE_RENDERED_INSTANCE,
    SUPPORTS_REACTIVE_INSTANCE,
    addEvents,
    argumentsConstructor,
    bindComponent,
    bindDataContext,
    callTemplateBaseHooks,
    contentAsFunc,
    contentAsView,
    createMatcher,
    currentViewIfRendering,
    expand,
    expandView,
    getTemplateBase,
    getTemplateInstance,
    getTemplateInstanceFunction,
    method,
    methodName,
    originalDot,
    originalFlattenAttributes,
    originalGetTemplate,
    originalInclude,
    originalVisitTag,
    ref,
    registerFirstCreatedHook,
    registerHooks,
    templateInstanceToComponent,
    withTemplateInstanceFunc,
    wrapHelper,
    wrapViewAndTemplate,
    slice = [].slice,
    extend = function (child, parent) {
  for (var key in meteorBabelHelpers.sanitizeForInObject(parent)) {
    if (hasProp.call(parent, key)) child[key] = parent[key];
  }

  function ctor() {
    this.constructor = child;
  }

  ctor.prototype = parent.prototype;
  child.prototype = new ctor();
  child.__super__ = parent.prototype;
  return child;
},
    hasProp = {}.hasOwnProperty,
    indexOf = [].indexOf || function (item) {
  for (var i = 0, l = this.length; i < l; i++) {
    if (i in this && this[i] === item) return i;
  }

  return -1;
};

createMatcher = function (propertyOrMatcherOrFunction, checkMixins) {
  var matcher, property;

  if (_.isString(propertyOrMatcherOrFunction)) {
    property = propertyOrMatcherOrFunction;

    propertyOrMatcherOrFunction = function (_this) {
      return function (child, parent) {
        if (checkMixins && child !== parent && child.getFirstWith) {
          return !!child.getFirstWith(null, property);
        } else {
          return property in child;
        }
      };
    }(this);
  } else if (!_.isFunction(propertyOrMatcherOrFunction)) {
    assert(_.isObject(propertyOrMatcherOrFunction));
    matcher = propertyOrMatcherOrFunction;

    propertyOrMatcherOrFunction = function (_this) {
      return function (child, parent) {
        var childWithProperty, value;

        for (property in meteorBabelHelpers.sanitizeForInObject(matcher)) {
          value = matcher[property];

          if (checkMixins && child !== parent && child.getFirstWith) {
            childWithProperty = child.getFirstWith(null, property);
          } else {
            if (property in child) {
              childWithProperty = child;
            }
          }

          if (!childWithProperty) {
            return false;
          }

          if (_.isFunction(childWithProperty[property])) {
            if (childWithProperty[property]() !== value) {
              return false;
            }
          } else {
            if (childWithProperty[property] !== value) {
              return false;
            }
          }
        }

        return true;
      };
    }(this);
  }

  return propertyOrMatcherOrFunction;
};

getTemplateInstance = function (view, skipBlockHelpers) {
  while (view && !view._templateInstance) {
    if (skipBlockHelpers) {
      view = view.parentView;
    } else {
      view = view.originalParentView || view.parentView;
    }
  }

  return view != null ? view._templateInstance : void 0;
};

templateInstanceToComponent = function (templateInstanceFunc, skipBlockHelpers) {
  var templateInstance;
  templateInstance = typeof templateInstanceFunc === "function" ? templateInstanceFunc() : void 0;
  templateInstance = getTemplateInstance(templateInstance != null ? templateInstance.view : void 0, skipBlockHelpers);

  while (templateInstance) {
    if ('component' in templateInstance) {
      return templateInstance.component;
    }

    if (skipBlockHelpers) {
      templateInstance = getTemplateInstance(templateInstance.view.parentView, skipBlockHelpers);
    } else {
      templateInstance = getTemplateInstance(templateInstance.view.originalParentView || templateInstance.view.parentView, skipBlockHelpers);
    }
  }

  return null;
};

getTemplateInstanceFunction = function (view, skipBlockHelpers) {
  var templateInstance;
  templateInstance = getTemplateInstance(view, skipBlockHelpers);
  return function () {
    return templateInstance;
  };
};

ComponentsNamespaceReference = function () {
  function ComponentsNamespaceReference(namespace, templateInstance1) {
    this.namespace = namespace;
    this.templateInstance = templateInstance1;
  }

  return ComponentsNamespaceReference;
}();

originalDot = Spacebars.dot;

Spacebars.dot = function () {
  var args, value;
  value = arguments[0], args = 2 <= arguments.length ? slice.call(arguments, 1) : [];

  if (value instanceof ComponentsNamespaceReference) {
    return Blaze._getTemplate(value.namespace + "." + args.join('.'), value.templateInstance);
  }

  return originalDot.apply(null, [value].concat(slice.call(args)));
};

originalInclude = Spacebars.include;

Spacebars.include = function () {
  var args, templateOrFunction;
  templateOrFunction = arguments[0], args = 2 <= arguments.length ? slice.call(arguments, 1) : [];

  if (templateOrFunction instanceof ComponentsNamespaceReference) {
    templateOrFunction = Blaze._getTemplate(templateOrFunction.namespace, templateOrFunction.templateInstance);
  }

  return originalInclude.apply(null, [templateOrFunction].concat(slice.call(args)));
};

Blaze._getTemplateHelper = function (template, name, templateInstance) {
  var component, helper, isKnownOldStyleHelper, mixinOrComponent, ref, ref1, ref2;
  isKnownOldStyleHelper = false;

  if (template.__helpers.has(name)) {
    helper = template.__helpers.get(name);

    if (helper === Blaze._OLDSTYLE_HELPER) {
      isKnownOldStyleHelper = true;
    } else if (helper != null) {
      return wrapHelper(bindDataContext(helper), templateInstance);
    } else {
      return null;
    }
  }

  if (name in template) {
    if (!isKnownOldStyleHelper) {
      template.__helpers.set(name, Blaze._OLDSTYLE_HELPER);

      if (!template._NOWARN_OLDSTYLE_HELPERS) {
        Blaze._warn("Assigning helper with `" + template.viewName + "." + name + " = ...` is deprecated.  Use `" + template.viewName + ".helpers(...)` instead.");
      }
    }

    if (template[name] != null) {
      return wrapHelper(bindDataContext(template[name]), templateInstance);
    } else {
      return null;
    }
  }

  if (!templateInstance) {
    return null;
  }

  if ((ref = template.viewName) === 'Template.__dynamicWithDataContext' || ref === 'Template.__dynamic') {
    return null;
  }

  component = Tracker.nonreactive(function () {
    return templateInstanceToComponent(templateInstance, true);
  });

  if (component) {
    if (mixinOrComponent = component.getFirstWith(null, name)) {
      return wrapHelper(bindComponent(mixinOrComponent, mixinOrComponent[name]), templateInstance);
    }
  }

  if (name && name in BlazeComponent.components) {
    return new ComponentsNamespaceReference(name, templateInstance);
  }

  if (component) {
    if ((helper = (ref1 = component._componentInternals) != null ? (ref2 = ref1.templateBase) != null ? ref2.__helpers.get(name) : void 0 : void 0) != null) {
      return wrapHelper(bindDataContext(helper), templateInstance);
    }
  }

  return null;
};

share.inExpandAttributes = false;

bindComponent = function (component, helper) {
  if (_.isFunction(helper)) {
    return function () {
      var args, name, result, value;
      args = 1 <= arguments.length ? slice.call(arguments, 0) : [];
      result = helper.apply(component, args);

      if (share.inExpandAttributes && _.isObject(result)) {
        for (name in meteorBabelHelpers.sanitizeForInObject(result)) {
          value = result[name];

          if (share.EVENT_HANDLER_REGEX.test(name)) {
            if (_.isFunction(value)) {
              result[name] = _.bind(value, component);
            } else if (_.isArray(value)) {
              result[name] = _.map(value, function (fun) {
                if (_.isFunction(fun)) {
                  return _.bind(fun, component);
                } else {
                  return fun;
                }
              });
            }
          }
        }
      }

      return result;
    };
  } else {
    return helper;
  }
};

bindDataContext = function (helper) {
  if (_.isFunction(helper)) {
    return function () {
      var data;
      data = Blaze.getData();

      if (data == null) {
        data = {};
      }

      return helper.apply(data, arguments);
    };
  } else {
    return helper;
  }
};

wrapHelper = function (f, templateFunc) {
  if (!Blaze.Template._withTemplateInstanceFunc) {
    return Blaze._wrapCatchingExceptions(f, 'template helper');
  }

  if (!_.isFunction(f)) {
    return f;
  }

  return function () {
    var args, self;
    self = this;
    args = arguments;
    return Blaze.Template._withTemplateInstanceFunc(templateFunc, function () {
      return Blaze._wrapCatchingExceptions(f, 'template helper').apply(self, args);
    });
  };
};

if (Blaze.Template._withTemplateInstanceFunc) {
  withTemplateInstanceFunc = Blaze.Template._withTemplateInstanceFunc;
} else {
  withTemplateInstanceFunc = function (templateInstance, f) {
    return f();
  };
}

getTemplateBase = function (component) {
  return Tracker.nonreactive(function () {
    var componentTemplate, templateBase;
    componentTemplate = component.template();

    if (_.isString(componentTemplate)) {
      templateBase = Template[componentTemplate];

      if (!templateBase) {
        throw new Error("Template '" + componentTemplate + "' cannot be found.");
      }
    } else if (componentTemplate) {
      templateBase = componentTemplate;
    } else {
      throw new Error("Template for the component '" + (component.componentName() || 'unnamed') + "' not provided.");
    }

    return templateBase;
  });
};

callTemplateBaseHooks = function (component, hookName) {
  var callbacks, templateInstance;

  if (component !== component.component()) {
    return;
  }

  templateInstance = Tracker.nonreactive(function () {
    return component._componentInternals.templateInstance();
  });
  callbacks = component._componentInternals.templateBase._getCallbacks(hookName);

  Template._withTemplateInstanceFunc(function () {
    return templateInstance;
  }, function () {
    var callback, i, len, results;
    results = [];

    for (i = 0, len = callbacks.length; i < len; i++) {
      callback = callbacks[i];
      results.push(callback.call(templateInstance));
    }

    return results;
  });
};

wrapViewAndTemplate = function (currentView, f) {
  var templateInstance;
  templateInstance = getTemplateInstanceFunction(currentView, true);
  return withTemplateInstanceFunc(templateInstance, function () {
    return Blaze._withCurrentView(currentView, function () {
      return f();
    });
  });
};

addEvents = function (view, component) {
  var eventMap, events, eventsList, fn, handler, i, len, spec;
  eventsList = component.events();

  if (!_.isArray(eventsList)) {
    throw new Error("'events' method from the component '" + (component.componentName() || 'unnamed') + "' did not return a list of event maps.");
  }

  for (i = 0, len = eventsList.length; i < len; i++) {
    events = eventsList[i];
    eventMap = {};

    fn = function (spec, handler) {
      return eventMap[spec] = function () {
        var args, currentView, event;
        args = 1 <= arguments.length ? slice.call(arguments, 0) : [];
        event = args[0];
        currentView = Blaze.getView(event.currentTarget);
        wrapViewAndTemplate(currentView, function () {
          return handler.apply(component, args);
        });
      };
    };

    for (spec in meteorBabelHelpers.sanitizeForInObject(events)) {
      handler = events[spec];
      fn(spec, handler);
    }

    Blaze._addEventMap(view, eventMap, view);
  }
};

originalGetTemplate = Blaze._getTemplate;

Blaze._getTemplate = function (name, templateInstance) {
  var template;
  template = Tracker.nonreactive(function () {
    var parentComponent, ref;

    if (Blaze.currentView) {
      parentComponent = BlazeComponent.currentComponent();
    } else {
      parentComponent = templateInstanceToComponent(templateInstance, false);
    }

    return (ref = BlazeComponent.getComponent(name)) != null ? ref.renderComponent(parentComponent) : void 0;
  });

  if (template && (template instanceof Blaze.Template || _.isFunction(template))) {
    return template;
  }

  return originalGetTemplate(name);
};

registerHooks = function (template, hooks) {
  if (template.onCreated) {
    template.onCreated(hooks.onCreated);
    template.onRendered(hooks.onRendered);
    return template.onDestroyed(hooks.onDestroyed);
  } else {
    template.created = hooks.onCreated;
    template.rendered = hooks.onRendered;
    return template.destroyed = hooks.onDestroyed;
  }
};

registerFirstCreatedHook = function (template, onCreated) {
  var oldCreated;

  if (template._callbacks) {
    return template._callbacks.created.unshift(onCreated);
  } else {
    oldCreated = template.created;
    return template.created = function () {
      onCreated.call(this);
      return oldCreated != null ? oldCreated.call(this) : void 0;
    };
  }
};

Template.__dynamicWithDataContext.__helpers.set('chooseTemplate', function (name) {
  return Blaze._getTemplate(name, function (_this) {
    return function () {
      return Template.instance();
    };
  }(this));
});

argumentsConstructor = function () {
  return assert(false);
};

Template.registerHelper('args', function () {
  var obj;
  obj = {};
  obj.constructor = argumentsConstructor;
  obj._arguments = arguments;
  return obj;
});
share.EVENT_HANDLER_REGEX = /^on[A-Z]/;

share.isEventHandler = function (fun) {
  return _.isFunction(fun) && fun.eventHandler;
};

originalFlattenAttributes = HTML.flattenAttributes;

HTML.flattenAttributes = function (attrs) {
  var name, value;

  if (attrs = originalFlattenAttributes(attrs)) {
    for (name in meteorBabelHelpers.sanitizeForInObject(attrs)) {
      value = attrs[name];

      if (!share.EVENT_HANDLER_REGEX.test(name)) {
        continue;
      }

      if (share.isEventHandler(value)) {
        continue;
      }

      if (_.isArray(value) && _.some(value, share.isEventHandler)) {
        continue;
      }

      if (_.isArray(value)) {
        attrs[name] = _.map(value, Spacebars.event);
      } else {
        attrs[name] = Spacebars.event(value);
      }
    }
  }

  return attrs;
};

Spacebars.event = function () {
  var args, eventHandler, fun;
  eventHandler = arguments[0], args = 2 <= arguments.length ? slice.call(arguments, 1) : [];

  if (!_.isFunction(eventHandler)) {
    throw new Error("Event handler not a function: " + eventHandler);
  }

  args = Spacebars.mustacheImpl.apply(Spacebars, [function () {
    var xs;
    xs = 1 <= arguments.length ? slice.call(arguments, 0) : [];
    return xs;
  }].concat(slice.call(args)));

  fun = function () {
    var currentView, event, eventArgs;
    event = arguments[0], eventArgs = 2 <= arguments.length ? slice.call(arguments, 1) : [];
    currentView = Blaze.getView(event.currentTarget);
    return wrapViewAndTemplate(currentView, function () {
      return eventHandler.apply(null, [event].concat(args, eventArgs));
    });
  };

  fun.eventHandler = true;
  return fun;
};

originalVisitTag = HTML.ToHTMLVisitor.prototype.visitTag;

HTML.ToHTMLVisitor.prototype.visitTag = function (tag) {
  var attrs, name;

  if (attrs = tag.attrs) {
    attrs = HTML.flattenAttributes(attrs);

    for (name in meteorBabelHelpers.sanitizeForInObject(attrs)) {
      if (share.EVENT_HANDLER_REGEX.test(name)) {
        delete attrs[name];
      }
    }

    tag.attrs = attrs;
  }

  return originalVisitTag.call(this, tag);
};

currentViewIfRendering = function () {
  var view;
  view = Blaze.currentView;

  if (view != null ? view._isInRender : void 0) {
    return view;
  } else {
    return null;
  }
};

contentAsFunc = function (content) {
  if (!_.isFunction(content)) {
    return function () {
      return content;
    };
  }

  return content;
};

contentAsView = function (content) {
  if (content instanceof Blaze.Template) {
    return content.constructView();
  } else if (content instanceof Blaze.View) {
    return content;
  } else {
    return Blaze.View('render', contentAsFunc(content));
  }
};

HTMLJSExpander = Blaze._HTMLJSExpander.extend();
HTMLJSExpander.def({
  visitObject: function (x) {
    if (x instanceof Blaze.Template) {
      x = x.constructView();
    }

    if (x instanceof Blaze.View) {
      return expandView(x, this.parentView);
    }

    return HTML.TransformingVisitor.prototype.visitObject.call(this, x);
  }
});

expand = function (htmljs, parentView) {
  parentView = parentView || currentViewIfRendering();
  return new HTMLJSExpander({
    parentView: parentView
  }).visit(htmljs);
};

expandView = function (view, parentView) {
  var htmljs, result;

  Blaze._createView(view, parentView, true);

  view._isInRender = true;
  htmljs = Blaze._withCurrentView(view, function () {
    return view._render();
  });
  view._isInRender = false;
  Tracker.flush();
  result = expand(htmljs, view);
  Tracker.flush();

  if (Tracker.active) {
    Tracker.onInvalidate(function () {
      return Blaze._destroyView(view);
    });
  } else {
    Blaze._destroyView(view);
  }

  Tracker.flush();
  return result;
};

BlazeComponent = function (superClass) {
  extend(BlazeComponent, superClass);

  function BlazeComponent() {
    return BlazeComponent.__super__.constructor.apply(this, arguments);
  }

  BlazeComponent.getComponentForElement = function (domElement) {
    var templateInstance;

    if (!domElement) {
      return null;
    }

    if (domElement.nodeType !== Node.ELEMENT_NODE) {
      throw new Error("Expected DOM element.");
    }

    templateInstance = getTemplateInstanceFunction(Blaze.getView(domElement), true);
    return templateInstanceToComponent(templateInstance, true);
  };

  BlazeComponent.prototype.childComponents = function (nameOrComponent) {
    var component;

    if ((component = this.component()) !== this) {
      return component.childComponents(nameOrComponent);
    } else {
      return BlazeComponent.__super__.childComponents.apply(this, arguments);
    }
  };

  BlazeComponent.prototype.childComponentsWith = function (propertyOrMatcherOrFunction) {
    var component;

    if ((component = this.component()) !== this) {
      return component.childComponentsWith(propertyOrMatcherOrFunction);
    } else {
      assert(propertyOrMatcherOrFunction);
      propertyOrMatcherOrFunction = createMatcher(propertyOrMatcherOrFunction, true);
      return BlazeComponent.__super__.childComponentsWith.call(this, propertyOrMatcherOrFunction);
    }
  };

  BlazeComponent.prototype.parentComponent = function (parentComponent) {
    var component;

    if ((component = this.component()) !== this) {
      return component.parentComponent(parentComponent);
    } else {
      return BlazeComponent.__super__.parentComponent.apply(this, arguments);
    }
  };

  BlazeComponent.prototype.addChildComponent = function (childComponent) {
    var component;

    if ((component = this.component()) !== this) {
      return component.addChildComponent(childComponent);
    } else {
      return BlazeComponent.__super__.addChildComponent.apply(this, arguments);
    }
  };

  BlazeComponent.prototype.removeChildComponent = function (childComponent) {
    var component;

    if ((component = this.component()) !== this) {
      return component.removeChildComponent(childComponent);
    } else {
      return BlazeComponent.__super__.removeChildComponent.apply(this, arguments);
    }
  };

  BlazeComponent.prototype.mixins = function () {
    return [];
  };

  BlazeComponent.prototype.mixinParent = function (mixinParent) {
    if (this._componentInternals == null) {
      this._componentInternals = {};
    }

    if (mixinParent) {
      this._componentInternals.mixinParent = mixinParent;
      return this;
    }

    return this._componentInternals.mixinParent || null;
  };

  BlazeComponent.prototype.requireMixin = function (nameOrMixin) {
    var ref;
    assert((ref = this._componentInternals) != null ? ref.mixins : void 0);
    Tracker.nonreactive(function (_this) {
      return function () {
        var base, component, mixinInstance, mixinInstanceComponent, ref1, ref2, ref3;

        if (_this.getMixin(nameOrMixin)) {
          return;
        }

        if (_.isString(nameOrMixin)) {
          if (_this.constructor.getComponent) {
            mixinInstanceComponent = _this.constructor.getComponent(nameOrMixin);
          } else {
            mixinInstanceComponent = BlazeComponent.getComponent(nameOrMixin);
          }

          if (!mixinInstanceComponent) {
            throw new Error("Unknown mixin '" + nameOrMixin + "'.");
          }

          mixinInstance = new mixinInstanceComponent();
        } else if (_.isFunction(nameOrMixin)) {
          mixinInstance = new nameOrMixin();
        } else {
          mixinInstance = nameOrMixin;
        }

        _this._componentInternals.mixins.push(mixinInstance);

        if (mixinInstance.mixinParent) {
          mixinInstance.mixinParent(_this);
        }

        if (typeof mixinInstance.createMixins === "function") {
          mixinInstance.createMixins();
        }

        if (component = _this.component()) {
          if (component._componentInternals == null) {
            component._componentInternals = {};
          }

          if ((base = component._componentInternals).templateInstance == null) {
            base.templateInstance = new ReactiveField(null, function (a, b) {
              return a === b;
            });
          }

          if (!((ref1 = component._componentInternals.templateInstance()) != null ? ref1.view.isDestroyed : void 0)) {
            if (!component._componentInternals.inOnCreated && ((ref2 = component._componentInternals.templateInstance()) != null ? ref2.view.isCreated : void 0)) {
              if (typeof mixinInstance.onCreated === "function") {
                mixinInstance.onCreated();
              }
            }

            if (!component._componentInternals.inOnRendered && ((ref3 = component._componentInternals.templateInstance()) != null ? ref3.view.isRendered : void 0)) {
              return typeof mixinInstance.onRendered === "function" ? mixinInstance.onRendered() : void 0;
            }
          }
        }
      };
    }(this));
    return this;
  };

  BlazeComponent.prototype.createMixins = function () {
    var i, len, mixin, ref;

    if (this._componentInternals == null) {
      this._componentInternals = {};
    }

    if (this._componentInternals.mixins) {
      return;
    }

    this._componentInternals.mixins = [];
    ref = this.mixins();

    for (i = 0, len = ref.length; i < len; i++) {
      mixin = ref[i];
      this.requireMixin(mixin);
    }

    return this;
  };

  BlazeComponent.prototype.getMixin = function (nameOrMixin) {
    if (_.isString(nameOrMixin)) {
      return this.getFirstWith(this, function (_this) {
        return function (child, parent) {
          var mixinComponentName;
          mixinComponentName = (typeof child.componentName === "function" ? child.componentName() : void 0) || null;
          return mixinComponentName && mixinComponentName === nameOrMixin;
        };
      }(this));
    } else {
      return this.getFirstWith(this, function (_this) {
        return function (child, parent) {
          if (child.constructor === nameOrMixin) {
            return true;
          }

          if (child === nameOrMixin) {
            return true;
          }

          return false;
        };
      }(this));
    }
  };

  BlazeComponent.prototype.callFirstWith = function () {
    var afterComponentOrMixin, args, componentOrMixin, propertyName;
    afterComponentOrMixin = arguments[0], propertyName = arguments[1], args = 3 <= arguments.length ? slice.call(arguments, 2) : [];
    assert(_.isString(propertyName));
    componentOrMixin = this.getFirstWith(afterComponentOrMixin, propertyName);

    if (!componentOrMixin) {
      return;
    }

    if (_.isFunction(componentOrMixin[propertyName])) {
      return componentOrMixin[propertyName].apply(componentOrMixin, args);
    } else {
      return componentOrMixin[propertyName];
    }
  };

  BlazeComponent.prototype.getFirstWith = function (afterComponentOrMixin, propertyOrMatcherOrFunction) {
    var found, i, len, mixin, ref, ref1;
    assert((ref = this._componentInternals) != null ? ref.mixins : void 0);
    assert(propertyOrMatcherOrFunction);
    propertyOrMatcherOrFunction = createMatcher(propertyOrMatcherOrFunction, false);

    if (!afterComponentOrMixin) {
      if (propertyOrMatcherOrFunction.call(this, this, this)) {
        return this;
      }

      found = true;
    } else if (afterComponentOrMixin && afterComponentOrMixin === this) {
      found = true;
    } else {
      found = false;
    }

    ref1 = this._componentInternals.mixins;

    for (i = 0, len = ref1.length; i < len; i++) {
      mixin = ref1[i];

      if (found && propertyOrMatcherOrFunction.call(this, mixin, this)) {
        return mixin;
      }

      if (mixin === afterComponentOrMixin) {
        found = true;
      }
    }

    return null;
  };

  BlazeComponent.renderComponent = function (parentComponent) {
    return Tracker.nonreactive(function (_this) {
      return function () {
        var componentClass, data;
        componentClass = _this;

        if (Blaze.currentView) {
          data = Template.currentData();
        } else {
          data = null;
        }

        if ((data != null ? data.constructor : void 0) !== argumentsConstructor) {
          return wrapViewAndTemplate(Blaze.currentView, function () {
            var component;
            component = new componentClass();
            return component.renderComponent(parentComponent);
          });
        }

        return function () {
          var currentWith, nonreactiveArguments, reactiveArguments;
          assert(Tracker.active);
          currentWith = Blaze.getView('with');
          reactiveArguments = new ComputedField(function () {
            data = currentWith.dataVar.get();
            assert.equal(data != null ? data.constructor : void 0, argumentsConstructor);
            return data._arguments;
          }, EJSON.equals);
          nonreactiveArguments = reactiveArguments();
          return Tracker.nonreactive(function () {
            var template;
            template = Blaze._withCurrentView(Blaze.currentView.parentView.parentView, function (_this) {
              return function () {
                return wrapViewAndTemplate(Blaze.currentView, function () {
                  var component;

                  component = function (func, args, ctor) {
                    ctor.prototype = func.prototype;
                    var child = new ctor(),
                        result = func.apply(child, args);
                    return Object(result) === result ? result : child;
                  }(componentClass, nonreactiveArguments, function () {});

                  return component.renderComponent(parentComponent);
                });
              };
            }(this));
            registerFirstCreatedHook(template, function () {
              this.view.originalParentView = this.view.parentView;
              return this.view.parentView = this.view.parentView.parentView.parentView;
            });
            return template;
          });
        };
      };
    }(this));
  };

  BlazeComponent.prototype.renderComponent = function (parentComponent) {
    return Tracker.nonreactive(function (_this) {
      return function () {
        var component, template, templateBase;
        component = _this.component();
        component.createMixins();
        templateBase = getTemplateBase(component);
        template = new Blaze.Template("BlazeComponent." + (component.componentName() || 'unnamed'), templateBase.renderFunction);

        if (component._componentInternals == null) {
          component._componentInternals = {};
        }

        component._componentInternals.templateBase = templateBase;
        registerHooks(template, {
          onCreated: function () {
            var base, base1, base2, base3, componentOrMixin, results;

            if (parentComponent) {
              Tracker.nonreactive(function (_this) {
                return function () {
                  var ref;
                  assert(!component.parentComponent(), "Component '" + (component.componentName() || 'unnamed') + "' parent component '" + (((ref = component.parentComponent()) != null ? ref.componentName() : void 0) || 'unnamed') + "' already set.");
                  component.parentComponent(parentComponent);
                  return parentComponent.addChildComponent(component);
                };
              }(this));
            }

            this.view._onViewRendered(function (_this) {
              return function () {
                var componentOrMixin, results;

                if (_this.view.renderCount !== 1) {
                  return;
                }

                componentOrMixin = null;
                results = [];

                while (componentOrMixin = _this.component.getFirstWith(componentOrMixin, 'events')) {
                  results.push(addEvents(_this.view, componentOrMixin));
                }

                return results;
              };
            }(this));

            this.component = component;
            assert(!Tracker.nonreactive(function (_this) {
              return function () {
                var base;
                return typeof (base = _this.component._componentInternals).templateInstance === "function" ? base.templateInstance() : void 0;
              };
            }(this)));

            if ((base = this.component._componentInternals).templateInstance == null) {
              base.templateInstance = new ReactiveField(this, function (a, b) {
                return a === b;
              });
            }

            this.component._componentInternals.templateInstance(this);

            if ((base1 = this.component._componentInternals).isCreated == null) {
              base1.isCreated = new ReactiveField(true);
            }

            this.component._componentInternals.isCreated(true);

            if ((base2 = this.component._componentInternals).isRendered == null) {
              base2.isRendered = new ReactiveField(false);
            }

            this.component._componentInternals.isRendered(false);

            if ((base3 = this.component._componentInternals).isDestroyed == null) {
              base3.isDestroyed = new ReactiveField(false);
            }

            this.component._componentInternals.isDestroyed(false);

            try {
              this.component._componentInternals.inOnCreated = true;
              componentOrMixin = null;
              results = [];

              while (componentOrMixin = this.component.getFirstWith(componentOrMixin, 'onCreated')) {
                results.push(componentOrMixin.onCreated());
              }

              return results;
            } finally {
              delete this.component._componentInternals.inOnCreated;
            }
          },
          onRendered: function () {
            var base, componentOrMixin, results;

            if ((base = this.component._componentInternals).isRendered == null) {
              base.isRendered = new ReactiveField(true);
            }

            this.component._componentInternals.isRendered(true);

            Tracker.nonreactive(function (_this) {
              return function () {
                return assert.equal(_this.component._componentInternals.isCreated(), true);
              };
            }(this));

            try {
              this.component._componentInternals.inOnRendered = true;
              componentOrMixin = null;
              results = [];

              while (componentOrMixin = this.component.getFirstWith(componentOrMixin, 'onRendered')) {
                results.push(componentOrMixin.onRendered());
              }

              return results;
            } finally {
              delete this.component._componentInternals.inOnRendered;
            }
          },
          onDestroyed: function () {
            return this.autorun(function (_this) {
              return function (computation) {
                if (_this.component.childComponents().length) {
                  return;
                }

                computation.stop();
                return Tracker.nonreactive(function () {
                  var base, base1, componentOrMixin;
                  assert.equal(_this.component._componentInternals.isCreated(), true);

                  _this.component._componentInternals.isCreated(false);

                  if ((base = _this.component._componentInternals).isRendered == null) {
                    base.isRendered = new ReactiveField(false);
                  }

                  _this.component._componentInternals.isRendered(false);

                  if ((base1 = _this.component._componentInternals).isDestroyed == null) {
                    base1.isDestroyed = new ReactiveField(true);
                  }

                  _this.component._componentInternals.isDestroyed(true);

                  componentOrMixin = null;

                  while (componentOrMixin = _this.component.getFirstWith(componentOrMixin, 'onDestroyed')) {
                    componentOrMixin.onDestroyed();
                  }

                  if (parentComponent) {
                    component.parentComponent(null);
                    parentComponent.removeChildComponent(component);
                  }

                  return _this.component._componentInternals.templateInstance(null);
                });
              };
            }(this));
          }
        });
        return template;
      };
    }(this));
  };

  BlazeComponent.prototype.removeComponent = function () {
    if (this.isRendered()) {
      return Blaze.remove(this.component()._componentInternals.templateInstance().view);
    }
  };

  BlazeComponent._renderComponentTo = function (visitor, parentComponent, parentView, data) {
    var component;
    component = Tracker.nonreactive(function (_this) {
      return function () {
        var componentClass;
        componentClass = _this;
        parentView = parentView || currentViewIfRendering() || (parentComponent != null ? parentComponent.isRendered() : void 0) && parentComponent._componentInternals.templateInstance().view || null;
        return wrapViewAndTemplate(parentView, function () {
          return new componentClass();
        });
      };
    }(this));

    if (arguments.length > 2) {
      return component._renderComponentTo(visitor, parentComponent, parentView, data);
    } else {
      return component._renderComponentTo(visitor, parentComponent, parentView);
    }
  };

  BlazeComponent.renderComponentToHTML = function (parentComponent, parentView, data) {
    if (arguments.length > 2) {
      return this._renderComponentTo(new HTML.ToHTMLVisitor(), parentComponent, parentView, data);
    } else {
      return this._renderComponentTo(new HTML.ToHTMLVisitor(), parentComponent, parentView);
    }
  };

  BlazeComponent.prototype._renderComponentTo = function (visitor, parentComponent, parentView, data) {
    var expandedView, template;
    template = Tracker.nonreactive(function (_this) {
      return function () {
        parentView = parentView || currentViewIfRendering() || (parentComponent != null ? parentComponent.isRendered() : void 0) && parentComponent._componentInternals.templateInstance().view || null;
        return wrapViewAndTemplate(parentView, function () {
          return _this.component().renderComponent(parentComponent);
        });
      };
    }(this));

    if (arguments.length > 2) {
      expandedView = expandView(Blaze._TemplateWith(data, contentAsFunc(template)), parentView);
    } else {
      expandedView = expandView(contentAsView(template), parentView);
    }

    return visitor.visit(expandedView);
  };

  BlazeComponent.prototype.renderComponentToHTML = function (parentComponent, parentView, data) {
    if (arguments.length > 2) {
      return this._renderComponentTo(new HTML.ToHTMLVisitor(), parentComponent, parentView, data);
    } else {
      return this._renderComponentTo(new HTML.ToHTMLVisitor(), parentComponent, parentView);
    }
  };

  BlazeComponent.prototype.template = function () {
    return this.callFirstWith(this, 'template') || this.constructor.componentName();
  };

  BlazeComponent.prototype.onCreated = function () {
    return callTemplateBaseHooks(this, 'created');
  };

  BlazeComponent.prototype.onRendered = function () {
    return callTemplateBaseHooks(this, 'rendered');
  };

  BlazeComponent.prototype.onDestroyed = function () {
    return callTemplateBaseHooks(this, 'destroyed');
  };

  BlazeComponent.prototype.isCreated = function () {
    var base, component;
    component = this.component();

    if (component._componentInternals == null) {
      component._componentInternals = {};
    }

    if ((base = component._componentInternals).isCreated == null) {
      base.isCreated = new ReactiveField(false);
    }

    return component._componentInternals.isCreated();
  };

  BlazeComponent.prototype.isRendered = function () {
    var base, component;
    component = this.component();

    if (component._componentInternals == null) {
      component._componentInternals = {};
    }

    if ((base = component._componentInternals).isRendered == null) {
      base.isRendered = new ReactiveField(false);
    }

    return component._componentInternals.isRendered();
  };

  BlazeComponent.prototype.isDestroyed = function () {
    var base, component;
    component = this.component();

    if (component._componentInternals == null) {
      component._componentInternals = {};
    }

    if ((base = component._componentInternals).isDestroyed == null) {
      base.isDestroyed = new ReactiveField(false);
    }

    return component._componentInternals.isDestroyed();
  };

  BlazeComponent.prototype.insertDOMElement = function (parent, node, before) {
    if (before == null) {
      before = null;
    }

    if (parent && node && (node.parentNode !== parent || node.nextSibling !== before)) {
      parent.insertBefore(node, before);
    }
  };

  BlazeComponent.prototype.moveDOMElement = function (parent, node, before) {
    if (before == null) {
      before = null;
    }

    if (parent && node && (node.parentNode !== parent || node.nextSibling !== before)) {
      parent.insertBefore(node, before);
    }
  };

  BlazeComponent.prototype.removeDOMElement = function (parent, node) {
    if (parent && node && node.parentNode === parent) {
      parent.removeChild(node);
    }
  };

  BlazeComponent.prototype.events = function () {
    var eventMap, events, fn, handler, i, len, ref, results, spec, templateInstance, view;

    if (this !== this.component()) {
      return [];
    }

    if (this._componentInternals == null) {
      this._componentInternals = {};
    }

    view = Tracker.nonreactive(function (_this) {
      return function () {
        return _this._componentInternals.templateInstance().view;
      };
    }(this));
    templateInstance = getTemplateInstanceFunction(view, true);
    ref = this._componentInternals.templateBase.__eventMaps;
    results = [];

    for (i = 0, len = ref.length; i < len; i++) {
      events = ref[i];
      eventMap = {};

      fn = function (spec, handler) {
        return eventMap[spec] = function () {
          var args;
          args = 1 <= arguments.length ? slice.call(arguments, 0) : [];
          return withTemplateInstanceFunc(templateInstance, function () {
            return Blaze._withCurrentView(view, function () {
              return handler.apply(view, args);
            });
          });
        };
      };

      for (spec in meteorBabelHelpers.sanitizeForInObject(events)) {
        handler = events[spec];
        fn(spec, handler);
      }

      results.push(eventMap);
    }

    return results;
  };

  BlazeComponent.prototype.data = function (path, equalsFunc) {
    var base, component, ref, view;
    component = this.component();

    if (component._componentInternals == null) {
      component._componentInternals = {};
    }

    if ((base = component._componentInternals).templateInstance == null) {
      base.templateInstance = new ReactiveField(null, function (a, b) {
        return a === b;
      });
    }

    if (view = (ref = component._componentInternals.templateInstance()) != null ? ref.view : void 0) {
      if (path != null) {
        return Blaze._withCurrentView(null, function (_this) {
          return function () {
            return DataLookup.get(function () {
              return Blaze.getData(view);
            }, path, equalsFunc);
          };
        }(this));
      } else {
        return Blaze.getData(view);
      }
    }

    return void 0;
  };

  BlazeComponent.currentData = function (path, equalsFunc) {
    var currentView;

    if (!Blaze.currentView) {
      return void 0;
    }

    currentView = Blaze.currentView;

    if (_.isString(path)) {
      path = path.split('.');
    } else if (!_.isArray(path)) {
      return Blaze.getData(currentView);
    }

    return Blaze._withCurrentView(null, function (_this) {
      return function () {
        return DataLookup.get(function () {
          var lexicalData, result;

          if (Blaze._lexicalBindingLookup && (lexicalData = Blaze._lexicalBindingLookup(currentView, path[0]))) {
            result = {};
            result[path[0]] = lexicalData;
            return result;
          }

          return Blaze.getData(currentView);
        }, path, equalsFunc);
      };
    }(this));
  };

  BlazeComponent.prototype.currentData = function (path, equalsFunc) {
    return this.constructor.currentData(path, equalsFunc);
  };

  BlazeComponent.prototype.component = function () {
    var component, mixinParent;
    component = this;

    while (true) {
      if (!component.mixinParent) {
        return null;
      }

      if (!(mixinParent = component.mixinParent())) {
        return component;
      }

      component = mixinParent;
    }
  };

  BlazeComponent.currentComponent = function () {
    var templateInstance;
    templateInstance = getTemplateInstanceFunction(Blaze.currentView, false);
    return templateInstanceToComponent(templateInstance, false);
  };

  BlazeComponent.prototype.currentComponent = function () {
    return this.constructor.currentComponent();
  };

  BlazeComponent.prototype.firstNode = function () {
    if (this.isRendered()) {
      return this.component()._componentInternals.templateInstance().view._domrange.firstNode();
    }

    return void 0;
  };

  BlazeComponent.prototype.lastNode = function () {
    if (this.isRendered()) {
      return this.component()._componentInternals.templateInstance().view._domrange.lastNode();
    }

    return void 0;
  };

  BlazeComponent.prototype.autorun = function (runFunc) {
    var templateInstance;
    templateInstance = Tracker.nonreactive(function (_this) {
      return function () {
        var ref;
        return (ref = _this.component()._componentInternals) != null ? typeof ref.templateInstance === "function" ? ref.templateInstance() : void 0 : void 0;
      };
    }(this));

    if (!templateInstance) {
      throw new Error("The component has to be created before calling 'autorun'.");
    }

    return templateInstance.autorun(_.bind(runFunc, this));
  };

  return BlazeComponent;
}(BaseComponent);

SUPPORTS_REACTIVE_INSTANCE = ['subscriptionsReady'];
REQUIRE_RENDERED_INSTANCE = ['$', 'find', 'findAll'];
ref = Blaze.TemplateInstance.prototype;

for (methodName in meteorBabelHelpers.sanitizeForInObject(ref)) {
  method = ref[methodName];

  if (!(methodName in BlazeComponent.prototype)) {
    (function (methodName, method) {
      if (indexOf.call(SUPPORTS_REACTIVE_INSTANCE, methodName) >= 0) {
        return BlazeComponent.prototype[methodName] = function () {
          var args, base, component, templateInstance;
          args = 1 <= arguments.length ? slice.call(arguments, 0) : [];
          component = this.component();

          if (component._componentInternals == null) {
            component._componentInternals = {};
          }

          if ((base = component._componentInternals).templateInstance == null) {
            base.templateInstance = new ReactiveField(null, function (a, b) {
              return a === b;
            });
          }

          if (templateInstance = component._componentInternals.templateInstance()) {
            return templateInstance[methodName].apply(templateInstance, args);
          }

          return void 0;
        };
      } else if (indexOf.call(REQUIRE_RENDERED_INSTANCE, methodName) >= 0) {
        return BlazeComponent.prototype[methodName] = function () {
          var args, ref1;
          args = 1 <= arguments.length ? slice.call(arguments, 0) : [];

          if (this.isRendered()) {
            return (ref1 = this.component()._componentInternals.templateInstance())[methodName].apply(ref1, args);
          }

          return void 0;
        };
      } else {
        return BlazeComponent.prototype[methodName] = function () {
          var args, templateInstance;
          args = 1 <= arguments.length ? slice.call(arguments, 0) : [];
          templateInstance = Tracker.nonreactive(function (_this) {
            return function () {
              var ref1;
              return (ref1 = _this.component()._componentInternals) != null ? typeof ref1.templateInstance === "function" ? ref1.templateInstance() : void 0 : void 0;
            };
          }(this));

          if (!templateInstance) {
            throw new Error("The component has to be created before calling '" + methodName + "'.");
          }

          return templateInstance[methodName].apply(templateInstance, args);
        };
      }
    })(methodName, method);
  }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/peerlibrary_blaze-components/debug.coffee                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var extend = function (child, parent) {
  for (var key in meteorBabelHelpers.sanitizeForInObject(parent)) {
    if (hasProp.call(parent, key)) child[key] = parent[key];
  }

  function ctor() {
    this.constructor = child;
  }

  ctor.prototype = parent.prototype;
  child.prototype = new ctor();
  child.__super__ = parent.prototype;
  return child;
},
    hasProp = {}.hasOwnProperty,
    indexOf = [].indexOf || function (item) {
  for (var i = 0, l = this.length; i < l; i++) {
    if (i in this && this[i] === item) return i;
  }

  return -1;
};

BlazeComponentDebug = function (superClass) {
  extend(BlazeComponentDebug, superClass);

  function BlazeComponentDebug() {
    return BlazeComponentDebug.__super__.constructor.apply(this, arguments);
  }

  BlazeComponentDebug.startComponent = function (component) {
    BlazeComponentDebug.__super__.constructor.startComponent.apply(this, arguments);

    return console.log(component.data());
  };

  BlazeComponentDebug.startMarkedComponent = function (component) {
    BlazeComponentDebug.__super__.constructor.startMarkedComponent.apply(this, arguments);

    return console.log(component.data());
  };

  BlazeComponentDebug.dumpComponentSubtree = function (rootComponentOrElement) {
    if ('nodeType' in rootComponentOrElement && rootComponentOrElement.nodeType === Node.ELEMENT_NODE) {
      rootComponentOrElement = BlazeComponent.getComponentForElement(rootComponentOrElement);
    }

    return BlazeComponentDebug.__super__.constructor.dumpComponentSubtree.apply(this, arguments);
  };

  BlazeComponentDebug.dumpComponentTree = function (rootComponentOrElement) {
    if ('nodeType' in rootComponentOrElement && rootComponentOrElement.nodeType === Node.ELEMENT_NODE) {
      rootComponentOrElement = BlazeComponent.getComponentForElement(rootComponentOrElement);
    }

    return BlazeComponentDebug.__super__.constructor.dumpComponentTree.apply(this, arguments);
  };

  BlazeComponentDebug.dumpAllComponents = function () {
    var allRootComponents, j, len, rootComponent;
    allRootComponents = [];
    $('*').each(function (_this) {
      return function (i, element) {
        var component, rootComponent;
        component = BlazeComponent.getComponentForElement(element);

        if (!component) {
          return;
        }

        rootComponent = _this.componentRoot(component);

        if (indexOf.call(allRootComponents, rootComponent) < 0) {
          return allRootComponents.push(rootComponent);
        }
      };
    }(this));

    for (j = 0, len = allRootComponents.length; j < len; j++) {
      rootComponent = allRootComponents[j];
      this.dumpComponentSubtree(rootComponent);
    }
  };

  return BlazeComponentDebug;
}(BaseComponentDebug);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/peerlibrary_blaze-components/server.coffee                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Template.body.renderToDocument = function () {};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['peerlibrary:blaze-components'] = {}, {
  Template: Template,
  BlazeComponent: BlazeComponent,
  BlazeComponentDebug: BlazeComponentDebug
});

})();

//# sourceURL=meteor://💻app/packages/peerlibrary_blaze-components.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvcGVlcmxpYnJhcnlfYmxhemUtY29tcG9uZW50cy90ZW1wbGF0ZS5jb2ZmZWUiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL3BlZXJsaWJyYXJ5X2JsYXplLWNvbXBvbmVudHMvbGliLmNvZmZlZSIsIm1ldGVvcjovL/CfkrthcHAvbGliLmNvZmZlZSIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvcGVlcmxpYnJhcnlfYmxhemUtY29tcG9uZW50cy9kZWJ1Zy5jb2ZmZWUiLCJtZXRlb3I6Ly/wn5K7YXBwL2RlYnVnLmNvZmZlZSIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvcGVlcmxpYnJhcnlfYmxhemUtY29tcG9uZW50cy9zZXJ2ZXIuY29mZmVlIl0sIm5hbWVzIjpbIlRlbXBsYXRlIiwiQmxhemUiLCJDb21wb25lbnRzTmFtZXNwYWNlUmVmZXJlbmNlIiwiSFRNTEpTRXhwYW5kZXIiLCJSRVFVSVJFX1JFTkRFUkVEX0lOU1RBTkNFIiwiU1VQUE9SVFNfUkVBQ1RJVkVfSU5TVEFOQ0UiLCJhZGRFdmVudHMiLCJhcmd1bWVudHNDb25zdHJ1Y3RvciIsImJpbmRDb21wb25lbnQiLCJiaW5kRGF0YUNvbnRleHQiLCJjYWxsVGVtcGxhdGVCYXNlSG9va3MiLCJjb250ZW50QXNGdW5jIiwiY29udGVudEFzVmlldyIsImNyZWF0ZU1hdGNoZXIiLCJjdXJyZW50Vmlld0lmUmVuZGVyaW5nIiwiZXhwYW5kIiwiZXhwYW5kVmlldyIsImdldFRlbXBsYXRlQmFzZSIsImdldFRlbXBsYXRlSW5zdGFuY2UiLCJnZXRUZW1wbGF0ZUluc3RhbmNlRnVuY3Rpb24iLCJtZXRob2QiLCJtZXRob2ROYW1lIiwib3JpZ2luYWxEb3QiLCJvcmlnaW5hbEZsYXR0ZW5BdHRyaWJ1dGVzIiwib3JpZ2luYWxHZXRUZW1wbGF0ZSIsIm9yaWdpbmFsSW5jbHVkZSIsIm9yaWdpbmFsVmlzaXRUYWciLCJyZWYiLCJyZWdpc3RlckZpcnN0Q3JlYXRlZEhvb2siLCJyZWdpc3Rlckhvb2tzIiwidGVtcGxhdGVJbnN0YW5jZVRvQ29tcG9uZW50Iiwid2l0aFRlbXBsYXRlSW5zdGFuY2VGdW5jIiwid3JhcEhlbHBlciIsIndyYXBWaWV3QW5kVGVtcGxhdGUiLCJzbGljZSIsImV4dGVuZCIsImNoaWxkIiwicGFyZW50Iiwia2V5IiwiaGFzUHJvcCIsImNhbGwiLCJjdG9yIiwiY29uc3RydWN0b3IiLCJwcm90b3R5cGUiLCJfX3N1cGVyX18iLCJoYXNPd25Qcm9wZXJ0eSIsImluZGV4T2YiLCJpdGVtIiwiaSIsImwiLCJsZW5ndGgiLCJwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb24iLCJjaGVja01peGlucyIsIm1hdGNoZXIiLCJwcm9wZXJ0eSIsIl8iLCJpc1N0cmluZyIsIl90aGlzIiwiZ2V0Rmlyc3RXaXRoIiwiaXNGdW5jdGlvbiIsImFzc2VydCIsImlzT2JqZWN0IiwiY2hpbGRXaXRoUHJvcGVydHkiLCJ2YWx1ZSIsInZpZXciLCJza2lwQmxvY2tIZWxwZXJzIiwiX3RlbXBsYXRlSW5zdGFuY2UiLCJwYXJlbnRWaWV3Iiwib3JpZ2luYWxQYXJlbnRWaWV3IiwidGVtcGxhdGVJbnN0YW5jZUZ1bmMiLCJ0ZW1wbGF0ZUluc3RhbmNlIiwiY29tcG9uZW50IiwibmFtZXNwYWNlIiwidGVtcGxhdGVJbnN0YW5jZTEiLCJTcGFjZWJhcnMiLCJkb3QiLCJhcmdzIiwiYXJndW1lbnRzIiwiX2dldFRlbXBsYXRlIiwiam9pbiIsImFwcGx5IiwiY29uY2F0IiwiaW5jbHVkZSIsInRlbXBsYXRlT3JGdW5jdGlvbiIsIl9nZXRUZW1wbGF0ZUhlbHBlciIsInRlbXBsYXRlIiwibmFtZSIsImhlbHBlciIsImlzS25vd25PbGRTdHlsZUhlbHBlciIsIm1peGluT3JDb21wb25lbnQiLCJyZWYxIiwicmVmMiIsIl9faGVscGVycyIsImhhcyIsImdldCIsIl9PTERTVFlMRV9IRUxQRVIiLCJzZXQiLCJfTk9XQVJOX09MRFNUWUxFX0hFTFBFUlMiLCJfd2FybiIsInZpZXdOYW1lIiwiVHJhY2tlciIsIm5vbnJlYWN0aXZlIiwiQmxhemVDb21wb25lbnQiLCJjb21wb25lbnRzIiwiX2NvbXBvbmVudEludGVybmFscyIsInRlbXBsYXRlQmFzZSIsInNoYXJlIiwiaW5FeHBhbmRBdHRyaWJ1dGVzIiwicmVzdWx0IiwiRVZFTlRfSEFORExFUl9SRUdFWCIsInRlc3QiLCJiaW5kIiwiaXNBcnJheSIsIm1hcCIsImZ1biIsImRhdGEiLCJnZXREYXRhIiwiZiIsInRlbXBsYXRlRnVuYyIsIl93aXRoVGVtcGxhdGVJbnN0YW5jZUZ1bmMiLCJfd3JhcENhdGNoaW5nRXhjZXB0aW9ucyIsInNlbGYiLCJjb21wb25lbnRUZW1wbGF0ZSIsIkVycm9yIiwiY29tcG9uZW50TmFtZSIsImhvb2tOYW1lIiwiY2FsbGJhY2tzIiwiX2dldENhbGxiYWNrcyIsImNhbGxiYWNrIiwibGVuIiwicmVzdWx0cyIsInB1c2giLCJjdXJyZW50VmlldyIsIl93aXRoQ3VycmVudFZpZXciLCJldmVudE1hcCIsImV2ZW50cyIsImV2ZW50c0xpc3QiLCJmbiIsImhhbmRsZXIiLCJzcGVjIiwiZXZlbnQiLCJnZXRWaWV3IiwiY3VycmVudFRhcmdldCIsIl9hZGRFdmVudE1hcCIsInBhcmVudENvbXBvbmVudCIsImN1cnJlbnRDb21wb25lbnQiLCJnZXRDb21wb25lbnQiLCJyZW5kZXJDb21wb25lbnQiLCJob29rcyIsIm9uQ3JlYXRlZCIsIm9uUmVuZGVyZWQiLCJvbkRlc3Ryb3llZCIsImNyZWF0ZWQiLCJyZW5kZXJlZCIsImRlc3Ryb3llZCIsIm9sZENyZWF0ZWQiLCJfY2FsbGJhY2tzIiwidW5zaGlmdCIsIl9fZHluYW1pY1dpdGhEYXRhQ29udGV4dCIsImluc3RhbmNlIiwicmVnaXN0ZXJIZWxwZXIiLCJvYmoiLCJfYXJndW1lbnRzIiwiaXNFdmVudEhhbmRsZXIiLCJldmVudEhhbmRsZXIiLCJIVE1MIiwiZmxhdHRlbkF0dHJpYnV0ZXMiLCJhdHRycyIsInNvbWUiLCJtdXN0YWNoZUltcGwiLCJ4cyIsImV2ZW50QXJncyIsIlRvSFRNTFZpc2l0b3IiLCJ2aXNpdFRhZyIsInRhZyIsIl9pc0luUmVuZGVyIiwiY29udGVudCIsImNvbnN0cnVjdFZpZXciLCJWaWV3IiwiX0hUTUxKU0V4cGFuZGVyIiwiZGVmIiwidmlzaXRPYmplY3QiLCJ4IiwiVHJhbnNmb3JtaW5nVmlzaXRvciIsImh0bWxqcyIsInZpc2l0IiwiX2NyZWF0ZVZpZXciLCJfcmVuZGVyIiwiZmx1c2giLCJhY3RpdmUiLCJvbkludmFsaWRhdGUiLCJfZGVzdHJveVZpZXciLCJzdXBlckNsYXNzIiwiZ2V0Q29tcG9uZW50Rm9yRWxlbWVudCIsImRvbUVsZW1lbnQiLCJub2RlVHlwZSIsIk5vZGUiLCJFTEVNRU5UX05PREUiLCJjaGlsZENvbXBvbmVudHMiLCJuYW1lT3JDb21wb25lbnQiLCJjaGlsZENvbXBvbmVudHNXaXRoIiwiYWRkQ2hpbGRDb21wb25lbnQiLCJjaGlsZENvbXBvbmVudCIsInJlbW92ZUNoaWxkQ29tcG9uZW50IiwibWl4aW5zIiwibWl4aW5QYXJlbnQiLCJyZXF1aXJlTWl4aW4iLCJuYW1lT3JNaXhpbiIsImJhc2UiLCJtaXhpbkluc3RhbmNlIiwibWl4aW5JbnN0YW5jZUNvbXBvbmVudCIsInJlZjMiLCJnZXRNaXhpbiIsImNyZWF0ZU1peGlucyIsIlJlYWN0aXZlRmllbGQiLCJhIiwiYiIsImlzRGVzdHJveWVkIiwiaW5PbkNyZWF0ZWQiLCJpc0NyZWF0ZWQiLCJpbk9uUmVuZGVyZWQiLCJpc1JlbmRlcmVkIiwibWl4aW4iLCJtaXhpbkNvbXBvbmVudE5hbWUiLCJjYWxsRmlyc3RXaXRoIiwiYWZ0ZXJDb21wb25lbnRPck1peGluIiwiY29tcG9uZW50T3JNaXhpbiIsInByb3BlcnR5TmFtZSIsImZvdW5kIiwiY29tcG9uZW50Q2xhc3MiLCJjdXJyZW50RGF0YSIsImN1cnJlbnRXaXRoIiwibm9ucmVhY3RpdmVBcmd1bWVudHMiLCJyZWFjdGl2ZUFyZ3VtZW50cyIsIkNvbXB1dGVkRmllbGQiLCJkYXRhVmFyIiwiZXF1YWwiLCJFSlNPTiIsImVxdWFscyIsImZ1bmMiLCJPYmplY3QiLCJyZW5kZXJGdW5jdGlvbiIsImJhc2UxIiwiYmFzZTIiLCJiYXNlMyIsIl9vblZpZXdSZW5kZXJlZCIsInJlbmRlckNvdW50IiwiYXV0b3J1biIsImNvbXB1dGF0aW9uIiwic3RvcCIsInJlbW92ZUNvbXBvbmVudCIsInJlbW92ZSIsIl9yZW5kZXJDb21wb25lbnRUbyIsInZpc2l0b3IiLCJyZW5kZXJDb21wb25lbnRUb0hUTUwiLCJleHBhbmRlZFZpZXciLCJfVGVtcGxhdGVXaXRoIiwiaW5zZXJ0RE9NRWxlbWVudCIsIm5vZGUiLCJiZWZvcmUiLCJwYXJlbnROb2RlIiwibmV4dFNpYmxpbmciLCJpbnNlcnRCZWZvcmUiLCJtb3ZlRE9NRWxlbWVudCIsInJlbW92ZURPTUVsZW1lbnQiLCJyZW1vdmVDaGlsZCIsIl9fZXZlbnRNYXBzIiwicGF0aCIsImVxdWFsc0Z1bmMiLCJEYXRhTG9va3VwIiwic3BsaXQiLCJsZXhpY2FsRGF0YSIsIl9sZXhpY2FsQmluZGluZ0xvb2t1cCIsImZpcnN0Tm9kZSIsIl9kb21yYW5nZSIsImxhc3ROb2RlIiwicnVuRnVuYyIsIkJhc2VDb21wb25lbnQiLCJUZW1wbGF0ZUluc3RhbmNlIiwiQmxhemVDb21wb25lbnREZWJ1ZyIsInN0YXJ0Q29tcG9uZW50IiwiY29uc29sZSIsImxvZyIsInN0YXJ0TWFya2VkQ29tcG9uZW50IiwiZHVtcENvbXBvbmVudFN1YnRyZWUiLCJyb290Q29tcG9uZW50T3JFbGVtZW50IiwiZHVtcENvbXBvbmVudFRyZWUiLCJkdW1wQWxsQ29tcG9uZW50cyIsImFsbFJvb3RDb21wb25lbnRzIiwiaiIsInJvb3RDb21wb25lbnQiLCIkIiwiZWFjaCIsImVsZW1lbnQiLCJjb21wb25lbnRSb290IiwiQmFzZUNvbXBvbmVudERlYnVnIiwiYm9keSIsInJlbmRlclRvRG9jdW1lbnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsV0FBV0MsTUFBTUQsUUFBakIsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQ0EsSUFBQUUsNEJBQUE7QUFBQSxJQUFBQyxjQUFBO0FBQUEsSUFBQUMseUJBQUE7QUFBQSxJQUFBQywwQkFBQTtBQUFBLElBQUFDLFNBQUE7QUFBQSxJQUFBQyxvQkFBQTtBQUFBLElBQUFDLGFBQUE7QUFBQSxJQUFBQyxlQUFBO0FBQUEsSUFBQUMscUJBQUE7QUFBQSxJQUFBQyxhQUFBO0FBQUEsSUFBQUMsYUFBQTtBQUFBLElBQUFDLGFBQUE7QUFBQSxJQUFBQyxzQkFBQTtBQUFBLElBQUFDLE1BQUE7QUFBQSxJQUFBQyxVQUFBO0FBQUEsSUFBQUMsZUFBQTtBQUFBLElBQUFDLG1CQUFBO0FBQUEsSUFBQUMsMkJBQUE7QUFBQSxJQUFBQyxNQUFBO0FBQUEsSUFBQUMsVUFBQTtBQUFBLElBQUFDLFdBQUE7QUFBQSxJQUFBQyx5QkFBQTtBQUFBLElBQUFDLG1CQUFBO0FBQUEsSUFBQUMsZUFBQTtBQUFBLElBQUFDLGdCQUFBO0FBQUEsSUFBQUMsR0FBQTtBQUFBLElBQUFDLHdCQUFBO0FBQUEsSUFBQUMsYUFBQTtBQUFBLElBQUFDLDJCQUFBO0FBQUEsSUFBQUMsd0JBQUE7QUFBQSxJQUFBQyxVQUFBO0FBQUEsSUFBQUMsbUJBQUE7QUFBQSxJQUFBQyxRQUFBLEdBQUFBLEtBQUE7QUFBQSxJQ0NFQyxTQUFTLFVBQVNDLEtBQVQsRUFBZ0JDLE1BQWhCLEVBQXdCO0FBQUUsT0FBSyxJQUFJQyxHQUFULDJDQUFnQkQsTUFBaEIsR0FBd0I7QUFBRSxRQUFJRSxRQUFRQyxJQUFSLENBQWFILE1BQWIsRUFBcUJDLEdBQXJCLENBQUosRUFBK0JGLE1BQU1FLEdBQU4sSUFBYUQsT0FBT0MsR0FBUCxDQUFiO0FBQTJCOztBQUFDLFdBQVNHLElBQVQsR0FBZ0I7QUFBRSxTQUFLQyxXQUFMLEdBQW1CTixLQUFuQjtBQUEyQjs7QUFBQ0ssT0FBS0UsU0FBTCxHQUFpQk4sT0FBT00sU0FBeEI7QUFBbUNQLFFBQU1PLFNBQU4sR0FBa0IsSUFBSUYsSUFBSixFQUFsQjtBQUE4QkwsUUFBTVEsU0FBTixHQUFrQlAsT0FBT00sU0FBekI7QUFBb0MsU0FBT1AsS0FBUDtBQUFlLENERDVSO0FBQUEsSUNFRUcsVUFBVSxHQUFHTSxjREZmO0FBQUEsSUNHRUMsVUFBVSxHQUFHQSxPQUFILElBQWMsVUFBU0MsSUFBVCxFQUFlO0FBQUUsT0FBSyxJQUFJQyxJQUFJLENBQVIsRUFBV0MsSUFBSSxLQUFLQyxNQUF6QixFQUFpQ0YsSUFBSUMsQ0FBckMsRUFBd0NELEdBQXhDLEVBQTZDO0FBQUUsUUFBSUEsS0FBSyxJQUFMLElBQWEsS0FBS0EsQ0FBTCxNQUFZRCxJQUE3QixFQUFtQyxPQUFPQyxDQUFQO0FBQVc7O0FBQUMsU0FBTyxDQUFDLENBQVI7QUFBWSxDREhySjs7QUFBQW5DLGdCQUFnQixVQUFDc0MsMkJBQUQsRUFBOEJDLFdBQTlCO0FBQ2QsTUFBQUMsT0FBQSxFQUFBQyxRQUFBOztBQUFBLE1BQUdDLEVBQUVDLFFBQUYsQ0FBV0wsMkJBQVgsQ0FBSDtBQUNFRyxlQUFXSCwyQkFBWDs7QUFDQUEsa0NBQThCLFVBQUFNLEtBQUE7QUNPNUIsYURQNEIsVUFBQ3JCLEtBQUQsRUFBUUMsTUFBUjtBQUc1QixZQUFHZSxlQUFnQmhCLFVBQVdDLE1BQTNCLElBQXNDRCxNQUFNc0IsWUFBL0M7QUNNSSxpQkRMRixDQUFDLENBQUN0QixNQUFNc0IsWUFBTixDQUFtQixJQUFuQixFQUF5QkosUUFBekIsQ0NLQTtBRE5KO0FDUUksaUJETEZBLFlBQVlsQixLQ0tWO0FBQ0Q7QURaeUIsT0NPNUI7QURQNEIsV0FBOUI7QUFGRixTQVVLLElBQUcsQ0FBSW1CLEVBQUVJLFVBQUYsQ0FBYVIsMkJBQWIsQ0FBUDtBQUNIUyxXQUFPTCxFQUFFTSxRQUFGLENBQVdWLDJCQUFYLENBQVA7QUFDQUUsY0FBVUYsMkJBQVY7O0FBQ0FBLGtDQUE4QixVQUFBTSxLQUFBO0FDUTVCLGFEUjRCLFVBQUNyQixLQUFELEVBQVFDLE1BQVI7QUFDNUIsWUFBQXlCLGlCQUFBLEVBQUFDLEtBQUE7O0FBQUEsYUFBQVQsUUFBQSwyQ0FBQUQsT0FBQTtBQ1VJVSxrQkFBUVYsUUFBUUMsUUFBUixDQUFSOztBRFBGLGNBQUdGLGVBQWdCaEIsVUFBV0MsTUFBM0IsSUFBc0NELE1BQU1zQixZQUEvQztBQUNFSSxnQ0FBb0IxQixNQUFNc0IsWUFBTixDQUFtQixJQUFuQixFQUF5QkosUUFBekIsQ0FBcEI7QUFERjtBQUdFLGdCQUE2QkEsWUFBWWxCLEtBQXpDO0FBQUEwQixrQ0FBb0IxQixLQUFwQjtBQUhGO0FDY0c7O0FEVkgsZUFBb0IwQixpQkFBcEI7QUFBQSxtQkFBTyxLQUFQO0FDYUc7O0FEWEgsY0FBR1AsRUFBRUksVUFBRixDQUFhRyxrQkFBa0JSLFFBQWxCLENBQWIsQ0FBSDtBQUNFLGdCQUFvQlEsa0JBQWtCUixRQUFsQixRQUFpQ1MsS0FBckQ7QUFBQSxxQkFBTyxLQUFQO0FBREY7QUFBQTtBQUdFLGdCQUFvQkQsa0JBQWtCUixRQUFsQixNQUErQlMsS0FBbkQ7QUFBQSxxQkFBTyxLQUFQO0FBSEY7QUNvQkc7QUQ3Qkw7O0FDK0JFLGVEakJGLElDaUJFO0FEaEMwQixPQ1E1QjtBRFI0QixXQUE5QjtBQ21DRDs7QUFDRCxTRG5CQVosMkJDbUJBO0FEbERjLENBQWhCOztBQWlDQWpDLHNCQUFzQixVQUFDOEMsSUFBRCxFQUFPQyxnQkFBUDtBQUNwQixTQUFNRCxRQUFTLENBQUlBLEtBQUtFLGlCQUF4QjtBQUNFLFFBQUdELGdCQUFIO0FBQ0VELGFBQU9BLEtBQUtHLFVBQVo7QUFERjtBQUdFSCxhQUFPQSxLQUFLSSxrQkFBTCxJQUEyQkosS0FBS0csVUFBdkM7QUNxQkQ7QUR6Qkg7O0FDMkJBLFNBQU9ILFFBQVEsSUFBUixHRHJCUEEsS0FBTUUsaUJDcUJDLEdEckJELE1DcUJOO0FENUJvQixDQUF0Qjs7QUFhQXBDLDhCQUE4QixVQUFDdUMsb0JBQUQsRUFBdUJKLGdCQUF2QjtBQUM1QixNQUFBSyxnQkFBQTtBQUFBQSxxQkFBQSxPQUFBRCxvQkFBQSxrQkFBbUJBLHNCQUFuQixHQUFtQixNQUFuQjtBQUlBQyxxQkFBbUJwRCxvQkFBQW9ELG9CQUFBLE9BQW9CQSxpQkFBa0JOLElBQXRDLEdBQXNDLE1BQXRDLEVBQTRDQyxnQkFBNUMsQ0FBbkI7O0FBRUEsU0FBTUssZ0JBQU47QUFDRSxRQUFxQyxlQUFlQSxnQkFBcEQ7QUFBQSxhQUFPQSxpQkFBaUJDLFNBQXhCO0FDaUJDOztBRGZELFFBQUdOLGdCQUFIO0FBQ0VLLHlCQUFtQnBELG9CQUFvQm9ELGlCQUFpQk4sSUFBakIsQ0FBc0JHLFVBQTFDLEVBQXNERixnQkFBdEQsQ0FBbkI7QUFERjtBQUdFSyx5QkFBbUJwRCxvQkFBcUJvRCxpQkFBaUJOLElBQWpCLENBQXNCSSxrQkFBdEIsSUFBNENFLGlCQUFpQk4sSUFBakIsQ0FBc0JHLFVBQXZGLEVBQW9HRixnQkFBcEcsQ0FBbkI7QUNpQkQ7QUR2Qkg7O0FDeUJBLFNEakJBLElDaUJBO0FEaEM0QixDQUE5Qjs7QUFpQkE5Qyw4QkFBOEIsVUFBQzZDLElBQUQsRUFBT0MsZ0JBQVA7QUFDNUIsTUFBQUssZ0JBQUE7QUFBQUEscUJBQW1CcEQsb0JBQW9COEMsSUFBcEIsRUFBMEJDLGdCQUExQixDQUFuQjtBQ29CQSxTRG5CQTtBQ29CRSxXRG5CQUssZ0JDbUJBO0FEcEJGLEdDbUJBO0FEckI0QixDQUE5Qjs7QUFLTXBFLCtCQUFBO0FBQ1MsV0FBQUEsNEJBQUEsQ0FBQ3NFLFNBQUQsRUFBYUMsaUJBQWI7QUFBQyxTQUFDRCxTQUFELEdBQUFBLFNBQUE7QUFBWSxTQUFDRixnQkFBRCxHQUFBRyxpQkFBQTtBQUFiOztBQzBCYixTQUFPdkUsNEJBQVA7QUFFRCxDRDdCSzs7QUFLTm9CLGNBQWNvRCxVQUFVQyxHQUF4Qjs7QUFDQUQsVUFBVUMsR0FBVixHQUFnQjtBQUNkLE1BQUFDLElBQUEsRUFBQWIsS0FBQTtBQURlQSxVQUFBYyxVQUFBLElBQU9ELE9BQUEsS0FBQUMsVUFBQTNCLE1BQUEsR0FBQWhCLE1BQUFNLElBQUEsQ0FBQXFDLFNBQUEsU0FBUDs7QUFDZixNQUFHZCxpQkFBaUI3RCw0QkFBcEI7QUFDRSxXQUFPRCxNQUFNNkUsWUFBTixDQUFzQmYsTUFBTVMsU0FBTixHQUFnQixHQUFoQixHQUFtQkksS0FBS0csSUFBTCxDQUFVLEdBQVYsQ0FBekMsRUFBMERoQixNQUFNTyxnQkFBaEUsQ0FBUDtBQzhCRDs7QUFDRCxTRDdCQWhELFlBQUEwRCxLQUFBLE9BQVksQ0FBQWpCLEtBQUEsRUFBT2tCLE1BQVAsQ0FBTy9DLE1BQUFNLElBQUEsQ0FBQW9DLElBQUEsQ0FBUCxDQUFaLENDNkJBO0FEakNjLENBQWhCOztBQU1BbkQsa0JBQWtCaUQsVUFBVVEsT0FBNUI7O0FBQ0FSLFVBQVVRLE9BQVYsR0FBb0I7QUFLbEIsTUFBQU4sSUFBQSxFQUFBTyxrQkFBQTtBQUxtQkEsdUJBQUFOLFVBQUEsSUFBb0JELE9BQUEsS0FBQUMsVUFBQTNCLE1BQUEsR0FBQWhCLE1BQUFNLElBQUEsQ0FBQXFDLFNBQUEsU0FBcEI7O0FBS25CLE1BQUdNLDhCQUE4QmpGLDRCQUFqQztBQUNFaUYseUJBQXFCbEYsTUFBTTZFLFlBQU4sQ0FBbUJLLG1CQUFtQlgsU0FBdEMsRUFBaURXLG1CQUFtQmIsZ0JBQXBFLENBQXJCO0FDOEJEOztBQUNELFNEN0JBN0MsZ0JBQUF1RCxLQUFBLE9BQWdCLENBQUFHLGtCQUFBLEVBQW9CRixNQUFwQixDQUFvQi9DLE1BQUFNLElBQUEsQ0FBQW9DLElBQUEsQ0FBcEIsQ0FBaEIsQ0M2QkE7QURyQ2tCLENBQXBCOztBQTRCQTNFLE1BQU1tRixrQkFBTixHQUEyQixVQUFDQyxRQUFELEVBQVdDLElBQVgsRUFBaUJoQixnQkFBakI7QUFDekIsTUFBQUMsU0FBQSxFQUFBZ0IsTUFBQSxFQUFBQyxxQkFBQSxFQUFBQyxnQkFBQSxFQUFBOUQsR0FBQSxFQUFBK0QsSUFBQSxFQUFBQyxJQUFBO0FBQUFILDBCQUF3QixLQUF4Qjs7QUFDQSxNQUFHSCxTQUFTTyxTQUFULENBQW1CQyxHQUFuQixDQUF1QlAsSUFBdkIsQ0FBSDtBQUNFQyxhQUFTRixTQUFTTyxTQUFULENBQW1CRSxHQUFuQixDQUF1QlIsSUFBdkIsQ0FBVDs7QUFDQSxRQUFHQyxXQUFVdEYsTUFBTThGLGdCQUFuQjtBQUNFUCw4QkFBd0IsSUFBeEI7QUFERixXQUVLLElBQUdELFVBQUEsSUFBSDtBQUNILGFBQU92RCxXQUFXdkIsZ0JBQWdCOEUsTUFBaEIsQ0FBWCxFQUFvQ2pCLGdCQUFwQyxDQUFQO0FBREc7QUFHSCxhQUFPLElBQVA7QUFQSjtBQ3NCQzs7QURaRCxNQUFHZ0IsUUFBUUQsUUFBWDtBQUVFLFNBQU9HLHFCQUFQO0FBQ0VILGVBQVNPLFNBQVQsQ0FBbUJJLEdBQW5CLENBQXVCVixJQUF2QixFQUE2QnJGLE1BQU04RixnQkFBbkM7O0FBQ0EsV0FBT1YsU0FBU1ksd0JBQWhCO0FBQ0VoRyxjQUFNaUcsS0FBTixDQUFZLDRCQUE0QmIsU0FBU2MsUUFBckMsR0FBZ0QsR0FBaEQsR0FBc0RiLElBQXRELEdBQTZELCtCQUE3RCxHQUErRkQsU0FBU2MsUUFBeEcsR0FBbUgseUJBQS9IO0FBSEo7QUNpQkM7O0FEYkQsUUFBR2QsU0FBQUMsSUFBQSxTQUFIO0FBQ0UsYUFBT3RELFdBQVd2QixnQkFBZ0I0RSxTQUFTQyxJQUFULENBQWhCLENBQVgsRUFBNENoQixnQkFBNUMsQ0FBUDtBQURGO0FBR0UsYUFBTyxJQUFQO0FBVEo7QUN5QkM7O0FEZEQsT0FBbUJBLGdCQUFuQjtBQUFBLFdBQU8sSUFBUDtBQ2lCQzs7QURYRCxPQUFBM0MsTUFBZTBELFNBQVNjLFFBQXhCLE1BQXFDLG1DQUFyQyxJQUFleEUsUUFBMkQsb0JBQTFFO0FBQUEsV0FBTyxJQUFQO0FDY0M7O0FEVkQ0QyxjQUFZNkIsUUFBUUMsV0FBUixDQUFvQjtBQ1k5QixXRFRBdkUsNEJBQTRCd0MsZ0JBQTVCLEVBQThDLElBQTlDLENDU0E7QURaVSxJQUFaOztBQU1BLE1BQUdDLFNBQUg7QUFFRSxRQUFHa0IsbUJBQW1CbEIsVUFBVWIsWUFBVixDQUF1QixJQUF2QixFQUE2QjRCLElBQTdCLENBQXRCO0FBQ0UsYUFBT3RELFdBQVd4QixjQUFjaUYsZ0JBQWQsRUFBZ0NBLGlCQUFpQkgsSUFBakIsQ0FBaEMsQ0FBWCxFQUFvRWhCLGdCQUFwRSxDQUFQO0FBSEo7QUNZQzs7QURKRCxNQUFHZ0IsUUFBU0EsUUFBUWdCLGVBQWVDLFVBQW5DO0FBQ0UsV0FBTyxJQUFJckcsNEJBQUosQ0FBaUNvRixJQUFqQyxFQUF1Q2hCLGdCQUF2QyxDQUFQO0FDTUQ7O0FESEQsTUFBR0MsU0FBSDtBQUVFLFFBQUcsQ0FBQWdCLFNBQUEsQ0FBQUcsT0FBQW5CLFVBQUFpQyxtQkFBQSxhQUFBYixPQUFBRCxLQUFBZSxZQUFBLFlBQUFkLEtBQUFDLFNBQUEsQ0FBQUUsR0FBQSxDQUFBUixJQUFBLDRCQUFIO0FBQ0UsYUFBT3RELFdBQVd2QixnQkFBZ0I4RSxNQUFoQixDQUFYLEVBQW9DakIsZ0JBQXBDLENBQVA7QUFISjtBQ1FDOztBQUNELFNESkEsSUNJQTtBRDVEeUIsQ0FBM0I7O0FBMERBb0MsTUFBTUMsa0JBQU4sR0FBMkIsS0FBM0I7O0FBRUFuRyxnQkFBZ0IsVUFBQytELFNBQUQsRUFBWWdCLE1BQVo7QUFDZCxNQUFHaEMsRUFBRUksVUFBRixDQUFhNEIsTUFBYixDQUFIO0FDTUUsV0RMQTtBQUNFLFVBQUFYLElBQUEsRUFBQVUsSUFBQSxFQUFBc0IsTUFBQSxFQUFBN0MsS0FBQTtBQUREYSxhQUFBLEtBQUFDLFVBQUEzQixNQUFBLEdBQUFoQixNQUFBTSxJQUFBLENBQUFxQyxTQUFBO0FBQ0MrQixlQUFTckIsT0FBT1AsS0FBUCxDQUFhVCxTQUFiLEVBQXdCSyxJQUF4QixDQUFUOztBQUlBLFVBQUc4QixNQUFNQyxrQkFBTixJQUE2QnBELEVBQUVNLFFBQUYsQ0FBVytDLE1BQVgsQ0FBaEM7QUFDRSxhQUFBdEIsSUFBQSwyQ0FBQXNCLE1BQUE7QUNLRTdDLGtCQUFRNkMsT0FBT3RCLElBQVAsQ0FBUjs7QUFDQSxjRE42Qm9CLE1BQU1HLG1CQUFOLENBQTBCQyxJQUExQixDQUErQnhCLElBQS9CLENDTTdCLEVETjZCO0FBQzdCLGdCQUFHL0IsRUFBRUksVUFBRixDQUFhSSxLQUFiLENBQUg7QUFDRTZDLHFCQUFPdEIsSUFBUCxJQUFlL0IsRUFBRXdELElBQUYsQ0FBT2hELEtBQVAsRUFBY1EsU0FBZCxDQUFmO0FBREYsbUJBRUssSUFBR2hCLEVBQUV5RCxPQUFGLENBQVVqRCxLQUFWLENBQUg7QUFDSDZDLHFCQUFPdEIsSUFBUCxJQUFlL0IsRUFBRTBELEdBQUYsQ0FBTWxELEtBQU4sRUFBYSxVQUFDbUQsR0FBRDtBQUMxQixvQkFBRzNELEVBQUVJLFVBQUYsQ0FBYXVELEdBQWIsQ0FBSDtBQ09JLHlCRE5GM0QsRUFBRXdELElBQUYsQ0FBT0csR0FBUCxFQUFZM0MsU0FBWixDQ01FO0FEUEo7QUNTSSx5QkRORjJDLEdDTUU7QUFDRDtBRFhVLGdCQUFmO0FDYUM7QUFDRjtBRG5CTDtBQ3FCQzs7QUFDRCxhRFhBTixNQ1dBO0FEM0JGLEtDS0E7QURORjtBQytCRSxXRFpBckIsTUNZQTtBQUNEO0FEakNhLENBQWhCOztBQXNCQTlFLGtCQUFrQixVQUFDOEUsTUFBRDtBQUNoQixNQUFHaEMsRUFBRUksVUFBRixDQUFhNEIsTUFBYixDQUFIO0FDZUUsV0RkQTtBQUNFLFVBQUE0QixJQUFBO0FBQUFBLGFBQU9sSCxNQUFNbUgsT0FBTixFQUFQOztBQ2dCQSxVQUFJRCxRQUFRLElBQVosRUFBa0I7QURmbEJBLGVBQVEsRUFBUjtBQ2lCQzs7QUFDRCxhRGpCQTVCLE9BQU9QLEtBQVAsQ0FBYW1DLElBQWIsRUFBbUJ0QyxTQUFuQixDQ2lCQTtBRHBCRixLQ2NBO0FEZkY7QUN3QkUsV0RsQkFVLE1Da0JBO0FBQ0Q7QUQxQmUsQ0FBbEI7O0FBU0F2RCxhQUFhLFVBQUNxRixDQUFELEVBQUlDLFlBQUo7QUFFWCxPQUFpRXJILE1BQU1ELFFBQU4sQ0FBZXVILHlCQUFoRjtBQUFBLFdBQU90SCxNQUFNdUgsdUJBQU4sQ0FBOEJILENBQTlCLEVBQWlDLGlCQUFqQyxDQUFQO0FDcUJDOztBRG5CRCxPQUFnQjlELEVBQUVJLFVBQUYsQ0FBYTBELENBQWIsQ0FBaEI7QUFBQSxXQUFPQSxDQUFQO0FDc0JDOztBQUNELFNEckJBO0FBQ0UsUUFBQXpDLElBQUEsRUFBQTZDLElBQUE7QUFBQUEsV0FBTyxJQUFQO0FBQ0E3QyxXQUFPQyxTQUFQO0FDdUJBLFdEckJBNUUsTUFBTUQsUUFBTixDQUFldUgseUJBQWYsQ0FBeUNELFlBQXpDLEVBQXVEO0FDc0JyRCxhRHJCQXJILE1BQU11SCx1QkFBTixDQUE4QkgsQ0FBOUIsRUFBaUMsaUJBQWpDLEVBQW9EckMsS0FBcEQsQ0FBMER5QyxJQUExRCxFQUFnRTdDLElBQWhFLENDcUJBO0FEdEJGLE1DcUJBO0FEekJGLEdDcUJBO0FEM0JXLENBQWI7O0FBYUEsSUFBRzNFLE1BQU1ELFFBQU4sQ0FBZXVILHlCQUFsQjtBQUNFeEYsNkJBQTJCOUIsTUFBTUQsUUFBTixDQUFldUgseUJBQTFDO0FBREY7QUFJRXhGLDZCQUEyQixVQUFDdUMsZ0JBQUQsRUFBbUIrQyxDQUFuQjtBQ3dCekIsV0R2QkFBLEdDdUJBO0FEeEJ5QixHQUEzQjtBQzBCRDs7QUR2QkRwRyxrQkFBa0IsVUFBQ3NELFNBQUQ7QUMwQmhCLFNEeEJBNkIsUUFBUUMsV0FBUixDQUFvQjtBQUNsQixRQUFBcUIsaUJBQUEsRUFBQWpCLFlBQUE7QUFBQWlCLHdCQUFvQm5ELFVBQVVjLFFBQVYsRUFBcEI7O0FBQ0EsUUFBRzlCLEVBQUVDLFFBQUYsQ0FBV2tFLGlCQUFYLENBQUg7QUFDRWpCLHFCQUFlekcsU0FBUzBILGlCQUFULENBQWY7O0FBQ0EsV0FBMEVqQixZQUExRTtBQUFBLGNBQU0sSUFBSWtCLEtBQUosQ0FBVSxlQUFhRCxpQkFBYixHQUErQixvQkFBekMsQ0FBTjtBQUZGO0FBQUEsV0FHSyxJQUFHQSxpQkFBSDtBQUNIakIscUJBQWVpQixpQkFBZjtBQURHO0FBR0gsWUFBTSxJQUFJQyxLQUFKLENBQVUsa0NBQStCcEQsVUFBVXFELGFBQVYsTUFBNkIsU0FBNUQsSUFBc0UsaUJBQWhGLENBQU47QUM0QkQ7O0FBQ0QsV0QzQkFuQixZQzJCQTtBRHJDRixJQ3dCQTtBRDFCZ0IsQ0FBbEI7O0FBY0EvRix3QkFBd0IsVUFBQzZELFNBQUQsRUFBWXNELFFBQVo7QUFFdEIsTUFBQUMsU0FBQSxFQUFBeEQsZ0JBQUE7O0FBQUEsTUFBY0MsY0FBYUEsVUFBVUEsU0FBVixFQUEzQjtBQUFBO0FDK0JDOztBRDdCREQscUJBQW1COEIsUUFBUUMsV0FBUixDQUFvQjtBQytCckMsV0Q5QkE5QixVQUFVaUMsbUJBQVYsQ0FBOEJsQyxnQkFBOUIsRUM4QkE7QUQvQmlCLElBQW5CO0FBRUF3RCxjQUFZdkQsVUFBVWlDLG1CQUFWLENBQThCQyxZQUE5QixDQUEyQ3NCLGFBQTNDLENBQXlERixRQUF6RCxDQUFaOztBQUNBN0gsV0FBU3VILHlCQUFULENBQ0U7QUMrQkEsV0Q5QkVqRCxnQkM4QkY7QURoQ0YsS0FJRTtBQUNFLFFBQUEwRCxRQUFBLEVBQUFoRixDQUFBLEVBQUFpRixHQUFBLEVBQUFDLE9BQUE7QUFBQUEsY0FBQTs7QUMrQkYsU0QvQkVsRixJQUFBLEdBQUFpRixNQUFBSCxVQUFBNUUsTUMrQkYsRUQvQkVGLElBQUFpRixHQytCRixFRC9CRWpGLEdDK0JGLEVEL0JFO0FDZ0NBZ0YsaUJBQVdGLFVBQVU5RSxDQUFWLENBQVg7QUFDQWtGLGNBQVFDLElBQVIsQ0RoQ0VILFNBQVN4RixJQUFULENBQWM4QixnQkFBZCxDQ2dDRjtBRGpDQTs7QUNtQ0YsV0FBTzRELE9BQVA7QUR4Q0Y7QUFQc0IsQ0FBeEI7O0FBa0JBakcsc0JBQXNCLFVBQUNtRyxXQUFELEVBQWNmLENBQWQ7QUFLcEIsTUFBQS9DLGdCQUFBO0FBQUFBLHFCQUFtQm5ELDRCQUE0QmlILFdBQTVCLEVBQXlDLElBQXpDLENBQW5CO0FDK0JBLFNEekJBckcseUJBQXlCdUMsZ0JBQXpCLEVBQTJDO0FDMEJ6QyxXRHBCQXJFLE1BQU1vSSxnQkFBTixDQUF1QkQsV0FBdkIsRUFBb0M7QUNxQmxDLGFEcEJBZixHQ29CQTtBRHJCRixNQ29CQTtBRDFCRixJQ3lCQTtBRHBDb0IsQ0FBdEI7O0FBb0JBL0csWUFBWSxVQUFDMEQsSUFBRCxFQUFPTyxTQUFQO0FBQ1YsTUFBQStELFFBQUEsRUFBQUMsTUFBQSxFQUFBQyxVQUFBLEVBQUFDLEVBQUEsRUFBQUMsT0FBQSxFQUFBMUYsQ0FBQSxFQUFBaUYsR0FBQSxFQUFBVSxJQUFBO0FBQUFILGVBQWFqRSxVQUFVZ0UsTUFBVixFQUFiOztBQUVBLE9BQTZJaEYsRUFBRXlELE9BQUYsQ0FBVXdCLFVBQVYsQ0FBN0k7QUFBQSxVQUFNLElBQUliLEtBQUosQ0FBVSwwQ0FBdUNwRCxVQUFVcUQsYUFBVixNQUE2QixTQUFwRSxJQUE4RSx3Q0FBeEYsQ0FBTjtBQ3lCQzs7QUR2QkQsT0FBQTVFLElBQUEsR0FBQWlGLE1BQUFPLFdBQUF0RixNQUFBLEVBQUFGLElBQUFpRixHQUFBLEVBQUFqRixHQUFBO0FDeUJFdUYsYUFBU0MsV0FBV3hGLENBQVgsQ0FBVDtBRHhCQXNGLGVBQVcsRUFBWDs7QUMwQkFHLFNEdkJLLFVBQUNFLElBQUQsRUFBT0QsT0FBUDtBQ3dCSCxhRHZCRUosU0FBU0ssSUFBVCxJQUFpQjtBQUNmLFlBQUEvRCxJQUFBLEVBQUF3RCxXQUFBLEVBQUFRLEtBQUE7QUFEZ0JoRSxlQUFBLEtBQUFDLFVBQUEzQixNQUFBLEdBQUFoQixNQUFBTSxJQUFBLENBQUFxQyxTQUFBO0FBQ2hCK0QsZ0JBQVFoRSxLQUFLLENBQUwsQ0FBUjtBQUVBd0Qsc0JBQWNuSSxNQUFNNEksT0FBTixDQUFjRCxNQUFNRSxhQUFwQixDQUFkO0FBQ0E3Ryw0QkFBb0JtRyxXQUFwQixFQUFpQztBQ3lCakMsaUJEeEJFTSxRQUFRMUQsS0FBUixDQUFjVCxTQUFkLEVBQXlCSyxJQUF6QixDQ3dCRjtBRHpCQTtBQUplLE9DdUJuQjtBRHhCRyxLQ3VCTDs7QUR4QkEsU0FBQStELElBQUEsMkNBQUFKLE1BQUE7QUNvQ0VHLGdCQUFVSCxPQUFPSSxJQUFQLENBQVY7QUFDQUYsU0RwQ0lFLElDb0NKLEVEcENVRCxPQ29DVjtBRHJDRjs7QUFhQXpJLFVBQU04SSxZQUFOLENBQW1CL0UsSUFBbkIsRUFBeUJzRSxRQUF6QixFQUFtQ3RFLElBQW5DO0FBaEJGO0FBTFUsQ0FBWjs7QUF5QkF4QyxzQkFBc0J2QixNQUFNNkUsWUFBNUI7O0FBQ0E3RSxNQUFNNkUsWUFBTixHQUFxQixVQUFDUSxJQUFELEVBQU9oQixnQkFBUDtBQUVuQixNQUFBZSxRQUFBO0FBQUFBLGFBQVdlLFFBQVFDLFdBQVIsQ0FBb0I7QUFDN0IsUUFBQTJDLGVBQUEsRUFBQXJILEdBQUE7O0FBQUEsUUFBRzFCLE1BQU1tSSxXQUFUO0FBQ0VZLHdCQUFrQjFDLGVBQWUyQyxnQkFBZixFQUFsQjtBQURGO0FBS0VELHdCQUFrQmxILDRCQUE0QndDLGdCQUE1QixFQUE4QyxLQUE5QyxDQUFsQjtBQzJCRDs7QUFDRCxXQUFPLENBQUMzQyxNQUFNMkUsZUFBZTRDLFlBQWYsQ0FBNEI1RCxJQUE1QixDQUFQLEtBQTZDLElBQTdDLEdBQW9EM0QsSUQxQnhCd0gsZUMwQndCLENEMUJSSCxlQzBCUSxDQUFwRCxHRDFCUCxNQzBCQTtBRGxDUyxJQUFYOztBQVNBLE1BQW1CM0QsYUFBY0Esb0JBQW9CcEYsTUFBTUQsUUFBMUIsSUFBc0N1RCxFQUFFSSxVQUFGLENBQWEwQixRQUFiLENBQXBELENBQW5CO0FBQUEsV0FBT0EsUUFBUDtBQzZCQzs7QUFDRCxTRDVCQTdELG9CQUFvQjhELElBQXBCLENDNEJBO0FEekNtQixDQUFyQjs7QUFlQXpELGdCQUFnQixVQUFDd0QsUUFBRCxFQUFXK0QsS0FBWDtBQUNkLE1BQUcvRCxTQUFTZ0UsU0FBWjtBQUNFaEUsYUFBU2dFLFNBQVQsQ0FBbUJELE1BQU1DLFNBQXpCO0FBQ0FoRSxhQUFTaUUsVUFBVCxDQUFvQkYsTUFBTUUsVUFBMUI7QUM4QkEsV0Q3QkFqRSxTQUFTa0UsV0FBVCxDQUFxQkgsTUFBTUcsV0FBM0IsQ0M2QkE7QURoQ0Y7QUFNRWxFLGFBQVNtRSxPQUFULEdBQW1CSixNQUFNQyxTQUF6QjtBQUNBaEUsYUFBU29FLFFBQVQsR0FBb0JMLE1BQU1FLFVBQTFCO0FDNkJBLFdENUJBakUsU0FBU3FFLFNBQVQsR0FBcUJOLE1BQU1HLFdDNEIzQjtBQUNEO0FEdENhLENBQWhCOztBQVdBM0gsMkJBQTJCLFVBQUN5RCxRQUFELEVBQVdnRSxTQUFYO0FBQ3pCLE1BQUFNLFVBQUE7O0FBQUEsTUFBR3RFLFNBQVN1RSxVQUFaO0FDZ0NFLFdEL0JBdkUsU0FBU3VFLFVBQVQsQ0FBb0JKLE9BQXBCLENBQTRCSyxPQUE1QixDQUFvQ1IsU0FBcEMsQ0MrQkE7QURoQ0Y7QUFJRU0saUJBQWF0RSxTQUFTbUUsT0FBdEI7QUMrQkEsV0Q5QkFuRSxTQUFTbUUsT0FBVCxHQUFtQjtBQUNqQkgsZ0JBQVU3RyxJQUFWLENBQWUsSUFBZjtBQytCQSxhQUFPbUgsY0FBYyxJQUFkLEdEOUJQQSxXQUFZbkgsSUFBWixDQUFpQixJQUFqQixDQzhCTyxHRDlCUCxNQzhCQTtBRGhDaUIsS0M4Qm5CO0FBSUQ7QUR4Q3dCLENBQTNCOztBQWlCQXhDLFNBQVM4Six3QkFBVCxDQUFrQ2xFLFNBQWxDLENBQTRDSSxHQUE1QyxDQUFnRCxnQkFBaEQsRUFBa0UsVUFBQ1YsSUFBRDtBQzJCaEUsU0QxQkFyRixNQUFNNkUsWUFBTixDQUFtQlEsSUFBbkIsRUFBeUIsVUFBQTdCLEtBQUE7QUMyQnZCLFdEM0J1QjtBQzRCckIsYUQzQkZ6RCxTQUFTK0osUUFBVCxFQzJCRTtBRDVCcUIsS0MyQnZCO0FEM0J1QixTQUF6QixDQzBCQTtBRDNCRjs7QUFJQXhKLHVCQUF1QjtBQytCckIsU0Q3QkFxRCxPQUFPLEtBQVAsQ0M2QkE7QUQvQnFCLENBQXZCOztBQU1BNUQsU0FBU2dLLGNBQVQsQ0FBd0IsTUFBeEIsRUFBZ0M7QUFDOUIsTUFBQUMsR0FBQTtBQUFBQSxRQUFNLEVBQU47QUFFQUEsTUFBSXZILFdBQUosR0FBa0JuQyxvQkFBbEI7QUFDQTBKLE1BQUlDLFVBQUosR0FBaUJyRixTQUFqQjtBQzZCQSxTRDVCQW9GLEdDNEJBO0FEakNGO0FBT0F2RCxNQUFNRyxtQkFBTixHQUE0QixVQUE1Qjs7QUFFQUgsTUFBTXlELGNBQU4sR0FBdUIsVUFBQ2pELEdBQUQ7QUM4QnJCLFNEN0JBM0QsRUFBRUksVUFBRixDQUFhdUQsR0FBYixLQUFzQkEsSUFBSWtELFlDNkIxQjtBRDlCcUIsQ0FBdkI7O0FBS0E3SSw0QkFBNEI4SSxLQUFLQyxpQkFBakM7O0FBQ0FELEtBQUtDLGlCQUFMLEdBQXlCLFVBQUNDLEtBQUQ7QUFDdkIsTUFBQWpGLElBQUEsRUFBQXZCLEtBQUE7O0FBQUEsTUFBR3dHLFFBQVFoSiwwQkFBMEJnSixLQUExQixDQUFYO0FBQ0UsU0FBQWpGLElBQUEsMkNBQUFpRixLQUFBO0FDK0JFeEcsY0FBUXdHLE1BQU1qRixJQUFOLENBQVI7O0FBQ0EsVUFBSSxDRGhDd0JvQixNQUFNRyxtQkFBTixDQUEwQkMsSUFBMUIsQ0FBK0J4QixJQUEvQixDQ2dDNUIsRURoQzRCO0FDaUMxQjtBQUNEOztBRGhDRCxVQUFZb0IsTUFBTXlELGNBQU4sQ0FBcUJwRyxLQUFyQixDQUFaO0FBQUE7QUNtQ0M7O0FEbENELFVBQVlSLEVBQUV5RCxPQUFGLENBQVVqRCxLQUFWLEtBQXFCUixFQUFFaUgsSUFBRixDQUFPekcsS0FBUCxFQUFjMkMsTUFBTXlELGNBQXBCLENBQWpDO0FBQUE7QUNxQ0M7O0FEakNELFVBQUc1RyxFQUFFeUQsT0FBRixDQUFVakQsS0FBVixDQUFIO0FBQ0V3RyxjQUFNakYsSUFBTixJQUFjL0IsRUFBRTBELEdBQUYsQ0FBTWxELEtBQU4sRUFBYVcsVUFBVWtFLEtBQXZCLENBQWQ7QUFERjtBQUdFMkIsY0FBTWpGLElBQU4sSUFBY1osVUFBVWtFLEtBQVYsQ0FBZ0I3RSxLQUFoQixDQUFkO0FDbUNEO0FEOUNMO0FDZ0RDOztBQUNELFNEcENBd0csS0NvQ0E7QURsRHVCLENBQXpCOztBQWdCQTdGLFVBQVVrRSxLQUFWLEdBQWtCO0FBQ2hCLE1BQUFoRSxJQUFBLEVBQUF3RixZQUFBLEVBQUFsRCxHQUFBO0FBRGlCa0QsaUJBQUF2RixVQUFBLElBQWNELE9BQUEsS0FBQUMsVUFBQTNCLE1BQUEsR0FBQWhCLE1BQUFNLElBQUEsQ0FBQXFDLFNBQUEsU0FBZDs7QUFDakIsT0FBdUV0QixFQUFFSSxVQUFGLENBQWF5RyxZQUFiLENBQXZFO0FBQUEsVUFBTSxJQUFJekMsS0FBSixDQUFVLG1DQUFpQ3lDLFlBQTNDLENBQU47QUN5Q0M7O0FEdENEeEYsU0FBT0YsVUFBVStGLFlBQVYsQ0FBQXpGLEtBQUEsQ0FBQU4sU0FBQSxFQUF1QixDQUFDO0FBQVcsUUFBQWdHLEVBQUE7QUFBVkEsU0FBQSxLQUFBN0YsVUFBQTNCLE1BQUEsR0FBQWhCLE1BQUFNLElBQUEsQ0FBQXFDLFNBQUE7QUMwQzlCLFdEMUN3QzZGLEVDMEN4QztBRDFDNEIsS0FBaUJ6RixNQUFqQixDQUFpQi9DLE1BQUFNLElBQUEsQ0FBQW9DLElBQUEsQ0FBakIsQ0FBdkIsQ0FBUDs7QUFFQXNDLFFBQU07QUFDSixRQUFBa0IsV0FBQSxFQUFBUSxLQUFBLEVBQUErQixTQUFBO0FBREsvQixZQUFBL0QsVUFBQSxJQUFPOEYsWUFBQSxLQUFBOUYsVUFBQTNCLE1BQUEsR0FBQWhCLE1BQUFNLElBQUEsQ0FBQXFDLFNBQUEsU0FBUDtBQUNMdUQsa0JBQWNuSSxNQUFNNEksT0FBTixDQUFjRCxNQUFNRSxhQUFwQixDQUFkO0FDNkNBLFdENUNBN0csb0JBQW9CbUcsV0FBcEIsRUFBaUM7QUM2Qy9CLGFEekNBZ0MsYUFBYXBGLEtBQWIsQ0FBbUIsSUFBbkIsRUFBeUIsQ0FBQzRELEtBQUQsRUFBUTNELE1BQVIsQ0FBZUwsSUFBZixFQUFxQitGLFNBQXJCLENBQXpCLENDeUNBO0FEN0NGLE1DNENBO0FEOUNJLEdBQU47O0FBUUF6RCxNQUFJa0QsWUFBSixHQUFtQixJQUFuQjtBQzJDQSxTRHpDQWxELEdDeUNBO0FEekRnQixDQUFsQjs7QUFtQkF4RixtQkFBbUIySSxLQUFLTyxhQUFMLENBQWtCakksU0FBbEIsQ0FBb0JrSSxRQUF2Qzs7QUFDQVIsS0FBS08sYUFBTCxDQUFrQmpJLFNBQWxCLENBQW9Ca0ksUUFBcEIsR0FBK0IsVUFBQ0MsR0FBRDtBQUM3QixNQUFBUCxLQUFBLEVBQUFqRixJQUFBOztBQUFBLE1BQUdpRixRQUFRTyxJQUFJUCxLQUFmO0FBQ0VBLFlBQVFGLEtBQUtDLGlCQUFMLENBQXVCQyxLQUF2QixDQUFSOztBQUNBLFNBQUFqRixJQUFBLDJDQUFBaUYsS0FBQTtBQzRDRSxVRDVDcUI3RCxNQUFNRyxtQkFBTixDQUEwQkMsSUFBMUIsQ0FBK0J4QixJQUEvQixDQzRDckIsRUQ1Q3FCO0FBQ3JCLGVBQU9pRixNQUFNakYsSUFBTixDQUFQO0FDNkNDO0FEOUNIOztBQUVBd0YsUUFBSVAsS0FBSixHQUFZQSxLQUFaO0FDK0NEOztBQUNELFNEOUNBN0ksaUJBQWlCYyxJQUFqQixDQUFzQixJQUF0QixFQUF5QnNJLEdBQXpCLENDOENBO0FEckQ2QixDQUEvQjs7QUFTQWhLLHlCQUF5QjtBQUN2QixNQUFBa0QsSUFBQTtBQUFBQSxTQUFPL0QsTUFBTW1JLFdBQWI7O0FBQ0EsTUFBQXBFLFFBQUEsT0FBR0EsS0FBTStHLFdBQVQsR0FBUyxNQUFUO0FDaURFLFdEaERBL0csSUNnREE7QURqREY7QUNtREUsV0RoREEsSUNnREE7QUFDRDtBRHREc0IsQ0FBekI7O0FBT0FyRCxnQkFBZ0IsVUFBQ3FLLE9BQUQ7QUFHZCxNQUFHLENBQUN6SCxFQUFFSSxVQUFGLENBQWFxSCxPQUFiLENBQUo7QUFDRSxXQUFPO0FDaURMLGFEaERBQSxPQ2dEQTtBRGpESyxLQUFQO0FDbUREOztBQUNELFNEakRBQSxPQ2lEQTtBRHhEYyxDQUFoQjs7QUFTQXBLLGdCQUFnQixVQUFDb0ssT0FBRDtBQUdkLE1BQUdBLG1CQUFtQi9LLE1BQU1ELFFBQTVCO0FDaURFLFdEaERBZ0wsUUFBUUMsYUFBUixFQ2dEQTtBRGpERixTQUVLLElBQUdELG1CQUFtQi9LLE1BQU1pTCxJQUE1QjtBQ2lESCxXRGhEQUYsT0NnREE7QURqREc7QUNtREgsV0RoREEvSyxNQUFNaUwsSUFBTixDQUFXLFFBQVgsRUFBcUJ2SyxjQUFjcUssT0FBZCxDQUFyQixDQ2dEQTtBQUNEO0FEekRhLENBQWhCOztBQVVBN0ssaUJBQWlCRixNQUFNa0wsZUFBTixDQUFzQmhKLE1BQXRCLEVBQWpCO0FBQ0FoQyxlQUFlaUwsR0FBZixDQUVFO0FBQUFDLGVBQWEsVUFBQ0MsQ0FBRDtBQUNYLFFBQUdBLGFBQWFyTCxNQUFNRCxRQUF0QjtBQUNFc0wsVUFBSUEsRUFBRUwsYUFBRixFQUFKO0FDbUREOztBRGxERCxRQUFHSyxhQUFhckwsTUFBTWlMLElBQXRCO0FBQ0UsYUFBT2xLLFdBQVdzSyxDQUFYLEVBQWMsS0FBQ25ILFVBQWYsQ0FBUDtBQ29ERDs7QUFDRCxXRG5EQWtHLEtBQUtrQixtQkFBTCxDQUF5QjVJLFNBQXpCLENBQW1DMEksV0FBbkMsQ0FBK0M3SSxJQUEvQyxDQUFvRCxJQUFwRCxFQUF1RDhJLENBQXZELENDbURBO0FEekRGO0FBQUEsQ0FGRjs7QUFXQXZLLFNBQVMsVUFBQ3lLLE1BQUQsRUFBU3JILFVBQVQ7QUFDUEEsZUFBYUEsY0FBY3JELHdCQUEzQjtBQ3FEQSxTRG5EQyxJQUFJWCxjQUFKLENBQW1CO0FBQUFnRSxnQkFBWUE7QUFBWixHQUFuQixDQUFELENBQTRDc0gsS0FBNUMsQ0FBa0RELE1BQWxELENDbURBO0FEdERPLENBQVQ7O0FBTUF4SyxhQUFhLFVBQUNnRCxJQUFELEVBQU9HLFVBQVA7QUFDWCxNQUFBcUgsTUFBQSxFQUFBNUUsTUFBQTs7QUFBQTNHLFFBQU15TCxXQUFOLENBQWtCMUgsSUFBbEIsRUFBd0JHLFVBQXhCLEVBQW9DLElBQXBDOztBQUVBSCxPQUFLK0csV0FBTCxHQUFtQixJQUFuQjtBQUNBUyxXQUFTdkwsTUFBTW9JLGdCQUFOLENBQXVCckUsSUFBdkIsRUFBNkI7QUNzRHBDLFdEckRBQSxLQUFLMkgsT0FBTCxFQ3FEQTtBRHRETyxJQUFUO0FBRUEzSCxPQUFLK0csV0FBTCxHQUFtQixLQUFuQjtBQUVBM0UsVUFBUXdGLEtBQVI7QUFFQWhGLFdBQVM3RixPQUFPeUssTUFBUCxFQUFleEgsSUFBZixDQUFUO0FBRUFvQyxVQUFRd0YsS0FBUjs7QUFFQSxNQUFHeEYsUUFBUXlGLE1BQVg7QUFDRXpGLFlBQVEwRixZQUFSLENBQXFCO0FDbURuQixhRGxEQTdMLE1BQU04TCxZQUFOLENBQW1CL0gsSUFBbkIsQ0NrREE7QURuREY7QUFERjtBQUlFL0QsVUFBTThMLFlBQU4sQ0FBbUIvSCxJQUFuQjtBQ29ERDs7QURsRERvQyxVQUFRd0YsS0FBUjtBQ29EQSxTRGxEQWhGLE1Da0RBO0FEeEVXLENBQWI7O0FBd0JNTixpQkFBQSxVQUFBMEYsVUFBQTtBQ29ESjdKLFNBQU9tRSxjQUFQLEVBQXVCMEYsVUFBdkI7O0FBRUEsV0FBUzFGLGNBQVQsR0FBMEI7QUFDeEIsV0FBT0EsZUFBZTFELFNBQWYsQ0FBeUJGLFdBQXpCLENBQXFDc0MsS0FBckMsQ0FBMkMsSUFBM0MsRUFBaURILFNBQWpELENBQVA7QUFDRDs7QUR0RER5QixpQkFBQzJGLHNCQUFELEdBQXlCLFVBQUNDLFVBQUQ7QUFDdkIsUUFBQTVILGdCQUFBOztBQUFBLFNBQW1CNEgsVUFBbkI7QUFBQSxhQUFPLElBQVA7QUMyREM7O0FEeERELFFBQStDQSxXQUFXQyxRQUFYLEtBQXVCQyxLQUFLQyxZQUEzRTtBQUFBLFlBQU0sSUFBSTFFLEtBQUosQ0FBVSx1QkFBVixDQUFOO0FDMkRDOztBRHJERHJELHVCQUFtQm5ELDRCQUE0QmxCLE1BQU00SSxPQUFOLENBQWNxRCxVQUFkLENBQTVCLEVBQXVELElBQXZELENBQW5CO0FDdURBLFdEdERBcEssNEJBQTRCd0MsZ0JBQTVCLEVBQThDLElBQTlDLENDc0RBO0FEakV1QixHQUF6Qjs7QUNvRUFnQyxpQkFBZTNELFNBQWYsQ0R2REEySixlQ3VEQSxHRHZEaUIsVUFBQ0MsZUFBRDtBQUNmLFFBQUFoSSxTQUFBOztBQUFBLFFBQUcsQ0FBQ0EsWUFBWSxLQUFDQSxTQUFELEVBQWIsTUFBZ0MsSUFBbkM7QUN5REUsYUR4REFBLFVBQVUrSCxlQUFWLENBQTBCQyxlQUExQixDQ3dEQTtBRHpERjtBQzJERSxhRHhEQWpHLGVBQUExRCxTQUFBLENBQUEwSixlQUFBLENBQUF0SCxLQUFBLE9BQUFILFNBQUEsQ0N3REE7QUFDRDtBRDdEYyxHQ3VEakI7O0FBU0F5QixpQkFBZTNELFNBQWYsQ0R4REE2SixtQkN3REEsR0R4RHFCLFVBQUNySiwyQkFBRDtBQUNuQixRQUFBb0IsU0FBQTs7QUFBQSxRQUFHLENBQUNBLFlBQVksS0FBQ0EsU0FBRCxFQUFiLE1BQWdDLElBQW5DO0FDMERFLGFEekRBQSxVQUFVaUksbUJBQVYsQ0FBOEJySiwyQkFBOUIsQ0N5REE7QUQxREY7QUFHRVMsYUFBT1QsMkJBQVA7QUFFQUEsb0NBQThCdEMsY0FBY3NDLDJCQUFkLEVBQTJDLElBQTNDLENBQTlCO0FDeURBLGFEdkRBbUQsZUFBQTFELFNBQUEsQ0FBQTRKLG1CQUFBLENBQUFoSyxJQUFBLE9BQU1XLDJCQUFOLENDdURBO0FBQ0Q7QURoRWtCLEdDd0RyQjs7QUFXQW1ELGlCQUFlM0QsU0FBZixDRHpEQXFHLGVDeURBLEdEekRpQixVQUFDQSxlQUFEO0FBQ2YsUUFBQXpFLFNBQUE7O0FBQUEsUUFBRyxDQUFDQSxZQUFZLEtBQUNBLFNBQUQsRUFBYixNQUFnQyxJQUFuQztBQzJERSxhRDFEQUEsVUFBVXlFLGVBQVYsQ0FBMEJBLGVBQTFCLENDMERBO0FEM0RGO0FDNkRFLGFEMURBMUMsZUFBQTFELFNBQUEsQ0FBQW9HLGVBQUEsQ0FBQWhFLEtBQUEsT0FBQUgsU0FBQSxDQzBEQTtBQUNEO0FEL0RjLEdDeURqQjs7QUFTQXlCLGlCQUFlM0QsU0FBZixDRDVEQThKLGlCQzREQSxHRDVEbUIsVUFBQ0MsY0FBRDtBQUNqQixRQUFBbkksU0FBQTs7QUFBQSxRQUFHLENBQUNBLFlBQVksS0FBQ0EsU0FBRCxFQUFiLE1BQWdDLElBQW5DO0FDOERFLGFEN0RBQSxVQUFVa0ksaUJBQVYsQ0FBNEJDLGNBQTVCLENDNkRBO0FEOURGO0FDZ0VFLGFEN0RBcEcsZUFBQTFELFNBQUEsQ0FBQTZKLGlCQUFBLENBQUF6SCxLQUFBLE9BQUFILFNBQUEsQ0M2REE7QUFDRDtBRGxFZ0IsR0M0RG5COztBQVNBeUIsaUJBQWUzRCxTQUFmLENEL0RBZ0ssb0JDK0RBLEdEL0RzQixVQUFDRCxjQUFEO0FBQ3BCLFFBQUFuSSxTQUFBOztBQUFBLFFBQUcsQ0FBQ0EsWUFBWSxLQUFDQSxTQUFELEVBQWIsTUFBZ0MsSUFBbkM7QUNpRUUsYURoRUFBLFVBQVVvSSxvQkFBVixDQUErQkQsY0FBL0IsQ0NnRUE7QURqRUY7QUNtRUUsYURoRUFwRyxlQUFBMUQsU0FBQSxDQUFBK0osb0JBQUEsQ0FBQTNILEtBQUEsT0FBQUgsU0FBQSxDQ2dFQTtBQUNEO0FEckVtQixHQytEdEI7O0FBU0F5QixpQkFBZTNELFNBQWYsQ0RsRUFpSyxNQ2tFQSxHRGxFUTtBQ21FTixXRGxFQSxFQ2tFQTtBRG5FTSxHQ2tFUjs7QUFJQXRHLGlCQUFlM0QsU0FBZixDRGhFQWtLLFdDZ0VBLEdEaEVhLFVBQUNBLFdBQUQ7QUNpRVgsUUFBSSxLQUFLckcsbUJBQUwsSUFBNEIsSUFBaEMsRUFBc0M7QURoRXRDLFdBQUNBLG1CQUFELEdBQXdCLEVBQXhCO0FDa0VDOztBRC9ERCxRQUFHcUcsV0FBSDtBQUNFLFdBQUNyRyxtQkFBRCxDQUFxQnFHLFdBQXJCLEdBQW1DQSxXQUFuQztBQUVBLGFBQU8sSUFBUDtBQ2dFRDs7QUFDRCxXRDlEQSxLQUFDckcsbUJBQUQsQ0FBcUJxRyxXQUFyQixJQUFvQyxJQzhEcEM7QUR4RVcsR0NnRWI7O0FBV0F2RyxpQkFBZTNELFNBQWYsQ0QvREFtSyxZQytEQSxHRC9EYyxVQUFDQyxXQUFEO0FBQ1osUUFBQXBMLEdBQUE7QUFBQWlDLFdBQUEsQ0FBQWpDLE1BQUEsS0FBQTZFLG1CQUFBLFlBQUE3RSxJQUE2QmlMLE1BQTdCLEdBQTZCLE1BQTdCO0FBRUF4RyxZQUFRQyxXQUFSLENBQW9CLFVBQUE1QyxLQUFBO0FDZ0VsQixhRGhFa0I7QUFHbEIsWUFBQXVKLElBQUEsRUFBQXpJLFNBQUEsRUFBQTBJLGFBQUEsRUFBQUMsc0JBQUEsRUFBQXhILElBQUEsRUFBQUMsSUFBQSxFQUFBd0gsSUFBQTs7QUFBQSxZQUFVMUosTUFBQzJKLFFBQUQsQ0FBVUwsV0FBVixDQUFWO0FBQUE7QUNpRUc7O0FEL0RILFlBQUd4SixFQUFFQyxRQUFGLENBQVd1SixXQUFYLENBQUg7QUFHRSxjQUFHdEosTUFBQ2YsV0FBRCxDQUFhd0csWUFBaEI7QUFDRWdFLHFDQUF5QnpKLE1BQUNmLFdBQUQsQ0FBYXdHLFlBQWIsQ0FBMEI2RCxXQUExQixDQUF6QjtBQURGO0FBR0VHLHFDQUF5QjVHLGVBQWU0QyxZQUFmLENBQTRCNkQsV0FBNUIsQ0FBekI7QUMrREM7O0FEOURILGVBQXlERyxzQkFBekQ7QUFBQSxrQkFBTSxJQUFJdkYsS0FBSixDQUFVLG9CQUFrQm9GLFdBQWxCLEdBQThCLElBQXhDLENBQU47QUNpRUc7O0FEaEVIRSwwQkFBZ0IsSUFBSUMsc0JBQUosRUFBaEI7QUFSRixlQVNLLElBQUczSixFQUFFSSxVQUFGLENBQWFvSixXQUFiLENBQUg7QUFDSEUsMEJBQWdCLElBQUlGLFdBQUosRUFBaEI7QUFERztBQUdIRSwwQkFBZ0JGLFdBQWhCO0FDa0VDOztBRDdESHRKLGNBQUMrQyxtQkFBRCxDQUFxQm9HLE1BQXJCLENBQTRCekUsSUFBNUIsQ0FBaUM4RSxhQUFqQzs7QUFLQSxZQUFHQSxjQUFjSixXQUFqQjtBQUNFSSx3QkFBY0osV0FBZCxDQUEwQnBKLEtBQTFCO0FDMkRDOztBQUNELFlBQUksT0FBT3dKLGNBQWNJLFlBQXJCLEtBQXNDLFVBQTFDLEVBQXNEO0FEekR4REosd0JBQWNJLFlBQWQ7QUMyREc7O0FEekRILFlBQUc5SSxZQUFZZCxNQUFDYyxTQUFELEVBQWY7QUMyREksY0FBSUEsVUFBVWlDLG1CQUFWLElBQWlDLElBQXJDLEVBQTJDO0FEMUQ3Q2pDLHNCQUFVaUMsbUJBQVYsR0FBaUMsRUFBakM7QUM0REc7O0FBQ0QsY0FBSSxDQUFDd0csT0FBT3pJLFVBQVVpQyxtQkFBbEIsRUFBdUNsQyxnQkFBdkMsSUFBMkQsSUFBL0QsRUFBcUU7QUFDbkUwSSxpQkQ3RDBCMUksZ0JDNkQxQixHRDdEOEMsSUFBSWdKLGFBQUosQ0FBa0IsSUFBbEIsRUFBd0IsVUFBQ0MsQ0FBRCxFQUFJQyxDQUFKO0FDOERwRSxxQkQ5RDhFRCxNQUFLQyxDQzhEbkY7QUQ5RDRDLGNDNkQ5QztBQUdEOztBRDFESCxpQkFBQTlILE9BQUFuQixVQUFBaUMsbUJBQUEsQ0FBQWxDLGdCQUFBLGNBQUFvQixLQUF5RDFCLElBQXpELENBQThEeUosV0FBOUQsR0FBOEQsTUFBOUQ7QUFDRSxnQkFBOEIsQ0FBSWxKLFVBQVVpQyxtQkFBVixDQUE4QmtILFdBQWxDLE1BQUEvSCxPQUFBcEIsVUFBQWlDLG1CQUFBLENBQUFsQyxnQkFBQSxjQUFBcUIsS0FBb0czQixJQUFwRyxDQUF5RzJKLFNBQXpHLEdBQXlHLE1BQXpHLENBQTlCO0FDNERJLGtCQUFJLE9BQU9WLGNBQWM1RCxTQUFyQixLQUFtQyxVQUF2QyxFQUFtRDtBRDVEdkQ0RCw4QkFBYzVELFNBQWQ7QUFBQTtBQytERzs7QUQ5REgsZ0JBQStCLENBQUk5RSxVQUFVaUMsbUJBQVYsQ0FBOEJvSCxZQUFsQyxNQUFBVCxPQUFBNUksVUFBQWlDLG1CQUFBLENBQUFsQyxnQkFBQSxjQUFBNkksS0FBcUduSixJQUFyRyxDQUEwRzZKLFVBQTFHLEdBQTBHLE1BQTFHLENBQS9CO0FDZ0VJLHFCQUFPLE9BQU9aLGNBQWMzRCxVQUFyQixLQUFvQyxVQUFwQyxHRGhFWDJELGNBQWMzRCxVQUFkLEVDZ0VXLEdEaEVHLE1DZ0VWO0FEbEVOO0FBUkY7QUM2RUc7QUQ5R2UsT0NnRWxCO0FEaEVrQixXQUFwQjtBQ2lIQSxXRG5FQSxJQ21FQTtBRHBIWSxHQytEZDs7QUF3REFoRCxpQkFBZTNELFNBQWYsQ0RuRUEwSyxZQ21FQSxHRG5FYztBQUNaLFFBQUFySyxDQUFBLEVBQUFpRixHQUFBLEVBQUE2RixLQUFBLEVBQUFuTSxHQUFBOztBQ29FQSxRQUFJLEtBQUs2RSxtQkFBTCxJQUE0QixJQUFoQyxFQUFzQztBRHBFdEMsV0FBQ0EsbUJBQUQsR0FBd0IsRUFBeEI7QUNzRUM7O0FEbkVELFFBQVUsS0FBQ0EsbUJBQUQsQ0FBcUJvRyxNQUEvQjtBQUFBO0FDc0VDOztBRHJFRCxTQUFDcEcsbUJBQUQsQ0FBcUJvRyxNQUFyQixHQUE4QixFQUE5QjtBQUVBakwsVUFBQSxLQUFBaUwsTUFBQTs7QUFBQSxTQUFBNUosSUFBQSxHQUFBaUYsTUFBQXRHLElBQUF1QixNQUFBLEVBQUFGLElBQUFpRixHQUFBLEVBQUFqRixHQUFBO0FDdUVFOEssY0FBUW5NLElBQUlxQixDQUFKLENBQVI7QUR0RUEsV0FBQzhKLFlBQUQsQ0FBY2dCLEtBQWQ7QUFERjs7QUMwRUEsV0R0RUEsSUNzRUE7QURqRlksR0NtRWQ7O0FBaUJBeEgsaUJBQWUzRCxTQUFmLENEdkVBeUssUUN1RUEsR0R2RVUsVUFBQ0wsV0FBRDtBQUNSLFFBQUd4SixFQUFFQyxRQUFGLENBQVd1SixXQUFYLENBQUg7QUN3RUUsYUR0RUEsS0FBQ3JKLFlBQUQsQ0FBYyxJQUFkLEVBQWlCLFVBQUFELEtBQUE7QUN1RWYsZUR2RWUsVUFBQ3JCLEtBQUQsRUFBUUMsTUFBUjtBQUdmLGNBQUEwTCxrQkFBQTtBQUFBQSwrQkFBQSxRQUFBM0wsTUFBQXdGLGFBQUEsa0JBQXFCeEYsTUFBTXdGLGFBQU4sRUFBckIsR0FBMkIsTUFBM0IsS0FBK0MsSUFBL0M7QUFDQSxpQkFBT21HLHNCQUF1QkEsdUJBQXNCaEIsV0FBcEQ7QUFKZSxTQ3VFZjtBRHZFZSxhQUFqQixDQ3NFQTtBRHhFRjtBQ2dGRSxhRHZFQSxLQUFDckosWUFBRCxDQUFjLElBQWQsRUFBaUIsVUFBQUQsS0FBQTtBQ3dFZixlRHhFZSxVQUFDckIsS0FBRCxFQUFRQyxNQUFSO0FBRWYsY0FBZUQsTUFBTU0sV0FBTixLQUFxQnFLLFdBQXBDO0FBQUEsbUJBQU8sSUFBUDtBQ3lFRzs7QUR0RUgsY0FBZTNLLFVBQVMySyxXQUF4QjtBQUFBLG1CQUFPLElBQVA7QUN5RUc7O0FBQ0QsaUJEeEVGLEtDd0VFO0FEL0VhLFNDd0VmO0FEeEVlLGFBQWpCLENDdUVBO0FBV0Q7QUQ1Rk8sR0N1RVY7O0FBd0JBekcsaUJBQWUzRCxTQUFmLENEMUVBcUwsYUMwRUEsR0QxRWU7QUFDYixRQUFBQyxxQkFBQSxFQUFBckosSUFBQSxFQUFBc0osZ0JBQUEsRUFBQUMsWUFBQTtBQURjRiw0QkFBQXBKLFVBQUEsSUFBdUJzSixlQUFBdEosVUFBQSxFQUF2QixFQUFxQ0QsT0FBQSxLQUFBQyxVQUFBM0IsTUFBQSxHQUFBaEIsTUFBQU0sSUFBQSxDQUFBcUMsU0FBQSxTQUFyQztBQUNkakIsV0FBT0wsRUFBRUMsUUFBRixDQUFXMkssWUFBWCxDQUFQO0FBRUFELHVCQUFtQixLQUFDeEssWUFBRCxDQUFjdUsscUJBQWQsRUFBcUNFLFlBQXJDLENBQW5COztBQUdBLFNBQWNELGdCQUFkO0FBQUE7QUMyRUM7O0FEdkVELFFBQUczSyxFQUFFSSxVQUFGLENBQWF1SyxpQkFBaUJDLFlBQWpCLENBQWIsQ0FBSDtBQUNFLGFBQU9ELGlCQUFpQkMsWUFBakIsRUFBQW5KLEtBQUEsQ0FBQWtKLGdCQUFBLEVBQStCdEosSUFBL0IsQ0FBUDtBQURGO0FBR0UsYUFBT3NKLGlCQUFpQkMsWUFBakIsQ0FBUDtBQ3lFRDtBRHRGWSxHQzBFZjs7QUFlQTdILGlCQUFlM0QsU0FBZixDRDFFQWUsWUMwRUEsR0QxRWMsVUFBQ3VLLHFCQUFELEVBQXdCOUssMkJBQXhCO0FBQ1osUUFBQWlMLEtBQUEsRUFBQXBMLENBQUEsRUFBQWlGLEdBQUEsRUFBQTZGLEtBQUEsRUFBQW5NLEdBQUEsRUFBQStELElBQUE7QUFBQTlCLFdBQUEsQ0FBQWpDLE1BQUEsS0FBQTZFLG1CQUFBLFlBQUE3RSxJQUE2QmlMLE1BQTdCLEdBQTZCLE1BQTdCO0FBQ0FoSixXQUFPVCwyQkFBUDtBQUdBQSxrQ0FBOEJ0QyxjQUFjc0MsMkJBQWQsRUFBMkMsS0FBM0MsQ0FBOUI7O0FBR0EsUUFBRyxDQUFJOEsscUJBQVA7QUFDRSxVQUFZOUssNEJBQTRCWCxJQUE1QixDQUFpQyxJQUFqQyxFQUFvQyxJQUFwQyxFQUF1QyxJQUF2QyxDQUFaO0FBQUEsZUFBTyxJQUFQO0FDeUVDOztBRHZFRDRMLGNBQVEsSUFBUjtBQUhGLFdBS0ssSUFBR0gseUJBQTBCQSwwQkFBeUIsSUFBdEQ7QUFDSEcsY0FBUSxJQUFSO0FBREc7QUFHSEEsY0FBUSxLQUFSO0FDd0VEOztBRHJFRDFJLFdBQUEsS0FBQWMsbUJBQUEsQ0FBQW9HLE1BQUE7O0FBQUEsU0FBQTVKLElBQUEsR0FBQWlGLE1BQUF2QyxLQUFBeEMsTUFBQSxFQUFBRixJQUFBaUYsR0FBQSxFQUFBakYsR0FBQTtBQ3dFRThLLGNBQVFwSSxLQUFLMUMsQ0FBTCxDQUFSOztBRHZFQSxVQUFnQm9MLFNBQVVqTCw0QkFBNEJYLElBQTVCLENBQWlDLElBQWpDLEVBQW9Dc0wsS0FBcEMsRUFBMkMsSUFBM0MsQ0FBMUI7QUFBQSxlQUFPQSxLQUFQO0FDMEVDOztBRHhFRCxVQUFnQkEsVUFBU0cscUJBQXpCO0FBQUFHLGdCQUFRLElBQVI7QUMyRUM7QUQ5RUg7O0FDZ0ZBLFdEM0VBLElDMkVBO0FEbkdZLEdDMEVkOztBRDNDQTlILGlCQUFDNkMsZUFBRCxHQUFrQixVQUFDSCxlQUFEO0FDd0VoQixXRHZFQTVDLFFBQVFDLFdBQVIsQ0FBb0IsVUFBQTVDLEtBQUE7QUN3RWxCLGFEeEVrQjtBQUNsQixZQUFBNEssY0FBQSxFQUFBbEgsSUFBQTtBQUFBa0gseUJBQWlCNUssS0FBakI7O0FBRUEsWUFBR3hELE1BQU1tSSxXQUFUO0FBTUVqQixpQkFBT25ILFNBQVNzTyxXQUFULEVBQVA7QUFORjtBQVVFbkgsaUJBQU8sSUFBUDtBQ2tFQzs7QURoRUgsYUFBQUEsUUFBQSxPQUFHQSxLQUFNekUsV0FBVCxHQUFTLE1BQVQsTUFBMEJuQyxvQkFBMUI7QUFHRSxpQkFBTzBCLG9CQUFvQmhDLE1BQU1tSSxXQUExQixFQUF1QztBQUM1QyxnQkFBQTdELFNBQUE7QUFBQUEsd0JBQVksSUFBSThKLGNBQUosRUFBWjtBQUVBLG1CQUFPOUosVUFBVTRFLGVBQVYsQ0FBMEJILGVBQTFCLENBQVA7QUFISyxZQUFQO0FDb0VDOztBQUNELGVENURGO0FBQ0UsY0FBQXVGLFdBQUEsRUFBQUMsb0JBQUEsRUFBQUMsaUJBQUE7QUFBQTdLLGlCQUFPd0MsUUFBUXlGLE1BQWY7QUFLQTBDLHdCQUFjdE8sTUFBTTRJLE9BQU4sQ0FBYyxNQUFkLENBQWQ7QUFPQTRGLDhCQUFvQixJQUFJQyxhQUFKLENBQWtCO0FBQ3BDdkgsbUJBQU9vSCxZQUFZSSxPQUFaLENBQW9CN0ksR0FBcEIsRUFBUDtBQUNBbEMsbUJBQU9nTCxLQUFQLENBQUF6SCxRQUFBLE9BQWFBLEtBQU16RSxXQUFuQixHQUFtQixNQUFuQixFQUFnQ25DLG9CQUFoQztBQ29ERSxtQkRuREY0RyxLQUFLK0MsVUNtREg7QUR0RGdCLGFBS2xCMkUsTUFBTUMsTUFMWSxDQUFwQjtBQVFBTixpQ0FBdUJDLG1CQUF2QjtBQ2lERSxpQkQvQ0ZySSxRQUFRQyxXQUFSLENBQW9CO0FBR2xCLGdCQUFBaEIsUUFBQTtBQUFBQSx1QkFBV3BGLE1BQU1vSSxnQkFBTixDQUF1QnBJLE1BQU1tSSxXQUFOLENBQWtCakUsVUFBbEIsQ0FBNkJBLFVBQXBELEVBQWdFLFVBQUFWLEtBQUE7QUMrQ3ZFLHFCRC9DdUU7QUFHekUsdUJBQU94QixvQkFBb0JoQyxNQUFNbUksV0FBMUIsRUFBdUM7QUFFNUMsc0JBQUE3RCxTQUFBOztBQUFBQSw4QkFBWSxVQUFBd0ssSUFBQSxFQUFBbkssSUFBQSxFQUFBbkMsSUFBQTtBQzhDTkEseUJBQUtFLFNBQUwsR0FBaUJvTSxLQUFLcE0sU0FBdEI7QUFDQSx3QkFBSVAsUUFBUSxJQUFJSyxJQUFKLEVBQVo7QUFBQSx3QkFBc0JtRSxTQUFTbUksS0FBSy9KLEtBQUwsQ0FBVzVDLEtBQVgsRUFBa0J3QyxJQUFsQixDQUEvQjtBQUNBLDJCQUFPb0ssT0FBT3BJLE1BQVAsTUFBbUJBLE1BQW5CLEdBQTRCQSxNQUE1QixHQUFxQ3hFLEtBQTVDO0FBQ0QsbUJEakRPLENBQUlpTSxjQUFKLEVBQW1CRyxvQkFBbkIsaUJBQVo7O0FBRUEseUJBQU9qSyxVQUFVNEUsZUFBVixDQUEwQkgsZUFBMUIsQ0FBUDtBQUpLLGtCQUFQO0FBSHlFLGVDK0N2RTtBRC9DdUUsbUJBQWhFLENBQVg7QUFVQXBILHFDQUF5QnlELFFBQXpCLEVBQW1DO0FBR2pDLG1CQUFDckIsSUFBRCxDQUFNSSxrQkFBTixHQUEyQixLQUFDSixJQUFELENBQU1HLFVBQWpDO0FDZ0RFLHFCRC9DRixLQUFDSCxJQUFELENBQU1HLFVBQU4sR0FBbUIsS0FBQ0gsSUFBRCxDQUFNRyxVQUFOLENBQWlCQSxVQUFqQixDQUE0QkEsVUMrQzdDO0FEbkRKO0FDcURFLG1CRC9DRmtCLFFDK0NFO0FEbEVKLFlDK0NFO0FEdEVKLFNDNERFO0FEdkZnQixPQ3dFbEI7QUR4RWtCLFdBQXBCLENDdUVBO0FEeEVnQixHQUFsQjs7QUM0SEFpQixpQkFBZTNELFNBQWYsQ0RwREF3RyxlQ29EQSxHRHBEaUIsVUFBQ0gsZUFBRDtBQ3FEZixXRGhEQTVDLFFBQVFDLFdBQVIsQ0FBb0IsVUFBQTVDLEtBQUE7QUNpRGxCLGFEakRrQjtBQUNsQixZQUFBYyxTQUFBLEVBQUFjLFFBQUEsRUFBQW9CLFlBQUE7QUFBQWxDLG9CQUFZZCxNQUFDYyxTQUFELEVBQVo7QUFHQUEsa0JBQVU4SSxZQUFWO0FBRUE1Ryx1QkFBZXhGLGdCQUFnQnNELFNBQWhCLENBQWY7QUFLQWMsbUJBQVcsSUFBSXBGLE1BQU1ELFFBQVYsQ0FBbUIscUJBQWtCdUUsVUFBVXFELGFBQVYsTUFBNkIsU0FBL0MsQ0FBbkIsRUFBK0VuQixhQUFhd0ksY0FBNUYsQ0FBWDs7QUM0Q0UsWUFBSTFLLFVBQVVpQyxtQkFBVixJQUFpQyxJQUFyQyxFQUEyQztBRHRDN0NqQyxvQkFBVWlDLG1CQUFWLEdBQWlDLEVBQWpDO0FDd0NHOztBRHZDSGpDLGtCQUFVaUMsbUJBQVYsQ0FBOEJDLFlBQTlCLEdBQTZDQSxZQUE3QztBQUVBNUUsc0JBQWN3RCxRQUFkLEVBQ0U7QUFBQWdFLHFCQUFXO0FBR1QsZ0JBQUEyRCxJQUFBLEVBQUFrQyxLQUFBLEVBQUFDLEtBQUEsRUFBQUMsS0FBQSxFQUFBbEIsZ0JBQUEsRUFBQWhHLE9BQUE7O0FBQUEsZ0JBQUdjLGVBQUg7QUFFRTVDLHNCQUFRQyxXQUFSLENBQW9CLFVBQUE1QyxLQUFBO0FDc0NoQix1QkR0Q2dCO0FBRWxCLHNCQUFBOUIsR0FBQTtBQUFBaUMseUJBQU8sQ0FBSVcsVUFBVXlFLGVBQVYsRUFBWCxFQUF3QyxpQkFBY3pFLFVBQVVxRCxhQUFWLE1BQTZCLFNBQTNDLElBQXFELHNCQUFyRCxJQUEwRSxFQUFBakcsTUFBQTRDLFVBQUF5RSxlQUFBLGNBQUFySCxJQUE4QmlHLGFBQTlCLEtBQUMsTUFBRCxLQUFpRCxTQUEzSCxJQUFxSSxnQkFBN0s7QUFHQXJELDRCQUFVeUUsZUFBVixDQUEwQkEsZUFBMUI7QUNxQ0kseUJEcENKQSxnQkFBZ0J5RCxpQkFBaEIsQ0FBa0NsSSxTQUFsQyxDQ29DSTtBRDFDYyxpQkNzQ2hCO0FEdENnQixxQkFBcEI7QUM2Q0M7O0FEckNILGlCQUFDUCxJQUFELENBQU1xTCxlQUFOLENBQXNCLFVBQUE1TCxLQUFBO0FDdUNsQixxQkR2Q2tCO0FBRXBCLG9CQUFBeUssZ0JBQUEsRUFBQWhHLE9BQUE7O0FBQUEsb0JBQWN6RSxNQUFDTyxJQUFELENBQU1zTCxXQUFOLEtBQXFCLENBQW5DO0FBQUE7QUN5Q0s7O0FEdENMcEIsbUNBQW1CLElBQW5CO0FBQ0FoRywwQkFBQTs7QUN3Q0ksdUJEeENFZ0csbUJBQW1CekssTUFBQ2MsU0FBRCxDQUFXYixZQUFYLENBQXdCd0ssZ0JBQXhCLEVBQTBDLFFBQTFDLENDd0NyQixFRHhDSjtBQ3lDTWhHLDBCQUFRQyxJQUFSLENEeENKN0gsVUFBVW1ELE1BQUNPLElBQVgsRUFBaUJrSyxnQkFBakIsQ0N3Q0k7QUR6Q047O0FDMkNJLHVCQUFPaEcsT0FBUDtBRGpEZ0IsZUN1Q2xCO0FEdkNrQixtQkFBdEI7O0FBU0EsaUJBQUMzRCxTQUFELEdBQWFBLFNBQWI7QUFHQVgsbUJBQU8sQ0FBSXdDLFFBQVFDLFdBQVIsQ0FBb0IsVUFBQTVDLEtBQUE7QUMwQzNCLHFCRDFDMkI7QUFBRyxvQkFBQXVKLElBQUE7QUM0QzVCLHVCQUFPLE9BQU8sQ0FBQ0EsT0FBT3ZKLE1BQU1jLFNBQU4sQ0FBZ0JpQyxtQkFBeEIsRUFBNkNsQyxnQkFBcEQsS0FBeUUsVUFBekUsR0FBc0YwSSxLRDVDbEMxSSxnQkM0Q2tDLEVBQXRGLEdENUNvRCxNQzRDM0Q7QUQ1Q3lCLGVDMEMzQjtBRDFDMkIsbUJBQXBCLENBQVg7O0FDK0NFLGdCQUFJLENBQUMwSSxPQUFPLEtBQUt6SSxTQUFMLENBQWVpQyxtQkFBdkIsRUFBNENsQyxnQkFBNUMsSUFBZ0UsSUFBcEUsRUFBMEU7QUFDeEUwSSxtQkQ5QzJCMUksZ0JDOEMzQixHRDlDK0MsSUFBSWdKLGFBQUosQ0FBa0IsSUFBbEIsRUFBcUIsVUFBQ0MsQ0FBRCxFQUFJQyxDQUFKO0FDK0NsRSx1QkQvQzRFRCxNQUFLQyxDQytDakY7QUQvQzZDLGdCQzhDL0M7QUFHRDs7QURoREgsaUJBQUNqSixTQUFELENBQVdpQyxtQkFBWCxDQUErQmxDLGdCQUEvQixDQUFnRCxJQUFoRDs7QUNrREUsZ0JBQUksQ0FBQzRLLFFBQVEsS0FBSzNLLFNBQUwsQ0FBZWlDLG1CQUF4QixFQUE2Q21ILFNBQTdDLElBQTBELElBQTlELEVBQW9FO0FBQ2xFdUIsb0JEakQyQnZCLFNDaUQzQixHRGpEd0MsSUFBSUwsYUFBSixDQUFrQixJQUFsQixDQ2lEeEM7QUFDRDs7QURqREgsaUJBQUMvSSxTQUFELENBQVdpQyxtQkFBWCxDQUErQm1ILFNBQS9CLENBQXlDLElBQXpDOztBQ21ERSxnQkFBSSxDQUFDd0IsUUFBUSxLQUFLNUssU0FBTCxDQUFlaUMsbUJBQXhCLEVBQTZDcUgsVUFBN0MsSUFBMkQsSUFBL0QsRUFBcUU7QUFDbkVzQixvQkRoRDJCdEIsVUNnRDNCLEdEaER5QyxJQUFJUCxhQUFKLENBQWtCLEtBQWxCLENDZ0R6QztBQUNEOztBRGhESCxpQkFBQy9JLFNBQUQsQ0FBV2lDLG1CQUFYLENBQStCcUgsVUFBL0IsQ0FBMEMsS0FBMUM7O0FDa0RFLGdCQUFJLENBQUN1QixRQUFRLEtBQUs3SyxTQUFMLENBQWVpQyxtQkFBeEIsRUFBNkNpSCxXQUE3QyxJQUE0RCxJQUFoRSxFQUFzRTtBQUNwRTJCLG9CRGpEMkIzQixXQ2lEM0IsR0RqRDBDLElBQUlILGFBQUosQ0FBa0IsS0FBbEIsQ0NpRDFDO0FBQ0Q7O0FEakRILGlCQUFDL0ksU0FBRCxDQUFXaUMsbUJBQVgsQ0FBK0JpSCxXQUEvQixDQUEyQyxLQUEzQzs7QUFFQTtBQUtFLG1CQUFDbEosU0FBRCxDQUFXaUMsbUJBQVgsQ0FBK0JrSCxXQUEvQixHQUE2QyxJQUE3QztBQUNBUSxpQ0FBbUIsSUFBbkI7QUFDQWhHLHdCQUFBOztBQzhDRSxxQkQ5Q0lnRyxtQkFBbUIsS0FBQzNKLFNBQUQsQ0FBV2IsWUFBWCxDQUF3QndLLGdCQUF4QixFQUEwQyxXQUExQyxDQzhDdkIsRUQ5Q0Y7QUMrQ0loRyx3QkFBUUMsSUFBUixDRDlDRitGLGlCQUFpQjdFLFNBQWpCLEVDOENFO0FEL0NKOztBQ2lERSxxQkFBT25CLE9BQVA7QUR4REo7QUFVRSxxQkFBTyxLQUFDM0QsU0FBRCxDQUFXaUMsbUJBQVgsQ0FBK0JrSCxXQUF0QztBQ2lEQztBRHBHTDtBQXFEQXBFLHNCQUFZO0FBR1YsZ0JBQUEwRCxJQUFBLEVBQUFrQixnQkFBQSxFQUFBaEcsT0FBQTs7QUNnREUsZ0JBQUksQ0FBQzhFLE9BQU8sS0FBS3pJLFNBQUwsQ0FBZWlDLG1CQUF2QixFQUE0Q3FILFVBQTVDLElBQTBELElBQTlELEVBQW9FO0FBQ2xFYixtQkRqRDJCYSxVQ2lEM0IsR0RqRHlDLElBQUlQLGFBQUosQ0FBa0IsSUFBbEIsQ0NpRHpDO0FBQ0Q7O0FEakRILGlCQUFDL0ksU0FBRCxDQUFXaUMsbUJBQVgsQ0FBK0JxSCxVQUEvQixDQUEwQyxJQUExQzs7QUFFQXpILG9CQUFRQyxXQUFSLENBQW9CLFVBQUE1QyxLQUFBO0FDa0RoQixxQkRsRGdCO0FDbURkLHVCRGxESkcsT0FBT2dMLEtBQVAsQ0FBYW5MLE1BQUNjLFNBQUQsQ0FBV2lDLG1CQUFYLENBQStCbUgsU0FBL0IsRUFBYixFQUF5RCxJQUF6RCxDQ2tESTtBRG5EYyxlQ2tEaEI7QURsRGdCLG1CQUFwQjs7QUFHQTtBQUVFLG1CQUFDcEosU0FBRCxDQUFXaUMsbUJBQVgsQ0FBK0JvSCxZQUEvQixHQUE4QyxJQUE5QztBQUNBTSxpQ0FBbUIsSUFBbkI7QUFDQWhHLHdCQUFBOztBQ21ERSxxQkRuRElnRyxtQkFBbUIsS0FBQzNKLFNBQUQsQ0FBV2IsWUFBWCxDQUF3QndLLGdCQUF4QixFQUEwQyxZQUExQyxDQ21EdkIsRURuREY7QUNvREloRyx3QkFBUUMsSUFBUixDRG5ERitGLGlCQUFpQjVFLFVBQWpCLEVDbURFO0FEcERKOztBQ3NERSxxQkFBT3BCLE9BQVA7QUQxREo7QUFPRSxxQkFBTyxLQUFDM0QsU0FBRCxDQUFXaUMsbUJBQVgsQ0FBK0JvSCxZQUF0QztBQ3NEQztBRDNITDtBQXVFQXJFLHVCQUFhO0FDdURULG1CRHRERixLQUFDZ0csT0FBRCxDQUFTLFVBQUE5TCxLQUFBO0FDdURMLHFCRHZESyxVQUFDK0wsV0FBRDtBQUtQLG9CQUFVL0wsTUFBQ2MsU0FBRCxDQUFXK0gsZUFBWCxHQUE2QnBKLE1BQXZDO0FBQUE7QUNxREs7O0FEcERMc00sNEJBQVlDLElBQVo7QUNzREksdUJEcERKckosUUFBUUMsV0FBUixDQUFvQjtBQUNsQixzQkFBQTJHLElBQUEsRUFBQWtDLEtBQUEsRUFBQWhCLGdCQUFBO0FBQUF0Syx5QkFBT2dMLEtBQVAsQ0FBYW5MLE1BQUNjLFNBQUQsQ0FBV2lDLG1CQUFYLENBQStCbUgsU0FBL0IsRUFBYixFQUF5RCxJQUF6RDs7QUFFQWxLLHdCQUFDYyxTQUFELENBQVdpQyxtQkFBWCxDQUErQm1ILFNBQS9CLENBQXlDLEtBQXpDOztBQ3FESSxzQkFBSSxDQUFDWCxPQUFPdkosTUFBTWMsU0FBTixDQUFnQmlDLG1CQUF4QixFQUE2Q3FILFVBQTdDLElBQTJELElBQS9ELEVBQXFFO0FBQ25FYix5QkRwRHlCYSxVQ29EekIsR0RwRHVDLElBQUlQLGFBQUosQ0FBa0IsS0FBbEIsQ0NvRHZDO0FBQ0Q7O0FEcERMN0osd0JBQUNjLFNBQUQsQ0FBV2lDLG1CQUFYLENBQStCcUgsVUFBL0IsQ0FBMEMsS0FBMUM7O0FDc0RJLHNCQUFJLENBQUNxQixRQUFRekwsTUFBTWMsU0FBTixDQUFnQmlDLG1CQUF6QixFQUE4Q2lILFdBQTlDLElBQTZELElBQWpFLEVBQXVFO0FBQ3JFeUIsMEJEckR5QnpCLFdDcUR6QixHRHJEd0MsSUFBSUgsYUFBSixDQUFrQixJQUFsQixDQ3FEeEM7QUFDRDs7QURyREw3Six3QkFBQ2MsU0FBRCxDQUFXaUMsbUJBQVgsQ0FBK0JpSCxXQUEvQixDQUEyQyxJQUEzQzs7QUFFQVMscUNBQW1CLElBQW5COztBQUNBLHlCQUFNQSxtQkFBbUJ6SyxNQUFDYyxTQUFELENBQVdiLFlBQVgsQ0FBd0J3SyxnQkFBeEIsRUFBMEMsYUFBMUMsQ0FBekI7QUFDRUEscUNBQWlCM0UsV0FBakI7QUFERjs7QUFHQSxzQkFBR1AsZUFBSDtBQUVFekUsOEJBQVV5RSxlQUFWLENBQTBCLElBQTFCO0FBQ0FBLG9DQUFnQjJELG9CQUFoQixDQUFxQ3BJLFNBQXJDO0FDcURHOztBQUNELHlCRG5ESmQsTUFBQ2MsU0FBRCxDQUFXaUMsbUJBQVgsQ0FBK0JsQyxnQkFBL0IsQ0FBZ0QsSUFBaEQsQ0NtREk7QUR4RU4sa0JDb0RJO0FENURHLGVDdURMO0FEdkRLLG1CQUFULENDc0RFO0FEOUhKO0FBQUEsU0FERjtBQytKRSxlRHZERmUsUUN1REU7QURuTGdCLE9DaURsQjtBRGpEa0IsV0FBcEIsQ0NnREE7QURyRGUsR0NvRGpCOztBQXlJQWlCLGlCQUFlM0QsU0FBZixDRDFEQStNLGVDMERBLEdEMURpQjtBQUNmLFFBQXlFLEtBQUM3QixVQUFELEVBQXpFO0FDMkRFLGFEM0RGNU4sTUFBTTBQLE1BQU4sQ0FBYSxLQUFDcEwsU0FBRCxHQUFhaUMsbUJBQWIsQ0FBaUNsQyxnQkFBakMsR0FBb0ROLElBQWpFLENDMkRFO0FBQ0Q7QUQ3RGMsR0MwRGpCOztBRHZEQXNDLGlCQUFDc0osa0JBQUQsR0FBcUIsVUFBQ0MsT0FBRCxFQUFVN0csZUFBVixFQUEyQjdFLFVBQTNCLEVBQXVDZ0QsSUFBdkM7QUFDbkIsUUFBQTVDLFNBQUE7QUFBQUEsZ0JBQVk2QixRQUFRQyxXQUFSLENBQW9CLFVBQUE1QyxLQUFBO0FDK0Q5QixhRC9EOEI7QUFDOUIsWUFBQTRLLGNBQUE7QUFBQUEseUJBQWlCNUssS0FBakI7QUFFQVUscUJBQWFBLGNBQWNyRCx3QkFBZCxJQUEwQyxDQUFBa0ksbUJBQUEsT0FBQ0EsZ0JBQWlCNkUsVUFBakIsRUFBRCxHQUFDLE1BQUQsS0FBbUM3RSxnQkFBZ0J4QyxtQkFBaEIsQ0FBb0NsQyxnQkFBcEMsR0FBdUROLElBQXBJLElBQTZJLElBQTFKO0FDZ0VFLGVEOURGL0Isb0JBQW9Ca0MsVUFBcEIsRUFBZ0M7QUMrRDVCLGlCRDlERixJQUFJa0ssY0FBSixFQzhERTtBRC9ESixVQzhERTtBRG5FNEIsT0MrRDlCO0FEL0Q4QixXQUFwQixDQUFaOztBQVFBLFFBQUd4SixVQUFVM0IsTUFBVixHQUFtQixDQUF0QjtBQ2lFRSxhRGhFQXFCLFVBQVVxTCxrQkFBVixDQUE2QkMsT0FBN0IsRUFBc0M3RyxlQUF0QyxFQUF1RDdFLFVBQXZELEVBQW1FZ0QsSUFBbkUsQ0NnRUE7QURqRUY7QUNtRUUsYURoRUE1QyxVQUFVcUwsa0JBQVYsQ0FBNkJDLE9BQTdCLEVBQXNDN0csZUFBdEMsRUFBdUQ3RSxVQUF2RCxDQ2dFQTtBQUNEO0FEN0VrQixHQUFyQjs7QUFjQW1DLGlCQUFDd0oscUJBQUQsR0FBd0IsVUFBQzlHLGVBQUQsRUFBa0I3RSxVQUFsQixFQUE4QmdELElBQTlCO0FBQ3RCLFFBQUd0QyxVQUFVM0IsTUFBVixHQUFtQixDQUF0QjtBQ21FRSxhRGxFQSxLQUFDME0sa0JBQUQsQ0FBb0IsSUFBSXZGLEtBQUtPLGFBQVQsRUFBcEIsRUFBOEM1QixlQUE5QyxFQUErRDdFLFVBQS9ELEVBQTJFZ0QsSUFBM0UsQ0NrRUE7QURuRUY7QUNxRUUsYURsRUEsS0FBQ3lJLGtCQUFELENBQW9CLElBQUl2RixLQUFLTyxhQUFULEVBQXBCLEVBQThDNUIsZUFBOUMsRUFBK0Q3RSxVQUEvRCxDQ2tFQTtBQUNEO0FEdkVxQixHQUF4Qjs7QUMwRUFtQyxpQkFBZTNELFNBQWYsQ0RwRUFpTixrQkNvRUEsR0RwRW9CLFVBQUNDLE9BQUQsRUFBVTdHLGVBQVYsRUFBMkI3RSxVQUEzQixFQUF1Q2dELElBQXZDO0FBQ2xCLFFBQUE0SSxZQUFBLEVBQUExSyxRQUFBO0FBQUFBLGVBQVdlLFFBQVFDLFdBQVIsQ0FBb0IsVUFBQTVDLEtBQUE7QUNzRTdCLGFEdEU2QjtBQUM3QlUscUJBQWFBLGNBQWNyRCx3QkFBZCxJQUEwQyxDQUFBa0ksbUJBQUEsT0FBQ0EsZ0JBQWlCNkUsVUFBakIsRUFBRCxHQUFDLE1BQUQsS0FBbUM3RSxnQkFBZ0J4QyxtQkFBaEIsQ0FBb0NsQyxnQkFBcEMsR0FBdUROLElBQXBJLElBQTZJLElBQTFKO0FDdUVFLGVEckVGL0Isb0JBQW9Ca0MsVUFBcEIsRUFBZ0M7QUNzRTVCLGlCRHJFRlYsTUFBQ2MsU0FBRCxHQUFhNEUsZUFBYixDQUE2QkgsZUFBN0IsQ0NxRUU7QUR0RUosVUNxRUU7QUR4RTJCLE9Dc0U3QjtBRHRFNkIsV0FBcEIsQ0FBWDs7QUFNQSxRQUFHbkUsVUFBVTNCLE1BQVYsR0FBbUIsQ0FBdEI7QUFDRTZNLHFCQUFlL08sV0FBV2YsTUFBTStQLGFBQU4sQ0FBb0I3SSxJQUFwQixFQUEwQnhHLGNBQWMwRSxRQUFkLENBQTFCLENBQVgsRUFBOERsQixVQUE5RCxDQUFmO0FBREY7QUFHRTRMLHFCQUFlL08sV0FBV0osY0FBY3lFLFFBQWQsQ0FBWCxFQUFvQ2xCLFVBQXBDLENBQWY7QUN3RUQ7O0FBQ0QsV0R2RUEwTCxRQUFRcEUsS0FBUixDQUFjc0UsWUFBZCxDQ3VFQTtBRG5Ga0IsR0NvRXBCOztBQWtCQXpKLGlCQUFlM0QsU0FBZixDRHhFQW1OLHFCQ3dFQSxHRHhFdUIsVUFBQzlHLGVBQUQsRUFBa0I3RSxVQUFsQixFQUE4QmdELElBQTlCO0FBQ3JCLFFBQUd0QyxVQUFVM0IsTUFBVixHQUFtQixDQUF0QjtBQ3lFRSxhRHhFQSxLQUFDME0sa0JBQUQsQ0FBb0IsSUFBSXZGLEtBQUtPLGFBQVQsRUFBcEIsRUFBOEM1QixlQUE5QyxFQUErRDdFLFVBQS9ELEVBQTJFZ0QsSUFBM0UsQ0N3RUE7QUR6RUY7QUMyRUUsYUR4RUEsS0FBQ3lJLGtCQUFELENBQW9CLElBQUl2RixLQUFLTyxhQUFULEVBQXBCLEVBQThDNUIsZUFBOUMsRUFBK0Q3RSxVQUEvRCxDQ3dFQTtBQUNEO0FEN0VvQixHQ3dFdkI7O0FBUUFtQyxpQkFBZTNELFNBQWYsQ0QxRUEwQyxRQzBFQSxHRDFFVTtBQzJFUixXRDFFQSxLQUFDMkksYUFBRCxDQUFlLElBQWYsRUFBa0IsVUFBbEIsS0FBaUMsS0FBQ3RMLFdBQUQsQ0FBYWtGLGFBQWIsRUMwRWpDO0FEM0VRLEdDMEVWOztBQUlBdEIsaUJBQWUzRCxTQUFmLENEM0VBMEcsU0MyRUEsR0QzRVc7QUM0RVQsV0QzRUEzSSxzQkFBc0IsSUFBdEIsRUFBeUIsU0FBekIsQ0MyRUE7QUQ1RVMsR0MyRVg7O0FBSUE0RixpQkFBZTNELFNBQWYsQ0Q1RUEyRyxVQzRFQSxHRDVFWTtBQzZFVixXRDVFQTVJLHNCQUFzQixJQUF0QixFQUF5QixVQUF6QixDQzRFQTtBRDdFVSxHQzRFWjs7QUFJQTRGLGlCQUFlM0QsU0FBZixDRDdFQTRHLFdDNkVBLEdEN0VhO0FDOEVYLFdEN0VBN0ksc0JBQXNCLElBQXRCLEVBQXlCLFdBQXpCLENDNkVBO0FEOUVXLEdDNkViOztBQUlBNEYsaUJBQWUzRCxTQUFmLENEOUVBZ0wsU0M4RUEsR0Q5RVc7QUFDVCxRQUFBWCxJQUFBLEVBQUF6SSxTQUFBO0FBQUFBLGdCQUFZLEtBQUNBLFNBQUQsRUFBWjs7QUNnRkEsUUFBSUEsVUFBVWlDLG1CQUFWLElBQWlDLElBQXJDLEVBQTJDO0FEOUUzQ2pDLGdCQUFVaUMsbUJBQVYsR0FBaUMsRUFBakM7QUNnRkM7O0FBQ0QsUUFBSSxDQUFDd0csT0FBT3pJLFVBQVVpQyxtQkFBbEIsRUFBdUNtSCxTQUF2QyxJQUFvRCxJQUF4RCxFQUE4RDtBQUM1RFgsV0RqRjRCVyxTQ2lGNUIsR0RqRnlDLElBQUlMLGFBQUosQ0FBa0IsS0FBbEIsQ0NpRnpDO0FBQ0Q7O0FBQ0QsV0RqRkEvSSxVQUFVaUMsbUJBQVYsQ0FBOEJtSCxTQUE5QixFQ2lGQTtBRHZGUyxHQzhFWDs7QUFZQXJILGlCQUFlM0QsU0FBZixDRGxGQWtMLFVDa0ZBLEdEbEZZO0FBQ1YsUUFBQWIsSUFBQSxFQUFBekksU0FBQTtBQUFBQSxnQkFBWSxLQUFDQSxTQUFELEVBQVo7O0FDb0ZBLFFBQUlBLFVBQVVpQyxtQkFBVixJQUFpQyxJQUFyQyxFQUEyQztBRGxGM0NqQyxnQkFBVWlDLG1CQUFWLEdBQWlDLEVBQWpDO0FDb0ZDOztBQUNELFFBQUksQ0FBQ3dHLE9BQU96SSxVQUFVaUMsbUJBQWxCLEVBQXVDcUgsVUFBdkMsSUFBcUQsSUFBekQsRUFBK0Q7QUFDN0RiLFdEckY0QmEsVUNxRjVCLEdEckYwQyxJQUFJUCxhQUFKLENBQWtCLEtBQWxCLENDcUYxQztBQUNEOztBQUNELFdEckZBL0ksVUFBVWlDLG1CQUFWLENBQThCcUgsVUFBOUIsRUNxRkE7QUQzRlUsR0NrRlo7O0FBWUF2SCxpQkFBZTNELFNBQWYsQ0R0RkE4SyxXQ3NGQSxHRHRGYTtBQUNYLFFBQUFULElBQUEsRUFBQXpJLFNBQUE7QUFBQUEsZ0JBQVksS0FBQ0EsU0FBRCxFQUFaOztBQ3dGQSxRQUFJQSxVQUFVaUMsbUJBQVYsSUFBaUMsSUFBckMsRUFBMkM7QUR0RjNDakMsZ0JBQVVpQyxtQkFBVixHQUFpQyxFQUFqQztBQ3dGQzs7QUFDRCxRQUFJLENBQUN3RyxPQUFPekksVUFBVWlDLG1CQUFsQixFQUF1Q2lILFdBQXZDLElBQXNELElBQTFELEVBQWdFO0FBQzlEVCxXRHpGNEJTLFdDeUY1QixHRHpGMkMsSUFBSUgsYUFBSixDQUFrQixLQUFsQixDQ3lGM0M7QUFDRDs7QUFDRCxXRHpGQS9JLFVBQVVpQyxtQkFBVixDQUE4QmlILFdBQTlCLEVDeUZBO0FEL0ZXLEdDc0ZiOztBQVlBbkgsaUJBQWUzRCxTQUFmLENEMUZBc04sZ0JDMEZBLEdEMUZrQixVQUFDNU4sTUFBRCxFQUFTNk4sSUFBVCxFQUFlQyxNQUFmO0FDMkZoQixRQUFJQSxVQUFVLElBQWQsRUFBb0I7QUQxRnBCQSxlQUFVLElBQVY7QUM0RkM7O0FEM0ZELFFBQUc5TixVQUFXNk4sSUFBWCxLQUFxQkEsS0FBS0UsVUFBTCxLQUFxQi9OLE1BQXJCLElBQStCNk4sS0FBS0csV0FBTCxLQUFzQkYsTUFBMUUsQ0FBSDtBQUNFOU4sYUFBT2lPLFlBQVAsQ0FBb0JKLElBQXBCLEVBQTBCQyxNQUExQjtBQzZGRDtBRGhHZSxHQzBGbEI7O0FBU0E3SixpQkFBZTNELFNBQWYsQ0Q1RkE0TixjQzRGQSxHRDVGZ0IsVUFBQ2xPLE1BQUQsRUFBUzZOLElBQVQsRUFBZUMsTUFBZjtBQzZGZCxRQUFJQSxVQUFVLElBQWQsRUFBb0I7QUQ1RnBCQSxlQUFVLElBQVY7QUM4RkM7O0FEN0ZELFFBQUc5TixVQUFXNk4sSUFBWCxLQUFxQkEsS0FBS0UsVUFBTCxLQUFxQi9OLE1BQXJCLElBQStCNk4sS0FBS0csV0FBTCxLQUFzQkYsTUFBMUUsQ0FBSDtBQUNFOU4sYUFBT2lPLFlBQVAsQ0FBb0JKLElBQXBCLEVBQTBCQyxNQUExQjtBQytGRDtBRGxHYSxHQzRGaEI7O0FBU0E3SixpQkFBZTNELFNBQWYsQ0Q5RkE2TixnQkM4RkEsR0Q5RmtCLFVBQUNuTyxNQUFELEVBQVM2TixJQUFUO0FBQ2hCLFFBQUc3TixVQUFXNk4sSUFBWCxJQUFvQkEsS0FBS0UsVUFBTCxLQUFtQi9OLE1BQTFDO0FBQ0VBLGFBQU9vTyxXQUFQLENBQW1CUCxJQUFuQjtBQytGRDtBRGpHZSxHQzhGbEI7O0FBTUE1SixpQkFBZTNELFNBQWYsQ0Q5RkE0RixNQzhGQSxHRDlGUTtBQUVOLFFBQUFELFFBQUEsRUFBQUMsTUFBQSxFQUFBRSxFQUFBLEVBQUFDLE9BQUEsRUFBQTFGLENBQUEsRUFBQWlGLEdBQUEsRUFBQXRHLEdBQUEsRUFBQXVHLE9BQUEsRUFBQVMsSUFBQSxFQUFBckUsZ0JBQUEsRUFBQU4sSUFBQTs7QUFBQSxRQUFpQixTQUFLLEtBQUNPLFNBQUQsRUFBdEI7QUFBQSxhQUFPLEVBQVA7QUNnR0M7O0FBQ0QsUUFBSSxLQUFLaUMsbUJBQUwsSUFBNEIsSUFBaEMsRUFBc0M7QUQvRnRDLFdBQUNBLG1CQUFELEdBQXdCLEVBQXhCO0FDaUdDOztBRC9GRHhDLFdBQU9vQyxRQUFRQyxXQUFSLENBQW9CLFVBQUE1QyxLQUFBO0FDaUd6QixhRGpHeUI7QUNrR3ZCLGVEakdGQSxNQUFDK0MsbUJBQUQsQ0FBcUJsQyxnQkFBckIsR0FBd0NOLElDaUd0QztBRGxHdUIsT0NpR3pCO0FEakd5QixXQUFwQixDQUFQO0FBR0FNLHVCQUFtQm5ELDRCQUE0QjZDLElBQTVCLEVBQWtDLElBQWxDLENBQW5CO0FBRUFyQyxVQUFBLEtBQUE2RSxtQkFBQSxDQUFBQyxZQUFBLENBQUFpSyxXQUFBO0FBQUF4SSxjQUFBOztBQ21HQSxTRG5HQWxGLElBQUEsR0FBQWlGLE1BQUF0RyxJQUFBdUIsTUNtR0EsRURuR0FGLElBQUFpRixHQ21HQSxFRG5HQWpGLEdDbUdBLEVEbkdBO0FDb0dFdUYsZUFBUzVHLElBQUlxQixDQUFKLENBQVQ7QURuR0FzRixpQkFBVyxFQUFYOztBQ3FHQUcsV0RsR0ssVUFBQ0UsSUFBRCxFQUFPRCxPQUFQO0FDbUdILGVEbEdFSixTQUFTSyxJQUFULElBQWlCO0FBSWYsY0FBQS9ELElBQUE7QUFKZ0JBLGlCQUFBLEtBQUFDLFVBQUEzQixNQUFBLEdBQUFoQixNQUFBTSxJQUFBLENBQUFxQyxTQUFBO0FDcUdsQixpQkRqR0U5Qyx5QkFBeUJ1QyxnQkFBekIsRUFBMkM7QUNrRzNDLG1CRGpHRXJFLE1BQU1vSSxnQkFBTixDQUF1QnJFLElBQXZCLEVBQTZCO0FDa0c3QixxQkRqR0UwRSxRQUFRMUQsS0FBUixDQUFjaEIsSUFBZCxFQUFvQlksSUFBcEIsQ0NpR0Y7QURsR0EsY0NpR0Y7QURsR0EsWUNpR0Y7QURyR2lCLFNDa0duQjtBRG5HRyxPQ2tHTDs7QURuR0EsV0FBQStELElBQUEsMkNBQUFKLE1BQUE7QUMrR0VHLGtCQUFVSCxPQUFPSSxJQUFQLENBQVY7QUFDQUYsV0QvR0lFLElDK0dKLEVEL0dVRCxPQytHVjtBRGhIRjs7QUNrSEFSLGNBQVFDLElBQVIsQ0R4R0FHLFFDd0dBO0FEckhGOztBQ3VIQSxXQUFPSixPQUFQO0FEbElNLEdDOEZSOztBQXVDQTVCLGlCQUFlM0QsU0FBZixDRHZHQXdFLElDdUdBLEdEdkdNLFVBQUN3SixJQUFELEVBQU9DLFVBQVA7QUFDSixRQUFBNUQsSUFBQSxFQUFBekksU0FBQSxFQUFBNUMsR0FBQSxFQUFBcUMsSUFBQTtBQUFBTyxnQkFBWSxLQUFDQSxTQUFELEVBQVo7O0FDeUdBLFFBQUlBLFVBQVVpQyxtQkFBVixJQUFpQyxJQUFyQyxFQUEyQztBRHZHM0NqQyxnQkFBVWlDLG1CQUFWLEdBQWlDLEVBQWpDO0FDeUdDOztBQUNELFFBQUksQ0FBQ3dHLE9BQU96SSxVQUFVaUMsbUJBQWxCLEVBQXVDbEMsZ0JBQXZDLElBQTJELElBQS9ELEVBQXFFO0FBQ25FMEksV0QxRzRCMUksZ0JDMEc1QixHRDFHZ0QsSUFBSWdKLGFBQUosQ0FBa0IsSUFBbEIsRUFBd0IsVUFBQ0MsQ0FBRCxFQUFJQyxDQUFKO0FDMkd0RSxlRDNHZ0ZELE1BQUtDLENDMkdyRjtBRDNHOEMsUUMwR2hEO0FBR0Q7O0FEM0dELFFBQUd4SixPQUFBLENBQUFyQyxNQUFBNEMsVUFBQWlDLG1CQUFBLENBQUFsQyxnQkFBQSxjQUFBM0MsSUFBeURxQyxJQUF6RCxHQUF5RCxNQUE1RDtBQUNFLFVBQUcyTSxRQUFBLElBQUg7QUFLRSxlQUFPMVEsTUFBTW9JLGdCQUFOLENBQXVCLElBQXZCLEVBQTZCLFVBQUE1RSxLQUFBO0FDeUdsQyxpQkR6R2tDO0FDMEdoQyxtQkR6R0ZvTixXQUFXL0ssR0FBWCxDQUFlO0FDMEdYLHFCRHpHRjdGLE1BQU1tSCxPQUFOLENBQWNwRCxJQUFkLENDeUdFO0FEMUdKLGVBR0UyTSxJQUhGLEVBR1FDLFVBSFIsQ0N5R0U7QUQxR2dDLFdDeUdsQztBRHpHa0MsZUFBN0IsQ0FBUDtBQUxGO0FBV0UsZUFBTzNRLE1BQU1tSCxPQUFOLENBQWNwRCxJQUFkLENBQVA7QUFaSjtBQ3dIQzs7QUFDRCxXRDNHQSxNQzJHQTtBRC9ISSxHQ3VHTjs7QUQxRUFzQyxpQkFBQ2dJLFdBQUQsR0FBYyxVQUFDcUMsSUFBRCxFQUFPQyxVQUFQO0FBQ1osUUFBQXhJLFdBQUE7O0FBQUEsU0FBd0JuSSxNQUFNbUksV0FBOUI7QUFBQSxhQUFPLE1BQVA7QUN3R0M7O0FEdEdEQSxrQkFBY25JLE1BQU1tSSxXQUFwQjs7QUFFQSxRQUFHN0UsRUFBRUMsUUFBRixDQUFXbU4sSUFBWCxDQUFIO0FBQ0VBLGFBQU9BLEtBQUtHLEtBQUwsQ0FBVyxHQUFYLENBQVA7QUFERixXQUVLLElBQUcsQ0FBSXZOLEVBQUV5RCxPQUFGLENBQVUySixJQUFWLENBQVA7QUFDSCxhQUFPMVEsTUFBTW1ILE9BQU4sQ0FBY2dCLFdBQWQsQ0FBUDtBQ3VHRDs7QUFDRCxXRGxHQW5JLE1BQU1vSSxnQkFBTixDQUF1QixJQUF2QixFQUE2QixVQUFBNUUsS0FBQTtBQ21HM0IsYURuRzJCO0FDb0d6QixlRG5HRm9OLFdBQVcvSyxHQUFYLENBQWU7QUFDYixjQUFBaUwsV0FBQSxFQUFBbkssTUFBQTs7QUFBQSxjQUFHM0csTUFBTStRLHFCQUFOLEtBQWdDRCxjQUFjOVEsTUFBTStRLHFCQUFOLENBQTRCNUksV0FBNUIsRUFBeUN1SSxLQUFLLENBQUwsQ0FBekMsQ0FBOUMsQ0FBSDtBQUdFL0oscUJBQVMsRUFBVDtBQUNBQSxtQkFBTytKLEtBQUssQ0FBTCxDQUFQLElBQWtCSSxXQUFsQjtBQUNBLG1CQUFPbkssTUFBUDtBQ21HQzs7QUFDRCxpQkRsR0YzRyxNQUFNbUgsT0FBTixDQUFjZ0IsV0FBZCxDQ2tHRTtBRDFHSixXQVVFdUksSUFWRixFQVVRQyxVQVZSLENDbUdFO0FEcEd5QixPQ21HM0I7QURuRzJCLFdBQTdCLENDa0dBO0FEaEhZLEdBQWQ7O0FDK0hBdEssaUJBQWUzRCxTQUFmLENEbkdBMkwsV0NtR0EsR0RuR2EsVUFBQ3FDLElBQUQsRUFBT0MsVUFBUDtBQ29HWCxXRG5HQSxLQUFDbE8sV0FBRCxDQUFhNEwsV0FBYixDQUF5QnFDLElBQXpCLEVBQStCQyxVQUEvQixDQ21HQTtBRHBHVyxHQ21HYjs7QUFJQXRLLGlCQUFlM0QsU0FBZixDRG5HQTRCLFNDbUdBLEdEbkdXO0FBQ1QsUUFBQUEsU0FBQSxFQUFBc0ksV0FBQTtBQUFBdEksZ0JBQVksSUFBWjs7QUFFQTtBQUVFLFdBQW1CQSxVQUFVc0ksV0FBN0I7QUFBQSxlQUFPLElBQVA7QUNvR0M7O0FEakdELFlBQXdCQSxjQUFjdEksVUFBVXNJLFdBQVYsRUFBdEM7QUFBQSxlQUFPdEksU0FBUDtBQ29HQzs7QURuR0RBLGtCQUFZc0ksV0FBWjtBQU5GO0FBSFMsR0NtR1g7O0FEcEZBdkcsaUJBQUMyQyxnQkFBRCxHQUFtQjtBQUdqQixRQUFBM0UsZ0JBQUE7QUFBQUEsdUJBQW1CbkQsNEJBQTRCbEIsTUFBTW1JLFdBQWxDLEVBQStDLEtBQS9DLENBQW5CO0FDa0dBLFdEakdBdEcsNEJBQTRCd0MsZ0JBQTVCLEVBQThDLEtBQTlDLENDaUdBO0FEckdpQixHQUFuQjs7QUN3R0FnQyxpQkFBZTNELFNBQWYsQ0RqR0FzRyxnQkNpR0EsR0RqR2tCO0FDa0doQixXRGpHQSxLQUFDdkcsV0FBRCxDQUFhdUcsZ0JBQWIsRUNpR0E7QURsR2dCLEdDaUdsQjs7QUFJQTNDLGlCQUFlM0QsU0FBZixDRGxHQXNPLFNDa0dBLEdEbEdXO0FBQ1QsUUFBeUYsS0FBQ3BELFVBQUQsRUFBekY7QUFBQSxhQUFPLEtBQUN0SixTQUFELEdBQWFpQyxtQkFBYixDQUFpQ2xDLGdCQUFqQyxHQUFvRE4sSUFBcEQsQ0FBeURrTixTQUF6RCxDQUFtRUQsU0FBbkUsRUFBUDtBQ29HQzs7QUFDRCxXRG5HQSxNQ21HQTtBRHRHUyxHQ2tHWDs7QUFPQTNLLGlCQUFlM0QsU0FBZixDRHBHQXdPLFFDb0dBLEdEcEdVO0FBQ1IsUUFBd0YsS0FBQ3RELFVBQUQsRUFBeEY7QUFBQSxhQUFPLEtBQUN0SixTQUFELEdBQWFpQyxtQkFBYixDQUFpQ2xDLGdCQUFqQyxHQUFvRE4sSUFBcEQsQ0FBeURrTixTQUF6RCxDQUFtRUMsUUFBbkUsRUFBUDtBQ3NHQzs7QUFDRCxXRHJHQSxNQ3FHQTtBRHhHUSxHQ29HVjs7QUFPQTdLLGlCQUFlM0QsU0FBZixDRHJHQTRNLE9DcUdBLEdEckdTLFVBQUM2QixPQUFEO0FBQ1AsUUFBQTlNLGdCQUFBO0FBQUFBLHVCQUFtQjhCLFFBQVFDLFdBQVIsQ0FBb0IsVUFBQTVDLEtBQUE7QUN1R3JDLGFEdkdxQztBQUNyQyxZQUFBOUIsR0FBQTtBQ3dHRSxlQUFPLENBQUNBLE1BQU04QixNQUFNYyxTQUFOLEdBQWtCaUMsbUJBQXpCLEtBQWlELElBQWpELEdBQXdELE9BQU83RSxJQUFJMkMsZ0JBQVgsS0FBZ0MsVUFBaEMsR0FBNkMzQyxJRHhHNUUyQyxnQkN3RzRFLEVBQTdDLEdEeEcvQixNQ3dHekIsR0R4R3lCLE1Dd0doQztBRHpHbUMsT0N1R3JDO0FEdkdxQyxXQUFwQixDQUFuQjs7QUFHQSxTQUFtRkEsZ0JBQW5GO0FBQUEsWUFBTSxJQUFJcUQsS0FBSixDQUFVLDJEQUFWLENBQU47QUMyR0M7O0FBQ0QsV0QxR0FyRCxpQkFBaUJpTCxPQUFqQixDQUF5QmhNLEVBQUV3RCxJQUFGLENBQU9xSyxPQUFQLEVBQWdCLElBQWhCLENBQXpCLENDMEdBO0FEaEhPLEdDcUdUOztBQWNBLFNBQU85SyxjQUFQO0FBRUQsQ0QzdUJLLENBQXVCK0ssYUFBdkI7O0FBOG5CTmhSLDZCQUE2QixDQUMzQixvQkFEMkIsQ0FBN0I7QUFJQUQsNEJBQTRCLENBQzFCLEdBRDBCLEVBRTFCLE1BRjBCLEVBRzFCLFNBSDBCLENBQTVCO0FBUUF1QixNQUFBMUIsTUFBQXFSLGdCQUFBLENBQUEzTyxTQUFBOztBQUFBLEtBQUF0QixVQUFBLDJDQUFBTSxHQUFBO0FDeUdFUCxXQUFTTyxJQUFJTixVQUFKLENBQVQ7O0FBQ0EsTUQxR3dELEVBQUFBLGNBQW1CaUYsZUFBYzNELFNBQWpDLENDMEd4RCxFRDFHd0Q7QUFDckQsZUFBQ3RCLFVBQUQsRUFBYUQsTUFBYjtBQUNELFVBQUcwQixRQUFBTixJQUFBLENBQWNuQywwQkFBZCxFQUFBZ0IsVUFBQSxNQUFIO0FDMkdJLGVEMUdGaUYsZUFBYzNELFNBQWQsQ0FBaUJ0QixVQUFqQixJQUErQjtBQUM3QixjQUFBdUQsSUFBQSxFQUFBb0ksSUFBQSxFQUFBekksU0FBQSxFQUFBRCxnQkFBQTtBQUQ4Qk0saUJBQUEsS0FBQUMsVUFBQTNCLE1BQUEsR0FBQWhCLE1BQUFNLElBQUEsQ0FBQXFDLFNBQUE7QUFDOUJOLHNCQUFZLEtBQUNBLFNBQUQsRUFBWjs7QUM2R0UsY0FBSUEsVUFBVWlDLG1CQUFWLElBQWlDLElBQXJDLEVBQTJDO0FEM0c3Q2pDLHNCQUFVaUMsbUJBQVYsR0FBaUMsRUFBakM7QUM2R0c7O0FBQ0QsY0FBSSxDQUFDd0csT0FBT3pJLFVBQVVpQyxtQkFBbEIsRUFBdUNsQyxnQkFBdkMsSUFBMkQsSUFBL0QsRUFBcUU7QUFDbkUwSSxpQkQ5RzBCMUksZ0JDOEcxQixHRDlHOEMsSUFBSWdKLGFBQUosQ0FBa0IsSUFBbEIsRUFBd0IsVUFBQ0MsQ0FBRCxFQUFJQyxDQUFKO0FDK0dwRSxxQkQvRzhFRCxNQUFLQyxDQytHbkY7QUQvRzRDLGNDOEc5QztBQUdEOztBRC9HSCxjQUFHbEosbUJBQW1CQyxVQUFVaUMsbUJBQVYsQ0FBOEJsQyxnQkFBOUIsRUFBdEI7QUFDRSxtQkFBT0EsaUJBQWlCakQsVUFBakIsRUFBQTJELEtBQUEsQ0FBQVYsZ0JBQUEsRUFBNkJNLElBQTdCLENBQVA7QUNpSEM7O0FBQ0QsaUJEaEhGLE1DZ0hFO0FEekgyQixTQzBHN0I7QUQzR0osYUFZSyxJQUFHOUIsUUFBQU4sSUFBQSxDQUFjcEMseUJBQWQsRUFBQWlCLFVBQUEsTUFBSDtBQ2lIRCxlRGhIRmlGLGVBQWMzRCxTQUFkLENBQWlCdEIsVUFBakIsSUFBK0I7QUFDN0IsY0FBQXVELElBQUEsRUFBQWMsSUFBQTtBQUQ4QmQsaUJBQUEsS0FBQUMsVUFBQTNCLE1BQUEsR0FBQWhCLE1BQUFNLElBQUEsQ0FBQXFDLFNBQUE7O0FBQzlCLGNBQWtGLEtBQUNnSixVQUFELEVBQWxGO0FBQUEsbUJBQU8sQ0FBQW5JLE9BQUEsS0FBQ25CLFNBQUQsR0FBYWlDLG1CQUFiLENBQWlDbEMsZ0JBQWpDLElBQW9EakQsVUFBcEQsRUFBQTJELEtBQUEsQ0FBQVUsSUFBQSxFQUFnRWQsSUFBaEUsQ0FBUDtBQ29IRzs7QUFDRCxpQkRuSEYsTUNtSEU7QUR0SDJCLFNDZ0g3QjtBRGpIQztBQzBIRCxlRG5IRjBCLGVBQWMzRCxTQUFkLENBQWlCdEIsVUFBakIsSUFBK0I7QUFDN0IsY0FBQXVELElBQUEsRUFBQU4sZ0JBQUE7QUFEOEJNLGlCQUFBLEtBQUFDLFVBQUEzQixNQUFBLEdBQUFoQixNQUFBTSxJQUFBLENBQUFxQyxTQUFBO0FBQzlCUCw2QkFBbUI4QixRQUFRQyxXQUFSLENBQW9CLFVBQUE1QyxLQUFBO0FDc0huQyxtQkR0SG1DO0FBQ3JDLGtCQUFBaUMsSUFBQTtBQ3VISSxxQkFBTyxDQUFDQSxPQUFPakMsTUFBTWMsU0FBTixHQUFrQmlDLG1CQUExQixLQUFrRCxJQUFsRCxHQUF5RCxPQUFPZCxLQUFLcEIsZ0JBQVosS0FBaUMsVUFBakMsR0FBOENvQixLRHZIaEZwQixnQkN1SGdGLEVBQTlDLEdEdkhsQyxNQ3VIdkIsR0R2SHVCLE1DdUg5QjtBRHhIaUMsYUNzSG5DO0FEdEhtQyxpQkFBcEIsQ0FBbkI7O0FBR0EsZUFBeUZBLGdCQUF6RjtBQUFBLGtCQUFNLElBQUlxRCxLQUFKLENBQVUscURBQW1EdEcsVUFBbkQsR0FBOEQsSUFBeEUsQ0FBTjtBQzBIRzs7QUFDRCxpQkR6SEZpRCxpQkFBaUJqRCxVQUFqQixFQUFBMkQsS0FBQSxDQUFBVixnQkFBQSxFQUE2Qk0sSUFBN0IsQ0N5SEU7QUQvSDJCLFNDbUg3QjtBQWNEO0FEckpGLE9BQUN2RCxVQUFELEVBQWFELE1BQWI7QUN1SkY7QUR4SkgsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBRTFtQ0EsSUFBQWUsU0FBQSxVQUFBQyxLQUFBLEVBQUFDLE1BQUE7QUFBQSxXQUFBQyxHQUFBLDJDQUFBRCxNQUFBO0FBQUEsUUFBQUUsUUFBQUMsSUFBQSxDQUFBSCxNQUFBLEVBQUFDLEdBQUEsR0FBQUYsTUFBQUUsR0FBQSxJQUFBRCxPQUFBQyxHQUFBO0FBQUE7O0FBQUEsV0FBQUcsSUFBQTtBQUFBLFNBQUFDLFdBQUEsR0FBQU4sS0FBQTtBQUFBOztBQUFBSyxPQUFBRSxTQUFBLEdBQUFOLE9BQUFNLFNBQUE7QUFBQVAsUUFBQU8sU0FBQSxPQUFBRixJQUFBO0FBQUFMLFFBQUFRLFNBQUEsR0FBQVAsT0FBQU0sU0FBQTtBQUFBLFNBQUFQLEtBQUE7QUFBQTtBQUFBLElDRUVHLFVBQVUsR0FBR00sY0RGZjtBQUFBLElDR0VDLFVBQVUsR0FBR0EsT0FBSCxJQUFjLFVBQVNDLElBQVQsRUFBZTtBQUFFLE9BQUssSUFBSUMsSUFBSSxDQUFSLEVBQVdDLElBQUksS0FBS0MsTUFBekIsRUFBaUNGLElBQUlDLENBQXJDLEVBQXdDRCxHQUF4QyxFQUE2QztBQUFFLFFBQUlBLEtBQUssSUFBTCxJQUFhLEtBQUtBLENBQUwsTUFBWUQsSUFBN0IsRUFBbUMsT0FBT0MsQ0FBUDtBQUFXOztBQUFDLFNBQU8sQ0FBQyxDQUFSO0FBQVksQ0RIcko7O0FBQU11TyxzQkFBQSxVQUFBdkYsVUFBQTtBQ01KN0osU0FBT29QLG1CQUFQLEVBQTRCdkYsVUFBNUI7O0FBRUEsV0FBU3VGLG1CQUFULEdBQStCO0FBQzdCLFdBQU9BLG9CQUFvQjNPLFNBQXBCLENBQThCRixXQUE5QixDQUEwQ3NDLEtBQTFDLENBQWdELElBQWhELEVBQXNESCxTQUF0RCxDQUFQO0FBQ0Q7O0FEVEQwTSxzQkFBQ0MsY0FBRCxHQUFpQixVQUFDak4sU0FBRDtBQUNmZ04sd0JBQUEzTyxTQUFBLENBQUFGLFdBQUEsQ0FBQThPLGNBQUEsQ0FBQXhNLEtBQUEsT0FBQUgsU0FBQTs7QUNZQSxXRFZBNE0sUUFBUUMsR0FBUixDQUFZbk4sVUFBVTRDLElBQVYsRUFBWixDQ1VBO0FEYmUsR0FBakI7O0FBS0FvSyxzQkFBQ0ksb0JBQUQsR0FBdUIsVUFBQ3BOLFNBQUQ7QUFDckJnTix3QkFBQTNPLFNBQUEsQ0FBQUYsV0FBQSxDQUFBaVAsb0JBQUEsQ0FBQTNNLEtBQUEsT0FBQUgsU0FBQTs7QUNZQSxXRFZBNE0sUUFBUUMsR0FBUixDQUFZbk4sVUFBVTRDLElBQVYsRUFBWixDQ1VBO0FEYnFCLEdBQXZCOztBQUtBb0ssc0JBQUNLLG9CQUFELEdBQXVCLFVBQUNDLHNCQUFEO0FBQ3JCLFFBQUcsY0FBY0Esc0JBQWQsSUFBeUNBLHVCQUF1QjFGLFFBQXZCLEtBQW1DQyxLQUFLQyxZQUFwRjtBQUNFd0YsK0JBQXlCdkwsZUFBZTJGLHNCQUFmLENBQXNDNEYsc0JBQXRDLENBQXpCO0FDWUQ7O0FBQ0QsV0RYQU4sb0JBQUEzTyxTQUFBLENBQUFGLFdBQUEsQ0FBQWtQLG9CQUFBLENBQUE1TSxLQUFBLE9BQUFILFNBQUEsQ0NXQTtBRGZxQixHQUF2Qjs7QUFNQTBNLHNCQUFDTyxpQkFBRCxHQUFvQixVQUFDRCxzQkFBRDtBQUNsQixRQUFHLGNBQWNBLHNCQUFkLElBQXlDQSx1QkFBdUIxRixRQUF2QixLQUFtQ0MsS0FBS0MsWUFBcEY7QUFDRXdGLCtCQUF5QnZMLGVBQWUyRixzQkFBZixDQUFzQzRGLHNCQUF0QyxDQUF6QjtBQ2FEOztBQUNELFdEWkFOLG9CQUFBM08sU0FBQSxDQUFBRixXQUFBLENBQUFvUCxpQkFBQSxDQUFBOU0sS0FBQSxPQUFBSCxTQUFBLENDWUE7QURoQmtCLEdBQXBCOztBQU1BME0sc0JBQUNRLGlCQUFELEdBQW9CO0FBQ2xCLFFBQUFDLGlCQUFBLEVBQUFDLENBQUEsRUFBQWhLLEdBQUEsRUFBQWlLLGFBQUE7QUFBQUYsd0JBQW9CLEVBQXBCO0FBRUFHLE1BQUUsR0FBRixFQUFPQyxJQUFQLENBQVksVUFBQTNPLEtBQUE7QUNjVixhRGRVLFVBQUNULENBQUQsRUFBSXFQLE9BQUo7QUFDVixZQUFBOU4sU0FBQSxFQUFBMk4sYUFBQTtBQUFBM04sb0JBQVkrQixlQUFlMkYsc0JBQWYsQ0FBc0NvRyxPQUF0QyxDQUFaOztBQUNBLGFBQWM5TixTQUFkO0FBQUE7QUNpQkc7O0FEaEJIMk4sd0JBQWdCek8sTUFBQzZPLGFBQUQsQ0FBZS9OLFNBQWYsQ0FBaEI7O0FBQ0EsWUFBNEN6QixRQUFBTixJQUFBLENBQWlCd1AsaUJBQWpCLEVBQUFFLGFBQUEsS0FBNUM7QUNrQkksaUJEbEJKRixrQkFBa0I3SixJQUFsQixDQUF1QitKLGFBQXZCLENDa0JJO0FBQ0Q7QUR2Qk8sT0NjVjtBRGRVLFdBQVo7O0FBTUEsU0FBQUQsSUFBQSxHQUFBaEssTUFBQStKLGtCQUFBOU8sTUFBQSxFQUFBK08sSUFBQWhLLEdBQUEsRUFBQWdLLEdBQUE7QUNxQkVDLHNCQUFnQkYsa0JBQWtCQyxDQUFsQixDQUFoQjtBRHBCQSxXQUFDTCxvQkFBRCxDQUFzQk0sYUFBdEI7QUFERjtBQVRrQixHQUFwQjs7QUNtQ0EsU0FBT1gsbUJBQVA7QUFFRCxDRDVESyxDQUE0QmdCLGtCQUE1QixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FFQ052UyxTQUFTd1MsSUFBVCxDQUFjQyxnQkFBZCxHQUFpQyxjQUFqQyxDIiwiZmlsZSI6Ii9wYWNrYWdlcy9wZWVybGlicmFyeV9ibGF6ZS1jb21wb25lbnRzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiVGVtcGxhdGUgPSBCbGF6ZS5UZW1wbGF0ZVxuIiwiIyBUT0RPOiBEZWR1cGxpY2F0ZSBiZXR3ZWVuIGJsYXplIGNvbXBvbmVudCBhbmQgY29tbW9uIGNvbXBvbmVudCBwYWNrYWdlcy5cbmNyZWF0ZU1hdGNoZXIgPSAocHJvcGVydHlPck1hdGNoZXJPckZ1bmN0aW9uLCBjaGVja01peGlucykgLT5cbiAgaWYgXy5pc1N0cmluZyBwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb25cbiAgICBwcm9wZXJ0eSA9IHByb3BlcnR5T3JNYXRjaGVyT3JGdW5jdGlvblxuICAgIHByb3BlcnR5T3JNYXRjaGVyT3JGdW5jdGlvbiA9IChjaGlsZCwgcGFyZW50KSA9PlxuICAgICAgIyBJZiBjaGlsZCBpcyBwYXJlbnQsIHdlIG1pZ2h0IGdldCBpbnRvIGFuIGluZmluaXRlIGxvb3AgaWYgdGhpcyBpc1xuICAgICAgIyBjYWxsZWQgZnJvbSBnZXRGaXJzdFdpdGgsIHNvIGluIHRoYXQgY2FzZSB3ZSBkbyBub3QgdXNlIGdldEZpcnN0V2l0aC5cbiAgICAgIGlmIGNoZWNrTWl4aW5zIGFuZCBjaGlsZCBpc250IHBhcmVudCBhbmQgY2hpbGQuZ2V0Rmlyc3RXaXRoXG4gICAgICAgICEhY2hpbGQuZ2V0Rmlyc3RXaXRoIG51bGwsIHByb3BlcnR5XG4gICAgICBlbHNlXG4gICAgICAgIHByb3BlcnR5IG9mIGNoaWxkXG5cbiAgZWxzZSBpZiBub3QgXy5pc0Z1bmN0aW9uIHByb3BlcnR5T3JNYXRjaGVyT3JGdW5jdGlvblxuICAgIGFzc2VydCBfLmlzT2JqZWN0IHByb3BlcnR5T3JNYXRjaGVyT3JGdW5jdGlvblxuICAgIG1hdGNoZXIgPSBwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb25cbiAgICBwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb24gPSAoY2hpbGQsIHBhcmVudCkgPT5cbiAgICAgIGZvciBwcm9wZXJ0eSwgdmFsdWUgb2YgbWF0Y2hlclxuICAgICAgICAjIElmIGNoaWxkIGlzIHBhcmVudCwgd2UgbWlnaHQgZ2V0IGludG8gYW4gaW5maW5pdGUgbG9vcCBpZiB0aGlzIGlzXG4gICAgICAgICMgY2FsbGVkIGZyb20gZ2V0Rmlyc3RXaXRoLCBzbyBpbiB0aGF0IGNhc2Ugd2UgZG8gbm90IHVzZSBnZXRGaXJzdFdpdGguXG4gICAgICAgIGlmIGNoZWNrTWl4aW5zIGFuZCBjaGlsZCBpc250IHBhcmVudCBhbmQgY2hpbGQuZ2V0Rmlyc3RXaXRoXG4gICAgICAgICAgY2hpbGRXaXRoUHJvcGVydHkgPSBjaGlsZC5nZXRGaXJzdFdpdGggbnVsbCwgcHJvcGVydHlcbiAgICAgICAgZWxzZVxuICAgICAgICAgIGNoaWxkV2l0aFByb3BlcnR5ID0gY2hpbGQgaWYgcHJvcGVydHkgb2YgY2hpbGRcbiAgICAgICAgcmV0dXJuIGZhbHNlIHVubGVzcyBjaGlsZFdpdGhQcm9wZXJ0eVxuXG4gICAgICAgIGlmIF8uaXNGdW5jdGlvbiBjaGlsZFdpdGhQcm9wZXJ0eVtwcm9wZXJ0eV1cbiAgICAgICAgICByZXR1cm4gZmFsc2UgdW5sZXNzIGNoaWxkV2l0aFByb3BlcnR5W3Byb3BlcnR5XSgpIGlzIHZhbHVlXG4gICAgICAgIGVsc2VcbiAgICAgICAgICByZXR1cm4gZmFsc2UgdW5sZXNzIGNoaWxkV2l0aFByb3BlcnR5W3Byb3BlcnR5XSBpcyB2YWx1ZVxuXG4gICAgICB0cnVlXG5cbiAgcHJvcGVydHlPck1hdGNoZXJPckZ1bmN0aW9uXG5cbmdldFRlbXBsYXRlSW5zdGFuY2UgPSAodmlldywgc2tpcEJsb2NrSGVscGVycykgLT5cbiAgd2hpbGUgdmlldyBhbmQgbm90IHZpZXcuX3RlbXBsYXRlSW5zdGFuY2VcbiAgICBpZiBza2lwQmxvY2tIZWxwZXJzXG4gICAgICB2aWV3ID0gdmlldy5wYXJlbnRWaWV3XG4gICAgZWxzZVxuICAgICAgdmlldyA9IHZpZXcub3JpZ2luYWxQYXJlbnRWaWV3IG9yIHZpZXcucGFyZW50Vmlld1xuXG4gIHZpZXc/Ll90ZW1wbGF0ZUluc3RhbmNlXG5cbiMgTW9yZSBvciBsZXNzIHRoZSBzYW1lIGFzIGFsZGVlZDp0ZW1wbGF0ZS1leHRlbnNpb24ncyB0ZW1wbGF0ZS5nZXQoJ2NvbXBvbmVudCcpIGp1c3Qgc3BlY2lhbGl6ZWQuXG4jIEl0IGFsbG93cyB1cyB0byBub3QgaGF2ZSBhIGRlcGVuZGVuY3kgb24gdGVtcGxhdGUtZXh0ZW5zaW9uIHBhY2thZ2UgYW5kIHRoYXQgd2UgY2FuIHdvcmsgd2l0aCBJcm9uXG4jIFJvdXRlciB3aGljaCBoYXMgaXRzIG93biBEeW5hbWljVGVtcGxhdGUgY2xhc3Mgd2hpY2ggaXMgbm90IHBhdGNoZWQgYnkgdGVtcGxhdGUtZXh0ZW5zaW9uIGFuZCB0aHVzXG4jIGRvZXMgbm90IGhhdmUgLmdldCgpIG1ldGhvZC5cbnRlbXBsYXRlSW5zdGFuY2VUb0NvbXBvbmVudCA9ICh0ZW1wbGF0ZUluc3RhbmNlRnVuYywgc2tpcEJsb2NrSGVscGVycykgLT5cbiAgdGVtcGxhdGVJbnN0YW5jZSA9IHRlbXBsYXRlSW5zdGFuY2VGdW5jPygpXG5cbiAgIyBJcm9uIFJvdXRlciB1c2VzIGl0cyBvd24gRHluYW1pY1RlbXBsYXRlIHdoaWNoIGlzIG5vdCBhIHByb3BlciB0ZW1wbGF0ZSBpbnN0YW5jZSwgYnV0IGl0IGlzXG4gICMgcGFzc2VkIGluIGFzIHN1Y2gsIHNvIHdlIHdhbnQgdG8gZmluZCB0aGUgcmVhbCBvbmUgYmVmb3JlIHdlIHN0YXJ0IHNlYXJjaGluZyBmb3IgdGhlIGNvbXBvbmVudC5cbiAgdGVtcGxhdGVJbnN0YW5jZSA9IGdldFRlbXBsYXRlSW5zdGFuY2UgdGVtcGxhdGVJbnN0YW5jZT8udmlldywgc2tpcEJsb2NrSGVscGVyc1xuXG4gIHdoaWxlIHRlbXBsYXRlSW5zdGFuY2VcbiAgICByZXR1cm4gdGVtcGxhdGVJbnN0YW5jZS5jb21wb25lbnQgaWYgJ2NvbXBvbmVudCcgb2YgdGVtcGxhdGVJbnN0YW5jZVxuXG4gICAgaWYgc2tpcEJsb2NrSGVscGVyc1xuICAgICAgdGVtcGxhdGVJbnN0YW5jZSA9IGdldFRlbXBsYXRlSW5zdGFuY2UgdGVtcGxhdGVJbnN0YW5jZS52aWV3LnBhcmVudFZpZXcsIHNraXBCbG9ja0hlbHBlcnNcbiAgICBlbHNlXG4gICAgICB0ZW1wbGF0ZUluc3RhbmNlID0gZ2V0VGVtcGxhdGVJbnN0YW5jZSAodGVtcGxhdGVJbnN0YW5jZS52aWV3Lm9yaWdpbmFsUGFyZW50VmlldyBvciB0ZW1wbGF0ZUluc3RhbmNlLnZpZXcucGFyZW50VmlldyksIHNraXBCbG9ja0hlbHBlcnNcblxuICBudWxsXG5cbmdldFRlbXBsYXRlSW5zdGFuY2VGdW5jdGlvbiA9ICh2aWV3LCBza2lwQmxvY2tIZWxwZXJzKSAtPlxuICB0ZW1wbGF0ZUluc3RhbmNlID0gZ2V0VGVtcGxhdGVJbnN0YW5jZSB2aWV3LCBza2lwQmxvY2tIZWxwZXJzXG4gIC0+XG4gICAgdGVtcGxhdGVJbnN0YW5jZVxuXG5jbGFzcyBDb21wb25lbnRzTmFtZXNwYWNlUmVmZXJlbmNlXG4gIGNvbnN0cnVjdG9yOiAoQG5hbWVzcGFjZSwgQHRlbXBsYXRlSW5zdGFuY2UpIC0+XG5cbiMgV2UgZXh0ZW5kIHRoZSBvcmlnaW5hbCBkb3Qgb3BlcmF0b3IgdG8gc3VwcG9ydCB7ez4gRm9vLkJhcn19LiBUaGlzIGdvZXMgdGhyb3VnaCBhIGdldFRlbXBsYXRlSGVscGVyIHBhdGgsIGJ1dFxuIyB3ZSB3YW50IHRvIHJlZGlyZWN0IGl0IHRvIHRoZSBnZXRUZW1wbGF0ZSBwYXRoLiBTbyB3ZSBtYXJrIGl0IGluIGdldFRlbXBsYXRlSGVscGVyIGFuZCB0aGVuIGhlcmUgY2FsbCBnZXRUZW1wbGF0ZS5cbm9yaWdpbmFsRG90ID0gU3BhY2ViYXJzLmRvdFxuU3BhY2ViYXJzLmRvdCA9ICh2YWx1ZSwgYXJncy4uLikgLT5cbiAgaWYgdmFsdWUgaW5zdGFuY2VvZiBDb21wb25lbnRzTmFtZXNwYWNlUmVmZXJlbmNlXG4gICAgcmV0dXJuIEJsYXplLl9nZXRUZW1wbGF0ZSBcIiN7dmFsdWUubmFtZXNwYWNlfS4je2FyZ3Muam9pbiAnLid9XCIsIHZhbHVlLnRlbXBsYXRlSW5zdGFuY2VcblxuICBvcmlnaW5hbERvdCB2YWx1ZSwgYXJncy4uLlxuXG5vcmlnaW5hbEluY2x1ZGUgPSBTcGFjZWJhcnMuaW5jbHVkZVxuU3BhY2ViYXJzLmluY2x1ZGUgPSAodGVtcGxhdGVPckZ1bmN0aW9uLCBhcmdzLi4uKSAtPlxuICAjIElmIENvbXBvbmVudHNOYW1lc3BhY2VSZWZlcmVuY2UgZ2V0cyBhbGwgdGhlIHdheSB0byB0aGUgU3BhY2ViYXJzLmluY2x1ZGUgaXQgbWVhbnMgdGhhdCB3ZSBhcmUgaW4gdGhlIHNpdHVhdGlvblxuICAjIHdoZXJlIHRoZXJlIGlzIGJvdGggbmFtZXNwYWNlIGFuZCBjb21wb25lbnQgd2l0aCB0aGUgc2FtZSBuYW1lLCBhbmQgdXNlciBpcyBpbmNsdWRpbmcgYSBjb21wb25lbnQuIEJ1dCBuYW1lc3BhY2VcbiAgIyByZWZlcmVuY2UgaXMgY3JlYXRlZCBpbnN0ZWFkIChiZWNhdXNlIHdlIGRvIG5vdCBrbm93IGluIGFkdmFuY2UgdGhhdCB0aGVyZSBpcyBubyBTcGFjZWJhcnMuZG90IGNhbGwgYXJvdW5kIGxvb2t1cFxuICAjIGNhbGwpLiBTbyB3ZSBkZXJlZmVyZW5jZSB0aGUgcmVmZXJlbmNlIGFuZCB0cnkgdG8gcmVzb2x2ZSBhIHRlbXBsYXRlLiBPZiBjb3Vyc2UsIGEgY29tcG9uZW50IG1pZ2h0IG5vdCByZWFsbHkgZXhpc3QuXG4gIGlmIHRlbXBsYXRlT3JGdW5jdGlvbiBpbnN0YW5jZW9mIENvbXBvbmVudHNOYW1lc3BhY2VSZWZlcmVuY2VcbiAgICB0ZW1wbGF0ZU9yRnVuY3Rpb24gPSBCbGF6ZS5fZ2V0VGVtcGxhdGUgdGVtcGxhdGVPckZ1bmN0aW9uLm5hbWVzcGFjZSwgdGVtcGxhdGVPckZ1bmN0aW9uLnRlbXBsYXRlSW5zdGFuY2VcblxuICBvcmlnaW5hbEluY2x1ZGUgdGVtcGxhdGVPckZ1bmN0aW9uLCBhcmdzLi4uXG5cbiMgV2Ugb3ZlcnJpZGUgdGhlIG9yaWdpbmFsIGxvb2t1cCBtZXRob2Qgd2l0aCBhIHNpbWlsYXIgb25lLCB3aGljaCBzdXBwb3J0cyBjb21wb25lbnRzIGFzIHdlbGwuXG4jXG4jIE5vdyB0aGUgb3JkZXIgb2YgdGhlIGxvb2t1cCB3aWxsIGJlLCBpbiBvcmRlcjpcbiMgICBhIGhlbHBlciBvZiB0aGUgY3VycmVudCB0ZW1wbGF0ZVxuIyAgIGEgcHJvcGVydHkgb2YgdGhlIGN1cnJlbnQgY29tcG9uZW50IChub3QgdGhlIEJsYXplQ29tcG9uZW50LmN1cnJlbnRDb21wb25lbnQoKSB0aG91Z2gsIGJ1dCBAY29tcG9uZW50KCkpXG4jICAgYSBoZWxwZXIgb2YgdGhlIGN1cnJlbnQgY29tcG9uZW50J3MgYmFzZSB0ZW1wbGF0ZSAobm90IHRoZSBCbGF6ZUNvbXBvbmVudC5jdXJyZW50Q29tcG9uZW50KCkgdGhvdWdoLCBidXQgQGNvbXBvbmVudCgpKVxuIyAgIHRoZSBuYW1lIG9mIGEgY29tcG9uZW50XG4jICAgdGhlIG5hbWUgb2YgYSB0ZW1wbGF0ZVxuIyAgIGdsb2JhbCBoZWxwZXJcbiMgICBhIHByb3BlcnR5IG9mIHRoZSBkYXRhIGNvbnRleHRcbiNcbiMgUmV0dXJucyBhIGZ1bmN0aW9uLCBhIG5vbi1mdW5jdGlvbiB2YWx1ZSwgb3IgbnVsbC4gSWYgYSBmdW5jdGlvbiBpcyBmb3VuZCwgaXQgaXMgYm91bmQgYXBwcm9wcmlhdGVseS5cbiNcbiMgTk9URTogVGhpcyBmdW5jdGlvbiBtdXN0IG5vdCBlc3RhYmxpc2ggYW55IHJlYWN0aXZlIGRlcGVuZGVuY2llcyBpdHNlbGYuICBJZiB0aGVyZSBpcyBhbnkgcmVhY3Rpdml0eVxuIyBpbiB0aGUgdmFsdWUsIGxvb2t1cCBzaG91bGQgcmV0dXJuIGEgZnVuY3Rpb24uXG4jXG4jIFRPRE86IFNob3VsZCB3ZSBhbHNvIGxvb2t1cCBmb3IgYSBwcm9wZXJ0eSBvZiB0aGUgY29tcG9uZW50LWxldmVsIGRhdGEgY29udGV4dCAoYW5kIHRlbXBsYXRlLWxldmVsIGRhdGEgY29udGV4dCk/XG5cbkJsYXplLl9nZXRUZW1wbGF0ZUhlbHBlciA9ICh0ZW1wbGF0ZSwgbmFtZSwgdGVtcGxhdGVJbnN0YW5jZSkgLT5cbiAgaXNLbm93bk9sZFN0eWxlSGVscGVyID0gZmFsc2VcbiAgaWYgdGVtcGxhdGUuX19oZWxwZXJzLmhhcyBuYW1lXG4gICAgaGVscGVyID0gdGVtcGxhdGUuX19oZWxwZXJzLmdldCBuYW1lXG4gICAgaWYgaGVscGVyIGlzIEJsYXplLl9PTERTVFlMRV9IRUxQRVJcbiAgICAgIGlzS25vd25PbGRTdHlsZUhlbHBlciA9IHRydWVcbiAgICBlbHNlIGlmIGhlbHBlcj9cbiAgICAgIHJldHVybiB3cmFwSGVscGVyIGJpbmREYXRhQ29udGV4dChoZWxwZXIpLCB0ZW1wbGF0ZUluc3RhbmNlXG4gICAgZWxzZVxuICAgICAgcmV0dXJuIG51bGxcblxuICAjIE9sZC1zdHlsZSBoZWxwZXIuXG4gIGlmIG5hbWUgb2YgdGVtcGxhdGVcbiAgICAjIE9ubHkgd2FybiBvbmNlIHBlciBoZWxwZXIuXG4gICAgdW5sZXNzIGlzS25vd25PbGRTdHlsZUhlbHBlclxuICAgICAgdGVtcGxhdGUuX19oZWxwZXJzLnNldCBuYW1lLCBCbGF6ZS5fT0xEU1RZTEVfSEVMUEVSXG4gICAgICB1bmxlc3MgdGVtcGxhdGUuX05PV0FSTl9PTERTVFlMRV9IRUxQRVJTXG4gICAgICAgIEJsYXplLl93YXJuIFwiQXNzaWduaW5nIGhlbHBlciB3aXRoIGBcIiArIHRlbXBsYXRlLnZpZXdOYW1lICsgXCIuXCIgKyBuYW1lICsgXCIgPSAuLi5gIGlzIGRlcHJlY2F0ZWQuICBVc2UgYFwiICsgdGVtcGxhdGUudmlld05hbWUgKyBcIi5oZWxwZXJzKC4uLilgIGluc3RlYWQuXCJcbiAgICBpZiB0ZW1wbGF0ZVtuYW1lXT9cbiAgICAgIHJldHVybiB3cmFwSGVscGVyIGJpbmREYXRhQ29udGV4dCh0ZW1wbGF0ZVtuYW1lXSksIHRlbXBsYXRlSW5zdGFuY2VcbiAgICBlbHNlXG4gICAgICByZXR1cm4gbnVsbFxuXG4gIHJldHVybiBudWxsIHVubGVzcyB0ZW1wbGF0ZUluc3RhbmNlXG5cbiAgIyBEbyBub3QgcmVzb2x2ZSBjb21wb25lbnQgaGVscGVycyBpZiBpbnNpZGUgVGVtcGxhdGUuZHluYW1pYy4gVGhlIHJlYXNvbiBpcyB0aGF0IFRlbXBsYXRlLmR5bmFtaWMgdXNlcyBhIGRhdGEgY29udGV4dFxuICAjIHZhbHVlIHdpdGggbmFtZSBcInRlbXBsYXRlXCIgaW50ZXJuYWxseS4gQnV0IHdoZW4gdXNlZCBpbnNpZGUgYSBjb21wb25lbnQgdGhlIGRhdGEgY29udGV4dCBsb29rdXAgaXMgdGhlbiByZXNvbHZlZFxuICAjIGludG8gYSBjdXJyZW50IGNvbXBvbmVudCdzIHRlbXBsYXRlIG1ldGhvZCBhbmQgbm90IHRoZSBkYXRhIGNvbnRleHQgXCJ0ZW1wbGF0ZVwiLiBUbyBmb3JjZSB0aGUgZGF0YSBjb250ZXh0IHJlc29sdmluZ1xuICAjIFRlbXBsYXRlLmR5bmFtaWMgc2hvdWxkIHVzZSBcInRoaXMudGVtcGxhdGVcIiBpbiBpdHMgdGVtcGxhdGVzLCBidXQgaXQgZG9lcyBub3QsIHNvIHdlIGhhdmUgYSBzcGVjaWFsIGNhc2UgaGVyZSBmb3IgaXQuXG4gIHJldHVybiBudWxsIGlmIHRlbXBsYXRlLnZpZXdOYW1lIGluIFsnVGVtcGxhdGUuX19keW5hbWljV2l0aERhdGFDb250ZXh0JywgJ1RlbXBsYXRlLl9fZHluYW1pYyddXG5cbiAgIyBCbGF6ZS5WaWV3Ojpsb29rdXAgc2hvdWxkIG5vdCBpbnRyb2R1Y2UgYW55IHJlYWN0aXZlIGRlcGVuZGVuY2llcywgYnV0IHdlIGNhbiBzaW1wbHkgaWdub3JlIHJlYWN0aXZpdHkgaGVyZSBiZWNhdXNlXG4gICMgdGVtcGxhdGUgaW5zdGFuY2UgcHJvYmFibHkgY2Fubm90IGNoYW5nZSB3aXRob3V0IHJlY29uc3RydWN0aW5nIHRoZSBjb21wb25lbnQgYXMgd2VsbC5cbiAgY29tcG9uZW50ID0gVHJhY2tlci5ub25yZWFjdGl2ZSAtPlxuICAgICMgV2Ugd2FudCB0byBza2lwIGFueSBibG9jayBoZWxwZXIuIHt7bWV0aG9kfX0gc2hvdWxkIHJlc29sdmUgdG9cbiAgICAjIHt7Y29tcG9uZW50Lm1ldGhvZH19IGFuZCBub3QgdG8ge3tjdXJyZW50Q29tcG9uZW50Lm1ldGhvZH19LlxuICAgIHRlbXBsYXRlSW5zdGFuY2VUb0NvbXBvbmVudCB0ZW1wbGF0ZUluc3RhbmNlLCB0cnVlXG5cbiAgIyBDb21wb25lbnQuXG4gIGlmIGNvbXBvbmVudFxuICAgICMgVGhpcyB3aWxsIGZpcnN0IHNlYXJjaCBvbiB0aGUgY29tcG9uZW50IGFuZCB0aGVuIGNvbnRpbnVlIHdpdGggbWl4aW5zLlxuICAgIGlmIG1peGluT3JDb21wb25lbnQgPSBjb21wb25lbnQuZ2V0Rmlyc3RXaXRoIG51bGwsIG5hbWVcbiAgICAgIHJldHVybiB3cmFwSGVscGVyIGJpbmRDb21wb25lbnQobWl4aW5PckNvbXBvbmVudCwgbWl4aW5PckNvbXBvbmVudFtuYW1lXSksIHRlbXBsYXRlSW5zdGFuY2VcblxuICAjIEEgc3BlY2lhbCBjYXNlIHRvIHN1cHBvcnQge3s+IEZvby5CYXJ9fS4gVGhpcyBnb2VzIHRocm91Z2ggYSBnZXRUZW1wbGF0ZUhlbHBlciBwYXRoLCBidXQgd2Ugd2FudCB0byByZWRpcmVjdFxuICAjIGl0IHRvIHRoZSBnZXRUZW1wbGF0ZSBwYXRoLiBTbyB3ZSBtYXJrIGl0IGFuZCBsZWF2ZSB0byBTcGFjZWJhcnMuZG90IHRvIGNhbGwgZ2V0VGVtcGxhdGUuXG4gICMgVE9ETzogV2Ugc2hvdWxkIHByb3ZpZGUgYSBCYXNlQ29tcG9uZW50LmdldENvbXBvbmVudHNOYW1lc3BhY2UgbWV0aG9kIGluc3RlYWQgb2YgYWNjZXNzaW5nIGNvbXBvbmVudHMgZGlyZWN0bHkuXG4gIGlmIG5hbWUgYW5kIG5hbWUgb2YgQmxhemVDb21wb25lbnQuY29tcG9uZW50c1xuICAgIHJldHVybiBuZXcgQ29tcG9uZW50c05hbWVzcGFjZVJlZmVyZW5jZSBuYW1lLCB0ZW1wbGF0ZUluc3RhbmNlXG5cbiAgIyBNYXliZSBhIHByZWV4aXN0aW5nIHRlbXBsYXRlIGhlbHBlciBvbiB0aGUgY29tcG9uZW50J3MgYmFzZSB0ZW1wbGF0ZS5cbiAgaWYgY29tcG9uZW50XG4gICAgIyBXZSBrbm93IHRoYXQgY29tcG9uZW50IGlzIHJlYWxseSBhIGNvbXBvbmVudC5cbiAgICBpZiAoaGVscGVyID0gY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHM/LnRlbXBsYXRlQmFzZT8uX19oZWxwZXJzLmdldCBuYW1lKT9cbiAgICAgIHJldHVybiB3cmFwSGVscGVyIGJpbmREYXRhQ29udGV4dChoZWxwZXIpLCB0ZW1wbGF0ZUluc3RhbmNlXG5cbiAgbnVsbFxuXG5zaGFyZS5pbkV4cGFuZEF0dHJpYnV0ZXMgPSBmYWxzZVxuXG5iaW5kQ29tcG9uZW50ID0gKGNvbXBvbmVudCwgaGVscGVyKSAtPlxuICBpZiBfLmlzRnVuY3Rpb24gaGVscGVyXG4gICAgKGFyZ3MuLi4pIC0+XG4gICAgICByZXN1bHQgPSBoZWxwZXIuYXBwbHkgY29tcG9uZW50LCBhcmdzXG5cbiAgICAgICMgSWYgd2UgYXJlIGV4cGFuZGluZyBhdHRyaWJ1dGVzIGFuZCB0aGlzIGlzIGFuIG9iamVjdCB3aXRoIGR5bmFtaWMgYXR0cmlidXRlcyxcbiAgICAgICMgdGhlbiB3ZSB3YW50IHRvIGJpbmQgYWxsIHBvc3NpYmxlIGV2ZW50IGhhbmRsZXJzIHRvIHRoZSBjb21wb25lbnQgYXMgd2VsbC5cbiAgICAgIGlmIHNoYXJlLmluRXhwYW5kQXR0cmlidXRlcyBhbmQgXy5pc09iamVjdCByZXN1bHRcbiAgICAgICAgZm9yIG5hbWUsIHZhbHVlIG9mIHJlc3VsdCB3aGVuIHNoYXJlLkVWRU5UX0hBTkRMRVJfUkVHRVgudGVzdCBuYW1lXG4gICAgICAgICAgaWYgXy5pc0Z1bmN0aW9uIHZhbHVlXG4gICAgICAgICAgICByZXN1bHRbbmFtZV0gPSBfLmJpbmQgdmFsdWUsIGNvbXBvbmVudFxuICAgICAgICAgIGVsc2UgaWYgXy5pc0FycmF5IHZhbHVlXG4gICAgICAgICAgICByZXN1bHRbbmFtZV0gPSBfLm1hcCB2YWx1ZSwgKGZ1bikgLT5cbiAgICAgICAgICAgICAgaWYgXy5pc0Z1bmN0aW9uIGZ1blxuICAgICAgICAgICAgICAgIF8uYmluZCBmdW4sIGNvbXBvbmVudFxuICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgZnVuXG5cbiAgICAgIHJlc3VsdFxuICBlbHNlXG4gICAgaGVscGVyXG5cbmJpbmREYXRhQ29udGV4dCA9IChoZWxwZXIpIC0+XG4gIGlmIF8uaXNGdW5jdGlvbiBoZWxwZXJcbiAgICAtPlxuICAgICAgZGF0YSA9IEJsYXplLmdldERhdGEoKVxuICAgICAgZGF0YSA/PSB7fVxuICAgICAgaGVscGVyLmFwcGx5IGRhdGEsIGFyZ3VtZW50c1xuICBlbHNlXG4gICAgaGVscGVyXG5cbndyYXBIZWxwZXIgPSAoZiwgdGVtcGxhdGVGdW5jKSAtPlxuICAjIFhYWCBDT01QQVQgV0lUSCBNRVRFT1IgMS4wLjMuMlxuICByZXR1cm4gQmxhemUuX3dyYXBDYXRjaGluZ0V4Y2VwdGlvbnMgZiwgJ3RlbXBsYXRlIGhlbHBlcicgdW5sZXNzIEJsYXplLlRlbXBsYXRlLl93aXRoVGVtcGxhdGVJbnN0YW5jZUZ1bmNcblxuICByZXR1cm4gZiB1bmxlc3MgXy5pc0Z1bmN0aW9uIGZcblxuICAtPlxuICAgIHNlbGYgPSBAXG4gICAgYXJncyA9IGFyZ3VtZW50c1xuXG4gICAgQmxhemUuVGVtcGxhdGUuX3dpdGhUZW1wbGF0ZUluc3RhbmNlRnVuYyB0ZW1wbGF0ZUZ1bmMsIC0+XG4gICAgICBCbGF6ZS5fd3JhcENhdGNoaW5nRXhjZXB0aW9ucyhmLCAndGVtcGxhdGUgaGVscGVyJykuYXBwbHkgc2VsZiwgYXJnc1xuXG5pZiBCbGF6ZS5UZW1wbGF0ZS5fd2l0aFRlbXBsYXRlSW5zdGFuY2VGdW5jXG4gIHdpdGhUZW1wbGF0ZUluc3RhbmNlRnVuYyA9IEJsYXplLlRlbXBsYXRlLl93aXRoVGVtcGxhdGVJbnN0YW5jZUZ1bmNcbmVsc2VcbiAgIyBYWFggQ09NUEFUIFdJVEggTUVURU9SIDEuMC4zLjIuXG4gIHdpdGhUZW1wbGF0ZUluc3RhbmNlRnVuYyA9ICh0ZW1wbGF0ZUluc3RhbmNlLCBmKSAtPlxuICAgIGYoKVxuXG5nZXRUZW1wbGF0ZUJhc2UgPSAoY29tcG9uZW50KSAtPlxuICAjIFdlIGRvIG5vdCBhbGxvdyB0ZW1wbGF0ZSB0byBiZSBhIHJlYWN0aXZlIG1ldGhvZC5cbiAgVHJhY2tlci5ub25yZWFjdGl2ZSAtPlxuICAgIGNvbXBvbmVudFRlbXBsYXRlID0gY29tcG9uZW50LnRlbXBsYXRlKClcbiAgICBpZiBfLmlzU3RyaW5nIGNvbXBvbmVudFRlbXBsYXRlXG4gICAgICB0ZW1wbGF0ZUJhc2UgPSBUZW1wbGF0ZVtjb21wb25lbnRUZW1wbGF0ZV1cbiAgICAgIHRocm93IG5ldyBFcnJvciBcIlRlbXBsYXRlICcje2NvbXBvbmVudFRlbXBsYXRlfScgY2Fubm90IGJlIGZvdW5kLlwiIHVubGVzcyB0ZW1wbGF0ZUJhc2VcbiAgICBlbHNlIGlmIGNvbXBvbmVudFRlbXBsYXRlXG4gICAgICB0ZW1wbGF0ZUJhc2UgPSBjb21wb25lbnRUZW1wbGF0ZVxuICAgIGVsc2VcbiAgICAgIHRocm93IG5ldyBFcnJvciBcIlRlbXBsYXRlIGZvciB0aGUgY29tcG9uZW50ICcje2NvbXBvbmVudC5jb21wb25lbnROYW1lKCkgb3IgJ3VubmFtZWQnfScgbm90IHByb3ZpZGVkLlwiXG5cbiAgICB0ZW1wbGF0ZUJhc2VcblxuY2FsbFRlbXBsYXRlQmFzZUhvb2tzID0gKGNvbXBvbmVudCwgaG9va05hbWUpIC0+XG4gICMgV2Ugd2FudCB0byBjYWxsIHRlbXBsYXRlIGJhc2UgaG9va3Mgb25seSB3aGVuIHdlIGFyZSBjYWxsaW5nIHRoaXMgZnVuY3Rpb24gb24gYSBjb21wb25lbnQgaXRzZWxmLlxuICByZXR1cm4gdW5sZXNzIGNvbXBvbmVudCBpcyBjb21wb25lbnQuY29tcG9uZW50KClcblxuICB0ZW1wbGF0ZUluc3RhbmNlID0gVHJhY2tlci5ub25yZWFjdGl2ZSAtPlxuICAgIGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLnRlbXBsYXRlSW5zdGFuY2UoKVxuICBjYWxsYmFja3MgPSBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscy50ZW1wbGF0ZUJhc2UuX2dldENhbGxiYWNrcyBob29rTmFtZVxuICBUZW1wbGF0ZS5fd2l0aFRlbXBsYXRlSW5zdGFuY2VGdW5jKFxuICAgIC0+XG4gICAgICB0ZW1wbGF0ZUluc3RhbmNlXG4gICxcbiAgICAtPlxuICAgICAgZm9yIGNhbGxiYWNrIGluIGNhbGxiYWNrc1xuICAgICAgICBjYWxsYmFjay5jYWxsIHRlbXBsYXRlSW5zdGFuY2VcbiAgKVxuXG4gIHJldHVyblxuXG53cmFwVmlld0FuZFRlbXBsYXRlID0gKGN1cnJlbnRWaWV3LCBmKSAtPlxuICAjIEZvciB0ZW1wbGF0ZSBjb250ZW50IHdyYXBwZWQgaW5zaWRlIHRoZSBibG9jayBoZWxwZXIsIHdlIHdhbnQgdG8gc2tpcCB0aGUgYmxvY2tcbiAgIyBoZWxwZXIgd2hlbiBzZWFyY2hpbmcgZm9yIGNvcnJlc3BvbmRpbmcgdGVtcGxhdGUuIFRoaXMgbWVhbnMgdGhhdCBUZW1wbGF0ZS5pbnN0YW5jZSgpXG4gICMgd2lsbCByZXR1cm4gdGhlIGNvbXBvbmVudCdzIHRlbXBsYXRlLCB3aGlsZSBCbGF6ZUNvbXBvbmVudC5jdXJyZW50Q29tcG9uZW50KCkgd2lsbFxuICAjIHJldHVybiB0aGUgY29tcG9uZW50IGluc2lkZS5cbiAgdGVtcGxhdGVJbnN0YW5jZSA9IGdldFRlbXBsYXRlSW5zdGFuY2VGdW5jdGlvbiBjdXJyZW50VmlldywgdHJ1ZVxuXG4gICMgV2Ugc2V0IHRlbXBsYXRlIGluc3RhbmNlIHRvIG1hdGNoIHRoZSBjdXJyZW50IHZpZXcgKG1vc3RseSwgb25seSBub3Qgd2hlbiBpbnNpZGVcbiAgIyB0aGUgYmxvY2sgaGVscGVyKS4gVGhlIGxhdHRlciB3ZSB1c2UgZm9yIEJsYXplQ29tcG9uZW50LmN1cnJlbnRDb21wb25lbnQoKSwgYnV0XG4gICMgaXQgaXMgZ29vZCB0aGF0IGJvdGggdGVtcGxhdGUgaW5zdGFuY2UgYW5kIGN1cnJlbnQgdmlldyBjb3JyZXNwb25kIHRvIGVhY2ggb3RoZXJcbiAgIyBhcyBtdWNoIGFzIHBvc3NpYmxlLlxuICB3aXRoVGVtcGxhdGVJbnN0YW5jZUZ1bmMgdGVtcGxhdGVJbnN0YW5jZSwgLT5cbiAgICAjIFdlIHNldCB2aWV3IGJhc2VkIG9uIHRoZSBjdXJyZW50IHZpZXcgc28gdGhhdCBpbnNpZGUgZXZlbnQgaGFuZGxlcnNcbiAgICAjIEJsYXplQ29tcG9uZW50LmN1cnJlbnREYXRhKCkgKGFuZCBCbGF6ZS5nZXREYXRhKCkgYW5kIFRlbXBsYXRlLmN1cnJlbnREYXRhKCkpXG4gICAgIyByZXR1cm5zIGRhdGEgY29udGV4dCBvZiBldmVudCB0YXJnZXQgYW5kIG5vdCBjb21wb25lbnQvdGVtcGxhdGUuIE1vcmVvdmVyLFxuICAgICMgaW5zaWRlIGV2ZW50IGhhbmRsZXJzIEJsYXplQ29tcG9uZW50LmN1cnJlbnRDb21wb25lbnQoKSByZXR1cm5zIHRoZSBjb21wb25lbnRcbiAgICAjIG9mIGV2ZW50IHRhcmdldC5cbiAgICBCbGF6ZS5fd2l0aEN1cnJlbnRWaWV3IGN1cnJlbnRWaWV3LCAtPlxuICAgICAgZigpXG5cbmFkZEV2ZW50cyA9ICh2aWV3LCBjb21wb25lbnQpIC0+XG4gIGV2ZW50c0xpc3QgPSBjb21wb25lbnQuZXZlbnRzKClcblxuICB0aHJvdyBuZXcgRXJyb3IgXCInZXZlbnRzJyBtZXRob2QgZnJvbSB0aGUgY29tcG9uZW50ICcje2NvbXBvbmVudC5jb21wb25lbnROYW1lKCkgb3IgJ3VubmFtZWQnfScgZGlkIG5vdCByZXR1cm4gYSBsaXN0IG9mIGV2ZW50IG1hcHMuXCIgdW5sZXNzIF8uaXNBcnJheSBldmVudHNMaXN0XG5cbiAgZm9yIGV2ZW50cyBpbiBldmVudHNMaXN0XG4gICAgZXZlbnRNYXAgPSB7fVxuXG4gICAgZm9yIHNwZWMsIGhhbmRsZXIgb2YgZXZlbnRzXG4gICAgICBkbyAoc3BlYywgaGFuZGxlcikgLT5cbiAgICAgICAgZXZlbnRNYXBbc3BlY10gPSAoYXJncy4uLikgLT5cbiAgICAgICAgICBldmVudCA9IGFyZ3NbMF1cblxuICAgICAgICAgIGN1cnJlbnRWaWV3ID0gQmxhemUuZ2V0VmlldyBldmVudC5jdXJyZW50VGFyZ2V0XG4gICAgICAgICAgd3JhcFZpZXdBbmRUZW1wbGF0ZSBjdXJyZW50VmlldywgLT5cbiAgICAgICAgICAgIGhhbmRsZXIuYXBwbHkgY29tcG9uZW50LCBhcmdzXG5cbiAgICAgICAgICAjIE1ha2Ugc3VyZSBDb2ZmZWVTY3JpcHQgZG9lcyBub3QgcmV0dXJuIGFueXRoaW5nLlxuICAgICAgICAgICMgUmV0dXJuaW5nIGZyb20gZXZlbnQgaGFuZGxlcnMgaXMgZGVwcmVjYXRlZC5cbiAgICAgICAgICByZXR1cm5cblxuICAgIEJsYXplLl9hZGRFdmVudE1hcCB2aWV3LCBldmVudE1hcCwgdmlld1xuXG4gIHJldHVyblxuXG5vcmlnaW5hbEdldFRlbXBsYXRlID0gQmxhemUuX2dldFRlbXBsYXRlXG5CbGF6ZS5fZ2V0VGVtcGxhdGUgPSAobmFtZSwgdGVtcGxhdGVJbnN0YW5jZSkgLT5cbiAgIyBCbGF6ZS5WaWV3Ojpsb29rdXAgc2hvdWxkIG5vdCBpbnRyb2R1Y2UgYW55IHJlYWN0aXZlIGRlcGVuZGVuY2llcywgc28gd2UgYXJlIG1ha2luZyBzdXJlIGl0IGlzIHNvLlxuICB0ZW1wbGF0ZSA9IFRyYWNrZXIubm9ucmVhY3RpdmUgLT5cbiAgICBpZiBCbGF6ZS5jdXJyZW50Vmlld1xuICAgICAgcGFyZW50Q29tcG9uZW50ID0gQmxhemVDb21wb25lbnQuY3VycmVudENvbXBvbmVudCgpXG4gICAgZWxzZVxuICAgICAgIyBXZSBkbyBub3Qgc2tpcCBibG9jayBoZWxwZXJzIHRvIGFzc3VyZSB0aGF0IHdoZW4gYmxvY2sgaGVscGVycyBhcmUgdXNlZCxcbiAgICAgICMgY29tcG9uZW50IHRyZWUgaW50ZWdyYXRlcyB0aGVtIG5pY2VseSBpbnRvIGEgdHJlZS5cbiAgICAgIHBhcmVudENvbXBvbmVudCA9IHRlbXBsYXRlSW5zdGFuY2VUb0NvbXBvbmVudCB0ZW1wbGF0ZUluc3RhbmNlLCBmYWxzZVxuXG4gICAgQmxhemVDb21wb25lbnQuZ2V0Q29tcG9uZW50KG5hbWUpPy5yZW5kZXJDb21wb25lbnQgcGFyZW50Q29tcG9uZW50XG4gIHJldHVybiB0ZW1wbGF0ZSBpZiB0ZW1wbGF0ZSBhbmQgKHRlbXBsYXRlIGluc3RhbmNlb2YgQmxhemUuVGVtcGxhdGUgb3IgXy5pc0Z1bmN0aW9uIHRlbXBsYXRlKVxuXG4gIG9yaWdpbmFsR2V0VGVtcGxhdGUgbmFtZVxuXG5yZWdpc3Rlckhvb2tzID0gKHRlbXBsYXRlLCBob29rcykgLT5cbiAgaWYgdGVtcGxhdGUub25DcmVhdGVkXG4gICAgdGVtcGxhdGUub25DcmVhdGVkIGhvb2tzLm9uQ3JlYXRlZFxuICAgIHRlbXBsYXRlLm9uUmVuZGVyZWQgaG9va3Mub25SZW5kZXJlZFxuICAgIHRlbXBsYXRlLm9uRGVzdHJveWVkIGhvb2tzLm9uRGVzdHJveWVkXG4gIGVsc2VcbiAgICAjIFhYWCBDT01QQVQgV0lUSCBNRVRFT1IgMS4wLjMuMi5cbiAgICB0ZW1wbGF0ZS5jcmVhdGVkID0gaG9va3Mub25DcmVhdGVkXG4gICAgdGVtcGxhdGUucmVuZGVyZWQgPSBob29rcy5vblJlbmRlcmVkXG4gICAgdGVtcGxhdGUuZGVzdHJveWVkID0gaG9va3Mub25EZXN0cm95ZWRcblxucmVnaXN0ZXJGaXJzdENyZWF0ZWRIb29rID0gKHRlbXBsYXRlLCBvbkNyZWF0ZWQpIC0+XG4gIGlmIHRlbXBsYXRlLl9jYWxsYmFja3NcbiAgICB0ZW1wbGF0ZS5fY2FsbGJhY2tzLmNyZWF0ZWQudW5zaGlmdCBvbkNyZWF0ZWRcbiAgZWxzZVxuICAgICMgWFhYIENPTVBBVCBXSVRIIE1FVEVPUiAxLjAuMy4yLlxuICAgIG9sZENyZWF0ZWQgPSB0ZW1wbGF0ZS5jcmVhdGVkXG4gICAgdGVtcGxhdGUuY3JlYXRlZCA9IC0+XG4gICAgICBvbkNyZWF0ZWQuY2FsbCBAXG4gICAgICBvbGRDcmVhdGVkPy5jYWxsIEBcblxuIyBXZSBtYWtlIFRlbXBsYXRlLmR5bmFtaWMgcmVzb2x2ZSB0byB0aGUgY29tcG9uZW50IGlmIGNvbXBvbmVudCBuYW1lIGlzIHNwZWNpZmllZCBhcyBhIHRlbXBsYXRlIG5hbWUsIGFuZCBub3RcbiMgdG8gdGhlIG5vbi1jb21wb25lbnQgdGVtcGxhdGUgd2hpY2ggaXMgcHJvYmFibHkgdXNlZCBvbmx5IGZvciB0aGUgY29udGVudC4gV2Ugc2ltcGx5IHJldXNlIEJsYXplLl9nZXRUZW1wbGF0ZS5cbiMgVE9ETzogSG93IHRvIHBhc3MgYXJncz9cbiMgICAgICAgTWF5YmUgc2ltcGx5IGJ5IHVzaW5nIFNwYWNlYmFycyBuZXN0ZWQgZXhwcmVzc2lvbnMgKGh0dHBzOi8vZ2l0aHViLmNvbS9tZXRlb3IvbWV0ZW9yL3B1bGwvNDEwMSk/XG4jICAgICAgIFRlbXBsYXRlLmR5bmFtaWMgdGVtcGxhdGU9XCIuLi5cIiBkYXRhPShhcmdzIC4uLik/IEJ1dCB0aGlzIGV4cG9zZXMgdGhlIGZhY3QgdGhhdCBhcmdzIGFyZSBwYXNzZWQgYXMgZGF0YSBjb250ZXh0LlxuIyAgICAgICBNYXliZSB3ZSBzaG91bGQgc2ltcGx5IG92ZXJyaWRlIFRlbXBsYXRlLmR5bmFtaWMgYW5kIGFkZCBcImFyZ3NcIiBhcmd1bWVudD9cbiMgVE9ETzogVGhpcyBjYW4gYmUgcmVtb3ZlZCBvbmNlIGh0dHBzOi8vZ2l0aHViLmNvbS9tZXRlb3IvbWV0ZW9yL3B1bGwvNDAzNiBpcyBtZXJnZWQgaW4uXG5UZW1wbGF0ZS5fX2R5bmFtaWNXaXRoRGF0YUNvbnRleHQuX19oZWxwZXJzLnNldCAnY2hvb3NlVGVtcGxhdGUnLCAobmFtZSkgLT5cbiAgQmxhemUuX2dldFRlbXBsYXRlIG5hbWUsID0+XG4gICAgVGVtcGxhdGUuaW5zdGFuY2UoKVxuXG5hcmd1bWVudHNDb25zdHJ1Y3RvciA9IC0+XG4gICMgVGhpcyBjbGFzcyBzaG91bGQgbmV2ZXIgcmVhbGx5IGJlIGNyZWF0ZWQuXG4gIGFzc2VydCBmYWxzZVxuXG4jIFRPRE86IEZpbmQgYSB3YXkgdG8gcGFzcyBhcmd1bWVudHMgdG8gdGhlIGNvbXBvbmVudCB3aXRob3V0IGhhdmluZyB0byBpbnRyb2R1Y2Ugb25lIGludGVybWVkaWFyeSBkYXRhIGNvbnRleHQgaW50byB0aGUgZGF0YSBjb250ZXh0IGhpZXJhcmNoeS5cbiMgICAgICAgKEluIGZhY3QgdHdvIGRhdGEgY29udGV4dHMsIGJlY2F1c2Ugd2UgYWRkIG9uZSBtb3JlIHdoZW4gcmVzdG9yaW5nIHRoZSBvcmlnaW5hbCBvbmUuKVxuVGVtcGxhdGUucmVnaXN0ZXJIZWxwZXIgJ2FyZ3MnLCAtPlxuICBvYmogPSB7fVxuICAjIFdlIHVzZSBjdXN0b20gY29uc3RydWN0b3IgdG8ga25vdyB0aGF0IGl0IGlzIG5vdCBhIHJlYWwgZGF0YSBjb250ZXh0LlxuICBvYmouY29uc3RydWN0b3IgPSBhcmd1bWVudHNDb25zdHJ1Y3RvclxuICBvYmouX2FyZ3VtZW50cyA9IGFyZ3VtZW50c1xuICBvYmpcblxuc2hhcmUuRVZFTlRfSEFORExFUl9SRUdFWCA9IC9eb25bQS1aXS9cblxuc2hhcmUuaXNFdmVudEhhbmRsZXIgPSAoZnVuKSAtPlxuICBfLmlzRnVuY3Rpb24oZnVuKSBhbmQgZnVuLmV2ZW50SGFuZGxlclxuXG4jIFdoZW4gZXZlbnQgaGFuZGxlcnMgYXJlIHByb3ZpZGVkIGRpcmVjdGx5IGFzIGFyZ3MgdGhleSBhcmUgbm90IHBhc3NlZCB0aHJvdWdoXG4jIFNwYWNlYmFycy5ldmVudCBieSB0aGUgdGVtcGxhdGUgY29tcGlsZXIsIHNvIHdlIGhhdmUgdG8gZG8gaXQgb3Vyc2VsdmVzLlxub3JpZ2luYWxGbGF0dGVuQXR0cmlidXRlcyA9IEhUTUwuZmxhdHRlbkF0dHJpYnV0ZXNcbkhUTUwuZmxhdHRlbkF0dHJpYnV0ZXMgPSAoYXR0cnMpIC0+XG4gIGlmIGF0dHJzID0gb3JpZ2luYWxGbGF0dGVuQXR0cmlidXRlcyBhdHRyc1xuICAgIGZvciBuYW1lLCB2YWx1ZSBvZiBhdHRycyB3aGVuIHNoYXJlLkVWRU5UX0hBTkRMRVJfUkVHRVgudGVzdCBuYW1lXG4gICAgICAjIEFscmVhZHkgcHJvY2Vzc2VkIGJ5IFNwYWNlYmFycy5ldmVudC5cbiAgICAgIGNvbnRpbnVlIGlmIHNoYXJlLmlzRXZlbnRIYW5kbGVyIHZhbHVlXG4gICAgICBjb250aW51ZSBpZiBfLmlzQXJyYXkodmFsdWUpIGFuZCBfLnNvbWUgdmFsdWUsIHNoYXJlLmlzRXZlbnRIYW5kbGVyXG5cbiAgICAgICMgV2hlbiBldmVudCBoYW5kbGVycyBhcmUgcHJvdmlkZWQgZGlyZWN0bHkgYXMgYXJncyxcbiAgICAgICMgd2UgcmVxdWlyZSB0aGVtIHRvIGJlIGp1c3QgZXZlbnQgaGFuZGxlcnMuXG4gICAgICBpZiBfLmlzQXJyYXkgdmFsdWVcbiAgICAgICAgYXR0cnNbbmFtZV0gPSBfLm1hcCB2YWx1ZSwgU3BhY2ViYXJzLmV2ZW50XG4gICAgICBlbHNlXG4gICAgICAgIGF0dHJzW25hbWVdID0gU3BhY2ViYXJzLmV2ZW50IHZhbHVlXG5cbiAgYXR0cnNcblxuU3BhY2ViYXJzLmV2ZW50ID0gKGV2ZW50SGFuZGxlciwgYXJncy4uLikgLT5cbiAgdGhyb3cgbmV3IEVycm9yIFwiRXZlbnQgaGFuZGxlciBub3QgYSBmdW5jdGlvbjogI3tldmVudEhhbmRsZXJ9XCIgdW5sZXNzIF8uaXNGdW5jdGlvbiBldmVudEhhbmRsZXJcblxuICAjIEV4ZWN1dGUgYWxsIGFyZ3VtZW50cy5cbiAgYXJncyA9IFNwYWNlYmFycy5tdXN0YWNoZUltcGwgKCh4cy4uLikgLT4geHMpLCBhcmdzLi4uXG5cbiAgZnVuID0gKGV2ZW50LCBldmVudEFyZ3MuLi4pIC0+XG4gICAgY3VycmVudFZpZXcgPSBCbGF6ZS5nZXRWaWV3IGV2ZW50LmN1cnJlbnRUYXJnZXRcbiAgICB3cmFwVmlld0FuZFRlbXBsYXRlIGN1cnJlbnRWaWV3LCAtPlxuICAgICAgIyBXZSBkbyBub3QgaGF2ZSB0byBiaW5kIFwidGhpc1wiIGJlY2F1c2UgZXZlbnQgaGFuZGxlcnMgYXJlIHJlc29sdmVkXG4gICAgICAjIGFzIHRlbXBsYXRlIGhlbHBlcnMgYW5kIGFyZSBhbHJlYWR5IGJvdW5kLiBXZSBiaW5kIGV2ZW50IGhhbmRsZXJzXG4gICAgICAjIGluIGR5bmFtaWMgYXR0cmlidXRlcyBhbHJlYWR5IGFzIHdlbGwuXG4gICAgICBldmVudEhhbmRsZXIuYXBwbHkgbnVsbCwgW2V2ZW50XS5jb25jYXQgYXJncywgZXZlbnRBcmdzXG5cbiAgZnVuLmV2ZW50SGFuZGxlciA9IHRydWVcblxuICBmdW5cblxuIyBXaGVuIGNvbnZlcnRpbmcgdGhlIGNvbXBvbmVudCB0byB0aGUgc3RhdGljIEhUTUwsIHJlbW92ZSBhbGwgZXZlbnQgaGFuZGxlcnMuXG5vcmlnaW5hbFZpc2l0VGFnID0gSFRNTC5Ub0hUTUxWaXNpdG9yOjp2aXNpdFRhZ1xuSFRNTC5Ub0hUTUxWaXNpdG9yOjp2aXNpdFRhZyA9ICh0YWcpIC0+XG4gIGlmIGF0dHJzID0gdGFnLmF0dHJzXG4gICAgYXR0cnMgPSBIVE1MLmZsYXR0ZW5BdHRyaWJ1dGVzIGF0dHJzXG4gICAgZm9yIG5hbWUgb2YgYXR0cnMgd2hlbiBzaGFyZS5FVkVOVF9IQU5ETEVSX1JFR0VYLnRlc3QgbmFtZVxuICAgICAgZGVsZXRlIGF0dHJzW25hbWVdXG4gICAgdGFnLmF0dHJzID0gYXR0cnNcblxuICBvcmlnaW5hbFZpc2l0VGFnLmNhbGwgQCwgdGFnXG5cbmN1cnJlbnRWaWV3SWZSZW5kZXJpbmcgPSAtPlxuICB2aWV3ID0gQmxhemUuY3VycmVudFZpZXdcbiAgaWYgdmlldz8uX2lzSW5SZW5kZXJcbiAgICB2aWV3XG4gIGVsc2VcbiAgICBudWxsXG5cbmNvbnRlbnRBc0Z1bmMgPSAoY29udGVudCkgLT5cbiAgIyBXZSBkbyBub3QgY2hlY2sgY29udGVudCBmb3IgdmFsaWRpdHkuXG5cbiAgaWYgIV8uaXNGdW5jdGlvbiBjb250ZW50XG4gICAgcmV0dXJuIC0+XG4gICAgICBjb250ZW50XG5cbiAgY29udGVudFxuXG5jb250ZW50QXNWaWV3ID0gKGNvbnRlbnQpIC0+XG4gICMgV2UgZG8gbm90IGNoZWNrIGNvbnRlbnQgZm9yIHZhbGlkaXR5LlxuXG4gIGlmIGNvbnRlbnQgaW5zdGFuY2VvZiBCbGF6ZS5UZW1wbGF0ZVxuICAgIGNvbnRlbnQuY29uc3RydWN0VmlldygpXG4gIGVsc2UgaWYgY29udGVudCBpbnN0YW5jZW9mIEJsYXplLlZpZXdcbiAgICBjb250ZW50XG4gIGVsc2VcbiAgICBCbGF6ZS5WaWV3ICdyZW5kZXInLCBjb250ZW50QXNGdW5jIGNvbnRlbnRcblxuSFRNTEpTRXhwYW5kZXIgPSBCbGF6ZS5fSFRNTEpTRXhwYW5kZXIuZXh0ZW5kKClcbkhUTUxKU0V4cGFuZGVyLmRlZlxuICAjIEJhc2VkIG9uIEJsYXplLl9IVE1MSlNFeHBhbmRlciwgYnV0IGNhbGxzIG91ciBleHBhbmRWaWV3LlxuICB2aXNpdE9iamVjdDogKHgpIC0+XG4gICAgaWYgeCBpbnN0YW5jZW9mIEJsYXplLlRlbXBsYXRlXG4gICAgICB4ID0geC5jb25zdHJ1Y3RWaWV3KClcbiAgICBpZiB4IGluc3RhbmNlb2YgQmxhemUuVmlld1xuICAgICAgcmV0dXJuIGV4cGFuZFZpZXcgeCwgQHBhcmVudFZpZXdcblxuICAgIEhUTUwuVHJhbnNmb3JtaW5nVmlzaXRvci5wcm90b3R5cGUudmlzaXRPYmplY3QuY2FsbCBALCB4XG5cbiMgQmFzZWQgb24gQmxhemUuX2V4cGFuZCwgYnV0IHVzZXMgb3VyIEhUTUxKU0V4cGFuZGVyLlxuZXhwYW5kID0gKGh0bWxqcywgcGFyZW50VmlldykgLT5cbiAgcGFyZW50VmlldyA9IHBhcmVudFZpZXcgb3IgY3VycmVudFZpZXdJZlJlbmRlcmluZygpXG5cbiAgKG5ldyBIVE1MSlNFeHBhbmRlciBwYXJlbnRWaWV3OiBwYXJlbnRWaWV3KS52aXNpdCBodG1sanNcblxuIyBCYXNlZCBvbiBCbGF6ZS5fZXhwYW5kVmlldywgYnV0IHdpdGggZmx1c2hpbmcuXG5leHBhbmRWaWV3ID0gKHZpZXcsIHBhcmVudFZpZXcpIC0+XG4gIEJsYXplLl9jcmVhdGVWaWV3IHZpZXcsIHBhcmVudFZpZXcsIHRydWVcblxuICB2aWV3Ll9pc0luUmVuZGVyID0gdHJ1ZVxuICBodG1sanMgPSBCbGF6ZS5fd2l0aEN1cnJlbnRWaWV3IHZpZXcsIC0+XG4gICAgdmlldy5fcmVuZGVyKClcbiAgdmlldy5faXNJblJlbmRlciA9IGZhbHNlXG5cbiAgVHJhY2tlci5mbHVzaCgpXG5cbiAgcmVzdWx0ID0gZXhwYW5kIGh0bWxqcywgdmlld1xuXG4gIFRyYWNrZXIuZmx1c2goKVxuXG4gIGlmIFRyYWNrZXIuYWN0aXZlXG4gICAgVHJhY2tlci5vbkludmFsaWRhdGUgLT5cbiAgICAgIEJsYXplLl9kZXN0cm95VmlldyB2aWV3XG4gIGVsc2VcbiAgICBCbGF6ZS5fZGVzdHJveVZpZXcgdmlld1xuXG4gIFRyYWNrZXIuZmx1c2goKVxuXG4gIHJlc3VsdFxuXG5jbGFzcyBCbGF6ZUNvbXBvbmVudCBleHRlbmRzIEJhc2VDb21wb25lbnRcbiAgIyBUT0RPOiBGaWd1cmUgb3V0IGhvdyB0byBkbyBhdCB0aGUgQmFzZUNvbXBvbmVudCBsZXZlbD9cbiAgQGdldENvbXBvbmVudEZvckVsZW1lbnQ6IChkb21FbGVtZW50KSAtPlxuICAgIHJldHVybiBudWxsIHVubGVzcyBkb21FbGVtZW50XG5cbiAgICAjIFRoaXMgdXNlcyB0aGUgc2FtZSBjaGVjayBpZiB0aGUgYXJndW1lbnQgaXMgYSBET00gZWxlbWVudCB0aGF0IEJsYXplLl9ET01SYW5nZS5mb3JFbGVtZW50IGRvZXMuXG4gICAgdGhyb3cgbmV3IEVycm9yIFwiRXhwZWN0ZWQgRE9NIGVsZW1lbnQuXCIgdW5sZXNzIGRvbUVsZW1lbnQubm9kZVR5cGUgaXMgTm9kZS5FTEVNRU5UX05PREVcblxuICAgICMgRm9yIERPTSBlbGVtZW50cyB3ZSB3YW50IHRvIHJldHVybiB0aGUgY29tcG9uZW50IHdoaWNoIG1hdGNoZXMgdGhlIHRlbXBsYXRlXG4gICAgIyB3aXRoIHRoYXQgRE9NIGVsZW1lbnQgYW5kIG5vdCB0aGUgY29tcG9uZW50IGNsb3Nlc3QgaW4gdGhlIGNvbXBvbmVudCB0cmVlLlxuICAgICMgU28gd2Ugc2tpcCB0aGUgYmxvY2sgaGVscGVycy4gKElmIERPTSBlbGVtZW50IGlzIHJlbmRlcmVkIGJ5IHRoZSBibG9jayBoZWxwZXJcbiAgICAjIHRoaXMgd2lsbCBmaW5kIHRoYXQgYmxvY2sgaGVscGVyIHRlbXBsYXRlL2NvbXBvbmVudC4pXG4gICAgdGVtcGxhdGVJbnN0YW5jZSA9IGdldFRlbXBsYXRlSW5zdGFuY2VGdW5jdGlvbiBCbGF6ZS5nZXRWaWV3KGRvbUVsZW1lbnQpLCB0cnVlXG4gICAgdGVtcGxhdGVJbnN0YW5jZVRvQ29tcG9uZW50IHRlbXBsYXRlSW5zdGFuY2UsIHRydWVcblxuICBjaGlsZENvbXBvbmVudHM6IChuYW1lT3JDb21wb25lbnQpIC0+XG4gICAgaWYgKGNvbXBvbmVudCA9IEBjb21wb25lbnQoKSkgaXNudCBAXG4gICAgICBjb21wb25lbnQuY2hpbGRDb21wb25lbnRzIG5hbWVPckNvbXBvbmVudFxuICAgIGVsc2VcbiAgICAgIHN1cGVyXG5cbiAgIyBBIHZlcnNpb24gb2YgY2hpbGRDb21wb25lbnRzV2l0aCB3aGljaCBrbm93cyBhYm91dCBtaXhpbnMuXG4gICMgV2hlbiBjaGVja2luZyBmb3IgcHJvcGVydGllcyBpdCBjaGVja3MgbWl4aW5zIGFzIHdlbGwuXG4gIGNoaWxkQ29tcG9uZW50c1dpdGg6IChwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb24pIC0+XG4gICAgaWYgKGNvbXBvbmVudCA9IEBjb21wb25lbnQoKSkgaXNudCBAXG4gICAgICBjb21wb25lbnQuY2hpbGRDb21wb25lbnRzV2l0aCBwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb25cbiAgICBlbHNlXG4gICAgICBhc3NlcnQgcHJvcGVydHlPck1hdGNoZXJPckZ1bmN0aW9uXG5cbiAgICAgIHByb3BlcnR5T3JNYXRjaGVyT3JGdW5jdGlvbiA9IGNyZWF0ZU1hdGNoZXIgcHJvcGVydHlPck1hdGNoZXJPckZ1bmN0aW9uLCB0cnVlXG5cbiAgICAgIHN1cGVyIHByb3BlcnR5T3JNYXRjaGVyT3JGdW5jdGlvblxuXG4gIHBhcmVudENvbXBvbmVudDogKHBhcmVudENvbXBvbmVudCkgLT5cbiAgICBpZiAoY29tcG9uZW50ID0gQGNvbXBvbmVudCgpKSBpc250IEBcbiAgICAgIGNvbXBvbmVudC5wYXJlbnRDb21wb25lbnQgcGFyZW50Q29tcG9uZW50XG4gICAgZWxzZVxuICAgICAgc3VwZXJcblxuICBhZGRDaGlsZENvbXBvbmVudDogKGNoaWxkQ29tcG9uZW50KSAtPlxuICAgIGlmIChjb21wb25lbnQgPSBAY29tcG9uZW50KCkpIGlzbnQgQFxuICAgICAgY29tcG9uZW50LmFkZENoaWxkQ29tcG9uZW50IGNoaWxkQ29tcG9uZW50XG4gICAgZWxzZVxuICAgICAgc3VwZXJcblxuICByZW1vdmVDaGlsZENvbXBvbmVudDogKGNoaWxkQ29tcG9uZW50KSAtPlxuICAgIGlmIChjb21wb25lbnQgPSBAY29tcG9uZW50KCkpIGlzbnQgQFxuICAgICAgY29tcG9uZW50LnJlbW92ZUNoaWxkQ29tcG9uZW50IGNoaWxkQ29tcG9uZW50XG4gICAgZWxzZVxuICAgICAgc3VwZXJcblxuICBtaXhpbnM6IC0+XG4gICAgW11cblxuICAjIFdoZW4gYSBjb21wb25lbnQgaXMgdXNlZCBhcyBhIG1peGluLCBjcmVhdGVNaXhpbnMgd2lsbCBjYWxsIHRoaXMgbWV0aG9kIHRvIHNldCB0aGUgcGFyZW50XG4gICMgY29tcG9uZW50IHVzaW5nIHRoaXMgbWl4aW4uIEV4dGVuZCB0aGlzIG1ldGhvZCBpZiB5b3Ugd2FudCB0byBkbyBhbnkgYWN0aW9uIHdoZW4gcGFyZW50IGlzXG4gICMgc2V0LCBmb3IgZXhhbXBsZSwgYWRkIGRlcGVuZGVuY3kgbWl4aW5zIHRvIHRoZSBwYXJlbnQuIE1ha2Ugc3VyZSB5b3UgY2FsbCBzdXBlciBhcyB3ZWxsLlxuICBtaXhpblBhcmVudDogKG1peGluUGFyZW50KSAtPlxuICAgIEBfY29tcG9uZW50SW50ZXJuYWxzID89IHt9XG5cbiAgICAjIFNldHRlci5cbiAgICBpZiBtaXhpblBhcmVudFxuICAgICAgQF9jb21wb25lbnRJbnRlcm5hbHMubWl4aW5QYXJlbnQgPSBtaXhpblBhcmVudFxuICAgICAgIyBUbyBhbGxvdyBjaGFpbmluZy5cbiAgICAgIHJldHVybiBAXG5cbiAgICAjIEdldHRlci5cbiAgICBAX2NvbXBvbmVudEludGVybmFscy5taXhpblBhcmVudCBvciBudWxsXG5cbiAgcmVxdWlyZU1peGluOiAobmFtZU9yTWl4aW4pIC0+XG4gICAgYXNzZXJ0IEBfY29tcG9uZW50SW50ZXJuYWxzPy5taXhpbnNcblxuICAgIFRyYWNrZXIubm9ucmVhY3RpdmUgPT5cbiAgICAgICMgRG8gbm90IGRvIGFueXRoaW5nIGlmIG1peGluIGlzIGFscmVhZHkgcmVxdWlyZWQuIFRoaXMgYWxsb3dzIG11bHRpcGxlIG1peGlucyB0byBjYWxsIHJlcXVpcmVNaXhpblxuICAgICAgIyBpbiBtaXhpblBhcmVudCBtZXRob2QgdG8gYWRkIGRlcGVuZGVuY2llcywgYnV0IGlmIGRlcGVuZGVuY2llcyBhcmUgYWxyZWFkeSB0aGVyZSwgbm90aGluZyBoYXBwZW5zLlxuICAgICAgcmV0dXJuIGlmIEBnZXRNaXhpbiBuYW1lT3JNaXhpblxuXG4gICAgICBpZiBfLmlzU3RyaW5nIG5hbWVPck1peGluXG4gICAgICAgICMgSXQgY291bGQgYmUgdGhhdCB0aGUgY29tcG9uZW50IGlzIG5vdCBhIHJlYWwgaW5zdGFuY2Ugb2YgdGhlIEJsYXplQ29tcG9uZW50IGNsYXNzLFxuICAgICAgICAjIHNvIGl0IG1pZ2h0IG5vdCBoYXZlIGEgY29uc3RydWN0b3IgcG9pbnRpbmcgYmFjayB0byBhIEJsYXplQ29tcG9uZW50IHN1YmNsYXNzLlxuICAgICAgICBpZiBAY29uc3RydWN0b3IuZ2V0Q29tcG9uZW50XG4gICAgICAgICAgbWl4aW5JbnN0YW5jZUNvbXBvbmVudCA9IEBjb25zdHJ1Y3Rvci5nZXRDb21wb25lbnQgbmFtZU9yTWl4aW5cbiAgICAgICAgZWxzZVxuICAgICAgICAgIG1peGluSW5zdGFuY2VDb21wb25lbnQgPSBCbGF6ZUNvbXBvbmVudC5nZXRDb21wb25lbnQgbmFtZU9yTWl4aW5cbiAgICAgICAgdGhyb3cgbmV3IEVycm9yIFwiVW5rbm93biBtaXhpbiAnI3tuYW1lT3JNaXhpbn0nLlwiIHVubGVzcyBtaXhpbkluc3RhbmNlQ29tcG9uZW50XG4gICAgICAgIG1peGluSW5zdGFuY2UgPSBuZXcgbWl4aW5JbnN0YW5jZUNvbXBvbmVudCgpXG4gICAgICBlbHNlIGlmIF8uaXNGdW5jdGlvbiBuYW1lT3JNaXhpblxuICAgICAgICBtaXhpbkluc3RhbmNlID0gbmV3IG5hbWVPck1peGluKClcbiAgICAgIGVsc2VcbiAgICAgICAgbWl4aW5JbnN0YW5jZSA9IG5hbWVPck1peGluXG5cbiAgICAgICMgV2UgYWRkIG1peGluIGJlZm9yZSB3ZSBjYWxsIG1peGluUGFyZW50IHNvIHRoYXQgZGVwZW5kZW5jaWVzIGNvbWUgYWZ0ZXIgdGhpcyBtaXhpbixcbiAgICAgICMgYW5kIHRoYXQgd2UgcHJldmVudCBwb3NzaWJsZSBpbmZpbml0ZSBsb29wcyBiZWNhdXNlIG9mIGNpcmN1bGFyIGRlcGVuZGVuY2llcy5cbiAgICAgICMgVE9ETzogRm9yIG5vdyB3ZSBkbyBub3QgcHJvdmlkZSBhbiBvZmZpY2lhbCBBUEkgdG8gYWRkIGRlcGVuZGVuY2llcyBiZWZvcmUgdGhlIG1peGluIGl0c2VsZi5cbiAgICAgIEBfY29tcG9uZW50SW50ZXJuYWxzLm1peGlucy5wdXNoIG1peGluSW5zdGFuY2VcblxuICAgICAgIyBXZSBhbGxvdyBtaXhpbnMgdG8gbm90IGJlIGNvbXBvbmVudHMsIHNvIG1ldGhvZHMgYXJlIG5vdCBuZWNlc3NhcnkgYXZhaWxhYmxlLlxuXG4gICAgICAjIFNldCBtaXhpbiBwYXJlbnQuXG4gICAgICBpZiBtaXhpbkluc3RhbmNlLm1peGluUGFyZW50XG4gICAgICAgIG1peGluSW5zdGFuY2UubWl4aW5QYXJlbnQgQFxuXG4gICAgICAjIE1heWJlIG1peGluIGhhcyBpdHMgb3duIG1peGlucyBhcyB3ZWxsLlxuICAgICAgbWl4aW5JbnN0YW5jZS5jcmVhdGVNaXhpbnM/KClcblxuICAgICAgaWYgY29tcG9uZW50ID0gQGNvbXBvbmVudCgpXG4gICAgICAgIGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzID89IHt9XG4gICAgICAgIGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLnRlbXBsYXRlSW5zdGFuY2UgPz0gbmV3IFJlYWN0aXZlRmllbGQgbnVsbCwgKGEsIGIpIC0+IGEgaXMgYlxuXG4gICAgICAgICMgSWYgYSBtaXhpbiBpcyBhZGRpbmcgYSBkZXBlbmRlbmN5IHVzaW5nIHJlcXVpcmVNaXhpbiBhZnRlciBpdHMgbWl4aW5QYXJlbnQgY2xhc3MgKGZvciBleGFtcGxlLCBpbiBvbkNyZWF0ZSlcbiAgICAgICAgIyBhbmQgdGhpcyBpcyB0aGlzIGRlcGVuZGVuY3kgbWl4aW4sIHRoZSB2aWV3IG1pZ2h0IGFscmVhZHkgYmUgY3JlYXRlZCBvciByZW5kZXJlZCBhbmQgY2FsbGJhY2tzIHdlcmVcbiAgICAgICAgIyBhbHJlYWR5IGNhbGxlZCwgc28gd2Ugc2hvdWxkIGNhbGwgdGhlbSBtYW51YWxseSBoZXJlIGFzIHdlbGwuIEJ1dCBvbmx5IGlmIGhlIHZpZXcgaGFzIG5vdCBiZWVuIGRlc3Ryb3llZFxuICAgICAgICAjIGFscmVhZHkuIEZvciB0aG9zZSBtaXhpbnMgd2UgZG8gbm90IGNhbGwgYW55dGhpbmcsIHRoZXJlIGlzIGxpdHRsZSB1c2UgZm9yIHRoZW0gbm93LlxuICAgICAgICB1bmxlc3MgY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMudGVtcGxhdGVJbnN0YW5jZSgpPy52aWV3LmlzRGVzdHJveWVkXG4gICAgICAgICAgbWl4aW5JbnN0YW5jZS5vbkNyZWF0ZWQ/KCkgaWYgbm90IGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLmluT25DcmVhdGVkIGFuZCBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscy50ZW1wbGF0ZUluc3RhbmNlKCk/LnZpZXcuaXNDcmVhdGVkXG4gICAgICAgICAgbWl4aW5JbnN0YW5jZS5vblJlbmRlcmVkPygpIGlmIG5vdCBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscy5pbk9uUmVuZGVyZWQgYW5kIGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLnRlbXBsYXRlSW5zdGFuY2UoKT8udmlldy5pc1JlbmRlcmVkXG5cbiAgICAjIFRvIGFsbG93IGNoYWluaW5nLlxuICAgIEBcblxuICAjIE1ldGhvZCB0byBpbnN0YW50aWF0ZSBhbGwgbWl4aW5zLlxuICBjcmVhdGVNaXhpbnM6IC0+XG4gICAgQF9jb21wb25lbnRJbnRlcm5hbHMgPz0ge31cblxuICAgICMgVG8gYWxsb3cgY2FsbGluZyBpdCBtdWx0aXBsZSB0aW1lcywgYnV0IG5vbi1maXJzdCBjYWxscyBhcmUgc2ltcGx5IGlnbm9yZWQuXG4gICAgcmV0dXJuIGlmIEBfY29tcG9uZW50SW50ZXJuYWxzLm1peGluc1xuICAgIEBfY29tcG9uZW50SW50ZXJuYWxzLm1peGlucyA9IFtdXG5cbiAgICBmb3IgbWl4aW4gaW4gQG1peGlucygpXG4gICAgICBAcmVxdWlyZU1peGluIG1peGluXG5cbiAgICAjIFRvIGFsbG93IGNoYWluaW5nLlxuICAgIEBcblxuICBnZXRNaXhpbjogKG5hbWVPck1peGluKSAtPlxuICAgIGlmIF8uaXNTdHJpbmcgbmFtZU9yTWl4aW5cbiAgICAgICMgQnkgcGFzc2luZyBAIGFzIHRoZSBmaXJzdCBhcmd1bWVudCwgd2UgdHJhdmVyc2Ugb25seSBtaXhpbnMuXG4gICAgICBAZ2V0Rmlyc3RXaXRoIEAsIChjaGlsZCwgcGFyZW50KSA9PlxuICAgICAgICAjIFdlIGRvIG5vdCByZXF1aXJlIG1peGlucyB0byBiZSBjb21wb25lbnRzLCBidXQgaWYgdGhleSBhcmUsIHRoZXkgY2FuXG4gICAgICAgICMgYmUgcmVmZXJlbmNlZCBiYXNlZCBvbiB0aGVpciBjb21wb25lbnQgbmFtZS5cbiAgICAgICAgbWl4aW5Db21wb25lbnROYW1lID0gY2hpbGQuY29tcG9uZW50TmFtZT8oKSBvciBudWxsXG4gICAgICAgIHJldHVybiBtaXhpbkNvbXBvbmVudE5hbWUgYW5kIG1peGluQ29tcG9uZW50TmFtZSBpcyBuYW1lT3JNaXhpblxuICAgIGVsc2VcbiAgICAgICMgQnkgcGFzc2luZyBAIGFzIHRoZSBmaXJzdCBhcmd1bWVudCwgd2UgdHJhdmVyc2Ugb25seSBtaXhpbnMuXG4gICAgICBAZ2V0Rmlyc3RXaXRoIEAsIChjaGlsZCwgcGFyZW50KSA9PlxuICAgICAgICAjIG5hbWVPck1peGluIGlzIGEgY2xhc3MuXG4gICAgICAgIHJldHVybiB0cnVlIGlmIGNoaWxkLmNvbnN0cnVjdG9yIGlzIG5hbWVPck1peGluXG5cbiAgICAgICAgIyBuYW1lT3JNaXhpbiBpcyBhbiBpbnN0YW5jZSwgb3Igc29tZXRoaW5nIGVsc2UuXG4gICAgICAgIHJldHVybiB0cnVlIGlmIGNoaWxkIGlzIG5hbWVPck1peGluXG5cbiAgICAgICAgZmFsc2VcblxuICAjIENhbGxzIHRoZSBjb21wb25lbnQgKGlmIGFmdGVyQ29tcG9uZW50T3JNaXhpbiBpcyBudWxsKSBvciB0aGUgZmlyc3QgbmV4dCBtaXhpblxuICAjIGFmdGVyIGFmdGVyQ29tcG9uZW50T3JNaXhpbiBpdCBmaW5kcywgYW5kIHJldHVybnMgdGhlIHJlc3VsdC5cbiAgY2FsbEZpcnN0V2l0aDogKGFmdGVyQ29tcG9uZW50T3JNaXhpbiwgcHJvcGVydHlOYW1lLCBhcmdzLi4uKSAtPlxuICAgIGFzc2VydCBfLmlzU3RyaW5nIHByb3BlcnR5TmFtZVxuXG4gICAgY29tcG9uZW50T3JNaXhpbiA9IEBnZXRGaXJzdFdpdGggYWZ0ZXJDb21wb25lbnRPck1peGluLCBwcm9wZXJ0eU5hbWVcblxuICAgICMgVE9ETzogU2hvdWxkIHdlIHRocm93IGFuIGVycm9yIGhlcmU/IFNvbWV0aGluZyBsaWtlIGNhbGxpbmcgYSBmdW5jdGlvbiB3aGljaCBkb2VzIG5vdCBleGlzdD9cbiAgICByZXR1cm4gdW5sZXNzIGNvbXBvbmVudE9yTWl4aW5cblxuICAgICMgV2UgYXJlIG5vdCBjYWxsaW5nIGNhbGxGaXJzdFdpdGggb24gdGhlIGNvbXBvbmVudE9yTWl4aW4gYmVjYXVzZSBoZXJlIHdlXG4gICAgIyBhcmUgYWxyZWFkeSB0cmF2ZXJzaW5nIG1peGlucyBzbyB3ZSBkbyBub3QgcmVjdXJzZSBvbmNlIG1vcmUuXG4gICAgaWYgXy5pc0Z1bmN0aW9uIGNvbXBvbmVudE9yTWl4aW5bcHJvcGVydHlOYW1lXVxuICAgICAgcmV0dXJuIGNvbXBvbmVudE9yTWl4aW5bcHJvcGVydHlOYW1lXSBhcmdzLi4uXG4gICAgZWxzZVxuICAgICAgcmV0dXJuIGNvbXBvbmVudE9yTWl4aW5bcHJvcGVydHlOYW1lXVxuXG4gIGdldEZpcnN0V2l0aDogKGFmdGVyQ29tcG9uZW50T3JNaXhpbiwgcHJvcGVydHlPck1hdGNoZXJPckZ1bmN0aW9uKSAtPlxuICAgIGFzc2VydCBAX2NvbXBvbmVudEludGVybmFscz8ubWl4aW5zXG4gICAgYXNzZXJ0IHByb3BlcnR5T3JNYXRjaGVyT3JGdW5jdGlvblxuXG4gICAgIyBIZXJlIHdlIGFyZSBhbHJlYWR5IHRyYXZlcnNpbmcgbWl4aW5zIHNvIHdlIGRvIG5vdCByZWN1cnNlIG9uY2UgbW9yZS5cbiAgICBwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb24gPSBjcmVhdGVNYXRjaGVyIHByb3BlcnR5T3JNYXRjaGVyT3JGdW5jdGlvbiwgZmFsc2VcblxuICAgICMgSWYgYWZ0ZXJDb21wb25lbnRPck1peGluIGlzIG5vdCBwcm92aWRlZCwgd2Ugc3RhcnQgd2l0aCB0aGUgY29tcG9uZW50LlxuICAgIGlmIG5vdCBhZnRlckNvbXBvbmVudE9yTWl4aW5cbiAgICAgIHJldHVybiBAIGlmIHByb3BlcnR5T3JNYXRjaGVyT3JGdW5jdGlvbi5jYWxsIEAsIEAsIEBcbiAgICAgICMgQW5kIGNvbnRpbnVlIHdpdGggbWl4aW5zLlxuICAgICAgZm91bmQgPSB0cnVlXG4gICAgIyBJZiBhZnRlckNvbXBvbmVudE9yTWl4aW4gaXMgdGhlIGNvbXBvbmVudCwgd2Ugc3RhcnQgd2l0aCBtaXhpbnMuXG4gICAgZWxzZSBpZiBhZnRlckNvbXBvbmVudE9yTWl4aW4gYW5kIGFmdGVyQ29tcG9uZW50T3JNaXhpbiBpcyBAXG4gICAgICBmb3VuZCA9IHRydWVcbiAgICBlbHNlXG4gICAgICBmb3VuZCA9IGZhbHNlXG5cbiAgICAjIFRPRE86IEltcGxlbWVudCB3aXRoIGEgbWFwIGJldHdlZW4gbWl4aW4gLT4gcG9zaXRpb24sIHNvIHRoYXQgd2UgZG8gbm90IGhhdmUgdG8gc2VlayB0byBmaW5kIGEgbWl4aW4uXG4gICAgZm9yIG1peGluIGluIEBfY29tcG9uZW50SW50ZXJuYWxzLm1peGluc1xuICAgICAgcmV0dXJuIG1peGluIGlmIGZvdW5kIGFuZCBwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb24uY2FsbCBALCBtaXhpbiwgQFxuXG4gICAgICBmb3VuZCA9IHRydWUgaWYgbWl4aW4gaXMgYWZ0ZXJDb21wb25lbnRPck1peGluXG5cbiAgICBudWxsXG5cbiAgIyBUaGlzIGNsYXNzIG1ldGhvZCBtb3JlIG9yIGxlc3MganVzdCBjcmVhdGVzIGFuIGluc3RhbmNlIG9mIGEgY29tcG9uZW50IGFuZCBjYWxscyBpdHMgcmVuZGVyQ29tcG9uZW50XG4gICMgbWV0aG9kLiBCdXQgYmVjYXVzZSB3ZSB3YW50IHRvIGFsbG93IHBhc3NpbmcgYXJndW1lbnRzIHRvIHRoZSBjb21wb25lbnQgaW4gdGVtcGxhdGVzLCB3ZSBoYXZlIHNvbWVcbiAgIyBjb21wbGljYXRlZCBjb2RlIGFyb3VuZCB0byBleHRyYWN0IGFuZCBwYXNzIHRob3NlIGFyZ3VtZW50cy4gSXQgaXMgc2ltaWxhciB0byBob3cgZGF0YSBjb250ZXh0IGlzXG4gICMgcGFzc2VkIHRvIGJsb2NrIGhlbHBlcnMuIEluIGEgZGF0YSBjb250ZXh0IHZpc2libGUgb25seSB0byB0aGUgYmxvY2sgaGVscGVyIHRlbXBsYXRlLlxuICAjIFRPRE86IFRoaXMgY291bGQgYmUgbWFkZSBsZXNzIGhhY2t5LiBTZWUgaHR0cHM6Ly9naXRodWIuY29tL21ldGVvci9tZXRlb3IvaXNzdWVzLzM5MTNcbiAgQHJlbmRlckNvbXBvbmVudDogKHBhcmVudENvbXBvbmVudCkgLT5cbiAgICBUcmFja2VyLm5vbnJlYWN0aXZlID0+XG4gICAgICBjb21wb25lbnRDbGFzcyA9IEBcblxuICAgICAgaWYgQmxhemUuY3VycmVudFZpZXdcbiAgICAgICAgIyBXZSBjaGVjayBkYXRhIGNvbnRleHQgaW4gYSBub24tcmVhY3RpdmUgd2F5LCBiZWNhdXNlIHdlIHdhbnQganVzdCB0byBwZWVrIGludG8gaXRcbiAgICAgICAgIyBhbmQgZGV0ZXJtaW5lIGlmIGRhdGEgY29udGV4dCBjb250YWlucyBjb21wb25lbnQgYXJndW1lbnRzIG9yIG5vdC4gQW5kIHdoaWxlXG4gICAgICAgICMgY29tcG9uZW50IGFyZ3VtZW50cyBtaWdodCBjaGFuZ2UgdGhyb3VnaCB0aW1lLCB0aGUgZmFjdCB0aGF0IHRoZXkgYXJlIHRoZXJlIGF0XG4gICAgICAgICMgYWxsIG9yIG5vdCAoXCJhcmdzXCIgdGVtcGxhdGUgaGVscGVyIHdhcyB1c2VkIG9yIG5vdCkgZG9lcyBub3QgY2hhbmdlIHRocm91Z2ggdGltZS5cbiAgICAgICAgIyBTbyB3ZSBjYW4gY2hlY2sgdGhhdCBub24tcmVhY3RpdmVseS5cbiAgICAgICAgZGF0YSA9IFRlbXBsYXRlLmN1cnJlbnREYXRhKClcbiAgICAgIGVsc2VcbiAgICAgICAgIyBUaGVyZSBpcyBubyBjdXJyZW50IHZpZXcgd2hlbiB0aGVyZSBpcyBubyBkYXRhIGNvbnRleHQgeWV0LCB0aHVzIGFsc28gbm8gYXJndW1lbnRzXG4gICAgICAgICMgd2VyZSBwcm92aWRlZCB0aHJvdWdoIFwiYXJnc1wiIHRlbXBsYXRlIGhlbHBlciwgc28gd2UganVzdCBjb250aW51ZSBub3JtYWxseS5cbiAgICAgICAgZGF0YSA9IG51bGxcblxuICAgICAgaWYgZGF0YT8uY29uc3RydWN0b3IgaXNudCBhcmd1bWVudHNDb25zdHJ1Y3RvclxuICAgICAgICAjIFNvIHRoYXQgY3VycmVudENvbXBvbmVudCBpbiB0aGUgY29uc3RydWN0b3IgY2FuIHJldHVybiB0aGUgY29tcG9uZW50XG4gICAgICAgICMgaW5zaWRlIHdoaWNoIHRoaXMgY29tcG9uZW50IGhhcyBiZWVuIGNvbnN0cnVjdGVkLlxuICAgICAgICByZXR1cm4gd3JhcFZpZXdBbmRUZW1wbGF0ZSBCbGF6ZS5jdXJyZW50VmlldywgPT5cbiAgICAgICAgICBjb21wb25lbnQgPSBuZXcgY29tcG9uZW50Q2xhc3MoKVxuXG4gICAgICAgICAgcmV0dXJuIGNvbXBvbmVudC5yZW5kZXJDb21wb25lbnQgcGFyZW50Q29tcG9uZW50XG5cbiAgICAgICMgQXJndW1lbnRzIHdlcmUgcHJvdmlkZWQgdGhyb3VnaCBcImFyZ3NcIiB0ZW1wbGF0ZSBoZWxwZXIuXG5cbiAgICAgICMgV2Ugd2FudCB0byByZWFjdGl2ZWx5IGRlcGVuZCBvbiB0aGUgZGF0YSBjb250ZXh0IGZvciBhcmd1bWVudHMsIHNvIHdlIHJldHVybiBhIGZ1bmN0aW9uXG4gICAgICAjIGluc3RlYWQgb2YgYSB0ZW1wbGF0ZS4gRnVuY3Rpb24gd2lsbCBiZSBydW4gaW5zaWRlIGFuIGF1dG9ydW4sIGEgcmVhY3RpdmUgY29udGV4dC5cbiAgICAgIC0+XG4gICAgICAgIGFzc2VydCBUcmFja2VyLmFjdGl2ZVxuXG4gICAgICAgICMgV2UgY2Fubm90IHVzZSBUZW1wbGF0ZS5nZXREYXRhKCkgaW5zaWRlIGEgbm9ybWFsIGF1dG9ydW4gYmVjYXVzZSBjdXJyZW50IHZpZXcgaXMgbm90IGRlZmluZWQgaW5zaWRlXG4gICAgICAgICMgYSBub3JtYWwgYXV0b3J1bi4gQnV0IHdlIGRvIG5vdCByZWFsbHkgaGF2ZSB0byBkZXBlbmQgcmVhY3RpdmVseSBvbiB0aGUgY3VycmVudCB2aWV3LCBvbmx5IG9uIHRoZVxuICAgICAgICAjIGRhdGEgY29udGV4dCBvZiBhIGtub3duICh0aGUgY2xvc2VzdCBCbGF6ZS5XaXRoKSB2aWV3LiBTbyB3ZSBnZXQgdGhpcyB2aWV3IGJ5IG91cnNlbHZlcy5cbiAgICAgICAgY3VycmVudFdpdGggPSBCbGF6ZS5nZXRWaWV3ICd3aXRoJ1xuXG4gICAgICAgICMgQnkgZGVmYXVsdCBkYXRhVmFyIGluIHRoZSBCbGF6ZS5XaXRoIHZpZXcgdXNlcyBSZWFjdGl2ZVZhciB3aXRoIGRlZmF1bHQgZXF1YWxpdHkgZnVuY3Rpb24gd2hpY2hcbiAgICAgICAgIyBzZWVzIGFsbCBvYmplY3RzIGFzIGRpZmZlcmVudC4gU28gaW52YWxpZGF0aW9ucyBhcmUgdHJpZ2dlcmVkIGZvciBldmVyeSBkYXRhIGNvbnRleHQgYXNzaWdubWVudHNcbiAgICAgICAgIyBldmVuIGlmIGRhdGEgaGFzIG5vdCByZWFsbHkgY2hhbmdlZC4gVGhpcyBpcyB3aHkgd3JhcCBpdCBpbnRvIGEgQ29tcHV0ZWRGaWVsZCB3aXRoIEVKU09OLmVxdWFscy5cbiAgICAgICAgIyBCZWNhdXNlIGl0IHVzZXMgRUpTT04uZXF1YWxzIGl0IHdpbGwgaW52YWxpZGF0ZSBvdXIgZnVuY3Rpb24gb25seSBpZiByZWFsbHkgY2hhbmdlcy5cbiAgICAgICAgIyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL21ldGVvci9tZXRlb3IvaXNzdWVzLzQwNzNcbiAgICAgICAgcmVhY3RpdmVBcmd1bWVudHMgPSBuZXcgQ29tcHV0ZWRGaWVsZCAtPlxuICAgICAgICAgIGRhdGEgPSBjdXJyZW50V2l0aC5kYXRhVmFyLmdldCgpXG4gICAgICAgICAgYXNzZXJ0LmVxdWFsIGRhdGE/LmNvbnN0cnVjdG9yLCBhcmd1bWVudHNDb25zdHJ1Y3RvclxuICAgICAgICAgIGRhdGEuX2FyZ3VtZW50c1xuICAgICAgICAsXG4gICAgICAgICAgRUpTT04uZXF1YWxzXG5cbiAgICAgICAgIyBIZXJlIHdlIHJlZ2lzdGVyIGEgcmVhY3RpdmUgZGVwZW5kZW5jeSBvbiB0aGUgQ29tcHV0ZWRGaWVsZC5cbiAgICAgICAgbm9ucmVhY3RpdmVBcmd1bWVudHMgPSByZWFjdGl2ZUFyZ3VtZW50cygpXG5cbiAgICAgICAgVHJhY2tlci5ub25yZWFjdGl2ZSAtPlxuICAgICAgICAgICMgQXJndW1lbnRzIHdlcmUgcGFzc2VkIGluIGFzIGEgZGF0YSBjb250ZXh0LiBXZSB3YW50IGN1cnJlbnREYXRhIGluIHRoZSBjb25zdHJ1Y3RvciB0byByZXR1cm4gdGhlXG4gICAgICAgICAgIyBvcmlnaW5hbCAocGFyZW50KSBkYXRhIGNvbnRleHQuIExpa2Ugd2Ugd2VyZSBub3QgcGFzc2luZyBpbiBhcmd1bWVudHMgYXMgYSBkYXRhIGNvbnRleHQuXG4gICAgICAgICAgdGVtcGxhdGUgPSBCbGF6ZS5fd2l0aEN1cnJlbnRWaWV3IEJsYXplLmN1cnJlbnRWaWV3LnBhcmVudFZpZXcucGFyZW50VmlldywgPT5cbiAgICAgICAgICAgICMgU28gdGhhdCBjdXJyZW50Q29tcG9uZW50IGluIHRoZSBjb25zdHJ1Y3RvciBjYW4gcmV0dXJuIHRoZSBjb21wb25lbnRcbiAgICAgICAgICAgICMgaW5zaWRlIHdoaWNoIHRoaXMgY29tcG9uZW50IGhhcyBiZWVuIGNvbnN0cnVjdGVkLlxuICAgICAgICAgICAgcmV0dXJuIHdyYXBWaWV3QW5kVGVtcGxhdGUgQmxhemUuY3VycmVudFZpZXcsID0+XG4gICAgICAgICAgICAgICMgVXNlIGFyZ3VtZW50cyBmb3IgdGhlIGNvbnN0cnVjdG9yLlxuICAgICAgICAgICAgICBjb21wb25lbnQgPSBuZXcgY29tcG9uZW50Q2xhc3Mgbm9ucmVhY3RpdmVBcmd1bWVudHMuLi5cblxuICAgICAgICAgICAgICByZXR1cm4gY29tcG9uZW50LnJlbmRlckNvbXBvbmVudCBwYXJlbnRDb21wb25lbnRcblxuICAgICAgICAgICMgSXQgaGFzIHRvIGJlIHRoZSBmaXJzdCBjYWxsYmFjayBzbyB0aGF0IG90aGVyIGhhdmUgYSBjb3JyZWN0IGRhdGEgY29udGV4dC5cbiAgICAgICAgICByZWdpc3RlckZpcnN0Q3JlYXRlZEhvb2sgdGVtcGxhdGUsIC0+XG4gICAgICAgICAgICAjIEFyZ3VtZW50cyB3ZXJlIHBhc3NlZCBpbiBhcyBhIGRhdGEgY29udGV4dC4gUmVzdG9yZSBvcmlnaW5hbCAocGFyZW50KSBkYXRhXG4gICAgICAgICAgICAjIGNvbnRleHQuIFNhbWUgbG9naWMgYXMgaW4gQmxhemUuX0luT3V0ZXJUZW1wbGF0ZVNjb3BlLlxuICAgICAgICAgICAgQHZpZXcub3JpZ2luYWxQYXJlbnRWaWV3ID0gQHZpZXcucGFyZW50Vmlld1xuICAgICAgICAgICAgQHZpZXcucGFyZW50VmlldyA9IEB2aWV3LnBhcmVudFZpZXcucGFyZW50Vmlldy5wYXJlbnRWaWV3XG5cbiAgICAgICAgICB0ZW1wbGF0ZVxuXG4gIHJlbmRlckNvbXBvbmVudDogKHBhcmVudENvbXBvbmVudCkgLT5cbiAgICAjIFRvIG1ha2Ugc3VyZSB3ZSBkbyBub3QgaW50cm9kdWNlIGFueSByZWFjdGl2ZSBkZXBlbmRlbmN5LiBUaGlzIGlzIGEgY29uc2Npb3VzIGRlc2lnbiBkZWNpc2lvbi5cbiAgICAjIFJlYWN0aXZpdHkgc2hvdWxkIGJlIGNoYW5naW5nIGRhdGEgY29udGV4dCwgYnV0IGNvbXBvbmVudHMgc2hvdWxkIGJlIG1vcmUgc3RhYmxlLCBvbmx5IGNoYW5naW5nXG4gICAgIyB3aGVuIHN0cnVjdHVyZSBjaGFuZ2UgaW4gcmVuZGVyZWQgRE9NLiBZb3UgY2FuIGNoYW5nZSB0aGUgY29tcG9uZW50IHlvdSBhcmUgaW5jbHVkaW5nIChvciBwYXNzXG4gICAgIyBkaWZmZXJlbnQgYXJndW1lbnRzKSByZWFjdGl2ZWx5IHRob3VnaC5cbiAgICBUcmFja2VyLm5vbnJlYWN0aXZlID0+XG4gICAgICBjb21wb25lbnQgPSBAY29tcG9uZW50KClcblxuICAgICAgIyBJZiBtaXhpbnMgaGF2ZSBub3QgeWV0IGJlZW4gY3JlYXRlZC5cbiAgICAgIGNvbXBvbmVudC5jcmVhdGVNaXhpbnMoKVxuXG4gICAgICB0ZW1wbGF0ZUJhc2UgPSBnZXRUZW1wbGF0ZUJhc2UgY29tcG9uZW50XG5cbiAgICAgICMgQ3JlYXRlIGEgbmV3IGNvbXBvbmVudCB0ZW1wbGF0ZSBiYXNlZCBvbiB0aGUgQmxhemUgdGVtcGxhdGUuIFdlIHdhbnQgb3VyIG93biB0ZW1wbGF0ZVxuICAgICAgIyBiZWNhdXNlIHRoZSBzYW1lIEJsYXplIHRlbXBsYXRlIGNvdWxkIGJlIHJldXNlZCBiZXR3ZWVuIG11bHRpcGxlIGNvbXBvbmVudHMuXG4gICAgICAjIFRPRE86IFNob3VsZCB3ZSBjYWNoZSB0aGVzZSB0ZW1wbGF0ZXMgYmFzZWQgb24gKGNvbXBvbmVudE5hbWUsIHRlbXBsYXRlQmFzZSkgcGFpcj8gV2UgY291bGQgdXNlIHR3byBsZXZlbHMgb2YgRVMyMDE1IE1hcHMsIGNvbXBvbmVudE5hbWUgLT4gdGVtcGxhdGVCYXNlIC0+IHRlbXBsYXRlLiBXaGF0IGFib3V0IGNvbXBvbmVudCBhcmd1bWVudHMgY2hhbmdpbmc/XG4gICAgICB0ZW1wbGF0ZSA9IG5ldyBCbGF6ZS5UZW1wbGF0ZSBcIkJsYXplQ29tcG9uZW50LiN7Y29tcG9uZW50LmNvbXBvbmVudE5hbWUoKSBvciAndW5uYW1lZCd9XCIsIHRlbXBsYXRlQmFzZS5yZW5kZXJGdW5jdGlvblxuXG4gICAgICAjIFdlIGxvb2t1cCBwcmVleGlzdGluZyB0ZW1wbGF0ZSBoZWxwZXJzIGluIEJsYXplLl9nZXRUZW1wbGF0ZUhlbHBlciwgaWYgdGhlIGNvbXBvbmVudCBkb2VzIG5vdCBoYXZlXG4gICAgICAjIGEgcHJvcGVydHkgd2l0aCB0aGUgc2FtZSBuYW1lLiBQcmVleGlzdGluZyBldmVudCBoYW5kbGVycyBhbmQgbGlmZS1jeWNsZSBob29rcyBhcmUgdGFrZW4gY2FyZSBvZlxuICAgICAgIyBpbiB0aGUgcmVsYXRlZCBtZXRob2RzIGluIHRoZSBiYXNlIGNsYXNzLlxuXG4gICAgICBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscyA/PSB7fVxuICAgICAgY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMudGVtcGxhdGVCYXNlID0gdGVtcGxhdGVCYXNlXG5cbiAgICAgIHJlZ2lzdGVySG9va3MgdGVtcGxhdGUsXG4gICAgICAgIG9uQ3JlYXRlZDogLT5cbiAgICAgICAgICAjIEAgaXMgYSB0ZW1wbGF0ZSBpbnN0YW5jZS5cblxuICAgICAgICAgIGlmIHBhcmVudENvbXBvbmVudFxuICAgICAgICAgICAgIyBjb21wb25lbnQucGFyZW50Q29tcG9uZW50IGlzIHJlYWN0aXZlLCBzbyB3ZSB1c2UgVHJhY2tlci5ub25yZWFjdGl2ZSBqdXN0IHRvIG1ha2Ugc3VyZSB3ZSBkbyBub3QgbGVhayBhbnkgcmVhY3Rpdml0eSBoZXJlLlxuICAgICAgICAgICAgVHJhY2tlci5ub25yZWFjdGl2ZSA9PlxuICAgICAgICAgICAgICAjIFRPRE86IFNob3VsZCB3ZSBzdXBwb3J0IHRoYXQgdGhlIHNhbWUgY29tcG9uZW50IGNhbiBiZSByZW5kZXJlZCBtdWx0aXBsZSB0aW1lcyBpbiBwYXJhbGxlbD8gSG93IGNvdWxkIHdlIGRvIHRoYXQ/IEZvciBkaWZmZXJlbnQgY29tcG9uZW50IHBhcmVudHMgb3Igb25seSB0aGUgc2FtZSBvbmU/XG4gICAgICAgICAgICAgIGFzc2VydCBub3QgY29tcG9uZW50LnBhcmVudENvbXBvbmVudCgpLCBcIkNvbXBvbmVudCAnI3tjb21wb25lbnQuY29tcG9uZW50TmFtZSgpIG9yICd1bm5hbWVkJ30nIHBhcmVudCBjb21wb25lbnQgJyN7Y29tcG9uZW50LnBhcmVudENvbXBvbmVudCgpPy5jb21wb25lbnROYW1lKCkgb3IgJ3VubmFtZWQnfScgYWxyZWFkeSBzZXQuXCJcblxuICAgICAgICAgICAgICAjIFdlIHNldCB0aGUgcGFyZW50IG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGlzIGNyZWF0ZWQsIG5vdCBqdXN0IGNvbnN0cnVjdGVkLlxuICAgICAgICAgICAgICBjb21wb25lbnQucGFyZW50Q29tcG9uZW50IHBhcmVudENvbXBvbmVudFxuICAgICAgICAgICAgICBwYXJlbnRDb21wb25lbnQuYWRkQ2hpbGRDb21wb25lbnQgY29tcG9uZW50XG5cbiAgICAgICAgICBAdmlldy5fb25WaWV3UmVuZGVyZWQgPT5cbiAgICAgICAgICAgICMgQXR0YWNoIGV2ZW50cyB0aGUgZmlyc3QgdGltZSB0ZW1wbGF0ZSBpbnN0YW5jZSByZW5kZXJzLlxuICAgICAgICAgICAgcmV0dXJuIHVubGVzcyBAdmlldy5yZW5kZXJDb3VudCBpcyAxXG5cbiAgICAgICAgICAgICMgV2UgZmlyc3QgYWRkIGV2ZW50IGhhbmRsZXJzIGZyb20gdGhlIGNvbXBvbmVudCwgdGhlbiBtaXhpbnMuXG4gICAgICAgICAgICBjb21wb25lbnRPck1peGluID0gbnVsbFxuICAgICAgICAgICAgd2hpbGUgY29tcG9uZW50T3JNaXhpbiA9IEBjb21wb25lbnQuZ2V0Rmlyc3RXaXRoIGNvbXBvbmVudE9yTWl4aW4sICdldmVudHMnXG4gICAgICAgICAgICAgIGFkZEV2ZW50cyBAdmlldywgY29tcG9uZW50T3JNaXhpblxuXG4gICAgICAgICAgQGNvbXBvbmVudCA9IGNvbXBvbmVudFxuXG4gICAgICAgICAgIyBUT0RPOiBTaG91bGQgd2Ugc3VwcG9ydCB0aGF0IHRoZSBzYW1lIGNvbXBvbmVudCBjYW4gYmUgcmVuZGVyZWQgbXVsdGlwbGUgdGltZXMgaW4gcGFyYWxsZWw/IEhvdyBjb3VsZCB3ZSBkbyB0aGF0PyBGb3IgZGlmZmVyZW50IGNvbXBvbmVudCBwYXJlbnRzIG9yIG9ubHkgdGhlIHNhbWUgb25lP1xuICAgICAgICAgIGFzc2VydCBub3QgVHJhY2tlci5ub25yZWFjdGl2ZSA9PiBAY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMudGVtcGxhdGVJbnN0YW5jZT8oKVxuXG4gICAgICAgICAgQGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLnRlbXBsYXRlSW5zdGFuY2UgPz0gbmV3IFJlYWN0aXZlRmllbGQgQCwgKGEsIGIpIC0+IGEgaXMgYlxuICAgICAgICAgIEBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscy50ZW1wbGF0ZUluc3RhbmNlIEBcblxuICAgICAgICAgIEBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscy5pc0NyZWF0ZWQgPz0gbmV3IFJlYWN0aXZlRmllbGQgdHJ1ZVxuICAgICAgICAgIEBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscy5pc0NyZWF0ZWQgdHJ1ZVxuXG4gICAgICAgICAgIyBNYXliZSB3ZSBhcmUgcmUtcmVuZGVyaW5nIHRoZSBjb21wb25lbnQuIFNvIGxldCdzIGluaXRpYWxpemUgdmFyaWFibGVzIGp1c3QgdG8gYmUgc3VyZS5cblxuICAgICAgICAgIEBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscy5pc1JlbmRlcmVkID89IG5ldyBSZWFjdGl2ZUZpZWxkIGZhbHNlXG4gICAgICAgICAgQGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLmlzUmVuZGVyZWQgZmFsc2VcblxuICAgICAgICAgIEBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscy5pc0Rlc3Ryb3llZCA/PSBuZXcgUmVhY3RpdmVGaWVsZCBmYWxzZVxuICAgICAgICAgIEBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscy5pc0Rlc3Ryb3llZCBmYWxzZVxuXG4gICAgICAgICAgdHJ5XG4gICAgICAgICAgICAjIFdlIGhhdmUgdG8ga25vdyBpZiB3ZSBzaG91bGQgY2FsbCBvbkNyZWF0ZWQgb24gdGhlIG1peGluIGluc2lkZSB0aGUgcmVxdWlyZU1peGluIG9yIG5vdC4gV2Ugd2FudCB0byBjYWxsXG4gICAgICAgICAgICAjIGl0IG9ubHkgb25jZS4gSWYgaXQgcmVxdWlyZU1peGluIGlzIGNhbGxlZCBmcm9tIG9uQ3JlYXRlZCBvZiBhbm90aGVyIG1peGluLCB0aGVuIGl0IHdpbGwgYmUgYWRkZWQgYXQgdGhlXG4gICAgICAgICAgICAjIGVuZCBhbmQgd2Ugd2lsbCBnZXQgaXQgaGVyZSBhdCB0aGUgZW5kLiBTbyB3ZSBzaG91bGQgbm90IGNhbGwgb25DcmVhdGVkIGluc2lkZSByZXF1aXJlTWl4aW4gYmVjYXVzZSB0aGVuXG4gICAgICAgICAgICAjIG9uQ3JlYXRlZCB3b3VsZCBiZSBjYWxsZWQgdHdpY2UuXG4gICAgICAgICAgICBAY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMuaW5PbkNyZWF0ZWQgPSB0cnVlXG4gICAgICAgICAgICBjb21wb25lbnRPck1peGluID0gbnVsbFxuICAgICAgICAgICAgd2hpbGUgY29tcG9uZW50T3JNaXhpbiA9IEBjb21wb25lbnQuZ2V0Rmlyc3RXaXRoIGNvbXBvbmVudE9yTWl4aW4sICdvbkNyZWF0ZWQnXG4gICAgICAgICAgICAgIGNvbXBvbmVudE9yTWl4aW4ub25DcmVhdGVkKClcbiAgICAgICAgICBmaW5hbGx5XG4gICAgICAgICAgICBkZWxldGUgQGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLmluT25DcmVhdGVkXG5cbiAgICAgICAgb25SZW5kZXJlZDogLT5cbiAgICAgICAgICAjIEAgaXMgYSB0ZW1wbGF0ZSBpbnN0YW5jZS5cblxuICAgICAgICAgIEBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscy5pc1JlbmRlcmVkID89IG5ldyBSZWFjdGl2ZUZpZWxkIHRydWVcbiAgICAgICAgICBAY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMuaXNSZW5kZXJlZCB0cnVlXG5cbiAgICAgICAgICBUcmFja2VyLm5vbnJlYWN0aXZlID0+XG4gICAgICAgICAgICBhc3NlcnQuZXF1YWwgQGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLmlzQ3JlYXRlZCgpLCB0cnVlXG5cbiAgICAgICAgICB0cnlcbiAgICAgICAgICAgICMgU2FtZSBhcyBmb3Igb25DcmVhdGVkIGFib3ZlLlxuICAgICAgICAgICAgQGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLmluT25SZW5kZXJlZCA9IHRydWVcbiAgICAgICAgICAgIGNvbXBvbmVudE9yTWl4aW4gPSBudWxsXG4gICAgICAgICAgICB3aGlsZSBjb21wb25lbnRPck1peGluID0gQGNvbXBvbmVudC5nZXRGaXJzdFdpdGggY29tcG9uZW50T3JNaXhpbiwgJ29uUmVuZGVyZWQnXG4gICAgICAgICAgICAgIGNvbXBvbmVudE9yTWl4aW4ub25SZW5kZXJlZCgpXG4gICAgICAgICAgZmluYWxseVxuICAgICAgICAgICAgZGVsZXRlIEBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscy5pbk9uUmVuZGVyZWRcblxuICAgICAgICBvbkRlc3Ryb3llZDogLT5cbiAgICAgICAgICBAYXV0b3J1biAoY29tcHV0YXRpb24pID0+XG4gICAgICAgICAgICAjIEAgaXMgYSB0ZW1wbGF0ZSBpbnN0YW5jZS5cblxuICAgICAgICAgICAgIyBXZSB3YWl0IGZvciBhbGwgY2hpbGRyZW4gY29tcG9uZW50cyB0byBiZSBkZXN0cm95ZWQgZmlyc3QuXG4gICAgICAgICAgICAjIFNlZSBodHRwczovL2dpdGh1Yi5jb20vbWV0ZW9yL21ldGVvci9pc3N1ZXMvNDE2NlxuICAgICAgICAgICAgcmV0dXJuIGlmIEBjb21wb25lbnQuY2hpbGRDb21wb25lbnRzKCkubGVuZ3RoXG4gICAgICAgICAgICBjb21wdXRhdGlvbi5zdG9wKClcblxuICAgICAgICAgICAgVHJhY2tlci5ub25yZWFjdGl2ZSA9PlxuICAgICAgICAgICAgICBhc3NlcnQuZXF1YWwgQGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLmlzQ3JlYXRlZCgpLCB0cnVlXG5cbiAgICAgICAgICAgICAgQGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLmlzQ3JlYXRlZCBmYWxzZVxuXG4gICAgICAgICAgICAgIEBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscy5pc1JlbmRlcmVkID89IG5ldyBSZWFjdGl2ZUZpZWxkIGZhbHNlXG4gICAgICAgICAgICAgIEBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscy5pc1JlbmRlcmVkIGZhbHNlXG5cbiAgICAgICAgICAgICAgQGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLmlzRGVzdHJveWVkID89IG5ldyBSZWFjdGl2ZUZpZWxkIHRydWVcbiAgICAgICAgICAgICAgQGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLmlzRGVzdHJveWVkIHRydWVcblxuICAgICAgICAgICAgICBjb21wb25lbnRPck1peGluID0gbnVsbFxuICAgICAgICAgICAgICB3aGlsZSBjb21wb25lbnRPck1peGluID0gQGNvbXBvbmVudC5nZXRGaXJzdFdpdGggY29tcG9uZW50T3JNaXhpbiwgJ29uRGVzdHJveWVkJ1xuICAgICAgICAgICAgICAgIGNvbXBvbmVudE9yTWl4aW4ub25EZXN0cm95ZWQoKVxuXG4gICAgICAgICAgICAgIGlmIHBhcmVudENvbXBvbmVudFxuICAgICAgICAgICAgICAgICMgVGhlIGNvbXBvbmVudCBoYXMgYmVlbiBkZXN0cm95ZWQsIGNsZWFyIHVwIHRoZSBwYXJlbnQuXG4gICAgICAgICAgICAgICAgY29tcG9uZW50LnBhcmVudENvbXBvbmVudCBudWxsXG4gICAgICAgICAgICAgICAgcGFyZW50Q29tcG9uZW50LnJlbW92ZUNoaWxkQ29tcG9uZW50IGNvbXBvbmVudFxuXG4gICAgICAgICAgICAgICMgUmVtb3ZlIHRoZSByZWZlcmVuY2Ugc28gdGhhdCBpdCBpcyBjbGVhciB0aGF0IHRlbXBsYXRlIGluc3RhbmNlIGlzIG5vdCBhdmFpbGFibGUgYW55bW9yZS5cbiAgICAgICAgICAgICAgQGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLnRlbXBsYXRlSW5zdGFuY2UgbnVsbFxuXG4gICAgICB0ZW1wbGF0ZVxuXG4gIHJlbW92ZUNvbXBvbmVudDogLT5cbiAgICBCbGF6ZS5yZW1vdmUgQGNvbXBvbmVudCgpLl9jb21wb25lbnRJbnRlcm5hbHMudGVtcGxhdGVJbnN0YW5jZSgpLnZpZXcgaWYgQGlzUmVuZGVyZWQoKVxuXG4gIEBfcmVuZGVyQ29tcG9uZW50VG86ICh2aXNpdG9yLCBwYXJlbnRDb21wb25lbnQsIHBhcmVudFZpZXcsIGRhdGEpIC0+XG4gICAgY29tcG9uZW50ID0gVHJhY2tlci5ub25yZWFjdGl2ZSA9PlxuICAgICAgY29tcG9uZW50Q2xhc3MgPSBAXG5cbiAgICAgIHBhcmVudFZpZXcgPSBwYXJlbnRWaWV3IG9yIGN1cnJlbnRWaWV3SWZSZW5kZXJpbmcoKSBvciAocGFyZW50Q29tcG9uZW50Py5pc1JlbmRlcmVkKCkgYW5kIHBhcmVudENvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLnRlbXBsYXRlSW5zdGFuY2UoKS52aWV3KSBvciBudWxsXG5cbiAgICAgIHdyYXBWaWV3QW5kVGVtcGxhdGUgcGFyZW50VmlldywgPT5cbiAgICAgICAgbmV3IGNvbXBvbmVudENsYXNzKClcblxuICAgIGlmIGFyZ3VtZW50cy5sZW5ndGggPiAyXG4gICAgICBjb21wb25lbnQuX3JlbmRlckNvbXBvbmVudFRvIHZpc2l0b3IsIHBhcmVudENvbXBvbmVudCwgcGFyZW50VmlldywgZGF0YVxuICAgIGVsc2VcbiAgICAgIGNvbXBvbmVudC5fcmVuZGVyQ29tcG9uZW50VG8gdmlzaXRvciwgcGFyZW50Q29tcG9uZW50LCBwYXJlbnRWaWV3XG5cbiAgQHJlbmRlckNvbXBvbmVudFRvSFRNTDogKHBhcmVudENvbXBvbmVudCwgcGFyZW50VmlldywgZGF0YSkgLT5cbiAgICBpZiBhcmd1bWVudHMubGVuZ3RoID4gMlxuICAgICAgQF9yZW5kZXJDb21wb25lbnRUbyBuZXcgSFRNTC5Ub0hUTUxWaXNpdG9yKCksIHBhcmVudENvbXBvbmVudCwgcGFyZW50VmlldywgZGF0YVxuICAgIGVsc2VcbiAgICAgIEBfcmVuZGVyQ29tcG9uZW50VG8gbmV3IEhUTUwuVG9IVE1MVmlzaXRvcigpLCBwYXJlbnRDb21wb25lbnQsIHBhcmVudFZpZXdcblxuICBfcmVuZGVyQ29tcG9uZW50VG86ICh2aXNpdG9yLCBwYXJlbnRDb21wb25lbnQsIHBhcmVudFZpZXcsIGRhdGEpIC0+XG4gICAgdGVtcGxhdGUgPSBUcmFja2VyLm5vbnJlYWN0aXZlID0+XG4gICAgICBwYXJlbnRWaWV3ID0gcGFyZW50VmlldyBvciBjdXJyZW50Vmlld0lmUmVuZGVyaW5nKCkgb3IgKHBhcmVudENvbXBvbmVudD8uaXNSZW5kZXJlZCgpIGFuZCBwYXJlbnRDb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscy50ZW1wbGF0ZUluc3RhbmNlKCkudmlldykgb3IgbnVsbFxuXG4gICAgICB3cmFwVmlld0FuZFRlbXBsYXRlIHBhcmVudFZpZXcsID0+XG4gICAgICAgIEBjb21wb25lbnQoKS5yZW5kZXJDb21wb25lbnQgcGFyZW50Q29tcG9uZW50XG5cbiAgICBpZiBhcmd1bWVudHMubGVuZ3RoID4gMlxuICAgICAgZXhwYW5kZWRWaWV3ID0gZXhwYW5kVmlldyBCbGF6ZS5fVGVtcGxhdGVXaXRoKGRhdGEsIGNvbnRlbnRBc0Z1bmMgdGVtcGxhdGUpLCBwYXJlbnRWaWV3XG4gICAgZWxzZVxuICAgICAgZXhwYW5kZWRWaWV3ID0gZXhwYW5kVmlldyBjb250ZW50QXNWaWV3KHRlbXBsYXRlKSwgcGFyZW50Vmlld1xuXG4gICAgdmlzaXRvci52aXNpdCBleHBhbmRlZFZpZXdcblxuICByZW5kZXJDb21wb25lbnRUb0hUTUw6IChwYXJlbnRDb21wb25lbnQsIHBhcmVudFZpZXcsIGRhdGEpIC0+XG4gICAgaWYgYXJndW1lbnRzLmxlbmd0aCA+IDJcbiAgICAgIEBfcmVuZGVyQ29tcG9uZW50VG8gbmV3IEhUTUwuVG9IVE1MVmlzaXRvcigpLCBwYXJlbnRDb21wb25lbnQsIHBhcmVudFZpZXcsIGRhdGFcbiAgICBlbHNlXG4gICAgICBAX3JlbmRlckNvbXBvbmVudFRvIG5ldyBIVE1MLlRvSFRNTFZpc2l0b3IoKSwgcGFyZW50Q29tcG9uZW50LCBwYXJlbnRWaWV3XG5cbiAgdGVtcGxhdGU6IC0+XG4gICAgQGNhbGxGaXJzdFdpdGgoQCwgJ3RlbXBsYXRlJykgb3IgQGNvbnN0cnVjdG9yLmNvbXBvbmVudE5hbWUoKVxuXG4gIG9uQ3JlYXRlZDogLT5cbiAgICBjYWxsVGVtcGxhdGVCYXNlSG9va3MgQCwgJ2NyZWF0ZWQnXG5cbiAgb25SZW5kZXJlZDogLT5cbiAgICBjYWxsVGVtcGxhdGVCYXNlSG9va3MgQCwgJ3JlbmRlcmVkJ1xuXG4gIG9uRGVzdHJveWVkOiAtPlxuICAgIGNhbGxUZW1wbGF0ZUJhc2VIb29rcyBALCAnZGVzdHJveWVkJ1xuXG4gIGlzQ3JlYXRlZDogLT5cbiAgICBjb21wb25lbnQgPSBAY29tcG9uZW50KClcblxuICAgIGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzID89IHt9XG4gICAgY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMuaXNDcmVhdGVkID89IG5ldyBSZWFjdGl2ZUZpZWxkIGZhbHNlXG5cbiAgICBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscy5pc0NyZWF0ZWQoKVxuXG4gIGlzUmVuZGVyZWQ6IC0+XG4gICAgY29tcG9uZW50ID0gQGNvbXBvbmVudCgpXG5cbiAgICBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscyA/PSB7fVxuICAgIGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLmlzUmVuZGVyZWQgPz0gbmV3IFJlYWN0aXZlRmllbGQgZmFsc2VcblxuICAgIGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLmlzUmVuZGVyZWQoKVxuXG4gIGlzRGVzdHJveWVkOiAtPlxuICAgIGNvbXBvbmVudCA9IEBjb21wb25lbnQoKVxuXG4gICAgY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMgPz0ge31cbiAgICBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscy5pc0Rlc3Ryb3llZCA/PSBuZXcgUmVhY3RpdmVGaWVsZCBmYWxzZVxuXG4gICAgY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMuaXNEZXN0cm95ZWQoKVxuXG4gIGluc2VydERPTUVsZW1lbnQ6IChwYXJlbnQsIG5vZGUsIGJlZm9yZSkgLT5cbiAgICBiZWZvcmUgPz0gbnVsbFxuICAgIGlmIHBhcmVudCBhbmQgbm9kZSBhbmQgKG5vZGUucGFyZW50Tm9kZSBpc250IHBhcmVudCBvciBub2RlLm5leHRTaWJsaW5nIGlzbnQgYmVmb3JlKVxuICAgICAgcGFyZW50Lmluc2VydEJlZm9yZSBub2RlLCBiZWZvcmVcblxuICAgIHJldHVyblxuXG4gIG1vdmVET01FbGVtZW50OiAocGFyZW50LCBub2RlLCBiZWZvcmUpIC0+XG4gICAgYmVmb3JlID89IG51bGxcbiAgICBpZiBwYXJlbnQgYW5kIG5vZGUgYW5kIChub2RlLnBhcmVudE5vZGUgaXNudCBwYXJlbnQgb3Igbm9kZS5uZXh0U2libGluZyBpc250IGJlZm9yZSlcbiAgICAgIHBhcmVudC5pbnNlcnRCZWZvcmUgbm9kZSwgYmVmb3JlXG5cbiAgICByZXR1cm5cblxuICByZW1vdmVET01FbGVtZW50OiAocGFyZW50LCBub2RlKSAtPlxuICAgIGlmIHBhcmVudCBhbmQgbm9kZSBhbmQgbm9kZS5wYXJlbnROb2RlIGlzIHBhcmVudFxuICAgICAgcGFyZW50LnJlbW92ZUNoaWxkIG5vZGVcblxuICAgIHJldHVyblxuXG4gIGV2ZW50czogLT5cbiAgICAjIEluIG1peGlucyB0aGVyZSBpcyBubyByZWFzb24gZm9yIGEgdGVtcGxhdGUgaW5zdGFuY2UgdG8gZXh0ZW5kIGEgQmxhemUgdGVtcGxhdGUuXG4gICAgcmV0dXJuIFtdIHVubGVzcyBAIGlzIEBjb21wb25lbnQoKVxuXG4gICAgQF9jb21wb25lbnRJbnRlcm5hbHMgPz0ge31cblxuICAgIHZpZXcgPSBUcmFja2VyLm5vbnJlYWN0aXZlID0+XG4gICAgICBAX2NvbXBvbmVudEludGVybmFscy50ZW1wbGF0ZUluc3RhbmNlKCkudmlld1xuICAgICMgV2Ugc2tpcCBibG9jayBoZWxwZXJzIHRvIG1hdGNoIEJsYXplIGJlaGF2aW9yLlxuICAgIHRlbXBsYXRlSW5zdGFuY2UgPSBnZXRUZW1wbGF0ZUluc3RhbmNlRnVuY3Rpb24gdmlldywgdHJ1ZVxuXG4gICAgZm9yIGV2ZW50cyBpbiBAX2NvbXBvbmVudEludGVybmFscy50ZW1wbGF0ZUJhc2UuX19ldmVudE1hcHNcbiAgICAgIGV2ZW50TWFwID0ge31cblxuICAgICAgZm9yIHNwZWMsIGhhbmRsZXIgb2YgZXZlbnRzXG4gICAgICAgIGRvIChzcGVjLCBoYW5kbGVyKSAtPlxuICAgICAgICAgIGV2ZW50TWFwW3NwZWNdID0gKGFyZ3MuLi4pIC0+XG4gICAgICAgICAgICAjIEluIHRlbXBsYXRlIGV2ZW50IGhhbmRsZXJzIHZpZXcgYW5kIHRlbXBsYXRlIGluc3RhbmNlIGFyZSBub3QgYmFzZWQgb24gdGhlIGN1cnJlbnQgdGFyZ2V0XG4gICAgICAgICAgICAjIChsaWtlIEJsYXplIENvbXBvbmVudHMgZXZlbnQgaGFuZGxlcnMgYXJlKSBidXQgaXQgaXMgYmFzZWQgb24gdGhlIHRlbXBsYXRlLWxldmVsIHZpZXcuXG4gICAgICAgICAgICAjIEluIGEgd2F5IHdlIGFyZSByZXZlcnRpbmcgaGVyZSB3aGF0IGFkZEV2ZW50cyBkb2VzLlxuICAgICAgICAgICAgd2l0aFRlbXBsYXRlSW5zdGFuY2VGdW5jIHRlbXBsYXRlSW5zdGFuY2UsIC0+XG4gICAgICAgICAgICAgIEJsYXplLl93aXRoQ3VycmVudFZpZXcgdmlldywgLT5cbiAgICAgICAgICAgICAgICBoYW5kbGVyLmFwcGx5IHZpZXcsIGFyZ3NcblxuICAgICAgZXZlbnRNYXBcblxuICAjIENvbXBvbmVudC1sZXZlbCBkYXRhIGNvbnRleHQuIFJlYWN0aXZlLiBVc2UgdGhpcyB0byBhbHdheXMgZ2V0IHRoZVxuICAjIHRvcC1sZXZlbCBkYXRhIGNvbnRleHQgdXNlZCB0byByZW5kZXIgdGhlIGNvbXBvbmVudC4gSWYgcGF0aCBpc1xuICAjIHByb3ZpZGVkLCBpdCByZXR1cm5zIG9ubHkgdGhlIHZhbHVlIHVuZGVyIHRoYXQgcGF0aCwgd2l0aCByZWFjdGl2aXR5XG4gICMgbGltaXRlZCB0byBjaGFuZ2VzIG9mIHRoYXQgdmFsdWUgb25seS5cbiAgZGF0YTogKHBhdGgsIGVxdWFsc0Z1bmMpIC0+XG4gICAgY29tcG9uZW50ID0gQGNvbXBvbmVudCgpXG5cbiAgICBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscyA/PSB7fVxuICAgIGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLnRlbXBsYXRlSW5zdGFuY2UgPz0gbmV3IFJlYWN0aXZlRmllbGQgbnVsbCwgKGEsIGIpIC0+IGEgaXMgYlxuXG4gICAgaWYgdmlldyA9IGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLnRlbXBsYXRlSW5zdGFuY2UoKT8udmlld1xuICAgICAgaWYgcGF0aD9cbiAgICAgICAgIyBEYXRhTG9va3VwIHVzZXMgaW50ZXJuYWxseSBjb21wdXRlZCBmaWVsZCwgd2hpY2ggdXNlcyB2aWV3J3MgYXV0b3J1biwgYnV0XG4gICAgICAgICMgZGF0YSBtaWdodCBiZSB1c2VkIGluc2lkZSByZW5kZXIoKSBtZXRob2QsIHdoZXJlIGl0IGlzIGZvcmJpZGRlbiB0byB1c2VcbiAgICAgICAgIyB2aWV3J3MgYXV0b3J1bi4gU28gd2UgdGVtcG9yYXJ5IGhpZGUgdGhlIGZhY3QgdGhhdCB3ZSBhcmUgaW5zaWRlIGEgdmlld1xuICAgICAgICAjIHRvIG1ha2UgY29tcHV0ZWQgZmllbGQgdXNlIG5vcm1hbCBhdXRvcnVuLlxuICAgICAgICByZXR1cm4gQmxhemUuX3dpdGhDdXJyZW50VmlldyBudWxsLCA9PlxuICAgICAgICAgIERhdGFMb29rdXAuZ2V0ID0+XG4gICAgICAgICAgICBCbGF6ZS5nZXREYXRhIHZpZXdcbiAgICAgICAgICAsXG4gICAgICAgICAgICBwYXRoLCBlcXVhbHNGdW5jXG4gICAgICBlbHNlXG4gICAgICAgIHJldHVybiBCbGF6ZS5nZXREYXRhIHZpZXdcblxuICAgIHVuZGVmaW5lZFxuXG4gICMgQ2FsbGVyLWxldmVsIGRhdGEgY29udGV4dC4gUmVhY3RpdmUuIFVzZSB0aGlzIHRvIGdldCBpbiBldmVudCBoYW5kbGVycyB0aGUgZGF0YVxuICAjIGNvbnRleHQgYXQgdGhlIHBsYWNlIHdoZXJlIGV2ZW50IG9yaWdpbmF0ZWQgKHRhcmdldCBjb250ZXh0KS4gSW4gdGVtcGxhdGUgaGVscGVyc1xuICAjIHRoZSBkYXRhIGNvbnRleHQgd2hlcmUgdGVtcGxhdGUgaGVscGVycyB3ZXJlIGNhbGxlZC4gSW4gb25DcmVhdGVkLCBvblJlbmRlcmVkLFxuICAjIGFuZCBvbkRlc3Ryb3llZCwgdGhlIHNhbWUgYXMgQGRhdGEoKS4gSW5zaWRlIGEgdGVtcGxhdGUgdGhpcyBpcyB0aGUgc2FtZSBhcyB0aGlzLlxuICAjIElmIHBhdGggaXMgcHJvdmlkZWQsIGl0IHJldHVybnMgb25seSB0aGUgdmFsdWUgdW5kZXIgdGhhdCBwYXRoLCB3aXRoIHJlYWN0aXZpdHlcbiAgIyBsaW1pdGVkIHRvIGNoYW5nZXMgb2YgdGhhdCB2YWx1ZSBvbmx5LiBNb3Jlb3ZlciwgaWYgcGF0aCBpcyBwcm92aWRlZCBpcyBhbHNvXG4gICMgbG9va3MgaW50byB0aGUgY3VycmVudCBsZXhpY2FsIHNjb3BlIGRhdGEuXG4gIEBjdXJyZW50RGF0YTogKHBhdGgsIGVxdWFsc0Z1bmMpIC0+XG4gICAgcmV0dXJuIHVuZGVmaW5lZCB1bmxlc3MgQmxhemUuY3VycmVudFZpZXdcblxuICAgIGN1cnJlbnRWaWV3ID0gQmxhemUuY3VycmVudFZpZXdcblxuICAgIGlmIF8uaXNTdHJpbmcgcGF0aFxuICAgICAgcGF0aCA9IHBhdGguc3BsaXQgJy4nXG4gICAgZWxzZSBpZiBub3QgXy5pc0FycmF5IHBhdGhcbiAgICAgIHJldHVybiBCbGF6ZS5nZXREYXRhIGN1cnJlbnRWaWV3XG5cbiAgICAjIERhdGFMb29rdXAgdXNlcyBpbnRlcm5hbGx5IGNvbXB1dGVkIGZpZWxkLCB3aGljaCB1c2VzIHZpZXcncyBhdXRvcnVuLCBidXRcbiAgICAjIGN1cnJlbnREYXRhIG1pZ2h0IGJlIHVzZWQgaW5zaWRlIHJlbmRlcigpIG1ldGhvZCwgd2hlcmUgaXQgaXMgZm9yYmlkZGVuIHRvIHVzZVxuICAgICMgdmlldydzIGF1dG9ydW4uIFNvIHdlIHRlbXBvcmFyeSBoaWRlIHRoZSBmYWN0IHRoYXQgd2UgYXJlIGluc2lkZSBhIHZpZXdcbiAgICAjIHRvIG1ha2UgY29tcHV0ZWQgZmllbGQgdXNlIG5vcm1hbCBhdXRvcnVuLlxuICAgIEJsYXplLl93aXRoQ3VycmVudFZpZXcgbnVsbCwgPT5cbiAgICAgIERhdGFMb29rdXAuZ2V0ID0+XG4gICAgICAgIGlmIEJsYXplLl9sZXhpY2FsQmluZGluZ0xvb2t1cCBhbmQgbGV4aWNhbERhdGEgPSBCbGF6ZS5fbGV4aWNhbEJpbmRpbmdMb29rdXAgY3VycmVudFZpZXcsIHBhdGhbMF1cbiAgICAgICAgICAjIFdlIHJldHVybiBjdXN0b20gZGF0YSBvYmplY3Qgc28gdGhhdCB3ZSBjYW4gcmV1c2UgdGhlIHNhbWVcbiAgICAgICAgICAjIGxvb2t1cCBsb2dpYyBmb3IgYm90aCBsZXhpY2FsIGFuZCB0aGUgbm9ybWFsIGRhdGEgY29udGV4dCBjYXNlLlxuICAgICAgICAgIHJlc3VsdCA9IHt9XG4gICAgICAgICAgcmVzdWx0W3BhdGhbMF1dID0gbGV4aWNhbERhdGFcbiAgICAgICAgICByZXR1cm4gcmVzdWx0XG5cbiAgICAgICAgQmxhemUuZ2V0RGF0YSBjdXJyZW50Vmlld1xuICAgICAgLFxuICAgICAgICBwYXRoLCBlcXVhbHNGdW5jXG5cbiAgIyBNZXRob2Qgc2hvdWxkIG5ldmVyIGJlIG92ZXJyaWRkZW4uIFRoZSBpbXBsZW1lbnRhdGlvbiBzaG91bGQgYWx3YXlzIGJlIGV4YWN0bHkgdGhlIHNhbWUgYXMgY2xhc3MgbWV0aG9kIGltcGxlbWVudGF0aW9uLlxuICBjdXJyZW50RGF0YTogKHBhdGgsIGVxdWFsc0Z1bmMpIC0+XG4gICAgQGNvbnN0cnVjdG9yLmN1cnJlbnREYXRhIHBhdGgsIGVxdWFsc0Z1bmNcblxuICAjIFVzZWZ1bCBpbiB0ZW1wbGF0ZXMgb3IgbWl4aW5zIHRvIGdldCBhIHJlZmVyZW5jZSB0byB0aGUgY29tcG9uZW50LlxuICBjb21wb25lbnQ6IC0+XG4gICAgY29tcG9uZW50ID0gQFxuXG4gICAgbG9vcFxuICAgICAgIyBJZiB3ZSBhcmUgb24gYSBtaXhpbiB3aXRob3V0IG1peGluUGFyZW50LCB3ZSBjYW5ub3QgcmVhbGx5IGdldCB0byB0aGUgY29tcG9uZW50LCByZXR1cm4gbnVsbC5cbiAgICAgIHJldHVybiBudWxsIHVubGVzcyBjb21wb25lbnQubWl4aW5QYXJlbnRcblxuICAgICAgIyBSZXR1cm4gY3VycmVudCBjb21wb25lbnQgdW5sZXNzIHRoZXJlIGlzIGEgbWl4aW4gcGFyZW50LlxuICAgICAgcmV0dXJuIGNvbXBvbmVudCB1bmxlc3MgbWl4aW5QYXJlbnQgPSBjb21wb25lbnQubWl4aW5QYXJlbnQoKVxuICAgICAgY29tcG9uZW50ID0gbWl4aW5QYXJlbnRcblxuICAjIENhbGxlci1sZXZlbCBjb21wb25lbnQuIEluIG1vc3QgY2FzZXMgdGhlIHNhbWUgYXMgQCwgYnV0IGluIGV2ZW50IGhhbmRsZXJzXG4gICMgaXQgcmV0dXJucyB0aGUgY29tcG9uZW50IGF0IHRoZSBwbGFjZSB3aGVyZSBldmVudCBvcmlnaW5hdGVkICh0YXJnZXQgY29tcG9uZW50KS5cbiAgIyBJbnNpZGUgdGVtcGxhdGUgY29udGVudCB3cmFwcGVkIHdpdGggYSBibG9jayBoZWxwZXIgY29tcG9uZW50LCBpdCBpcyB0aGUgY2xvc2VzdFxuICAjIGJsb2NrIGhlbHBlciBjb21wb25lbnQuXG4gIEBjdXJyZW50Q29tcG9uZW50OiAtPlxuICAgICMgV2UgYXJlIG5vdCBza2lwcGluZyBibG9jayBoZWxwZXJzIGJlY2F1c2Ugb25lIG9mIG1haW4gcmVhc29ucyBmb3IgQGN1cnJlbnRDb21wb25lbnQoKVxuICAgICMgaXMgdGhhdCB3ZSBjYW4gZ2V0IGhvbGQgb2YgdGhlIGJsb2NrIGhlbHBlciBjb21wb25lbnQgaW5zdGFuY2UuXG4gICAgdGVtcGxhdGVJbnN0YW5jZSA9IGdldFRlbXBsYXRlSW5zdGFuY2VGdW5jdGlvbiBCbGF6ZS5jdXJyZW50VmlldywgZmFsc2VcbiAgICB0ZW1wbGF0ZUluc3RhbmNlVG9Db21wb25lbnQgdGVtcGxhdGVJbnN0YW5jZSwgZmFsc2VcblxuICAjIE1ldGhvZCBzaG91bGQgbmV2ZXIgYmUgb3ZlcnJpZGRlbi4gVGhlIGltcGxlbWVudGF0aW9uIHNob3VsZCBhbHdheXMgYmUgZXhhY3RseSB0aGUgc2FtZSBhcyBjbGFzcyBtZXRob2QgaW1wbGVtZW50YXRpb24uXG4gIGN1cnJlbnRDb21wb25lbnQ6IC0+XG4gICAgQGNvbnN0cnVjdG9yLmN1cnJlbnRDb21wb25lbnQoKVxuXG4gIGZpcnN0Tm9kZTogLT5cbiAgICByZXR1cm4gQGNvbXBvbmVudCgpLl9jb21wb25lbnRJbnRlcm5hbHMudGVtcGxhdGVJbnN0YW5jZSgpLnZpZXcuX2RvbXJhbmdlLmZpcnN0Tm9kZSgpIGlmIEBpc1JlbmRlcmVkKClcblxuICAgIHVuZGVmaW5lZFxuXG4gIGxhc3ROb2RlOiAtPlxuICAgIHJldHVybiBAY29tcG9uZW50KCkuX2NvbXBvbmVudEludGVybmFscy50ZW1wbGF0ZUluc3RhbmNlKCkudmlldy5fZG9tcmFuZ2UubGFzdE5vZGUoKSBpZiBAaXNSZW5kZXJlZCgpXG5cbiAgICB1bmRlZmluZWRcblxuICAjIFRoZSBzYW1lIGFzIGl0IHdvdWxkIGJlIGdlbmVyYXRlZCBhdXRvbWF0aWNhbGx5LCBvbmx5IHRoYXQgdGhlIHJ1bkZ1bmMgZ2V0cyBib3VuZCB0byB0aGUgY29tcG9uZW50LlxuICBhdXRvcnVuOiAocnVuRnVuYykgLT5cbiAgICB0ZW1wbGF0ZUluc3RhbmNlID0gVHJhY2tlci5ub25yZWFjdGl2ZSA9PlxuICAgICAgQGNvbXBvbmVudCgpLl9jb21wb25lbnRJbnRlcm5hbHM/LnRlbXBsYXRlSW5zdGFuY2U/KClcblxuICAgIHRocm93IG5ldyBFcnJvciBcIlRoZSBjb21wb25lbnQgaGFzIHRvIGJlIGNyZWF0ZWQgYmVmb3JlIGNhbGxpbmcgJ2F1dG9ydW4nLlwiIHVubGVzcyB0ZW1wbGF0ZUluc3RhbmNlXG5cbiAgICB0ZW1wbGF0ZUluc3RhbmNlLmF1dG9ydW4gXy5iaW5kIHJ1bkZ1bmMsIEBcblxuU1VQUE9SVFNfUkVBQ1RJVkVfSU5TVEFOQ0UgPSBbXG4gICdzdWJzY3JpcHRpb25zUmVhZHknXG5dXG5cblJFUVVJUkVfUkVOREVSRURfSU5TVEFOQ0UgPSBbXG4gICckJyxcbiAgJ2ZpbmQnLFxuICAnZmluZEFsbCdcbl1cblxuIyBXZSBjb3B5IHV0aWxpdHkgbWV0aG9kcyAoJCwgZmluZEFsbCwgc3Vic2NyaWJlLCBldGMuKSBmcm9tIHRoZSB0ZW1wbGF0ZSBpbnN0YW5jZSBwcm90b3R5cGUsXG4jIGlmIGEgbWV0aG9kIHdpdGggdGhlIHNhbWUgbmFtZSBkb2VzIG5vdCBleGlzdCBhbHJlYWR5LlxuZm9yIG1ldGhvZE5hbWUsIG1ldGhvZCBvZiAoQmxhemUuVGVtcGxhdGVJbnN0YW5jZTo6KSB3aGVuIG1ldGhvZE5hbWUgbm90IG9mIChCbGF6ZUNvbXBvbmVudDo6KVxuICBkbyAobWV0aG9kTmFtZSwgbWV0aG9kKSAtPlxuICAgIGlmIG1ldGhvZE5hbWUgaW4gU1VQUE9SVFNfUkVBQ1RJVkVfSU5TVEFOQ0VcbiAgICAgIEJsYXplQ29tcG9uZW50OjpbbWV0aG9kTmFtZV0gPSAoYXJncy4uLikgLT5cbiAgICAgICAgY29tcG9uZW50ID0gQGNvbXBvbmVudCgpXG5cbiAgICAgICAgY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMgPz0ge31cbiAgICAgICAgY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMudGVtcGxhdGVJbnN0YW5jZSA/PSBuZXcgUmVhY3RpdmVGaWVsZCBudWxsLCAoYSwgYikgLT4gYSBpcyBiXG5cbiAgICAgICAgaWYgdGVtcGxhdGVJbnN0YW5jZSA9IGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLnRlbXBsYXRlSW5zdGFuY2UoKVxuICAgICAgICAgIHJldHVybiB0ZW1wbGF0ZUluc3RhbmNlW21ldGhvZE5hbWVdIGFyZ3MuLi5cblxuICAgICAgICB1bmRlZmluZWRcblxuICAgIGVsc2UgaWYgbWV0aG9kTmFtZSBpbiBSRVFVSVJFX1JFTkRFUkVEX0lOU1RBTkNFXG4gICAgICBCbGF6ZUNvbXBvbmVudDo6W21ldGhvZE5hbWVdID0gKGFyZ3MuLi4pIC0+XG4gICAgICAgIHJldHVybiBAY29tcG9uZW50KCkuX2NvbXBvbmVudEludGVybmFscy50ZW1wbGF0ZUluc3RhbmNlKClbbWV0aG9kTmFtZV0gYXJncy4uLiBpZiBAaXNSZW5kZXJlZCgpXG5cbiAgICAgICAgdW5kZWZpbmVkXG5cbiAgICBlbHNlXG4gICAgICBCbGF6ZUNvbXBvbmVudDo6W21ldGhvZE5hbWVdID0gKGFyZ3MuLi4pIC0+XG4gICAgICAgIHRlbXBsYXRlSW5zdGFuY2UgPSBUcmFja2VyLm5vbnJlYWN0aXZlID0+XG4gICAgICAgICAgQGNvbXBvbmVudCgpLl9jb21wb25lbnRJbnRlcm5hbHM/LnRlbXBsYXRlSW5zdGFuY2U/KClcblxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IgXCJUaGUgY29tcG9uZW50IGhhcyB0byBiZSBjcmVhdGVkIGJlZm9yZSBjYWxsaW5nICcje21ldGhvZE5hbWV9Jy5cIiB1bmxlc3MgdGVtcGxhdGVJbnN0YW5jZVxuXG4gICAgICAgIHRlbXBsYXRlSW5zdGFuY2VbbWV0aG9kTmFtZV0gYXJncy4uLlxuIiwidmFyIENvbXBvbmVudHNOYW1lc3BhY2VSZWZlcmVuY2UsIEhUTUxKU0V4cGFuZGVyLCBSRVFVSVJFX1JFTkRFUkVEX0lOU1RBTkNFLCBTVVBQT1JUU19SRUFDVElWRV9JTlNUQU5DRSwgYWRkRXZlbnRzLCBhcmd1bWVudHNDb25zdHJ1Y3RvciwgYmluZENvbXBvbmVudCwgYmluZERhdGFDb250ZXh0LCBjYWxsVGVtcGxhdGVCYXNlSG9va3MsIGNvbnRlbnRBc0Z1bmMsIGNvbnRlbnRBc1ZpZXcsIGNyZWF0ZU1hdGNoZXIsIGN1cnJlbnRWaWV3SWZSZW5kZXJpbmcsIGV4cGFuZCwgZXhwYW5kVmlldywgZ2V0VGVtcGxhdGVCYXNlLCBnZXRUZW1wbGF0ZUluc3RhbmNlLCBnZXRUZW1wbGF0ZUluc3RhbmNlRnVuY3Rpb24sIG1ldGhvZCwgbWV0aG9kTmFtZSwgb3JpZ2luYWxEb3QsIG9yaWdpbmFsRmxhdHRlbkF0dHJpYnV0ZXMsIG9yaWdpbmFsR2V0VGVtcGxhdGUsIG9yaWdpbmFsSW5jbHVkZSwgb3JpZ2luYWxWaXNpdFRhZywgcmVmLCByZWdpc3RlckZpcnN0Q3JlYXRlZEhvb2ssIHJlZ2lzdGVySG9va3MsIHRlbXBsYXRlSW5zdGFuY2VUb0NvbXBvbmVudCwgd2l0aFRlbXBsYXRlSW5zdGFuY2VGdW5jLCB3cmFwSGVscGVyLCB3cmFwVmlld0FuZFRlbXBsYXRlLCAgICAgICAgICAgICAgICBcbiAgc2xpY2UgPSBbXS5zbGljZSxcbiAgZXh0ZW5kID0gZnVuY3Rpb24oY2hpbGQsIHBhcmVudCkgeyBmb3IgKHZhciBrZXkgaW4gcGFyZW50KSB7IGlmIChoYXNQcm9wLmNhbGwocGFyZW50LCBrZXkpKSBjaGlsZFtrZXldID0gcGFyZW50W2tleV07IH0gZnVuY3Rpb24gY3RvcigpIHsgdGhpcy5jb25zdHJ1Y3RvciA9IGNoaWxkOyB9IGN0b3IucHJvdG90eXBlID0gcGFyZW50LnByb3RvdHlwZTsgY2hpbGQucHJvdG90eXBlID0gbmV3IGN0b3IoKTsgY2hpbGQuX19zdXBlcl9fID0gcGFyZW50LnByb3RvdHlwZTsgcmV0dXJuIGNoaWxkOyB9LFxuICBoYXNQcm9wID0ge30uaGFzT3duUHJvcGVydHksXG4gIGluZGV4T2YgPSBbXS5pbmRleE9mIHx8IGZ1bmN0aW9uKGl0ZW0pIHsgZm9yICh2YXIgaSA9IDAsIGwgPSB0aGlzLmxlbmd0aDsgaSA8IGw7IGkrKykgeyBpZiAoaSBpbiB0aGlzICYmIHRoaXNbaV0gPT09IGl0ZW0pIHJldHVybiBpOyB9IHJldHVybiAtMTsgfTtcblxuY3JlYXRlTWF0Y2hlciA9IGZ1bmN0aW9uKHByb3BlcnR5T3JNYXRjaGVyT3JGdW5jdGlvbiwgY2hlY2tNaXhpbnMpIHtcbiAgdmFyIG1hdGNoZXIsIHByb3BlcnR5O1xuICBpZiAoXy5pc1N0cmluZyhwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb24pKSB7XG4gICAgcHJvcGVydHkgPSBwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb247XG4gICAgcHJvcGVydHlPck1hdGNoZXJPckZ1bmN0aW9uID0gKGZ1bmN0aW9uKF90aGlzKSB7XG4gICAgICByZXR1cm4gZnVuY3Rpb24oY2hpbGQsIHBhcmVudCkge1xuICAgICAgICBpZiAoY2hlY2tNaXhpbnMgJiYgY2hpbGQgIT09IHBhcmVudCAmJiBjaGlsZC5nZXRGaXJzdFdpdGgpIHtcbiAgICAgICAgICByZXR1cm4gISFjaGlsZC5nZXRGaXJzdFdpdGgobnVsbCwgcHJvcGVydHkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJldHVybiBwcm9wZXJ0eSBpbiBjaGlsZDtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICB9KSh0aGlzKTtcbiAgfSBlbHNlIGlmICghXy5pc0Z1bmN0aW9uKHByb3BlcnR5T3JNYXRjaGVyT3JGdW5jdGlvbikpIHtcbiAgICBhc3NlcnQoXy5pc09iamVjdChwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb24pKTtcbiAgICBtYXRjaGVyID0gcHJvcGVydHlPck1hdGNoZXJPckZ1bmN0aW9uO1xuICAgIHByb3BlcnR5T3JNYXRjaGVyT3JGdW5jdGlvbiA9IChmdW5jdGlvbihfdGhpcykge1xuICAgICAgcmV0dXJuIGZ1bmN0aW9uKGNoaWxkLCBwYXJlbnQpIHtcbiAgICAgICAgdmFyIGNoaWxkV2l0aFByb3BlcnR5LCB2YWx1ZTtcbiAgICAgICAgZm9yIChwcm9wZXJ0eSBpbiBtYXRjaGVyKSB7XG4gICAgICAgICAgdmFsdWUgPSBtYXRjaGVyW3Byb3BlcnR5XTtcbiAgICAgICAgICBpZiAoY2hlY2tNaXhpbnMgJiYgY2hpbGQgIT09IHBhcmVudCAmJiBjaGlsZC5nZXRGaXJzdFdpdGgpIHtcbiAgICAgICAgICAgIGNoaWxkV2l0aFByb3BlcnR5ID0gY2hpbGQuZ2V0Rmlyc3RXaXRoKG51bGwsIHByb3BlcnR5KTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgaWYgKHByb3BlcnR5IGluIGNoaWxkKSB7XG4gICAgICAgICAgICAgIGNoaWxkV2l0aFByb3BlcnR5ID0gY2hpbGQ7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICghY2hpbGRXaXRoUHJvcGVydHkpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKF8uaXNGdW5jdGlvbihjaGlsZFdpdGhQcm9wZXJ0eVtwcm9wZXJ0eV0pKSB7XG4gICAgICAgICAgICBpZiAoY2hpbGRXaXRoUHJvcGVydHlbcHJvcGVydHldKCkgIT09IHZhbHVlKSB7XG4gICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgaWYgKGNoaWxkV2l0aFByb3BlcnR5W3Byb3BlcnR5XSAhPT0gdmFsdWUpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH07XG4gICAgfSkodGhpcyk7XG4gIH1cbiAgcmV0dXJuIHByb3BlcnR5T3JNYXRjaGVyT3JGdW5jdGlvbjtcbn07XG5cbmdldFRlbXBsYXRlSW5zdGFuY2UgPSBmdW5jdGlvbih2aWV3LCBza2lwQmxvY2tIZWxwZXJzKSB7XG4gIHdoaWxlICh2aWV3ICYmICF2aWV3Ll90ZW1wbGF0ZUluc3RhbmNlKSB7XG4gICAgaWYgKHNraXBCbG9ja0hlbHBlcnMpIHtcbiAgICAgIHZpZXcgPSB2aWV3LnBhcmVudFZpZXc7XG4gICAgfSBlbHNlIHtcbiAgICAgIHZpZXcgPSB2aWV3Lm9yaWdpbmFsUGFyZW50VmlldyB8fCB2aWV3LnBhcmVudFZpZXc7XG4gICAgfVxuICB9XG4gIHJldHVybiB2aWV3ICE9IG51bGwgPyB2aWV3Ll90ZW1wbGF0ZUluc3RhbmNlIDogdm9pZCAwO1xufTtcblxudGVtcGxhdGVJbnN0YW5jZVRvQ29tcG9uZW50ID0gZnVuY3Rpb24odGVtcGxhdGVJbnN0YW5jZUZ1bmMsIHNraXBCbG9ja0hlbHBlcnMpIHtcbiAgdmFyIHRlbXBsYXRlSW5zdGFuY2U7XG4gIHRlbXBsYXRlSW5zdGFuY2UgPSB0eXBlb2YgdGVtcGxhdGVJbnN0YW5jZUZ1bmMgPT09IFwiZnVuY3Rpb25cIiA/IHRlbXBsYXRlSW5zdGFuY2VGdW5jKCkgOiB2b2lkIDA7XG4gIHRlbXBsYXRlSW5zdGFuY2UgPSBnZXRUZW1wbGF0ZUluc3RhbmNlKHRlbXBsYXRlSW5zdGFuY2UgIT0gbnVsbCA/IHRlbXBsYXRlSW5zdGFuY2UudmlldyA6IHZvaWQgMCwgc2tpcEJsb2NrSGVscGVycyk7XG4gIHdoaWxlICh0ZW1wbGF0ZUluc3RhbmNlKSB7XG4gICAgaWYgKCdjb21wb25lbnQnIGluIHRlbXBsYXRlSW5zdGFuY2UpIHtcbiAgICAgIHJldHVybiB0ZW1wbGF0ZUluc3RhbmNlLmNvbXBvbmVudDtcbiAgICB9XG4gICAgaWYgKHNraXBCbG9ja0hlbHBlcnMpIHtcbiAgICAgIHRlbXBsYXRlSW5zdGFuY2UgPSBnZXRUZW1wbGF0ZUluc3RhbmNlKHRlbXBsYXRlSW5zdGFuY2Uudmlldy5wYXJlbnRWaWV3LCBza2lwQmxvY2tIZWxwZXJzKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGVtcGxhdGVJbnN0YW5jZSA9IGdldFRlbXBsYXRlSW5zdGFuY2UodGVtcGxhdGVJbnN0YW5jZS52aWV3Lm9yaWdpbmFsUGFyZW50VmlldyB8fCB0ZW1wbGF0ZUluc3RhbmNlLnZpZXcucGFyZW50Vmlldywgc2tpcEJsb2NrSGVscGVycyk7XG4gICAgfVxuICB9XG4gIHJldHVybiBudWxsO1xufTtcblxuZ2V0VGVtcGxhdGVJbnN0YW5jZUZ1bmN0aW9uID0gZnVuY3Rpb24odmlldywgc2tpcEJsb2NrSGVscGVycykge1xuICB2YXIgdGVtcGxhdGVJbnN0YW5jZTtcbiAgdGVtcGxhdGVJbnN0YW5jZSA9IGdldFRlbXBsYXRlSW5zdGFuY2Uodmlldywgc2tpcEJsb2NrSGVscGVycyk7XG4gIHJldHVybiBmdW5jdGlvbigpIHtcbiAgICByZXR1cm4gdGVtcGxhdGVJbnN0YW5jZTtcbiAgfTtcbn07XG5cbkNvbXBvbmVudHNOYW1lc3BhY2VSZWZlcmVuY2UgPSAoZnVuY3Rpb24oKSB7XG4gIGZ1bmN0aW9uIENvbXBvbmVudHNOYW1lc3BhY2VSZWZlcmVuY2UobmFtZXNwYWNlLCB0ZW1wbGF0ZUluc3RhbmNlMSkge1xuICAgIHRoaXMubmFtZXNwYWNlID0gbmFtZXNwYWNlO1xuICAgIHRoaXMudGVtcGxhdGVJbnN0YW5jZSA9IHRlbXBsYXRlSW5zdGFuY2UxO1xuICB9XG5cbiAgcmV0dXJuIENvbXBvbmVudHNOYW1lc3BhY2VSZWZlcmVuY2U7XG5cbn0pKCk7XG5cbm9yaWdpbmFsRG90ID0gU3BhY2ViYXJzLmRvdDtcblxuU3BhY2ViYXJzLmRvdCA9IGZ1bmN0aW9uKCkge1xuICB2YXIgYXJncywgdmFsdWU7XG4gIHZhbHVlID0gYXJndW1lbnRzWzBdLCBhcmdzID0gMiA8PSBhcmd1bWVudHMubGVuZ3RoID8gc2xpY2UuY2FsbChhcmd1bWVudHMsIDEpIDogW107XG4gIGlmICh2YWx1ZSBpbnN0YW5jZW9mIENvbXBvbmVudHNOYW1lc3BhY2VSZWZlcmVuY2UpIHtcbiAgICByZXR1cm4gQmxhemUuX2dldFRlbXBsYXRlKHZhbHVlLm5hbWVzcGFjZSArIFwiLlwiICsgKGFyZ3Muam9pbignLicpKSwgdmFsdWUudGVtcGxhdGVJbnN0YW5jZSk7XG4gIH1cbiAgcmV0dXJuIG9yaWdpbmFsRG90LmFwcGx5KG51bGwsIFt2YWx1ZV0uY29uY2F0KHNsaWNlLmNhbGwoYXJncykpKTtcbn07XG5cbm9yaWdpbmFsSW5jbHVkZSA9IFNwYWNlYmFycy5pbmNsdWRlO1xuXG5TcGFjZWJhcnMuaW5jbHVkZSA9IGZ1bmN0aW9uKCkge1xuICB2YXIgYXJncywgdGVtcGxhdGVPckZ1bmN0aW9uO1xuICB0ZW1wbGF0ZU9yRnVuY3Rpb24gPSBhcmd1bWVudHNbMF0sIGFyZ3MgPSAyIDw9IGFyZ3VtZW50cy5sZW5ndGggPyBzbGljZS5jYWxsKGFyZ3VtZW50cywgMSkgOiBbXTtcbiAgaWYgKHRlbXBsYXRlT3JGdW5jdGlvbiBpbnN0YW5jZW9mIENvbXBvbmVudHNOYW1lc3BhY2VSZWZlcmVuY2UpIHtcbiAgICB0ZW1wbGF0ZU9yRnVuY3Rpb24gPSBCbGF6ZS5fZ2V0VGVtcGxhdGUodGVtcGxhdGVPckZ1bmN0aW9uLm5hbWVzcGFjZSwgdGVtcGxhdGVPckZ1bmN0aW9uLnRlbXBsYXRlSW5zdGFuY2UpO1xuICB9XG4gIHJldHVybiBvcmlnaW5hbEluY2x1ZGUuYXBwbHkobnVsbCwgW3RlbXBsYXRlT3JGdW5jdGlvbl0uY29uY2F0KHNsaWNlLmNhbGwoYXJncykpKTtcbn07XG5cbkJsYXplLl9nZXRUZW1wbGF0ZUhlbHBlciA9IGZ1bmN0aW9uKHRlbXBsYXRlLCBuYW1lLCB0ZW1wbGF0ZUluc3RhbmNlKSB7XG4gIHZhciBjb21wb25lbnQsIGhlbHBlciwgaXNLbm93bk9sZFN0eWxlSGVscGVyLCBtaXhpbk9yQ29tcG9uZW50LCByZWYsIHJlZjEsIHJlZjI7XG4gIGlzS25vd25PbGRTdHlsZUhlbHBlciA9IGZhbHNlO1xuICBpZiAodGVtcGxhdGUuX19oZWxwZXJzLmhhcyhuYW1lKSkge1xuICAgIGhlbHBlciA9IHRlbXBsYXRlLl9faGVscGVycy5nZXQobmFtZSk7XG4gICAgaWYgKGhlbHBlciA9PT0gQmxhemUuX09MRFNUWUxFX0hFTFBFUikge1xuICAgICAgaXNLbm93bk9sZFN0eWxlSGVscGVyID0gdHJ1ZTtcbiAgICB9IGVsc2UgaWYgKGhlbHBlciAhPSBudWxsKSB7XG4gICAgICByZXR1cm4gd3JhcEhlbHBlcihiaW5kRGF0YUNvbnRleHQoaGVscGVyKSwgdGVtcGxhdGVJbnN0YW5jZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgfVxuICBpZiAobmFtZSBpbiB0ZW1wbGF0ZSkge1xuICAgIGlmICghaXNLbm93bk9sZFN0eWxlSGVscGVyKSB7XG4gICAgICB0ZW1wbGF0ZS5fX2hlbHBlcnMuc2V0KG5hbWUsIEJsYXplLl9PTERTVFlMRV9IRUxQRVIpO1xuICAgICAgaWYgKCF0ZW1wbGF0ZS5fTk9XQVJOX09MRFNUWUxFX0hFTFBFUlMpIHtcbiAgICAgICAgQmxhemUuX3dhcm4oXCJBc3NpZ25pbmcgaGVscGVyIHdpdGggYFwiICsgdGVtcGxhdGUudmlld05hbWUgKyBcIi5cIiArIG5hbWUgKyBcIiA9IC4uLmAgaXMgZGVwcmVjYXRlZC4gIFVzZSBgXCIgKyB0ZW1wbGF0ZS52aWV3TmFtZSArIFwiLmhlbHBlcnMoLi4uKWAgaW5zdGVhZC5cIik7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICh0ZW1wbGF0ZVtuYW1lXSAhPSBudWxsKSB7XG4gICAgICByZXR1cm4gd3JhcEhlbHBlcihiaW5kRGF0YUNvbnRleHQodGVtcGxhdGVbbmFtZV0pLCB0ZW1wbGF0ZUluc3RhbmNlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICB9XG4gIGlmICghdGVtcGxhdGVJbnN0YW5jZSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGlmICgocmVmID0gdGVtcGxhdGUudmlld05hbWUpID09PSAnVGVtcGxhdGUuX19keW5hbWljV2l0aERhdGFDb250ZXh0JyB8fCByZWYgPT09ICdUZW1wbGF0ZS5fX2R5bmFtaWMnKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgY29tcG9uZW50ID0gVHJhY2tlci5ub25yZWFjdGl2ZShmdW5jdGlvbigpIHtcbiAgICByZXR1cm4gdGVtcGxhdGVJbnN0YW5jZVRvQ29tcG9uZW50KHRlbXBsYXRlSW5zdGFuY2UsIHRydWUpO1xuICB9KTtcbiAgaWYgKGNvbXBvbmVudCkge1xuICAgIGlmIChtaXhpbk9yQ29tcG9uZW50ID0gY29tcG9uZW50LmdldEZpcnN0V2l0aChudWxsLCBuYW1lKSkge1xuICAgICAgcmV0dXJuIHdyYXBIZWxwZXIoYmluZENvbXBvbmVudChtaXhpbk9yQ29tcG9uZW50LCBtaXhpbk9yQ29tcG9uZW50W25hbWVdKSwgdGVtcGxhdGVJbnN0YW5jZSk7XG4gICAgfVxuICB9XG4gIGlmIChuYW1lICYmIG5hbWUgaW4gQmxhemVDb21wb25lbnQuY29tcG9uZW50cykge1xuICAgIHJldHVybiBuZXcgQ29tcG9uZW50c05hbWVzcGFjZVJlZmVyZW5jZShuYW1lLCB0ZW1wbGF0ZUluc3RhbmNlKTtcbiAgfVxuICBpZiAoY29tcG9uZW50KSB7XG4gICAgaWYgKChoZWxwZXIgPSAocmVmMSA9IGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzKSAhPSBudWxsID8gKHJlZjIgPSByZWYxLnRlbXBsYXRlQmFzZSkgIT0gbnVsbCA/IHJlZjIuX19oZWxwZXJzLmdldChuYW1lKSA6IHZvaWQgMCA6IHZvaWQgMCkgIT0gbnVsbCkge1xuICAgICAgcmV0dXJuIHdyYXBIZWxwZXIoYmluZERhdGFDb250ZXh0KGhlbHBlciksIHRlbXBsYXRlSW5zdGFuY2UpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gbnVsbDtcbn07XG5cbnNoYXJlLmluRXhwYW5kQXR0cmlidXRlcyA9IGZhbHNlO1xuXG5iaW5kQ29tcG9uZW50ID0gZnVuY3Rpb24oY29tcG9uZW50LCBoZWxwZXIpIHtcbiAgaWYgKF8uaXNGdW5jdGlvbihoZWxwZXIpKSB7XG4gICAgcmV0dXJuIGZ1bmN0aW9uKCkge1xuICAgICAgdmFyIGFyZ3MsIG5hbWUsIHJlc3VsdCwgdmFsdWU7XG4gICAgICBhcmdzID0gMSA8PSBhcmd1bWVudHMubGVuZ3RoID8gc2xpY2UuY2FsbChhcmd1bWVudHMsIDApIDogW107XG4gICAgICByZXN1bHQgPSBoZWxwZXIuYXBwbHkoY29tcG9uZW50LCBhcmdzKTtcbiAgICAgIGlmIChzaGFyZS5pbkV4cGFuZEF0dHJpYnV0ZXMgJiYgXy5pc09iamVjdChyZXN1bHQpKSB7XG4gICAgICAgIGZvciAobmFtZSBpbiByZXN1bHQpIHtcbiAgICAgICAgICB2YWx1ZSA9IHJlc3VsdFtuYW1lXTtcbiAgICAgICAgICBpZiAoc2hhcmUuRVZFTlRfSEFORExFUl9SRUdFWC50ZXN0KG5hbWUpKSB7XG4gICAgICAgICAgICBpZiAoXy5pc0Z1bmN0aW9uKHZhbHVlKSkge1xuICAgICAgICAgICAgICByZXN1bHRbbmFtZV0gPSBfLmJpbmQodmFsdWUsIGNvbXBvbmVudCk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKF8uaXNBcnJheSh2YWx1ZSkpIHtcbiAgICAgICAgICAgICAgcmVzdWx0W25hbWVdID0gXy5tYXAodmFsdWUsIGZ1bmN0aW9uKGZ1bikge1xuICAgICAgICAgICAgICAgIGlmIChfLmlzRnVuY3Rpb24oZnVuKSkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIF8uYmluZChmdW4sIGNvbXBvbmVudCk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBmdW47XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfTtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gaGVscGVyO1xuICB9XG59O1xuXG5iaW5kRGF0YUNvbnRleHQgPSBmdW5jdGlvbihoZWxwZXIpIHtcbiAgaWYgKF8uaXNGdW5jdGlvbihoZWxwZXIpKSB7XG4gICAgcmV0dXJuIGZ1bmN0aW9uKCkge1xuICAgICAgdmFyIGRhdGE7XG4gICAgICBkYXRhID0gQmxhemUuZ2V0RGF0YSgpO1xuICAgICAgaWYgKGRhdGEgPT0gbnVsbCkge1xuICAgICAgICBkYXRhID0ge307XG4gICAgICB9XG4gICAgICByZXR1cm4gaGVscGVyLmFwcGx5KGRhdGEsIGFyZ3VtZW50cyk7XG4gICAgfTtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gaGVscGVyO1xuICB9XG59O1xuXG53cmFwSGVscGVyID0gZnVuY3Rpb24oZiwgdGVtcGxhdGVGdW5jKSB7XG4gIGlmICghQmxhemUuVGVtcGxhdGUuX3dpdGhUZW1wbGF0ZUluc3RhbmNlRnVuYykge1xuICAgIHJldHVybiBCbGF6ZS5fd3JhcENhdGNoaW5nRXhjZXB0aW9ucyhmLCAndGVtcGxhdGUgaGVscGVyJyk7XG4gIH1cbiAgaWYgKCFfLmlzRnVuY3Rpb24oZikpIHtcbiAgICByZXR1cm4gZjtcbiAgfVxuICByZXR1cm4gZnVuY3Rpb24oKSB7XG4gICAgdmFyIGFyZ3MsIHNlbGY7XG4gICAgc2VsZiA9IHRoaXM7XG4gICAgYXJncyA9IGFyZ3VtZW50cztcbiAgICByZXR1cm4gQmxhemUuVGVtcGxhdGUuX3dpdGhUZW1wbGF0ZUluc3RhbmNlRnVuYyh0ZW1wbGF0ZUZ1bmMsIGZ1bmN0aW9uKCkge1xuICAgICAgcmV0dXJuIEJsYXplLl93cmFwQ2F0Y2hpbmdFeGNlcHRpb25zKGYsICd0ZW1wbGF0ZSBoZWxwZXInKS5hcHBseShzZWxmLCBhcmdzKTtcbiAgICB9KTtcbiAgfTtcbn07XG5cbmlmIChCbGF6ZS5UZW1wbGF0ZS5fd2l0aFRlbXBsYXRlSW5zdGFuY2VGdW5jKSB7XG4gIHdpdGhUZW1wbGF0ZUluc3RhbmNlRnVuYyA9IEJsYXplLlRlbXBsYXRlLl93aXRoVGVtcGxhdGVJbnN0YW5jZUZ1bmM7XG59IGVsc2Uge1xuICB3aXRoVGVtcGxhdGVJbnN0YW5jZUZ1bmMgPSBmdW5jdGlvbih0ZW1wbGF0ZUluc3RhbmNlLCBmKSB7XG4gICAgcmV0dXJuIGYoKTtcbiAgfTtcbn1cblxuZ2V0VGVtcGxhdGVCYXNlID0gZnVuY3Rpb24oY29tcG9uZW50KSB7XG4gIHJldHVybiBUcmFja2VyLm5vbnJlYWN0aXZlKGZ1bmN0aW9uKCkge1xuICAgIHZhciBjb21wb25lbnRUZW1wbGF0ZSwgdGVtcGxhdGVCYXNlO1xuICAgIGNvbXBvbmVudFRlbXBsYXRlID0gY29tcG9uZW50LnRlbXBsYXRlKCk7XG4gICAgaWYgKF8uaXNTdHJpbmcoY29tcG9uZW50VGVtcGxhdGUpKSB7XG4gICAgICB0ZW1wbGF0ZUJhc2UgPSBUZW1wbGF0ZVtjb21wb25lbnRUZW1wbGF0ZV07XG4gICAgICBpZiAoIXRlbXBsYXRlQmFzZSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJUZW1wbGF0ZSAnXCIgKyBjb21wb25lbnRUZW1wbGF0ZSArIFwiJyBjYW5ub3QgYmUgZm91bmQuXCIpO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoY29tcG9uZW50VGVtcGxhdGUpIHtcbiAgICAgIHRlbXBsYXRlQmFzZSA9IGNvbXBvbmVudFRlbXBsYXRlO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJUZW1wbGF0ZSBmb3IgdGhlIGNvbXBvbmVudCAnXCIgKyAoY29tcG9uZW50LmNvbXBvbmVudE5hbWUoKSB8fCAndW5uYW1lZCcpICsgXCInIG5vdCBwcm92aWRlZC5cIik7XG4gICAgfVxuICAgIHJldHVybiB0ZW1wbGF0ZUJhc2U7XG4gIH0pO1xufTtcblxuY2FsbFRlbXBsYXRlQmFzZUhvb2tzID0gZnVuY3Rpb24oY29tcG9uZW50LCBob29rTmFtZSkge1xuICB2YXIgY2FsbGJhY2tzLCB0ZW1wbGF0ZUluc3RhbmNlO1xuICBpZiAoY29tcG9uZW50ICE9PSBjb21wb25lbnQuY29tcG9uZW50KCkpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgdGVtcGxhdGVJbnN0YW5jZSA9IFRyYWNrZXIubm9ucmVhY3RpdmUoZnVuY3Rpb24oKSB7XG4gICAgcmV0dXJuIGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLnRlbXBsYXRlSW5zdGFuY2UoKTtcbiAgfSk7XG4gIGNhbGxiYWNrcyA9IGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLnRlbXBsYXRlQmFzZS5fZ2V0Q2FsbGJhY2tzKGhvb2tOYW1lKTtcbiAgVGVtcGxhdGUuX3dpdGhUZW1wbGF0ZUluc3RhbmNlRnVuYyhmdW5jdGlvbigpIHtcbiAgICByZXR1cm4gdGVtcGxhdGVJbnN0YW5jZTtcbiAgfSwgZnVuY3Rpb24oKSB7XG4gICAgdmFyIGNhbGxiYWNrLCBpLCBsZW4sIHJlc3VsdHM7XG4gICAgcmVzdWx0cyA9IFtdO1xuICAgIGZvciAoaSA9IDAsIGxlbiA9IGNhbGxiYWNrcy5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xuICAgICAgY2FsbGJhY2sgPSBjYWxsYmFja3NbaV07XG4gICAgICByZXN1bHRzLnB1c2goY2FsbGJhY2suY2FsbCh0ZW1wbGF0ZUluc3RhbmNlKSk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHRzO1xuICB9KTtcbn07XG5cbndyYXBWaWV3QW5kVGVtcGxhdGUgPSBmdW5jdGlvbihjdXJyZW50VmlldywgZikge1xuICB2YXIgdGVtcGxhdGVJbnN0YW5jZTtcbiAgdGVtcGxhdGVJbnN0YW5jZSA9IGdldFRlbXBsYXRlSW5zdGFuY2VGdW5jdGlvbihjdXJyZW50VmlldywgdHJ1ZSk7XG4gIHJldHVybiB3aXRoVGVtcGxhdGVJbnN0YW5jZUZ1bmModGVtcGxhdGVJbnN0YW5jZSwgZnVuY3Rpb24oKSB7XG4gICAgcmV0dXJuIEJsYXplLl93aXRoQ3VycmVudFZpZXcoY3VycmVudFZpZXcsIGZ1bmN0aW9uKCkge1xuICAgICAgcmV0dXJuIGYoKTtcbiAgICB9KTtcbiAgfSk7XG59O1xuXG5hZGRFdmVudHMgPSBmdW5jdGlvbih2aWV3LCBjb21wb25lbnQpIHtcbiAgdmFyIGV2ZW50TWFwLCBldmVudHMsIGV2ZW50c0xpc3QsIGZuLCBoYW5kbGVyLCBpLCBsZW4sIHNwZWM7XG4gIGV2ZW50c0xpc3QgPSBjb21wb25lbnQuZXZlbnRzKCk7XG4gIGlmICghXy5pc0FycmF5KGV2ZW50c0xpc3QpKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiJ2V2ZW50cycgbWV0aG9kIGZyb20gdGhlIGNvbXBvbmVudCAnXCIgKyAoY29tcG9uZW50LmNvbXBvbmVudE5hbWUoKSB8fCAndW5uYW1lZCcpICsgXCInIGRpZCBub3QgcmV0dXJuIGEgbGlzdCBvZiBldmVudCBtYXBzLlwiKTtcbiAgfVxuICBmb3IgKGkgPSAwLCBsZW4gPSBldmVudHNMaXN0Lmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgZXZlbnRzID0gZXZlbnRzTGlzdFtpXTtcbiAgICBldmVudE1hcCA9IHt9O1xuICAgIGZuID0gZnVuY3Rpb24oc3BlYywgaGFuZGxlcikge1xuICAgICAgcmV0dXJuIGV2ZW50TWFwW3NwZWNdID0gZnVuY3Rpb24oKSB7XG4gICAgICAgIHZhciBhcmdzLCBjdXJyZW50VmlldywgZXZlbnQ7XG4gICAgICAgIGFyZ3MgPSAxIDw9IGFyZ3VtZW50cy5sZW5ndGggPyBzbGljZS5jYWxsKGFyZ3VtZW50cywgMCkgOiBbXTtcbiAgICAgICAgZXZlbnQgPSBhcmdzWzBdO1xuICAgICAgICBjdXJyZW50VmlldyA9IEJsYXplLmdldFZpZXcoZXZlbnQuY3VycmVudFRhcmdldCk7XG4gICAgICAgIHdyYXBWaWV3QW5kVGVtcGxhdGUoY3VycmVudFZpZXcsIGZ1bmN0aW9uKCkge1xuICAgICAgICAgIHJldHVybiBoYW5kbGVyLmFwcGx5KGNvbXBvbmVudCwgYXJncyk7XG4gICAgICAgIH0pO1xuICAgICAgfTtcbiAgICB9O1xuICAgIGZvciAoc3BlYyBpbiBldmVudHMpIHtcbiAgICAgIGhhbmRsZXIgPSBldmVudHNbc3BlY107XG4gICAgICBmbihzcGVjLCBoYW5kbGVyKTtcbiAgICB9XG4gICAgQmxhemUuX2FkZEV2ZW50TWFwKHZpZXcsIGV2ZW50TWFwLCB2aWV3KTtcbiAgfVxufTtcblxub3JpZ2luYWxHZXRUZW1wbGF0ZSA9IEJsYXplLl9nZXRUZW1wbGF0ZTtcblxuQmxhemUuX2dldFRlbXBsYXRlID0gZnVuY3Rpb24obmFtZSwgdGVtcGxhdGVJbnN0YW5jZSkge1xuICB2YXIgdGVtcGxhdGU7XG4gIHRlbXBsYXRlID0gVHJhY2tlci5ub25yZWFjdGl2ZShmdW5jdGlvbigpIHtcbiAgICB2YXIgcGFyZW50Q29tcG9uZW50LCByZWY7XG4gICAgaWYgKEJsYXplLmN1cnJlbnRWaWV3KSB7XG4gICAgICBwYXJlbnRDb21wb25lbnQgPSBCbGF6ZUNvbXBvbmVudC5jdXJyZW50Q29tcG9uZW50KCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHBhcmVudENvbXBvbmVudCA9IHRlbXBsYXRlSW5zdGFuY2VUb0NvbXBvbmVudCh0ZW1wbGF0ZUluc3RhbmNlLCBmYWxzZSk7XG4gICAgfVxuICAgIHJldHVybiAocmVmID0gQmxhemVDb21wb25lbnQuZ2V0Q29tcG9uZW50KG5hbWUpKSAhPSBudWxsID8gcmVmLnJlbmRlckNvbXBvbmVudChwYXJlbnRDb21wb25lbnQpIDogdm9pZCAwO1xuICB9KTtcbiAgaWYgKHRlbXBsYXRlICYmICh0ZW1wbGF0ZSBpbnN0YW5jZW9mIEJsYXplLlRlbXBsYXRlIHx8IF8uaXNGdW5jdGlvbih0ZW1wbGF0ZSkpKSB7XG4gICAgcmV0dXJuIHRlbXBsYXRlO1xuICB9XG4gIHJldHVybiBvcmlnaW5hbEdldFRlbXBsYXRlKG5hbWUpO1xufTtcblxucmVnaXN0ZXJIb29rcyA9IGZ1bmN0aW9uKHRlbXBsYXRlLCBob29rcykge1xuICBpZiAodGVtcGxhdGUub25DcmVhdGVkKSB7XG4gICAgdGVtcGxhdGUub25DcmVhdGVkKGhvb2tzLm9uQ3JlYXRlZCk7XG4gICAgdGVtcGxhdGUub25SZW5kZXJlZChob29rcy5vblJlbmRlcmVkKTtcbiAgICByZXR1cm4gdGVtcGxhdGUub25EZXN0cm95ZWQoaG9va3Mub25EZXN0cm95ZWQpO1xuICB9IGVsc2Uge1xuICAgIHRlbXBsYXRlLmNyZWF0ZWQgPSBob29rcy5vbkNyZWF0ZWQ7XG4gICAgdGVtcGxhdGUucmVuZGVyZWQgPSBob29rcy5vblJlbmRlcmVkO1xuICAgIHJldHVybiB0ZW1wbGF0ZS5kZXN0cm95ZWQgPSBob29rcy5vbkRlc3Ryb3llZDtcbiAgfVxufTtcblxucmVnaXN0ZXJGaXJzdENyZWF0ZWRIb29rID0gZnVuY3Rpb24odGVtcGxhdGUsIG9uQ3JlYXRlZCkge1xuICB2YXIgb2xkQ3JlYXRlZDtcbiAgaWYgKHRlbXBsYXRlLl9jYWxsYmFja3MpIHtcbiAgICByZXR1cm4gdGVtcGxhdGUuX2NhbGxiYWNrcy5jcmVhdGVkLnVuc2hpZnQob25DcmVhdGVkKTtcbiAgfSBlbHNlIHtcbiAgICBvbGRDcmVhdGVkID0gdGVtcGxhdGUuY3JlYXRlZDtcbiAgICByZXR1cm4gdGVtcGxhdGUuY3JlYXRlZCA9IGZ1bmN0aW9uKCkge1xuICAgICAgb25DcmVhdGVkLmNhbGwodGhpcyk7XG4gICAgICByZXR1cm4gb2xkQ3JlYXRlZCAhPSBudWxsID8gb2xkQ3JlYXRlZC5jYWxsKHRoaXMpIDogdm9pZCAwO1xuICAgIH07XG4gIH1cbn07XG5cblRlbXBsYXRlLl9fZHluYW1pY1dpdGhEYXRhQ29udGV4dC5fX2hlbHBlcnMuc2V0KCdjaG9vc2VUZW1wbGF0ZScsIGZ1bmN0aW9uKG5hbWUpIHtcbiAgcmV0dXJuIEJsYXplLl9nZXRUZW1wbGF0ZShuYW1lLCAoZnVuY3Rpb24oX3RoaXMpIHtcbiAgICByZXR1cm4gZnVuY3Rpb24oKSB7XG4gICAgICByZXR1cm4gVGVtcGxhdGUuaW5zdGFuY2UoKTtcbiAgICB9O1xuICB9KSh0aGlzKSk7XG59KTtcblxuYXJndW1lbnRzQ29uc3RydWN0b3IgPSBmdW5jdGlvbigpIHtcbiAgcmV0dXJuIGFzc2VydChmYWxzZSk7XG59O1xuXG5UZW1wbGF0ZS5yZWdpc3RlckhlbHBlcignYXJncycsIGZ1bmN0aW9uKCkge1xuICB2YXIgb2JqO1xuICBvYmogPSB7fTtcbiAgb2JqLmNvbnN0cnVjdG9yID0gYXJndW1lbnRzQ29uc3RydWN0b3I7XG4gIG9iai5fYXJndW1lbnRzID0gYXJndW1lbnRzO1xuICByZXR1cm4gb2JqO1xufSk7XG5cbnNoYXJlLkVWRU5UX0hBTkRMRVJfUkVHRVggPSAvXm9uW0EtWl0vO1xuXG5zaGFyZS5pc0V2ZW50SGFuZGxlciA9IGZ1bmN0aW9uKGZ1bikge1xuICByZXR1cm4gXy5pc0Z1bmN0aW9uKGZ1bikgJiYgZnVuLmV2ZW50SGFuZGxlcjtcbn07XG5cbm9yaWdpbmFsRmxhdHRlbkF0dHJpYnV0ZXMgPSBIVE1MLmZsYXR0ZW5BdHRyaWJ1dGVzO1xuXG5IVE1MLmZsYXR0ZW5BdHRyaWJ1dGVzID0gZnVuY3Rpb24oYXR0cnMpIHtcbiAgdmFyIG5hbWUsIHZhbHVlO1xuICBpZiAoYXR0cnMgPSBvcmlnaW5hbEZsYXR0ZW5BdHRyaWJ1dGVzKGF0dHJzKSkge1xuICAgIGZvciAobmFtZSBpbiBhdHRycykge1xuICAgICAgdmFsdWUgPSBhdHRyc1tuYW1lXTtcbiAgICAgIGlmICghKHNoYXJlLkVWRU5UX0hBTkRMRVJfUkVHRVgudGVzdChuYW1lKSkpIHtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBpZiAoc2hhcmUuaXNFdmVudEhhbmRsZXIodmFsdWUpKSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgaWYgKF8uaXNBcnJheSh2YWx1ZSkgJiYgXy5zb21lKHZhbHVlLCBzaGFyZS5pc0V2ZW50SGFuZGxlcikpIHtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBpZiAoXy5pc0FycmF5KHZhbHVlKSkge1xuICAgICAgICBhdHRyc1tuYW1lXSA9IF8ubWFwKHZhbHVlLCBTcGFjZWJhcnMuZXZlbnQpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYXR0cnNbbmFtZV0gPSBTcGFjZWJhcnMuZXZlbnQodmFsdWUpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gYXR0cnM7XG59O1xuXG5TcGFjZWJhcnMuZXZlbnQgPSBmdW5jdGlvbigpIHtcbiAgdmFyIGFyZ3MsIGV2ZW50SGFuZGxlciwgZnVuO1xuICBldmVudEhhbmRsZXIgPSBhcmd1bWVudHNbMF0sIGFyZ3MgPSAyIDw9IGFyZ3VtZW50cy5sZW5ndGggPyBzbGljZS5jYWxsKGFyZ3VtZW50cywgMSkgOiBbXTtcbiAgaWYgKCFfLmlzRnVuY3Rpb24oZXZlbnRIYW5kbGVyKSkge1xuICAgIHRocm93IG5ldyBFcnJvcihcIkV2ZW50IGhhbmRsZXIgbm90IGEgZnVuY3Rpb246IFwiICsgZXZlbnRIYW5kbGVyKTtcbiAgfVxuICBhcmdzID0gU3BhY2ViYXJzLm11c3RhY2hlSW1wbC5hcHBseShTcGFjZWJhcnMsIFsoZnVuY3Rpb24oKSB7XG4gICAgdmFyIHhzO1xuICAgIHhzID0gMSA8PSBhcmd1bWVudHMubGVuZ3RoID8gc2xpY2UuY2FsbChhcmd1bWVudHMsIDApIDogW107XG4gICAgcmV0dXJuIHhzO1xuICB9KV0uY29uY2F0KHNsaWNlLmNhbGwoYXJncykpKTtcbiAgZnVuID0gZnVuY3Rpb24oKSB7XG4gICAgdmFyIGN1cnJlbnRWaWV3LCBldmVudCwgZXZlbnRBcmdzO1xuICAgIGV2ZW50ID0gYXJndW1lbnRzWzBdLCBldmVudEFyZ3MgPSAyIDw9IGFyZ3VtZW50cy5sZW5ndGggPyBzbGljZS5jYWxsKGFyZ3VtZW50cywgMSkgOiBbXTtcbiAgICBjdXJyZW50VmlldyA9IEJsYXplLmdldFZpZXcoZXZlbnQuY3VycmVudFRhcmdldCk7XG4gICAgcmV0dXJuIHdyYXBWaWV3QW5kVGVtcGxhdGUoY3VycmVudFZpZXcsIGZ1bmN0aW9uKCkge1xuICAgICAgcmV0dXJuIGV2ZW50SGFuZGxlci5hcHBseShudWxsLCBbZXZlbnRdLmNvbmNhdChhcmdzLCBldmVudEFyZ3MpKTtcbiAgICB9KTtcbiAgfTtcbiAgZnVuLmV2ZW50SGFuZGxlciA9IHRydWU7XG4gIHJldHVybiBmdW47XG59O1xuXG5vcmlnaW5hbFZpc2l0VGFnID0gSFRNTC5Ub0hUTUxWaXNpdG9yLnByb3RvdHlwZS52aXNpdFRhZztcblxuSFRNTC5Ub0hUTUxWaXNpdG9yLnByb3RvdHlwZS52aXNpdFRhZyA9IGZ1bmN0aW9uKHRhZykge1xuICB2YXIgYXR0cnMsIG5hbWU7XG4gIGlmIChhdHRycyA9IHRhZy5hdHRycykge1xuICAgIGF0dHJzID0gSFRNTC5mbGF0dGVuQXR0cmlidXRlcyhhdHRycyk7XG4gICAgZm9yIChuYW1lIGluIGF0dHJzKSB7XG4gICAgICBpZiAoc2hhcmUuRVZFTlRfSEFORExFUl9SRUdFWC50ZXN0KG5hbWUpKSB7XG4gICAgICAgIGRlbGV0ZSBhdHRyc1tuYW1lXTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGFnLmF0dHJzID0gYXR0cnM7XG4gIH1cbiAgcmV0dXJuIG9yaWdpbmFsVmlzaXRUYWcuY2FsbCh0aGlzLCB0YWcpO1xufTtcblxuY3VycmVudFZpZXdJZlJlbmRlcmluZyA9IGZ1bmN0aW9uKCkge1xuICB2YXIgdmlldztcbiAgdmlldyA9IEJsYXplLmN1cnJlbnRWaWV3O1xuICBpZiAodmlldyAhPSBudWxsID8gdmlldy5faXNJblJlbmRlciA6IHZvaWQgMCkge1xuICAgIHJldHVybiB2aWV3O1xuICB9IGVsc2Uge1xuICAgIHJldHVybiBudWxsO1xuICB9XG59O1xuXG5jb250ZW50QXNGdW5jID0gZnVuY3Rpb24oY29udGVudCkge1xuICBpZiAoIV8uaXNGdW5jdGlvbihjb250ZW50KSkge1xuICAgIHJldHVybiBmdW5jdGlvbigpIHtcbiAgICAgIHJldHVybiBjb250ZW50O1xuICAgIH07XG4gIH1cbiAgcmV0dXJuIGNvbnRlbnQ7XG59O1xuXG5jb250ZW50QXNWaWV3ID0gZnVuY3Rpb24oY29udGVudCkge1xuICBpZiAoY29udGVudCBpbnN0YW5jZW9mIEJsYXplLlRlbXBsYXRlKSB7XG4gICAgcmV0dXJuIGNvbnRlbnQuY29uc3RydWN0VmlldygpO1xuICB9IGVsc2UgaWYgKGNvbnRlbnQgaW5zdGFuY2VvZiBCbGF6ZS5WaWV3KSB7XG4gICAgcmV0dXJuIGNvbnRlbnQ7XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIEJsYXplLlZpZXcoJ3JlbmRlcicsIGNvbnRlbnRBc0Z1bmMoY29udGVudCkpO1xuICB9XG59O1xuXG5IVE1MSlNFeHBhbmRlciA9IEJsYXplLl9IVE1MSlNFeHBhbmRlci5leHRlbmQoKTtcblxuSFRNTEpTRXhwYW5kZXIuZGVmKHtcbiAgdmlzaXRPYmplY3Q6IGZ1bmN0aW9uKHgpIHtcbiAgICBpZiAoeCBpbnN0YW5jZW9mIEJsYXplLlRlbXBsYXRlKSB7XG4gICAgICB4ID0geC5jb25zdHJ1Y3RWaWV3KCk7XG4gICAgfVxuICAgIGlmICh4IGluc3RhbmNlb2YgQmxhemUuVmlldykge1xuICAgICAgcmV0dXJuIGV4cGFuZFZpZXcoeCwgdGhpcy5wYXJlbnRWaWV3KTtcbiAgICB9XG4gICAgcmV0dXJuIEhUTUwuVHJhbnNmb3JtaW5nVmlzaXRvci5wcm90b3R5cGUudmlzaXRPYmplY3QuY2FsbCh0aGlzLCB4KTtcbiAgfVxufSk7XG5cbmV4cGFuZCA9IGZ1bmN0aW9uKGh0bWxqcywgcGFyZW50Vmlldykge1xuICBwYXJlbnRWaWV3ID0gcGFyZW50VmlldyB8fCBjdXJyZW50Vmlld0lmUmVuZGVyaW5nKCk7XG4gIHJldHVybiAobmV3IEhUTUxKU0V4cGFuZGVyKHtcbiAgICBwYXJlbnRWaWV3OiBwYXJlbnRWaWV3XG4gIH0pKS52aXNpdChodG1sanMpO1xufTtcblxuZXhwYW5kVmlldyA9IGZ1bmN0aW9uKHZpZXcsIHBhcmVudFZpZXcpIHtcbiAgdmFyIGh0bWxqcywgcmVzdWx0O1xuICBCbGF6ZS5fY3JlYXRlVmlldyh2aWV3LCBwYXJlbnRWaWV3LCB0cnVlKTtcbiAgdmlldy5faXNJblJlbmRlciA9IHRydWU7XG4gIGh0bWxqcyA9IEJsYXplLl93aXRoQ3VycmVudFZpZXcodmlldywgZnVuY3Rpb24oKSB7XG4gICAgcmV0dXJuIHZpZXcuX3JlbmRlcigpO1xuICB9KTtcbiAgdmlldy5faXNJblJlbmRlciA9IGZhbHNlO1xuICBUcmFja2VyLmZsdXNoKCk7XG4gIHJlc3VsdCA9IGV4cGFuZChodG1sanMsIHZpZXcpO1xuICBUcmFja2VyLmZsdXNoKCk7XG4gIGlmIChUcmFja2VyLmFjdGl2ZSkge1xuICAgIFRyYWNrZXIub25JbnZhbGlkYXRlKGZ1bmN0aW9uKCkge1xuICAgICAgcmV0dXJuIEJsYXplLl9kZXN0cm95Vmlldyh2aWV3KTtcbiAgICB9KTtcbiAgfSBlbHNlIHtcbiAgICBCbGF6ZS5fZGVzdHJveVZpZXcodmlldyk7XG4gIH1cbiAgVHJhY2tlci5mbHVzaCgpO1xuICByZXR1cm4gcmVzdWx0O1xufTtcblxuQmxhemVDb21wb25lbnQgPSAoZnVuY3Rpb24oc3VwZXJDbGFzcykge1xuICBleHRlbmQoQmxhemVDb21wb25lbnQsIHN1cGVyQ2xhc3MpO1xuXG4gIGZ1bmN0aW9uIEJsYXplQ29tcG9uZW50KCkge1xuICAgIHJldHVybiBCbGF6ZUNvbXBvbmVudC5fX3N1cGVyX18uY29uc3RydWN0b3IuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgfVxuXG4gIEJsYXplQ29tcG9uZW50LmdldENvbXBvbmVudEZvckVsZW1lbnQgPSBmdW5jdGlvbihkb21FbGVtZW50KSB7XG4gICAgdmFyIHRlbXBsYXRlSW5zdGFuY2U7XG4gICAgaWYgKCFkb21FbGVtZW50KSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgaWYgKGRvbUVsZW1lbnQubm9kZVR5cGUgIT09IE5vZGUuRUxFTUVOVF9OT0RFKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBET00gZWxlbWVudC5cIik7XG4gICAgfVxuICAgIHRlbXBsYXRlSW5zdGFuY2UgPSBnZXRUZW1wbGF0ZUluc3RhbmNlRnVuY3Rpb24oQmxhemUuZ2V0Vmlldyhkb21FbGVtZW50KSwgdHJ1ZSk7XG4gICAgcmV0dXJuIHRlbXBsYXRlSW5zdGFuY2VUb0NvbXBvbmVudCh0ZW1wbGF0ZUluc3RhbmNlLCB0cnVlKTtcbiAgfTtcblxuICBCbGF6ZUNvbXBvbmVudC5wcm90b3R5cGUuY2hpbGRDb21wb25lbnRzID0gZnVuY3Rpb24obmFtZU9yQ29tcG9uZW50KSB7XG4gICAgdmFyIGNvbXBvbmVudDtcbiAgICBpZiAoKGNvbXBvbmVudCA9IHRoaXMuY29tcG9uZW50KCkpICE9PSB0aGlzKSB7XG4gICAgICByZXR1cm4gY29tcG9uZW50LmNoaWxkQ29tcG9uZW50cyhuYW1lT3JDb21wb25lbnQpO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gQmxhemVDb21wb25lbnQuX19zdXBlcl9fLmNoaWxkQ29tcG9uZW50cy5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgIH1cbiAgfTtcblxuICBCbGF6ZUNvbXBvbmVudC5wcm90b3R5cGUuY2hpbGRDb21wb25lbnRzV2l0aCA9IGZ1bmN0aW9uKHByb3BlcnR5T3JNYXRjaGVyT3JGdW5jdGlvbikge1xuICAgIHZhciBjb21wb25lbnQ7XG4gICAgaWYgKChjb21wb25lbnQgPSB0aGlzLmNvbXBvbmVudCgpKSAhPT0gdGhpcykge1xuICAgICAgcmV0dXJuIGNvbXBvbmVudC5jaGlsZENvbXBvbmVudHNXaXRoKHByb3BlcnR5T3JNYXRjaGVyT3JGdW5jdGlvbik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGFzc2VydChwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb24pO1xuICAgICAgcHJvcGVydHlPck1hdGNoZXJPckZ1bmN0aW9uID0gY3JlYXRlTWF0Y2hlcihwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb24sIHRydWUpO1xuICAgICAgcmV0dXJuIEJsYXplQ29tcG9uZW50Ll9fc3VwZXJfXy5jaGlsZENvbXBvbmVudHNXaXRoLmNhbGwodGhpcywgcHJvcGVydHlPck1hdGNoZXJPckZ1bmN0aW9uKTtcbiAgICB9XG4gIH07XG5cbiAgQmxhemVDb21wb25lbnQucHJvdG90eXBlLnBhcmVudENvbXBvbmVudCA9IGZ1bmN0aW9uKHBhcmVudENvbXBvbmVudCkge1xuICAgIHZhciBjb21wb25lbnQ7XG4gICAgaWYgKChjb21wb25lbnQgPSB0aGlzLmNvbXBvbmVudCgpKSAhPT0gdGhpcykge1xuICAgICAgcmV0dXJuIGNvbXBvbmVudC5wYXJlbnRDb21wb25lbnQocGFyZW50Q29tcG9uZW50KTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIEJsYXplQ29tcG9uZW50Ll9fc3VwZXJfXy5wYXJlbnRDb21wb25lbnQuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICB9XG4gIH07XG5cbiAgQmxhemVDb21wb25lbnQucHJvdG90eXBlLmFkZENoaWxkQ29tcG9uZW50ID0gZnVuY3Rpb24oY2hpbGRDb21wb25lbnQpIHtcbiAgICB2YXIgY29tcG9uZW50O1xuICAgIGlmICgoY29tcG9uZW50ID0gdGhpcy5jb21wb25lbnQoKSkgIT09IHRoaXMpIHtcbiAgICAgIHJldHVybiBjb21wb25lbnQuYWRkQ2hpbGRDb21wb25lbnQoY2hpbGRDb21wb25lbnQpO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gQmxhemVDb21wb25lbnQuX19zdXBlcl9fLmFkZENoaWxkQ29tcG9uZW50LmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgfVxuICB9O1xuXG4gIEJsYXplQ29tcG9uZW50LnByb3RvdHlwZS5yZW1vdmVDaGlsZENvbXBvbmVudCA9IGZ1bmN0aW9uKGNoaWxkQ29tcG9uZW50KSB7XG4gICAgdmFyIGNvbXBvbmVudDtcbiAgICBpZiAoKGNvbXBvbmVudCA9IHRoaXMuY29tcG9uZW50KCkpICE9PSB0aGlzKSB7XG4gICAgICByZXR1cm4gY29tcG9uZW50LnJlbW92ZUNoaWxkQ29tcG9uZW50KGNoaWxkQ29tcG9uZW50KTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIEJsYXplQ29tcG9uZW50Ll9fc3VwZXJfXy5yZW1vdmVDaGlsZENvbXBvbmVudC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgIH1cbiAgfTtcblxuICBCbGF6ZUNvbXBvbmVudC5wcm90b3R5cGUubWl4aW5zID0gZnVuY3Rpb24oKSB7XG4gICAgcmV0dXJuIFtdO1xuICB9O1xuXG4gIEJsYXplQ29tcG9uZW50LnByb3RvdHlwZS5taXhpblBhcmVudCA9IGZ1bmN0aW9uKG1peGluUGFyZW50KSB7XG4gICAgaWYgKHRoaXMuX2NvbXBvbmVudEludGVybmFscyA9PSBudWxsKSB7XG4gICAgICB0aGlzLl9jb21wb25lbnRJbnRlcm5hbHMgPSB7fTtcbiAgICB9XG4gICAgaWYgKG1peGluUGFyZW50KSB7XG4gICAgICB0aGlzLl9jb21wb25lbnRJbnRlcm5hbHMubWl4aW5QYXJlbnQgPSBtaXhpblBhcmVudDtcbiAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fY29tcG9uZW50SW50ZXJuYWxzLm1peGluUGFyZW50IHx8IG51bGw7XG4gIH07XG5cbiAgQmxhemVDb21wb25lbnQucHJvdG90eXBlLnJlcXVpcmVNaXhpbiA9IGZ1bmN0aW9uKG5hbWVPck1peGluKSB7XG4gICAgdmFyIHJlZjtcbiAgICBhc3NlcnQoKHJlZiA9IHRoaXMuX2NvbXBvbmVudEludGVybmFscykgIT0gbnVsbCA/IHJlZi5taXhpbnMgOiB2b2lkIDApO1xuICAgIFRyYWNrZXIubm9ucmVhY3RpdmUoKGZ1bmN0aW9uKF90aGlzKSB7XG4gICAgICByZXR1cm4gZnVuY3Rpb24oKSB7XG4gICAgICAgIHZhciBiYXNlLCBjb21wb25lbnQsIG1peGluSW5zdGFuY2UsIG1peGluSW5zdGFuY2VDb21wb25lbnQsIHJlZjEsIHJlZjIsIHJlZjM7XG4gICAgICAgIGlmIChfdGhpcy5nZXRNaXhpbihuYW1lT3JNaXhpbikpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKF8uaXNTdHJpbmcobmFtZU9yTWl4aW4pKSB7XG4gICAgICAgICAgaWYgKF90aGlzLmNvbnN0cnVjdG9yLmdldENvbXBvbmVudCkge1xuICAgICAgICAgICAgbWl4aW5JbnN0YW5jZUNvbXBvbmVudCA9IF90aGlzLmNvbnN0cnVjdG9yLmdldENvbXBvbmVudChuYW1lT3JNaXhpbik7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG1peGluSW5zdGFuY2VDb21wb25lbnQgPSBCbGF6ZUNvbXBvbmVudC5nZXRDb21wb25lbnQobmFtZU9yTWl4aW4pO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoIW1peGluSW5zdGFuY2VDb21wb25lbnQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIlVua25vd24gbWl4aW4gJ1wiICsgbmFtZU9yTWl4aW4gKyBcIicuXCIpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBtaXhpbkluc3RhbmNlID0gbmV3IG1peGluSW5zdGFuY2VDb21wb25lbnQoKTtcbiAgICAgICAgfSBlbHNlIGlmIChfLmlzRnVuY3Rpb24obmFtZU9yTWl4aW4pKSB7XG4gICAgICAgICAgbWl4aW5JbnN0YW5jZSA9IG5ldyBuYW1lT3JNaXhpbigpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG1peGluSW5zdGFuY2UgPSBuYW1lT3JNaXhpbjtcbiAgICAgICAgfVxuICAgICAgICBfdGhpcy5fY29tcG9uZW50SW50ZXJuYWxzLm1peGlucy5wdXNoKG1peGluSW5zdGFuY2UpO1xuICAgICAgICBpZiAobWl4aW5JbnN0YW5jZS5taXhpblBhcmVudCkge1xuICAgICAgICAgIG1peGluSW5zdGFuY2UubWl4aW5QYXJlbnQoX3RoaXMpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0eXBlb2YgbWl4aW5JbnN0YW5jZS5jcmVhdGVNaXhpbnMgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgIG1peGluSW5zdGFuY2UuY3JlYXRlTWl4aW5zKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNvbXBvbmVudCA9IF90aGlzLmNvbXBvbmVudCgpKSB7XG4gICAgICAgICAgaWYgKGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzID09IG51bGwpIHtcbiAgICAgICAgICAgIGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzID0ge307XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICgoYmFzZSA9IGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzKS50ZW1wbGF0ZUluc3RhbmNlID09IG51bGwpIHtcbiAgICAgICAgICAgIGJhc2UudGVtcGxhdGVJbnN0YW5jZSA9IG5ldyBSZWFjdGl2ZUZpZWxkKG51bGwsIGZ1bmN0aW9uKGEsIGIpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGEgPT09IGI7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKCEoKHJlZjEgPSBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscy50ZW1wbGF0ZUluc3RhbmNlKCkpICE9IG51bGwgPyByZWYxLnZpZXcuaXNEZXN0cm95ZWQgOiB2b2lkIDApKSB7XG4gICAgICAgICAgICBpZiAoIWNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLmluT25DcmVhdGVkICYmICgocmVmMiA9IGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLnRlbXBsYXRlSW5zdGFuY2UoKSkgIT0gbnVsbCA/IHJlZjIudmlldy5pc0NyZWF0ZWQgOiB2b2lkIDApKSB7XG4gICAgICAgICAgICAgIGlmICh0eXBlb2YgbWl4aW5JbnN0YW5jZS5vbkNyZWF0ZWQgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgICAgICAgIG1peGluSW5zdGFuY2Uub25DcmVhdGVkKCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMuaW5PblJlbmRlcmVkICYmICgocmVmMyA9IGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLnRlbXBsYXRlSW5zdGFuY2UoKSkgIT0gbnVsbCA/IHJlZjMudmlldy5pc1JlbmRlcmVkIDogdm9pZCAwKSkge1xuICAgICAgICAgICAgICByZXR1cm4gdHlwZW9mIG1peGluSW5zdGFuY2Uub25SZW5kZXJlZCA9PT0gXCJmdW5jdGlvblwiID8gbWl4aW5JbnN0YW5jZS5vblJlbmRlcmVkKCkgOiB2b2lkIDA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9O1xuICAgIH0pKHRoaXMpKTtcbiAgICByZXR1cm4gdGhpcztcbiAgfTtcblxuICBCbGF6ZUNvbXBvbmVudC5wcm90b3R5cGUuY3JlYXRlTWl4aW5zID0gZnVuY3Rpb24oKSB7XG4gICAgdmFyIGksIGxlbiwgbWl4aW4sIHJlZjtcbiAgICBpZiAodGhpcy5fY29tcG9uZW50SW50ZXJuYWxzID09IG51bGwpIHtcbiAgICAgIHRoaXMuX2NvbXBvbmVudEludGVybmFscyA9IHt9O1xuICAgIH1cbiAgICBpZiAodGhpcy5fY29tcG9uZW50SW50ZXJuYWxzLm1peGlucykge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLl9jb21wb25lbnRJbnRlcm5hbHMubWl4aW5zID0gW107XG4gICAgcmVmID0gdGhpcy5taXhpbnMoKTtcbiAgICBmb3IgKGkgPSAwLCBsZW4gPSByZWYubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgIG1peGluID0gcmVmW2ldO1xuICAgICAgdGhpcy5yZXF1aXJlTWl4aW4obWl4aW4pO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcztcbiAgfTtcblxuICBCbGF6ZUNvbXBvbmVudC5wcm90b3R5cGUuZ2V0TWl4aW4gPSBmdW5jdGlvbihuYW1lT3JNaXhpbikge1xuICAgIGlmIChfLmlzU3RyaW5nKG5hbWVPck1peGluKSkge1xuICAgICAgcmV0dXJuIHRoaXMuZ2V0Rmlyc3RXaXRoKHRoaXMsIChmdW5jdGlvbihfdGhpcykge1xuICAgICAgICByZXR1cm4gZnVuY3Rpb24oY2hpbGQsIHBhcmVudCkge1xuICAgICAgICAgIHZhciBtaXhpbkNvbXBvbmVudE5hbWU7XG4gICAgICAgICAgbWl4aW5Db21wb25lbnROYW1lID0gKHR5cGVvZiBjaGlsZC5jb21wb25lbnROYW1lID09PSBcImZ1bmN0aW9uXCIgPyBjaGlsZC5jb21wb25lbnROYW1lKCkgOiB2b2lkIDApIHx8IG51bGw7XG4gICAgICAgICAgcmV0dXJuIG1peGluQ29tcG9uZW50TmFtZSAmJiBtaXhpbkNvbXBvbmVudE5hbWUgPT09IG5hbWVPck1peGluO1xuICAgICAgICB9O1xuICAgICAgfSkodGhpcykpO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gdGhpcy5nZXRGaXJzdFdpdGgodGhpcywgKGZ1bmN0aW9uKF90aGlzKSB7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbihjaGlsZCwgcGFyZW50KSB7XG4gICAgICAgICAgaWYgKGNoaWxkLmNvbnN0cnVjdG9yID09PSBuYW1lT3JNaXhpbikge1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChjaGlsZCA9PT0gbmFtZU9yTWl4aW4pIHtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH07XG4gICAgICB9KSh0aGlzKSk7XG4gICAgfVxuICB9O1xuXG4gIEJsYXplQ29tcG9uZW50LnByb3RvdHlwZS5jYWxsRmlyc3RXaXRoID0gZnVuY3Rpb24oKSB7XG4gICAgdmFyIGFmdGVyQ29tcG9uZW50T3JNaXhpbiwgYXJncywgY29tcG9uZW50T3JNaXhpbiwgcHJvcGVydHlOYW1lO1xuICAgIGFmdGVyQ29tcG9uZW50T3JNaXhpbiA9IGFyZ3VtZW50c1swXSwgcHJvcGVydHlOYW1lID0gYXJndW1lbnRzWzFdLCBhcmdzID0gMyA8PSBhcmd1bWVudHMubGVuZ3RoID8gc2xpY2UuY2FsbChhcmd1bWVudHMsIDIpIDogW107XG4gICAgYXNzZXJ0KF8uaXNTdHJpbmcocHJvcGVydHlOYW1lKSk7XG4gICAgY29tcG9uZW50T3JNaXhpbiA9IHRoaXMuZ2V0Rmlyc3RXaXRoKGFmdGVyQ29tcG9uZW50T3JNaXhpbiwgcHJvcGVydHlOYW1lKTtcbiAgICBpZiAoIWNvbXBvbmVudE9yTWl4aW4pIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKF8uaXNGdW5jdGlvbihjb21wb25lbnRPck1peGluW3Byb3BlcnR5TmFtZV0pKSB7XG4gICAgICByZXR1cm4gY29tcG9uZW50T3JNaXhpbltwcm9wZXJ0eU5hbWVdLmFwcGx5KGNvbXBvbmVudE9yTWl4aW4sIGFyZ3MpO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gY29tcG9uZW50T3JNaXhpbltwcm9wZXJ0eU5hbWVdO1xuICAgIH1cbiAgfTtcblxuICBCbGF6ZUNvbXBvbmVudC5wcm90b3R5cGUuZ2V0Rmlyc3RXaXRoID0gZnVuY3Rpb24oYWZ0ZXJDb21wb25lbnRPck1peGluLCBwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb24pIHtcbiAgICB2YXIgZm91bmQsIGksIGxlbiwgbWl4aW4sIHJlZiwgcmVmMTtcbiAgICBhc3NlcnQoKHJlZiA9IHRoaXMuX2NvbXBvbmVudEludGVybmFscykgIT0gbnVsbCA/IHJlZi5taXhpbnMgOiB2b2lkIDApO1xuICAgIGFzc2VydChwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb24pO1xuICAgIHByb3BlcnR5T3JNYXRjaGVyT3JGdW5jdGlvbiA9IGNyZWF0ZU1hdGNoZXIocHJvcGVydHlPck1hdGNoZXJPckZ1bmN0aW9uLCBmYWxzZSk7XG4gICAgaWYgKCFhZnRlckNvbXBvbmVudE9yTWl4aW4pIHtcbiAgICAgIGlmIChwcm9wZXJ0eU9yTWF0Y2hlck9yRnVuY3Rpb24uY2FsbCh0aGlzLCB0aGlzLCB0aGlzKSkge1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgIH1cbiAgICAgIGZvdW5kID0gdHJ1ZTtcbiAgICB9IGVsc2UgaWYgKGFmdGVyQ29tcG9uZW50T3JNaXhpbiAmJiBhZnRlckNvbXBvbmVudE9yTWl4aW4gPT09IHRoaXMpIHtcbiAgICAgIGZvdW5kID0gdHJ1ZTtcbiAgICB9IGVsc2Uge1xuICAgICAgZm91bmQgPSBmYWxzZTtcbiAgICB9XG4gICAgcmVmMSA9IHRoaXMuX2NvbXBvbmVudEludGVybmFscy5taXhpbnM7XG4gICAgZm9yIChpID0gMCwgbGVuID0gcmVmMS5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xuICAgICAgbWl4aW4gPSByZWYxW2ldO1xuICAgICAgaWYgKGZvdW5kICYmIHByb3BlcnR5T3JNYXRjaGVyT3JGdW5jdGlvbi5jYWxsKHRoaXMsIG1peGluLCB0aGlzKSkge1xuICAgICAgICByZXR1cm4gbWl4aW47XG4gICAgICB9XG4gICAgICBpZiAobWl4aW4gPT09IGFmdGVyQ29tcG9uZW50T3JNaXhpbikge1xuICAgICAgICBmb3VuZCA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9O1xuXG4gIEJsYXplQ29tcG9uZW50LnJlbmRlckNvbXBvbmVudCA9IGZ1bmN0aW9uKHBhcmVudENvbXBvbmVudCkge1xuICAgIHJldHVybiBUcmFja2VyLm5vbnJlYWN0aXZlKChmdW5jdGlvbihfdGhpcykge1xuICAgICAgcmV0dXJuIGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgY29tcG9uZW50Q2xhc3MsIGRhdGE7XG4gICAgICAgIGNvbXBvbmVudENsYXNzID0gX3RoaXM7XG4gICAgICAgIGlmIChCbGF6ZS5jdXJyZW50Vmlldykge1xuICAgICAgICAgIGRhdGEgPSBUZW1wbGF0ZS5jdXJyZW50RGF0YSgpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGRhdGEgPSBudWxsO1xuICAgICAgICB9XG4gICAgICAgIGlmICgoZGF0YSAhPSBudWxsID8gZGF0YS5jb25zdHJ1Y3RvciA6IHZvaWQgMCkgIT09IGFyZ3VtZW50c0NvbnN0cnVjdG9yKSB7XG4gICAgICAgICAgcmV0dXJuIHdyYXBWaWV3QW5kVGVtcGxhdGUoQmxhemUuY3VycmVudFZpZXcsIGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgdmFyIGNvbXBvbmVudDtcbiAgICAgICAgICAgIGNvbXBvbmVudCA9IG5ldyBjb21wb25lbnRDbGFzcygpO1xuICAgICAgICAgICAgcmV0dXJuIGNvbXBvbmVudC5yZW5kZXJDb21wb25lbnQocGFyZW50Q29tcG9uZW50KTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgdmFyIGN1cnJlbnRXaXRoLCBub25yZWFjdGl2ZUFyZ3VtZW50cywgcmVhY3RpdmVBcmd1bWVudHM7XG4gICAgICAgICAgYXNzZXJ0KFRyYWNrZXIuYWN0aXZlKTtcbiAgICAgICAgICBjdXJyZW50V2l0aCA9IEJsYXplLmdldFZpZXcoJ3dpdGgnKTtcbiAgICAgICAgICByZWFjdGl2ZUFyZ3VtZW50cyA9IG5ldyBDb21wdXRlZEZpZWxkKGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgZGF0YSA9IGN1cnJlbnRXaXRoLmRhdGFWYXIuZ2V0KCk7XG4gICAgICAgICAgICBhc3NlcnQuZXF1YWwoZGF0YSAhPSBudWxsID8gZGF0YS5jb25zdHJ1Y3RvciA6IHZvaWQgMCwgYXJndW1lbnRzQ29uc3RydWN0b3IpO1xuICAgICAgICAgICAgcmV0dXJuIGRhdGEuX2FyZ3VtZW50cztcbiAgICAgICAgICB9LCBFSlNPTi5lcXVhbHMpO1xuICAgICAgICAgIG5vbnJlYWN0aXZlQXJndW1lbnRzID0gcmVhY3RpdmVBcmd1bWVudHMoKTtcbiAgICAgICAgICByZXR1cm4gVHJhY2tlci5ub25yZWFjdGl2ZShmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHZhciB0ZW1wbGF0ZTtcbiAgICAgICAgICAgIHRlbXBsYXRlID0gQmxhemUuX3dpdGhDdXJyZW50VmlldyhCbGF6ZS5jdXJyZW50Vmlldy5wYXJlbnRWaWV3LnBhcmVudFZpZXcsIChmdW5jdGlvbihfdGhpcykge1xuICAgICAgICAgICAgICByZXR1cm4gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHdyYXBWaWV3QW5kVGVtcGxhdGUoQmxhemUuY3VycmVudFZpZXcsIGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgICAgdmFyIGNvbXBvbmVudDtcbiAgICAgICAgICAgICAgICAgIGNvbXBvbmVudCA9IChmdW5jdGlvbihmdW5jLCBhcmdzLCBjdG9yKSB7XG4gICAgICAgICAgICAgICAgICAgIGN0b3IucHJvdG90eXBlID0gZnVuYy5wcm90b3R5cGU7XG4gICAgICAgICAgICAgICAgICAgIHZhciBjaGlsZCA9IG5ldyBjdG9yLCByZXN1bHQgPSBmdW5jLmFwcGx5KGNoaWxkLCBhcmdzKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIE9iamVjdChyZXN1bHQpID09PSByZXN1bHQgPyByZXN1bHQgOiBjaGlsZDtcbiAgICAgICAgICAgICAgICAgIH0pKGNvbXBvbmVudENsYXNzLCBub25yZWFjdGl2ZUFyZ3VtZW50cywgZnVuY3Rpb24oKXt9KTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBjb21wb25lbnQucmVuZGVyQ29tcG9uZW50KHBhcmVudENvbXBvbmVudCk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9KSh0aGlzKSk7XG4gICAgICAgICAgICByZWdpc3RlckZpcnN0Q3JlYXRlZEhvb2sodGVtcGxhdGUsIGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICB0aGlzLnZpZXcub3JpZ2luYWxQYXJlbnRWaWV3ID0gdGhpcy52aWV3LnBhcmVudFZpZXc7XG4gICAgICAgICAgICAgIHJldHVybiB0aGlzLnZpZXcucGFyZW50VmlldyA9IHRoaXMudmlldy5wYXJlbnRWaWV3LnBhcmVudFZpZXcucGFyZW50VmlldztcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgcmV0dXJuIHRlbXBsYXRlO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9O1xuICAgICAgfTtcbiAgICB9KSh0aGlzKSk7XG4gIH07XG5cbiAgQmxhemVDb21wb25lbnQucHJvdG90eXBlLnJlbmRlckNvbXBvbmVudCA9IGZ1bmN0aW9uKHBhcmVudENvbXBvbmVudCkge1xuICAgIHJldHVybiBUcmFja2VyLm5vbnJlYWN0aXZlKChmdW5jdGlvbihfdGhpcykge1xuICAgICAgcmV0dXJuIGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgY29tcG9uZW50LCB0ZW1wbGF0ZSwgdGVtcGxhdGVCYXNlO1xuICAgICAgICBjb21wb25lbnQgPSBfdGhpcy5jb21wb25lbnQoKTtcbiAgICAgICAgY29tcG9uZW50LmNyZWF0ZU1peGlucygpO1xuICAgICAgICB0ZW1wbGF0ZUJhc2UgPSBnZXRUZW1wbGF0ZUJhc2UoY29tcG9uZW50KTtcbiAgICAgICAgdGVtcGxhdGUgPSBuZXcgQmxhemUuVGVtcGxhdGUoXCJCbGF6ZUNvbXBvbmVudC5cIiArIChjb21wb25lbnQuY29tcG9uZW50TmFtZSgpIHx8ICd1bm5hbWVkJyksIHRlbXBsYXRlQmFzZS5yZW5kZXJGdW5jdGlvbik7XG4gICAgICAgIGlmIChjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscyA9PSBudWxsKSB7XG4gICAgICAgICAgY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMgPSB7fTtcbiAgICAgICAgfVxuICAgICAgICBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscy50ZW1wbGF0ZUJhc2UgPSB0ZW1wbGF0ZUJhc2U7XG4gICAgICAgIHJlZ2lzdGVySG9va3ModGVtcGxhdGUsIHtcbiAgICAgICAgICBvbkNyZWF0ZWQ6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgdmFyIGJhc2UsIGJhc2UxLCBiYXNlMiwgYmFzZTMsIGNvbXBvbmVudE9yTWl4aW4sIHJlc3VsdHM7XG4gICAgICAgICAgICBpZiAocGFyZW50Q29tcG9uZW50KSB7XG4gICAgICAgICAgICAgIFRyYWNrZXIubm9ucmVhY3RpdmUoKGZ1bmN0aW9uKF90aGlzKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgICAgdmFyIHJlZjtcbiAgICAgICAgICAgICAgICAgIGFzc2VydCghY29tcG9uZW50LnBhcmVudENvbXBvbmVudCgpLCBcIkNvbXBvbmVudCAnXCIgKyAoY29tcG9uZW50LmNvbXBvbmVudE5hbWUoKSB8fCAndW5uYW1lZCcpICsgXCInIHBhcmVudCBjb21wb25lbnQgJ1wiICsgKCgocmVmID0gY29tcG9uZW50LnBhcmVudENvbXBvbmVudCgpKSAhPSBudWxsID8gcmVmLmNvbXBvbmVudE5hbWUoKSA6IHZvaWQgMCkgfHwgJ3VubmFtZWQnKSArIFwiJyBhbHJlYWR5IHNldC5cIik7XG4gICAgICAgICAgICAgICAgICBjb21wb25lbnQucGFyZW50Q29tcG9uZW50KHBhcmVudENvbXBvbmVudCk7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gcGFyZW50Q29tcG9uZW50LmFkZENoaWxkQ29tcG9uZW50KGNvbXBvbmVudCk7XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgfSkodGhpcykpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy52aWV3Ll9vblZpZXdSZW5kZXJlZCgoZnVuY3Rpb24oX3RoaXMpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgIHZhciBjb21wb25lbnRPck1peGluLCByZXN1bHRzO1xuICAgICAgICAgICAgICAgIGlmIChfdGhpcy52aWV3LnJlbmRlckNvdW50ICE9PSAxKSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbXBvbmVudE9yTWl4aW4gPSBudWxsO1xuICAgICAgICAgICAgICAgIHJlc3VsdHMgPSBbXTtcbiAgICAgICAgICAgICAgICB3aGlsZSAoY29tcG9uZW50T3JNaXhpbiA9IF90aGlzLmNvbXBvbmVudC5nZXRGaXJzdFdpdGgoY29tcG9uZW50T3JNaXhpbiwgJ2V2ZW50cycpKSB7XG4gICAgICAgICAgICAgICAgICByZXN1bHRzLnB1c2goYWRkRXZlbnRzKF90aGlzLnZpZXcsIGNvbXBvbmVudE9yTWl4aW4pKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdHM7XG4gICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9KSh0aGlzKSk7XG4gICAgICAgICAgICB0aGlzLmNvbXBvbmVudCA9IGNvbXBvbmVudDtcbiAgICAgICAgICAgIGFzc2VydCghVHJhY2tlci5ub25yZWFjdGl2ZSgoZnVuY3Rpb24oX3RoaXMpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgIHZhciBiYXNlO1xuICAgICAgICAgICAgICAgIHJldHVybiB0eXBlb2YgKGJhc2UgPSBfdGhpcy5jb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscykudGVtcGxhdGVJbnN0YW5jZSA9PT0gXCJmdW5jdGlvblwiID8gYmFzZS50ZW1wbGF0ZUluc3RhbmNlKCkgOiB2b2lkIDA7XG4gICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9KSh0aGlzKSkpO1xuICAgICAgICAgICAgaWYgKChiYXNlID0gdGhpcy5jb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscykudGVtcGxhdGVJbnN0YW5jZSA9PSBudWxsKSB7XG4gICAgICAgICAgICAgIGJhc2UudGVtcGxhdGVJbnN0YW5jZSA9IG5ldyBSZWFjdGl2ZUZpZWxkKHRoaXMsIGZ1bmN0aW9uKGEsIGIpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gYSA9PT0gYjtcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLmNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLnRlbXBsYXRlSW5zdGFuY2UodGhpcyk7XG4gICAgICAgICAgICBpZiAoKGJhc2UxID0gdGhpcy5jb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscykuaXNDcmVhdGVkID09IG51bGwpIHtcbiAgICAgICAgICAgICAgYmFzZTEuaXNDcmVhdGVkID0gbmV3IFJlYWN0aXZlRmllbGQodHJ1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLmNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLmlzQ3JlYXRlZCh0cnVlKTtcbiAgICAgICAgICAgIGlmICgoYmFzZTIgPSB0aGlzLmNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzKS5pc1JlbmRlcmVkID09IG51bGwpIHtcbiAgICAgICAgICAgICAgYmFzZTIuaXNSZW5kZXJlZCA9IG5ldyBSZWFjdGl2ZUZpZWxkKGZhbHNlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMuaXNSZW5kZXJlZChmYWxzZSk7XG4gICAgICAgICAgICBpZiAoKGJhc2UzID0gdGhpcy5jb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscykuaXNEZXN0cm95ZWQgPT0gbnVsbCkge1xuICAgICAgICAgICAgICBiYXNlMy5pc0Rlc3Ryb3llZCA9IG5ldyBSZWFjdGl2ZUZpZWxkKGZhbHNlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMuaXNEZXN0cm95ZWQoZmFsc2UpO1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgdGhpcy5jb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscy5pbk9uQ3JlYXRlZCA9IHRydWU7XG4gICAgICAgICAgICAgIGNvbXBvbmVudE9yTWl4aW4gPSBudWxsO1xuICAgICAgICAgICAgICByZXN1bHRzID0gW107XG4gICAgICAgICAgICAgIHdoaWxlIChjb21wb25lbnRPck1peGluID0gdGhpcy5jb21wb25lbnQuZ2V0Rmlyc3RXaXRoKGNvbXBvbmVudE9yTWl4aW4sICdvbkNyZWF0ZWQnKSkge1xuICAgICAgICAgICAgICAgIHJlc3VsdHMucHVzaChjb21wb25lbnRPck1peGluLm9uQ3JlYXRlZCgpKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICByZXR1cm4gcmVzdWx0cztcbiAgICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICAgIGRlbGV0ZSB0aGlzLmNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLmluT25DcmVhdGVkO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgICAgb25SZW5kZXJlZDogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICB2YXIgYmFzZSwgY29tcG9uZW50T3JNaXhpbiwgcmVzdWx0cztcbiAgICAgICAgICAgIGlmICgoYmFzZSA9IHRoaXMuY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMpLmlzUmVuZGVyZWQgPT0gbnVsbCkge1xuICAgICAgICAgICAgICBiYXNlLmlzUmVuZGVyZWQgPSBuZXcgUmVhY3RpdmVGaWVsZCh0cnVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMuaXNSZW5kZXJlZCh0cnVlKTtcbiAgICAgICAgICAgIFRyYWNrZXIubm9ucmVhY3RpdmUoKGZ1bmN0aW9uKF90aGlzKSB7XG4gICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gYXNzZXJ0LmVxdWFsKF90aGlzLmNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLmlzQ3JlYXRlZCgpLCB0cnVlKTtcbiAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH0pKHRoaXMpKTtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgIHRoaXMuY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMuaW5PblJlbmRlcmVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgY29tcG9uZW50T3JNaXhpbiA9IG51bGw7XG4gICAgICAgICAgICAgIHJlc3VsdHMgPSBbXTtcbiAgICAgICAgICAgICAgd2hpbGUgKGNvbXBvbmVudE9yTWl4aW4gPSB0aGlzLmNvbXBvbmVudC5nZXRGaXJzdFdpdGgoY29tcG9uZW50T3JNaXhpbiwgJ29uUmVuZGVyZWQnKSkge1xuICAgICAgICAgICAgICAgIHJlc3VsdHMucHVzaChjb21wb25lbnRPck1peGluLm9uUmVuZGVyZWQoKSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdHM7XG4gICAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgICBkZWxldGUgdGhpcy5jb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscy5pbk9uUmVuZGVyZWQ7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSxcbiAgICAgICAgICBvbkRlc3Ryb3llZDogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5hdXRvcnVuKChmdW5jdGlvbihfdGhpcykge1xuICAgICAgICAgICAgICByZXR1cm4gZnVuY3Rpb24oY29tcHV0YXRpb24pIHtcbiAgICAgICAgICAgICAgICBpZiAoX3RoaXMuY29tcG9uZW50LmNoaWxkQ29tcG9uZW50cygpLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb21wdXRhdGlvbi5zdG9wKCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFRyYWNrZXIubm9ucmVhY3RpdmUoZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgICB2YXIgYmFzZSwgYmFzZTEsIGNvbXBvbmVudE9yTWl4aW47XG4gICAgICAgICAgICAgICAgICBhc3NlcnQuZXF1YWwoX3RoaXMuY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMuaXNDcmVhdGVkKCksIHRydWUpO1xuICAgICAgICAgICAgICAgICAgX3RoaXMuY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMuaXNDcmVhdGVkKGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgIGlmICgoYmFzZSA9IF90aGlzLmNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzKS5pc1JlbmRlcmVkID09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgYmFzZS5pc1JlbmRlcmVkID0gbmV3IFJlYWN0aXZlRmllbGQoZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgX3RoaXMuY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMuaXNSZW5kZXJlZChmYWxzZSk7XG4gICAgICAgICAgICAgICAgICBpZiAoKGJhc2UxID0gX3RoaXMuY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMpLmlzRGVzdHJveWVkID09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgYmFzZTEuaXNEZXN0cm95ZWQgPSBuZXcgUmVhY3RpdmVGaWVsZCh0cnVlKTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIF90aGlzLmNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLmlzRGVzdHJveWVkKHRydWUpO1xuICAgICAgICAgICAgICAgICAgY29tcG9uZW50T3JNaXhpbiA9IG51bGw7XG4gICAgICAgICAgICAgICAgICB3aGlsZSAoY29tcG9uZW50T3JNaXhpbiA9IF90aGlzLmNvbXBvbmVudC5nZXRGaXJzdFdpdGgoY29tcG9uZW50T3JNaXhpbiwgJ29uRGVzdHJveWVkJykpIHtcbiAgICAgICAgICAgICAgICAgICAgY29tcG9uZW50T3JNaXhpbi5vbkRlc3Ryb3llZCgpO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgaWYgKHBhcmVudENvbXBvbmVudCkge1xuICAgICAgICAgICAgICAgICAgICBjb21wb25lbnQucGFyZW50Q29tcG9uZW50KG51bGwpO1xuICAgICAgICAgICAgICAgICAgICBwYXJlbnRDb21wb25lbnQucmVtb3ZlQ2hpbGRDb21wb25lbnQoY29tcG9uZW50KTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIHJldHVybiBfdGhpcy5jb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscy50ZW1wbGF0ZUluc3RhbmNlKG51bGwpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfSkodGhpcykpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB0ZW1wbGF0ZTtcbiAgICAgIH07XG4gICAgfSkodGhpcykpO1xuICB9O1xuXG4gIEJsYXplQ29tcG9uZW50LnByb3RvdHlwZS5yZW1vdmVDb21wb25lbnQgPSBmdW5jdGlvbigpIHtcbiAgICBpZiAodGhpcy5pc1JlbmRlcmVkKCkpIHtcbiAgICAgIHJldHVybiBCbGF6ZS5yZW1vdmUodGhpcy5jb21wb25lbnQoKS5fY29tcG9uZW50SW50ZXJuYWxzLnRlbXBsYXRlSW5zdGFuY2UoKS52aWV3KTtcbiAgICB9XG4gIH07XG5cbiAgQmxhemVDb21wb25lbnQuX3JlbmRlckNvbXBvbmVudFRvID0gZnVuY3Rpb24odmlzaXRvciwgcGFyZW50Q29tcG9uZW50LCBwYXJlbnRWaWV3LCBkYXRhKSB7XG4gICAgdmFyIGNvbXBvbmVudDtcbiAgICBjb21wb25lbnQgPSBUcmFja2VyLm5vbnJlYWN0aXZlKChmdW5jdGlvbihfdGhpcykge1xuICAgICAgcmV0dXJuIGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgY29tcG9uZW50Q2xhc3M7XG4gICAgICAgIGNvbXBvbmVudENsYXNzID0gX3RoaXM7XG4gICAgICAgIHBhcmVudFZpZXcgPSBwYXJlbnRWaWV3IHx8IGN1cnJlbnRWaWV3SWZSZW5kZXJpbmcoKSB8fCAoKHBhcmVudENvbXBvbmVudCAhPSBudWxsID8gcGFyZW50Q29tcG9uZW50LmlzUmVuZGVyZWQoKSA6IHZvaWQgMCkgJiYgcGFyZW50Q29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMudGVtcGxhdGVJbnN0YW5jZSgpLnZpZXcpIHx8IG51bGw7XG4gICAgICAgIHJldHVybiB3cmFwVmlld0FuZFRlbXBsYXRlKHBhcmVudFZpZXcsIGZ1bmN0aW9uKCkge1xuICAgICAgICAgIHJldHVybiBuZXcgY29tcG9uZW50Q2xhc3MoKTtcbiAgICAgICAgfSk7XG4gICAgICB9O1xuICAgIH0pKHRoaXMpKTtcbiAgICBpZiAoYXJndW1lbnRzLmxlbmd0aCA+IDIpIHtcbiAgICAgIHJldHVybiBjb21wb25lbnQuX3JlbmRlckNvbXBvbmVudFRvKHZpc2l0b3IsIHBhcmVudENvbXBvbmVudCwgcGFyZW50VmlldywgZGF0YSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBjb21wb25lbnQuX3JlbmRlckNvbXBvbmVudFRvKHZpc2l0b3IsIHBhcmVudENvbXBvbmVudCwgcGFyZW50Vmlldyk7XG4gICAgfVxuICB9O1xuXG4gIEJsYXplQ29tcG9uZW50LnJlbmRlckNvbXBvbmVudFRvSFRNTCA9IGZ1bmN0aW9uKHBhcmVudENvbXBvbmVudCwgcGFyZW50VmlldywgZGF0YSkge1xuICAgIGlmIChhcmd1bWVudHMubGVuZ3RoID4gMikge1xuICAgICAgcmV0dXJuIHRoaXMuX3JlbmRlckNvbXBvbmVudFRvKG5ldyBIVE1MLlRvSFRNTFZpc2l0b3IoKSwgcGFyZW50Q29tcG9uZW50LCBwYXJlbnRWaWV3LCBkYXRhKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIHRoaXMuX3JlbmRlckNvbXBvbmVudFRvKG5ldyBIVE1MLlRvSFRNTFZpc2l0b3IoKSwgcGFyZW50Q29tcG9uZW50LCBwYXJlbnRWaWV3KTtcbiAgICB9XG4gIH07XG5cbiAgQmxhemVDb21wb25lbnQucHJvdG90eXBlLl9yZW5kZXJDb21wb25lbnRUbyA9IGZ1bmN0aW9uKHZpc2l0b3IsIHBhcmVudENvbXBvbmVudCwgcGFyZW50VmlldywgZGF0YSkge1xuICAgIHZhciBleHBhbmRlZFZpZXcsIHRlbXBsYXRlO1xuICAgIHRlbXBsYXRlID0gVHJhY2tlci5ub25yZWFjdGl2ZSgoZnVuY3Rpb24oX3RoaXMpIHtcbiAgICAgIHJldHVybiBmdW5jdGlvbigpIHtcbiAgICAgICAgcGFyZW50VmlldyA9IHBhcmVudFZpZXcgfHwgY3VycmVudFZpZXdJZlJlbmRlcmluZygpIHx8ICgocGFyZW50Q29tcG9uZW50ICE9IG51bGwgPyBwYXJlbnRDb21wb25lbnQuaXNSZW5kZXJlZCgpIDogdm9pZCAwKSAmJiBwYXJlbnRDb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscy50ZW1wbGF0ZUluc3RhbmNlKCkudmlldykgfHwgbnVsbDtcbiAgICAgICAgcmV0dXJuIHdyYXBWaWV3QW5kVGVtcGxhdGUocGFyZW50VmlldywgZnVuY3Rpb24oKSB7XG4gICAgICAgICAgcmV0dXJuIF90aGlzLmNvbXBvbmVudCgpLnJlbmRlckNvbXBvbmVudChwYXJlbnRDb21wb25lbnQpO1xuICAgICAgICB9KTtcbiAgICAgIH07XG4gICAgfSkodGhpcykpO1xuICAgIGlmIChhcmd1bWVudHMubGVuZ3RoID4gMikge1xuICAgICAgZXhwYW5kZWRWaWV3ID0gZXhwYW5kVmlldyhCbGF6ZS5fVGVtcGxhdGVXaXRoKGRhdGEsIGNvbnRlbnRBc0Z1bmModGVtcGxhdGUpKSwgcGFyZW50Vmlldyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGV4cGFuZGVkVmlldyA9IGV4cGFuZFZpZXcoY29udGVudEFzVmlldyh0ZW1wbGF0ZSksIHBhcmVudFZpZXcpO1xuICAgIH1cbiAgICByZXR1cm4gdmlzaXRvci52aXNpdChleHBhbmRlZFZpZXcpO1xuICB9O1xuXG4gIEJsYXplQ29tcG9uZW50LnByb3RvdHlwZS5yZW5kZXJDb21wb25lbnRUb0hUTUwgPSBmdW5jdGlvbihwYXJlbnRDb21wb25lbnQsIHBhcmVudFZpZXcsIGRhdGEpIHtcbiAgICBpZiAoYXJndW1lbnRzLmxlbmd0aCA+IDIpIHtcbiAgICAgIHJldHVybiB0aGlzLl9yZW5kZXJDb21wb25lbnRUbyhuZXcgSFRNTC5Ub0hUTUxWaXNpdG9yKCksIHBhcmVudENvbXBvbmVudCwgcGFyZW50VmlldywgZGF0YSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiB0aGlzLl9yZW5kZXJDb21wb25lbnRUbyhuZXcgSFRNTC5Ub0hUTUxWaXNpdG9yKCksIHBhcmVudENvbXBvbmVudCwgcGFyZW50Vmlldyk7XG4gICAgfVxuICB9O1xuXG4gIEJsYXplQ29tcG9uZW50LnByb3RvdHlwZS50ZW1wbGF0ZSA9IGZ1bmN0aW9uKCkge1xuICAgIHJldHVybiB0aGlzLmNhbGxGaXJzdFdpdGgodGhpcywgJ3RlbXBsYXRlJykgfHwgdGhpcy5jb25zdHJ1Y3Rvci5jb21wb25lbnROYW1lKCk7XG4gIH07XG5cbiAgQmxhemVDb21wb25lbnQucHJvdG90eXBlLm9uQ3JlYXRlZCA9IGZ1bmN0aW9uKCkge1xuICAgIHJldHVybiBjYWxsVGVtcGxhdGVCYXNlSG9va3ModGhpcywgJ2NyZWF0ZWQnKTtcbiAgfTtcblxuICBCbGF6ZUNvbXBvbmVudC5wcm90b3R5cGUub25SZW5kZXJlZCA9IGZ1bmN0aW9uKCkge1xuICAgIHJldHVybiBjYWxsVGVtcGxhdGVCYXNlSG9va3ModGhpcywgJ3JlbmRlcmVkJyk7XG4gIH07XG5cbiAgQmxhemVDb21wb25lbnQucHJvdG90eXBlLm9uRGVzdHJveWVkID0gZnVuY3Rpb24oKSB7XG4gICAgcmV0dXJuIGNhbGxUZW1wbGF0ZUJhc2VIb29rcyh0aGlzLCAnZGVzdHJveWVkJyk7XG4gIH07XG5cbiAgQmxhemVDb21wb25lbnQucHJvdG90eXBlLmlzQ3JlYXRlZCA9IGZ1bmN0aW9uKCkge1xuICAgIHZhciBiYXNlLCBjb21wb25lbnQ7XG4gICAgY29tcG9uZW50ID0gdGhpcy5jb21wb25lbnQoKTtcbiAgICBpZiAoY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMgPT0gbnVsbCkge1xuICAgICAgY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMgPSB7fTtcbiAgICB9XG4gICAgaWYgKChiYXNlID0gY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMpLmlzQ3JlYXRlZCA9PSBudWxsKSB7XG4gICAgICBiYXNlLmlzQ3JlYXRlZCA9IG5ldyBSZWFjdGl2ZUZpZWxkKGZhbHNlKTtcbiAgICB9XG4gICAgcmV0dXJuIGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLmlzQ3JlYXRlZCgpO1xuICB9O1xuXG4gIEJsYXplQ29tcG9uZW50LnByb3RvdHlwZS5pc1JlbmRlcmVkID0gZnVuY3Rpb24oKSB7XG4gICAgdmFyIGJhc2UsIGNvbXBvbmVudDtcbiAgICBjb21wb25lbnQgPSB0aGlzLmNvbXBvbmVudCgpO1xuICAgIGlmIChjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscyA9PSBudWxsKSB7XG4gICAgICBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscyA9IHt9O1xuICAgIH1cbiAgICBpZiAoKGJhc2UgPSBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscykuaXNSZW5kZXJlZCA9PSBudWxsKSB7XG4gICAgICBiYXNlLmlzUmVuZGVyZWQgPSBuZXcgUmVhY3RpdmVGaWVsZChmYWxzZSk7XG4gICAgfVxuICAgIHJldHVybiBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscy5pc1JlbmRlcmVkKCk7XG4gIH07XG5cbiAgQmxhemVDb21wb25lbnQucHJvdG90eXBlLmlzRGVzdHJveWVkID0gZnVuY3Rpb24oKSB7XG4gICAgdmFyIGJhc2UsIGNvbXBvbmVudDtcbiAgICBjb21wb25lbnQgPSB0aGlzLmNvbXBvbmVudCgpO1xuICAgIGlmIChjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscyA9PSBudWxsKSB7XG4gICAgICBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscyA9IHt9O1xuICAgIH1cbiAgICBpZiAoKGJhc2UgPSBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscykuaXNEZXN0cm95ZWQgPT0gbnVsbCkge1xuICAgICAgYmFzZS5pc0Rlc3Ryb3llZCA9IG5ldyBSZWFjdGl2ZUZpZWxkKGZhbHNlKTtcbiAgICB9XG4gICAgcmV0dXJuIGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzLmlzRGVzdHJveWVkKCk7XG4gIH07XG5cbiAgQmxhemVDb21wb25lbnQucHJvdG90eXBlLmluc2VydERPTUVsZW1lbnQgPSBmdW5jdGlvbihwYXJlbnQsIG5vZGUsIGJlZm9yZSkge1xuICAgIGlmIChiZWZvcmUgPT0gbnVsbCkge1xuICAgICAgYmVmb3JlID0gbnVsbDtcbiAgICB9XG4gICAgaWYgKHBhcmVudCAmJiBub2RlICYmIChub2RlLnBhcmVudE5vZGUgIT09IHBhcmVudCB8fCBub2RlLm5leHRTaWJsaW5nICE9PSBiZWZvcmUpKSB7XG4gICAgICBwYXJlbnQuaW5zZXJ0QmVmb3JlKG5vZGUsIGJlZm9yZSk7XG4gICAgfVxuICB9O1xuXG4gIEJsYXplQ29tcG9uZW50LnByb3RvdHlwZS5tb3ZlRE9NRWxlbWVudCA9IGZ1bmN0aW9uKHBhcmVudCwgbm9kZSwgYmVmb3JlKSB7XG4gICAgaWYgKGJlZm9yZSA9PSBudWxsKSB7XG4gICAgICBiZWZvcmUgPSBudWxsO1xuICAgIH1cbiAgICBpZiAocGFyZW50ICYmIG5vZGUgJiYgKG5vZGUucGFyZW50Tm9kZSAhPT0gcGFyZW50IHx8IG5vZGUubmV4dFNpYmxpbmcgIT09IGJlZm9yZSkpIHtcbiAgICAgIHBhcmVudC5pbnNlcnRCZWZvcmUobm9kZSwgYmVmb3JlKTtcbiAgICB9XG4gIH07XG5cbiAgQmxhemVDb21wb25lbnQucHJvdG90eXBlLnJlbW92ZURPTUVsZW1lbnQgPSBmdW5jdGlvbihwYXJlbnQsIG5vZGUpIHtcbiAgICBpZiAocGFyZW50ICYmIG5vZGUgJiYgbm9kZS5wYXJlbnROb2RlID09PSBwYXJlbnQpIHtcbiAgICAgIHBhcmVudC5yZW1vdmVDaGlsZChub2RlKTtcbiAgICB9XG4gIH07XG5cbiAgQmxhemVDb21wb25lbnQucHJvdG90eXBlLmV2ZW50cyA9IGZ1bmN0aW9uKCkge1xuICAgIHZhciBldmVudE1hcCwgZXZlbnRzLCBmbiwgaGFuZGxlciwgaSwgbGVuLCByZWYsIHJlc3VsdHMsIHNwZWMsIHRlbXBsYXRlSW5zdGFuY2UsIHZpZXc7XG4gICAgaWYgKHRoaXMgIT09IHRoaXMuY29tcG9uZW50KCkpIHtcbiAgICAgIHJldHVybiBbXTtcbiAgICB9XG4gICAgaWYgKHRoaXMuX2NvbXBvbmVudEludGVybmFscyA9PSBudWxsKSB7XG4gICAgICB0aGlzLl9jb21wb25lbnRJbnRlcm5hbHMgPSB7fTtcbiAgICB9XG4gICAgdmlldyA9IFRyYWNrZXIubm9ucmVhY3RpdmUoKGZ1bmN0aW9uKF90aGlzKSB7XG4gICAgICByZXR1cm4gZnVuY3Rpb24oKSB7XG4gICAgICAgIHJldHVybiBfdGhpcy5fY29tcG9uZW50SW50ZXJuYWxzLnRlbXBsYXRlSW5zdGFuY2UoKS52aWV3O1xuICAgICAgfTtcbiAgICB9KSh0aGlzKSk7XG4gICAgdGVtcGxhdGVJbnN0YW5jZSA9IGdldFRlbXBsYXRlSW5zdGFuY2VGdW5jdGlvbih2aWV3LCB0cnVlKTtcbiAgICByZWYgPSB0aGlzLl9jb21wb25lbnRJbnRlcm5hbHMudGVtcGxhdGVCYXNlLl9fZXZlbnRNYXBzO1xuICAgIHJlc3VsdHMgPSBbXTtcbiAgICBmb3IgKGkgPSAwLCBsZW4gPSByZWYubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgIGV2ZW50cyA9IHJlZltpXTtcbiAgICAgIGV2ZW50TWFwID0ge307XG4gICAgICBmbiA9IGZ1bmN0aW9uKHNwZWMsIGhhbmRsZXIpIHtcbiAgICAgICAgcmV0dXJuIGV2ZW50TWFwW3NwZWNdID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgdmFyIGFyZ3M7XG4gICAgICAgICAgYXJncyA9IDEgPD0gYXJndW1lbnRzLmxlbmd0aCA/IHNsaWNlLmNhbGwoYXJndW1lbnRzLCAwKSA6IFtdO1xuICAgICAgICAgIHJldHVybiB3aXRoVGVtcGxhdGVJbnN0YW5jZUZ1bmModGVtcGxhdGVJbnN0YW5jZSwgZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICByZXR1cm4gQmxhemUuX3dpdGhDdXJyZW50Vmlldyh2aWV3LCBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGhhbmRsZXIuYXBwbHkodmlldywgYXJncyk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfTtcbiAgICAgIH07XG4gICAgICBmb3IgKHNwZWMgaW4gZXZlbnRzKSB7XG4gICAgICAgIGhhbmRsZXIgPSBldmVudHNbc3BlY107XG4gICAgICAgIGZuKHNwZWMsIGhhbmRsZXIpO1xuICAgICAgfVxuICAgICAgcmVzdWx0cy5wdXNoKGV2ZW50TWFwKTtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdHM7XG4gIH07XG5cbiAgQmxhemVDb21wb25lbnQucHJvdG90eXBlLmRhdGEgPSBmdW5jdGlvbihwYXRoLCBlcXVhbHNGdW5jKSB7XG4gICAgdmFyIGJhc2UsIGNvbXBvbmVudCwgcmVmLCB2aWV3O1xuICAgIGNvbXBvbmVudCA9IHRoaXMuY29tcG9uZW50KCk7XG4gICAgaWYgKGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzID09IG51bGwpIHtcbiAgICAgIGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzID0ge307XG4gICAgfVxuICAgIGlmICgoYmFzZSA9IGNvbXBvbmVudC5fY29tcG9uZW50SW50ZXJuYWxzKS50ZW1wbGF0ZUluc3RhbmNlID09IG51bGwpIHtcbiAgICAgIGJhc2UudGVtcGxhdGVJbnN0YW5jZSA9IG5ldyBSZWFjdGl2ZUZpZWxkKG51bGwsIGZ1bmN0aW9uKGEsIGIpIHtcbiAgICAgICAgcmV0dXJuIGEgPT09IGI7XG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKHZpZXcgPSAocmVmID0gY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMudGVtcGxhdGVJbnN0YW5jZSgpKSAhPSBudWxsID8gcmVmLnZpZXcgOiB2b2lkIDApIHtcbiAgICAgIGlmIChwYXRoICE9IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIEJsYXplLl93aXRoQ3VycmVudFZpZXcobnVsbCwgKGZ1bmN0aW9uKF90aGlzKSB7XG4gICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgcmV0dXJuIERhdGFMb29rdXAuZ2V0KGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICByZXR1cm4gQmxhemUuZ2V0RGF0YSh2aWV3KTtcbiAgICAgICAgICAgIH0sIHBhdGgsIGVxdWFsc0Z1bmMpO1xuICAgICAgICAgIH07XG4gICAgICAgIH0pKHRoaXMpKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBCbGF6ZS5nZXREYXRhKHZpZXcpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdm9pZCAwO1xuICB9O1xuXG4gIEJsYXplQ29tcG9uZW50LmN1cnJlbnREYXRhID0gZnVuY3Rpb24ocGF0aCwgZXF1YWxzRnVuYykge1xuICAgIHZhciBjdXJyZW50VmlldztcbiAgICBpZiAoIUJsYXplLmN1cnJlbnRWaWV3KSB7XG4gICAgICByZXR1cm4gdm9pZCAwO1xuICAgIH1cbiAgICBjdXJyZW50VmlldyA9IEJsYXplLmN1cnJlbnRWaWV3O1xuICAgIGlmIChfLmlzU3RyaW5nKHBhdGgpKSB7XG4gICAgICBwYXRoID0gcGF0aC5zcGxpdCgnLicpO1xuICAgIH0gZWxzZSBpZiAoIV8uaXNBcnJheShwYXRoKSkge1xuICAgICAgcmV0dXJuIEJsYXplLmdldERhdGEoY3VycmVudFZpZXcpO1xuICAgIH1cbiAgICByZXR1cm4gQmxhemUuX3dpdGhDdXJyZW50VmlldyhudWxsLCAoZnVuY3Rpb24oX3RoaXMpIHtcbiAgICAgIHJldHVybiBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIERhdGFMb29rdXAuZ2V0KGZ1bmN0aW9uKCkge1xuICAgICAgICAgIHZhciBsZXhpY2FsRGF0YSwgcmVzdWx0O1xuICAgICAgICAgIGlmIChCbGF6ZS5fbGV4aWNhbEJpbmRpbmdMb29rdXAgJiYgKGxleGljYWxEYXRhID0gQmxhemUuX2xleGljYWxCaW5kaW5nTG9va3VwKGN1cnJlbnRWaWV3LCBwYXRoWzBdKSkpIHtcbiAgICAgICAgICAgIHJlc3VsdCA9IHt9O1xuICAgICAgICAgICAgcmVzdWx0W3BhdGhbMF1dID0gbGV4aWNhbERhdGE7XG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gQmxhemUuZ2V0RGF0YShjdXJyZW50Vmlldyk7XG4gICAgICAgIH0sIHBhdGgsIGVxdWFsc0Z1bmMpO1xuICAgICAgfTtcbiAgICB9KSh0aGlzKSk7XG4gIH07XG5cbiAgQmxhemVDb21wb25lbnQucHJvdG90eXBlLmN1cnJlbnREYXRhID0gZnVuY3Rpb24ocGF0aCwgZXF1YWxzRnVuYykge1xuICAgIHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLmN1cnJlbnREYXRhKHBhdGgsIGVxdWFsc0Z1bmMpO1xuICB9O1xuXG4gIEJsYXplQ29tcG9uZW50LnByb3RvdHlwZS5jb21wb25lbnQgPSBmdW5jdGlvbigpIHtcbiAgICB2YXIgY29tcG9uZW50LCBtaXhpblBhcmVudDtcbiAgICBjb21wb25lbnQgPSB0aGlzO1xuICAgIHdoaWxlICh0cnVlKSB7XG4gICAgICBpZiAoIWNvbXBvbmVudC5taXhpblBhcmVudCkge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH1cbiAgICAgIGlmICghKG1peGluUGFyZW50ID0gY29tcG9uZW50Lm1peGluUGFyZW50KCkpKSB7XG4gICAgICAgIHJldHVybiBjb21wb25lbnQ7XG4gICAgICB9XG4gICAgICBjb21wb25lbnQgPSBtaXhpblBhcmVudDtcbiAgICB9XG4gIH07XG5cbiAgQmxhemVDb21wb25lbnQuY3VycmVudENvbXBvbmVudCA9IGZ1bmN0aW9uKCkge1xuICAgIHZhciB0ZW1wbGF0ZUluc3RhbmNlO1xuICAgIHRlbXBsYXRlSW5zdGFuY2UgPSBnZXRUZW1wbGF0ZUluc3RhbmNlRnVuY3Rpb24oQmxhemUuY3VycmVudFZpZXcsIGZhbHNlKTtcbiAgICByZXR1cm4gdGVtcGxhdGVJbnN0YW5jZVRvQ29tcG9uZW50KHRlbXBsYXRlSW5zdGFuY2UsIGZhbHNlKTtcbiAgfTtcblxuICBCbGF6ZUNvbXBvbmVudC5wcm90b3R5cGUuY3VycmVudENvbXBvbmVudCA9IGZ1bmN0aW9uKCkge1xuICAgIHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLmN1cnJlbnRDb21wb25lbnQoKTtcbiAgfTtcblxuICBCbGF6ZUNvbXBvbmVudC5wcm90b3R5cGUuZmlyc3ROb2RlID0gZnVuY3Rpb24oKSB7XG4gICAgaWYgKHRoaXMuaXNSZW5kZXJlZCgpKSB7XG4gICAgICByZXR1cm4gdGhpcy5jb21wb25lbnQoKS5fY29tcG9uZW50SW50ZXJuYWxzLnRlbXBsYXRlSW5zdGFuY2UoKS52aWV3Ll9kb21yYW5nZS5maXJzdE5vZGUoKTtcbiAgICB9XG4gICAgcmV0dXJuIHZvaWQgMDtcbiAgfTtcblxuICBCbGF6ZUNvbXBvbmVudC5wcm90b3R5cGUubGFzdE5vZGUgPSBmdW5jdGlvbigpIHtcbiAgICBpZiAodGhpcy5pc1JlbmRlcmVkKCkpIHtcbiAgICAgIHJldHVybiB0aGlzLmNvbXBvbmVudCgpLl9jb21wb25lbnRJbnRlcm5hbHMudGVtcGxhdGVJbnN0YW5jZSgpLnZpZXcuX2RvbXJhbmdlLmxhc3ROb2RlKCk7XG4gICAgfVxuICAgIHJldHVybiB2b2lkIDA7XG4gIH07XG5cbiAgQmxhemVDb21wb25lbnQucHJvdG90eXBlLmF1dG9ydW4gPSBmdW5jdGlvbihydW5GdW5jKSB7XG4gICAgdmFyIHRlbXBsYXRlSW5zdGFuY2U7XG4gICAgdGVtcGxhdGVJbnN0YW5jZSA9IFRyYWNrZXIubm9ucmVhY3RpdmUoKGZ1bmN0aW9uKF90aGlzKSB7XG4gICAgICByZXR1cm4gZnVuY3Rpb24oKSB7XG4gICAgICAgIHZhciByZWY7XG4gICAgICAgIHJldHVybiAocmVmID0gX3RoaXMuY29tcG9uZW50KCkuX2NvbXBvbmVudEludGVybmFscykgIT0gbnVsbCA/IHR5cGVvZiByZWYudGVtcGxhdGVJbnN0YW5jZSA9PT0gXCJmdW5jdGlvblwiID8gcmVmLnRlbXBsYXRlSW5zdGFuY2UoKSA6IHZvaWQgMCA6IHZvaWQgMDtcbiAgICAgIH07XG4gICAgfSkodGhpcykpO1xuICAgIGlmICghdGVtcGxhdGVJbnN0YW5jZSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVGhlIGNvbXBvbmVudCBoYXMgdG8gYmUgY3JlYXRlZCBiZWZvcmUgY2FsbGluZyAnYXV0b3J1bicuXCIpO1xuICAgIH1cbiAgICByZXR1cm4gdGVtcGxhdGVJbnN0YW5jZS5hdXRvcnVuKF8uYmluZChydW5GdW5jLCB0aGlzKSk7XG4gIH07XG5cbiAgcmV0dXJuIEJsYXplQ29tcG9uZW50O1xuXG59KShCYXNlQ29tcG9uZW50KTtcblxuU1VQUE9SVFNfUkVBQ1RJVkVfSU5TVEFOQ0UgPSBbJ3N1YnNjcmlwdGlvbnNSZWFkeSddO1xuXG5SRVFVSVJFX1JFTkRFUkVEX0lOU1RBTkNFID0gWyckJywgJ2ZpbmQnLCAnZmluZEFsbCddO1xuXG5yZWYgPSBCbGF6ZS5UZW1wbGF0ZUluc3RhbmNlLnByb3RvdHlwZTtcbmZvciAobWV0aG9kTmFtZSBpbiByZWYpIHtcbiAgbWV0aG9kID0gcmVmW21ldGhvZE5hbWVdO1xuICBpZiAoIShtZXRob2ROYW1lIGluIEJsYXplQ29tcG9uZW50LnByb3RvdHlwZSkpIHtcbiAgICAoZnVuY3Rpb24obWV0aG9kTmFtZSwgbWV0aG9kKSB7XG4gICAgICBpZiAoaW5kZXhPZi5jYWxsKFNVUFBPUlRTX1JFQUNUSVZFX0lOU1RBTkNFLCBtZXRob2ROYW1lKSA+PSAwKSB7XG4gICAgICAgIHJldHVybiBCbGF6ZUNvbXBvbmVudC5wcm90b3R5cGVbbWV0aG9kTmFtZV0gPSBmdW5jdGlvbigpIHtcbiAgICAgICAgICB2YXIgYXJncywgYmFzZSwgY29tcG9uZW50LCB0ZW1wbGF0ZUluc3RhbmNlO1xuICAgICAgICAgIGFyZ3MgPSAxIDw9IGFyZ3VtZW50cy5sZW5ndGggPyBzbGljZS5jYWxsKGFyZ3VtZW50cywgMCkgOiBbXTtcbiAgICAgICAgICBjb21wb25lbnQgPSB0aGlzLmNvbXBvbmVudCgpO1xuICAgICAgICAgIGlmIChjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscyA9PSBudWxsKSB7XG4gICAgICAgICAgICBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscyA9IHt9O1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoKGJhc2UgPSBjb21wb25lbnQuX2NvbXBvbmVudEludGVybmFscykudGVtcGxhdGVJbnN0YW5jZSA9PSBudWxsKSB7XG4gICAgICAgICAgICBiYXNlLnRlbXBsYXRlSW5zdGFuY2UgPSBuZXcgUmVhY3RpdmVGaWVsZChudWxsLCBmdW5jdGlvbihhLCBiKSB7XG4gICAgICAgICAgICAgIHJldHVybiBhID09PSBiO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICh0ZW1wbGF0ZUluc3RhbmNlID0gY29tcG9uZW50Ll9jb21wb25lbnRJbnRlcm5hbHMudGVtcGxhdGVJbnN0YW5jZSgpKSB7XG4gICAgICAgICAgICByZXR1cm4gdGVtcGxhdGVJbnN0YW5jZVttZXRob2ROYW1lXS5hcHBseSh0ZW1wbGF0ZUluc3RhbmNlLCBhcmdzKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHZvaWQgMDtcbiAgICAgICAgfTtcbiAgICAgIH0gZWxzZSBpZiAoaW5kZXhPZi5jYWxsKFJFUVVJUkVfUkVOREVSRURfSU5TVEFOQ0UsIG1ldGhvZE5hbWUpID49IDApIHtcbiAgICAgICAgcmV0dXJuIEJsYXplQ29tcG9uZW50LnByb3RvdHlwZVttZXRob2ROYW1lXSA9IGZ1bmN0aW9uKCkge1xuICAgICAgICAgIHZhciBhcmdzLCByZWYxO1xuICAgICAgICAgIGFyZ3MgPSAxIDw9IGFyZ3VtZW50cy5sZW5ndGggPyBzbGljZS5jYWxsKGFyZ3VtZW50cywgMCkgOiBbXTtcbiAgICAgICAgICBpZiAodGhpcy5pc1JlbmRlcmVkKCkpIHtcbiAgICAgICAgICAgIHJldHVybiAocmVmMSA9IHRoaXMuY29tcG9uZW50KCkuX2NvbXBvbmVudEludGVybmFscy50ZW1wbGF0ZUluc3RhbmNlKCkpW21ldGhvZE5hbWVdLmFwcGx5KHJlZjEsIGFyZ3MpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gdm9pZCAwO1xuICAgICAgICB9O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIEJsYXplQ29tcG9uZW50LnByb3RvdHlwZVttZXRob2ROYW1lXSA9IGZ1bmN0aW9uKCkge1xuICAgICAgICAgIHZhciBhcmdzLCB0ZW1wbGF0ZUluc3RhbmNlO1xuICAgICAgICAgIGFyZ3MgPSAxIDw9IGFyZ3VtZW50cy5sZW5ndGggPyBzbGljZS5jYWxsKGFyZ3VtZW50cywgMCkgOiBbXTtcbiAgICAgICAgICB0ZW1wbGF0ZUluc3RhbmNlID0gVHJhY2tlci5ub25yZWFjdGl2ZSgoZnVuY3Rpb24oX3RoaXMpIHtcbiAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgdmFyIHJlZjE7XG4gICAgICAgICAgICAgIHJldHVybiAocmVmMSA9IF90aGlzLmNvbXBvbmVudCgpLl9jb21wb25lbnRJbnRlcm5hbHMpICE9IG51bGwgPyB0eXBlb2YgcmVmMS50ZW1wbGF0ZUluc3RhbmNlID09PSBcImZ1bmN0aW9uXCIgPyByZWYxLnRlbXBsYXRlSW5zdGFuY2UoKSA6IHZvaWQgMCA6IHZvaWQgMDtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfSkodGhpcykpO1xuICAgICAgICAgIGlmICghdGVtcGxhdGVJbnN0YW5jZSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVGhlIGNvbXBvbmVudCBoYXMgdG8gYmUgY3JlYXRlZCBiZWZvcmUgY2FsbGluZyAnXCIgKyBtZXRob2ROYW1lICsgXCInLlwiKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHRlbXBsYXRlSW5zdGFuY2VbbWV0aG9kTmFtZV0uYXBwbHkodGVtcGxhdGVJbnN0YW5jZSwgYXJncyk7XG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfSkobWV0aG9kTmFtZSwgbWV0aG9kKTtcbiAgfVxufVxuIiwiY2xhc3MgQmxhemVDb21wb25lbnREZWJ1ZyBleHRlbmRzIEJhc2VDb21wb25lbnREZWJ1Z1xuICBAc3RhcnRDb21wb25lbnQ6IChjb21wb25lbnQpIC0+XG4gICAgc3VwZXJcblxuICAgIGNvbnNvbGUubG9nIGNvbXBvbmVudC5kYXRhKClcblxuICBAc3RhcnRNYXJrZWRDb21wb25lbnQ6IChjb21wb25lbnQpIC0+XG4gICAgc3VwZXJcblxuICAgIGNvbnNvbGUubG9nIGNvbXBvbmVudC5kYXRhKClcblxuICBAZHVtcENvbXBvbmVudFN1YnRyZWU6IChyb290Q29tcG9uZW50T3JFbGVtZW50KSAtPlxuICAgIGlmICdub2RlVHlwZScgb2Ygcm9vdENvbXBvbmVudE9yRWxlbWVudCBhbmQgcm9vdENvbXBvbmVudE9yRWxlbWVudC5ub2RlVHlwZSBpcyBOb2RlLkVMRU1FTlRfTk9ERVxuICAgICAgcm9vdENvbXBvbmVudE9yRWxlbWVudCA9IEJsYXplQ29tcG9uZW50LmdldENvbXBvbmVudEZvckVsZW1lbnQgcm9vdENvbXBvbmVudE9yRWxlbWVudFxuXG4gICAgc3VwZXJcblxuICBAZHVtcENvbXBvbmVudFRyZWU6IChyb290Q29tcG9uZW50T3JFbGVtZW50KSAtPlxuICAgIGlmICdub2RlVHlwZScgb2Ygcm9vdENvbXBvbmVudE9yRWxlbWVudCBhbmQgcm9vdENvbXBvbmVudE9yRWxlbWVudC5ub2RlVHlwZSBpcyBOb2RlLkVMRU1FTlRfTk9ERVxuICAgICAgcm9vdENvbXBvbmVudE9yRWxlbWVudCA9IEJsYXplQ29tcG9uZW50LmdldENvbXBvbmVudEZvckVsZW1lbnQgcm9vdENvbXBvbmVudE9yRWxlbWVudFxuXG4gICAgc3VwZXJcblxuICBAZHVtcEFsbENvbXBvbmVudHM6IC0+XG4gICAgYWxsUm9vdENvbXBvbmVudHMgPSBbXVxuXG4gICAgJCgnKicpLmVhY2ggKGksIGVsZW1lbnQpID0+XG4gICAgICBjb21wb25lbnQgPSBCbGF6ZUNvbXBvbmVudC5nZXRDb21wb25lbnRGb3JFbGVtZW50IGVsZW1lbnRcbiAgICAgIHJldHVybiB1bmxlc3MgY29tcG9uZW50XG4gICAgICByb290Q29tcG9uZW50ID0gQGNvbXBvbmVudFJvb3QgY29tcG9uZW50XG4gICAgICBhbGxSb290Q29tcG9uZW50cy5wdXNoIHJvb3RDb21wb25lbnQgdW5sZXNzIHJvb3RDb21wb25lbnQgaW4gYWxsUm9vdENvbXBvbmVudHNcblxuICAgIGZvciByb290Q29tcG9uZW50IGluIGFsbFJvb3RDb21wb25lbnRzXG4gICAgICBAZHVtcENvbXBvbmVudFN1YnRyZWUgcm9vdENvbXBvbmVudFxuXG4gICAgcmV0dXJuXG4iLCJ2YXIgICAgICAgICAgICAgICAgICAgICBcbiAgZXh0ZW5kID0gZnVuY3Rpb24oY2hpbGQsIHBhcmVudCkgeyBmb3IgKHZhciBrZXkgaW4gcGFyZW50KSB7IGlmIChoYXNQcm9wLmNhbGwocGFyZW50LCBrZXkpKSBjaGlsZFtrZXldID0gcGFyZW50W2tleV07IH0gZnVuY3Rpb24gY3RvcigpIHsgdGhpcy5jb25zdHJ1Y3RvciA9IGNoaWxkOyB9IGN0b3IucHJvdG90eXBlID0gcGFyZW50LnByb3RvdHlwZTsgY2hpbGQucHJvdG90eXBlID0gbmV3IGN0b3IoKTsgY2hpbGQuX19zdXBlcl9fID0gcGFyZW50LnByb3RvdHlwZTsgcmV0dXJuIGNoaWxkOyB9LFxuICBoYXNQcm9wID0ge30uaGFzT3duUHJvcGVydHksXG4gIGluZGV4T2YgPSBbXS5pbmRleE9mIHx8IGZ1bmN0aW9uKGl0ZW0pIHsgZm9yICh2YXIgaSA9IDAsIGwgPSB0aGlzLmxlbmd0aDsgaSA8IGw7IGkrKykgeyBpZiAoaSBpbiB0aGlzICYmIHRoaXNbaV0gPT09IGl0ZW0pIHJldHVybiBpOyB9IHJldHVybiAtMTsgfTtcblxuQmxhemVDb21wb25lbnREZWJ1ZyA9IChmdW5jdGlvbihzdXBlckNsYXNzKSB7XG4gIGV4dGVuZChCbGF6ZUNvbXBvbmVudERlYnVnLCBzdXBlckNsYXNzKTtcblxuICBmdW5jdGlvbiBCbGF6ZUNvbXBvbmVudERlYnVnKCkge1xuICAgIHJldHVybiBCbGF6ZUNvbXBvbmVudERlYnVnLl9fc3VwZXJfXy5jb25zdHJ1Y3Rvci5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICB9XG5cbiAgQmxhemVDb21wb25lbnREZWJ1Zy5zdGFydENvbXBvbmVudCA9IGZ1bmN0aW9uKGNvbXBvbmVudCkge1xuICAgIEJsYXplQ29tcG9uZW50RGVidWcuX19zdXBlcl9fLmNvbnN0cnVjdG9yLnN0YXJ0Q29tcG9uZW50LmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgcmV0dXJuIGNvbnNvbGUubG9nKGNvbXBvbmVudC5kYXRhKCkpO1xuICB9O1xuXG4gIEJsYXplQ29tcG9uZW50RGVidWcuc3RhcnRNYXJrZWRDb21wb25lbnQgPSBmdW5jdGlvbihjb21wb25lbnQpIHtcbiAgICBCbGF6ZUNvbXBvbmVudERlYnVnLl9fc3VwZXJfXy5jb25zdHJ1Y3Rvci5zdGFydE1hcmtlZENvbXBvbmVudC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgIHJldHVybiBjb25zb2xlLmxvZyhjb21wb25lbnQuZGF0YSgpKTtcbiAgfTtcblxuICBCbGF6ZUNvbXBvbmVudERlYnVnLmR1bXBDb21wb25lbnRTdWJ0cmVlID0gZnVuY3Rpb24ocm9vdENvbXBvbmVudE9yRWxlbWVudCkge1xuICAgIGlmICgnbm9kZVR5cGUnIGluIHJvb3RDb21wb25lbnRPckVsZW1lbnQgJiYgcm9vdENvbXBvbmVudE9yRWxlbWVudC5ub2RlVHlwZSA9PT0gTm9kZS5FTEVNRU5UX05PREUpIHtcbiAgICAgIHJvb3RDb21wb25lbnRPckVsZW1lbnQgPSBCbGF6ZUNvbXBvbmVudC5nZXRDb21wb25lbnRGb3JFbGVtZW50KHJvb3RDb21wb25lbnRPckVsZW1lbnQpO1xuICAgIH1cbiAgICByZXR1cm4gQmxhemVDb21wb25lbnREZWJ1Zy5fX3N1cGVyX18uY29uc3RydWN0b3IuZHVtcENvbXBvbmVudFN1YnRyZWUuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgfTtcblxuICBCbGF6ZUNvbXBvbmVudERlYnVnLmR1bXBDb21wb25lbnRUcmVlID0gZnVuY3Rpb24ocm9vdENvbXBvbmVudE9yRWxlbWVudCkge1xuICAgIGlmICgnbm9kZVR5cGUnIGluIHJvb3RDb21wb25lbnRPckVsZW1lbnQgJiYgcm9vdENvbXBvbmVudE9yRWxlbWVudC5ub2RlVHlwZSA9PT0gTm9kZS5FTEVNRU5UX05PREUpIHtcbiAgICAgIHJvb3RDb21wb25lbnRPckVsZW1lbnQgPSBCbGF6ZUNvbXBvbmVudC5nZXRDb21wb25lbnRGb3JFbGVtZW50KHJvb3RDb21wb25lbnRPckVsZW1lbnQpO1xuICAgIH1cbiAgICByZXR1cm4gQmxhemVDb21wb25lbnREZWJ1Zy5fX3N1cGVyX18uY29uc3RydWN0b3IuZHVtcENvbXBvbmVudFRyZWUuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgfTtcblxuICBCbGF6ZUNvbXBvbmVudERlYnVnLmR1bXBBbGxDb21wb25lbnRzID0gZnVuY3Rpb24oKSB7XG4gICAgdmFyIGFsbFJvb3RDb21wb25lbnRzLCBqLCBsZW4sIHJvb3RDb21wb25lbnQ7XG4gICAgYWxsUm9vdENvbXBvbmVudHMgPSBbXTtcbiAgICAkKCcqJykuZWFjaCgoZnVuY3Rpb24oX3RoaXMpIHtcbiAgICAgIHJldHVybiBmdW5jdGlvbihpLCBlbGVtZW50KSB7XG4gICAgICAgIHZhciBjb21wb25lbnQsIHJvb3RDb21wb25lbnQ7XG4gICAgICAgIGNvbXBvbmVudCA9IEJsYXplQ29tcG9uZW50LmdldENvbXBvbmVudEZvckVsZW1lbnQoZWxlbWVudCk7XG4gICAgICAgIGlmICghY29tcG9uZW50KSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHJvb3RDb21wb25lbnQgPSBfdGhpcy5jb21wb25lbnRSb290KGNvbXBvbmVudCk7XG4gICAgICAgIGlmIChpbmRleE9mLmNhbGwoYWxsUm9vdENvbXBvbmVudHMsIHJvb3RDb21wb25lbnQpIDwgMCkge1xuICAgICAgICAgIHJldHVybiBhbGxSb290Q29tcG9uZW50cy5wdXNoKHJvb3RDb21wb25lbnQpO1xuICAgICAgICB9XG4gICAgICB9O1xuICAgIH0pKHRoaXMpKTtcbiAgICBmb3IgKGogPSAwLCBsZW4gPSBhbGxSb290Q29tcG9uZW50cy5sZW5ndGg7IGogPCBsZW47IGorKykge1xuICAgICAgcm9vdENvbXBvbmVudCA9IGFsbFJvb3RDb21wb25lbnRzW2pdO1xuICAgICAgdGhpcy5kdW1wQ29tcG9uZW50U3VidHJlZShyb290Q29tcG9uZW50KTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIEJsYXplQ29tcG9uZW50RGVidWc7XG5cbn0pKEJhc2VDb21wb25lbnREZWJ1Zyk7XG4iLCIjIE5vLW9wIG9uIHRoZSBzZXJ2ZXIuXG5UZW1wbGF0ZS5ib2R5LnJlbmRlclRvRG9jdW1lbnQgPSAtPlxuIl19
