(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var ReactiveVar = Package['reactive-var'].ReactiveVar;
var _ = Package.underscore._;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var __coffeescriptShare, ComputedField;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/peerlibrary_computed-field/lib.coffee                                                               //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
ComputedField = function () {
  function ComputedField(func, equalsFunc, dontStop) {
    var autorun, currentView, getter, handle, lastValue, ref, ref1, startAutorun;

    if (_.isBoolean(equalsFunc)) {
      dontStop = equalsFunc;
      equalsFunc = null;
    }

    handle = null;
    lastValue = null;

    if (currentView = (ref = Package.blaze) != null ? (ref1 = ref.Blaze) != null ? ref1.currentView : void 0 : void 0) {
      if (currentView._isInRender) {
        autorun = function (f) {
          var comp, stopComputation, templateInstanceFunc;
          templateInstanceFunc = Package.blaze.Blaze.Template._currentTemplateInstanceFunc;
          comp = Tracker.autorun(function (c) {
            return Package.blaze.Blaze._withCurrentView(currentView, function () {
              return Package.blaze.Blaze.Template._withTemplateInstanceFunc(templateInstanceFunc, function () {
                return f.call(currentView, c);
              });
            });
          });

          stopComputation = function () {
            return comp.stop();
          };

          currentView.onViewDestroyed(stopComputation);
          comp.onStop(function () {
            return currentView.removeViewDestroyedListener(stopComputation);
          });
          return comp;
        };
      } else {
        autorun = function (f) {
          return currentView.autorun(f);
        };
      }
    } else {
      autorun = Tracker.autorun;
    }

    startAutorun = function () {
      var originalStop;
      handle = autorun(function (computation) {
        var value;
        value = func();

        if (!lastValue) {
          lastValue = new ReactiveVar(value, equalsFunc);
        } else {
          lastValue.set(value);
        }

        if (!dontStop) {
          return Tracker.afterFlush(function () {
            if (!lastValue.dep.hasDependents()) {
              return getter.stop();
            }
          });
        }
      });

      if (handle.onStop) {
        return handle.onStop(function () {
          return handle = null;
        });
      } else {
        originalStop = handle.stop;
        return handle.stop = function () {
          if (handle) {
            originalStop.call(handle);
          }

          return handle = null;
        };
      }
    };

    startAutorun();

    getter = function () {
      getter.flush();
      return lastValue.get();
    };

    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(getter, this.constructor.prototype);
    } else {
      getter.__proto__ = this.constructor.prototype;
    }

    getter.toString = function () {
      return "ComputedField{" + this() + "}";
    };

    getter.apply = function () {
      return getter();
    };

    getter.call = function () {
      return getter();
    };

    getter.stop = function () {
      if (handle != null) {
        handle.stop();
      }

      return handle = null;
    };

    getter._isRunning = function () {
      return !!handle;
    };

    getter.flush = function () {
      return Tracker.nonreactive(function () {
        if (handle) {
          return handle.flush();
        } else {
          return startAutorun();
        }
      });
    };

    return getter;
  }

  return ComputedField;
}();
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['peerlibrary:computed-field'] = {}, {
  ComputedField: ComputedField
});

})();

//# sourceURL=meteor://💻app/packages/peerlibrary_computed-field.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvcGVlcmxpYnJhcnlfY29tcHV0ZWQtZmllbGQvbGliLmNvZmZlZSIsIm1ldGVvcjovL/CfkrthcHAvbGliLmNvZmZlZSJdLCJuYW1lcyI6WyJDb21wdXRlZEZpZWxkIiwiZnVuYyIsImVxdWFsc0Z1bmMiLCJkb250U3RvcCIsImF1dG9ydW4iLCJjdXJyZW50VmlldyIsImdldHRlciIsImhhbmRsZSIsImxhc3RWYWx1ZSIsInJlZiIsInJlZjEiLCJzdGFydEF1dG9ydW4iLCJfIiwiaXNCb29sZWFuIiwiUGFja2FnZSIsImJsYXplIiwiQmxhemUiLCJfaXNJblJlbmRlciIsImYiLCJjb21wIiwic3RvcENvbXB1dGF0aW9uIiwidGVtcGxhdGVJbnN0YW5jZUZ1bmMiLCJUZW1wbGF0ZSIsIl9jdXJyZW50VGVtcGxhdGVJbnN0YW5jZUZ1bmMiLCJUcmFja2VyIiwiYyIsIl93aXRoQ3VycmVudFZpZXciLCJfd2l0aFRlbXBsYXRlSW5zdGFuY2VGdW5jIiwiY2FsbCIsInN0b3AiLCJvblZpZXdEZXN0cm95ZWQiLCJvblN0b3AiLCJyZW1vdmVWaWV3RGVzdHJveWVkTGlzdGVuZXIiLCJvcmlnaW5hbFN0b3AiLCJjb21wdXRhdGlvbiIsInZhbHVlIiwiUmVhY3RpdmVWYXIiLCJzZXQiLCJhZnRlckZsdXNoIiwiZGVwIiwiaGFzRGVwZW5kZW50cyIsImZsdXNoIiwiZ2V0IiwiT2JqZWN0Iiwic2V0UHJvdG90eXBlT2YiLCJjb25zdHJ1Y3RvciIsInByb3RvdHlwZSIsIl9fcHJvdG9fXyIsInRvU3RyaW5nIiwiYXBwbHkiLCJfaXNSdW5uaW5nIiwibm9ucmVhY3RpdmUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBTUEsZ0JBQUE7QUFDUyxXQUFBQSxhQUFBLENBQUNDLElBQUQsRUFBT0MsVUFBUCxFQUFtQkMsUUFBbkI7QUFFWCxRQUFBQyxPQUFBLEVBQUFDLFdBQUEsRUFBQUMsTUFBQSxFQUFBQyxNQUFBLEVBQUFDLFNBQUEsRUFBQUMsR0FBQSxFQUFBQyxJQUFBLEVBQUFDLFlBQUE7O0FBQUEsUUFBR0MsRUFBRUMsU0FBRixDQUFZWCxVQUFaLENBQUg7QUFDRUMsaUJBQVdELFVBQVg7QUFDQUEsbUJBQWEsSUFBYjtBQ0dEOztBRERESyxhQUFTLElBQVQ7QUFDQUMsZ0JBQVksSUFBWjs7QUFJQSxRQUFHSCxjQUFBLENBQUFJLE1BQUFLLFFBQUFDLEtBQUEsYUFBQUwsT0FBQUQsSUFBQU8sS0FBQSxZQUFBTixLQUFvQ0wsV0FBcEMsR0FBb0MsTUFBcEMsR0FBb0MsTUFBdkM7QUFDRSxVQUFHQSxZQUFZWSxXQUFmO0FBTUViLGtCQUFVLFVBQUNjLENBQUQ7QUFDUixjQUFBQyxJQUFBLEVBQUFDLGVBQUEsRUFBQUMsb0JBQUE7QUFBQUEsaUNBQXVCUCxRQUFRQyxLQUFSLENBQWNDLEtBQWQsQ0FBb0JNLFFBQXBCLENBQTZCQyw0QkFBcEQ7QUFFQUosaUJBQU9LLFFBQVFwQixPQUFSLENBQWdCLFVBQUNxQixDQUFEO0FDTHJCLG1CRE1BWCxRQUFRQyxLQUFSLENBQWNDLEtBQWQsQ0FBb0JVLGdCQUFwQixDQUFxQ3JCLFdBQXJDLEVBQWtEO0FDTGhELHFCRE1BUyxRQUFRQyxLQUFSLENBQWNDLEtBQWQsQ0FBb0JNLFFBQXBCLENBQTZCSyx5QkFBN0IsQ0FBdUROLG9CQUF2RCxFQUE2RTtBQ0wzRSx1QkRNQUgsRUFBRVUsSUFBRixDQUFPdkIsV0FBUCxFQUFvQm9CLENBQXBCLENDTkE7QURLRixnQkNOQTtBREtGLGNDTkE7QURLSyxZQUFQOztBQUtBTCw0QkFBa0I7QUNIaEIsbUJESUFELEtBQUtVLElBQUwsRUNKQTtBREdnQixXQUFsQjs7QUFFQXhCLHNCQUFZeUIsZUFBWixDQUE0QlYsZUFBNUI7QUFDQUQsZUFBS1ksTUFBTCxDQUFZO0FDRlYsbUJER0ExQixZQUFZMkIsMkJBQVosQ0FBd0NaLGVBQXhDLENDSEE7QURFRjtBQ0FBLGlCREdBRCxJQ0hBO0FEWFEsU0FBVjtBQU5GO0FBdUJFZixrQkFBVSxVQUFDYyxDQUFEO0FDRlIsaUJER0FiLFlBQVlELE9BQVosQ0FBb0JjLENBQXBCLENDSEE7QURFUSxTQUFWO0FBeEJKO0FBQUE7QUE0QkVkLGdCQUFVb0IsUUFBUXBCLE9BQWxCO0FDREQ7O0FER0RPLG1CQUFlO0FBQ2IsVUFBQXNCLFlBQUE7QUFBQTFCLGVBQVNILFFBQVEsVUFBQzhCLFdBQUQ7QUFDZixZQUFBQyxLQUFBO0FBQUFBLGdCQUFRbEMsTUFBUjs7QUFFQSxhQUFPTyxTQUFQO0FBQ0VBLHNCQUFZLElBQUk0QixXQUFKLENBQWdCRCxLQUFoQixFQUF1QmpDLFVBQXZCLENBQVo7QUFERjtBQUdFTSxvQkFBVTZCLEdBQVYsQ0FBY0YsS0FBZDtBQ0FEOztBREVELGFBQU9oQyxRQUFQO0FDQUUsaUJEQ0FxQixRQUFRYyxVQUFSLENBQW1CO0FBR2pCLGlCQUFxQjlCLFVBQVUrQixHQUFWLENBQWNDLGFBQWQsRUFBckI7QUNGRSxxQkRFRmxDLE9BQU91QixJQUFQLEVDRkU7QUFDRDtBREZILFlDREE7QUFLRDtBRGJNLFFBQVQ7O0FBa0JBLFVBQUd0QixPQUFPd0IsTUFBVjtBQ0ZFLGVER0F4QixPQUFPd0IsTUFBUCxDQUFjO0FDRlosaUJER0F4QixTQUFTLElDSFQ7QURFRixVQ0hBO0FERUY7QUFLRTBCLHVCQUFlMUIsT0FBT3NCLElBQXRCO0FDRkEsZURHQXRCLE9BQU9zQixJQUFQLEdBQWM7QUFDWixjQUE0QnRCLE1BQTVCO0FBQUEwQix5QkFBYUwsSUFBYixDQUFrQnJCLE1BQWxCO0FDREM7O0FBQ0QsaUJEQ0FBLFNBQVMsSUNEVDtBRERZLFNDSGQ7QUFNRDtBRDVCWSxLQUFmOztBQTZCQUk7O0FBRUFMLGFBQVM7QUFFUEEsYUFBT21DLEtBQVA7QUNBQSxhRENBakMsVUFBVWtDLEdBQVYsRUNEQTtBREZPLEtBQVQ7O0FBTUEsUUFBR0MsT0FBT0MsY0FBVjtBQUNFRCxhQUFPQyxjQUFQLENBQXNCdEMsTUFBdEIsRUFBOEIsS0FBQ3VDLFdBQUQsQ0FBWUMsU0FBMUM7QUFERjtBQUdFeEMsYUFBT3lDLFNBQVAsR0FBbUIsS0FBQ0YsV0FBRCxDQUFZQyxTQUEvQjtBQ0REOztBREdEeEMsV0FBTzBDLFFBQVAsR0FBa0I7QUNEaEIsYURFQSxtQkFBaUIsTUFBakIsR0FBcUIsR0NGckI7QURDZ0IsS0FBbEI7O0FBR0ExQyxXQUFPMkMsS0FBUCxHQUFlO0FDRGIsYURFQTNDLFFDRkE7QURDYSxLQUFmOztBQUdBQSxXQUFPc0IsSUFBUCxHQUFjO0FDRFosYURFQXRCLFFDRkE7QURDWSxLQUFkOztBQUtBQSxXQUFPdUIsSUFBUCxHQUFjO0FDSFosVUFBSXRCLFVBQVUsSUFBZCxFQUFvQjtBRElwQkEsZUFBUXNCLElBQVI7QUNGQzs7QUFDRCxhREVBdEIsU0FBUyxJQ0ZUO0FEQVksS0FBZDs7QUFLQUQsV0FBTzRDLFVBQVAsR0FBb0I7QUNGbEIsYURHQSxDQUFDLENBQUMzQyxNQ0hGO0FERWtCLEtBQXBCOztBQUtBRCxXQUFPbUMsS0FBUCxHQUFlO0FDSmIsYURLQWpCLFFBQVEyQixXQUFSLENBQW9CO0FBQ2xCLFlBQUc1QyxNQUFIO0FDSkUsaUJES0FBLE9BQU9rQyxLQUFQLEVDTEE7QURJRjtBQ0ZFLGlCRE9BOUIsY0NQQTtBQUNEO0FEQUgsUUNMQTtBRElhLEtBQWY7O0FBU0EsV0FBT0wsTUFBUDtBQWpIVzs7QUMrR2IsU0FBT04sYUFBUDtBQUVELENEbEhLLEciLCJmaWxlIjoiL3BhY2thZ2VzL3BlZXJsaWJyYXJ5X2NvbXB1dGVkLWZpZWxkLmpzIiwic291cmNlc0NvbnRlbnQiOlsiY2xhc3MgQ29tcHV0ZWRGaWVsZFxuICBjb25zdHJ1Y3RvcjogKGZ1bmMsIGVxdWFsc0Z1bmMsIGRvbnRTdG9wKSAtPlxuICAgICMgVG8gc3VwcG9ydCBwYXNzaW5nIGJvb2xlYW4gYXMgdGhlIHNlY29uZCBhcmd1bWVudC5cbiAgICBpZiBfLmlzQm9vbGVhbiBlcXVhbHNGdW5jXG4gICAgICBkb250U3RvcCA9IGVxdWFsc0Z1bmNcbiAgICAgIGVxdWFsc0Z1bmMgPSBudWxsXG5cbiAgICBoYW5kbGUgPSBudWxsXG4gICAgbGFzdFZhbHVlID0gbnVsbFxuXG4gICAgIyBUT0RPOiBQcm92aWRlIGFuIG9wdGlvbiB0byBwcmV2ZW50IHVzaW5nIHZpZXcncyBhdXRvcnVuLlxuICAgICMgICAgICAgT25lIGNhbiB3cmFwIGNvZGUgd2l0aCBCbGF6ZS5fd2l0aEN1cnJlbnRWaWV3KG51bGwsIGNvZGUpIHRvIHByZXZlbnQgdXNpbmcgdmlldydzIGF1dG9ydW4gZm9yIG5vdy5cbiAgICBpZiBjdXJyZW50VmlldyA9IFBhY2thZ2UuYmxhemU/LkJsYXplPy5jdXJyZW50Vmlld1xuICAgICAgaWYgY3VycmVudFZpZXcuX2lzSW5SZW5kZXJcbiAgICAgICAgIyBJbnNpZGUgcmVuZGVyIHdlIGNhbm5vdCB1c2UgY3VycmVudFZpZXcuYXV0b3J1biBkaXJlY3RseSwgc28gd2UgdXNlIG91ciBvd24gdmVyc2lvbiBvZiBpdC5cbiAgICAgICAgIyBUaGlzIGFsbG93cyBjb21wdXRlZCBmaWVsZHMgdG8gYmUgY3JlYXRlZCBpbnNpZGUgQmxhemUgdGVtcGxhdGUgaGVscGVycywgd2hpY2ggYXJlIGNhbGxlZFxuICAgICAgICAjIHRoZSBmaXJzdCB0aW1lIGluc2lkZSByZW5kZXIuIFdoaWxlIGN1cnJlbnRWaWV3LmF1dG9ydW4gaXMgZGlzYWxsb3dlZCBpbnNpZGUgcmVuZGVyIGJlY2F1c2VcbiAgICAgICAgIyBhdXRvcnVuIHdvdWxkIGJlIHJlY3JlYXRlZCBmb3IgcmVhY2ggcmUtcmVuZGVyLCB0aGlzIGlzIGV4YWN0bHkgd2hhdCBjb21wdXRlZCBmaWVsZCBkb2VzXG4gICAgICAgICMgYW55d2F5IHNvIGl0IGlzIE9LIGZvciB1c2UgdG8gdXNlIGF1dG9ydW4gaW4gdGhpcyB3YXkuXG4gICAgICAgIGF1dG9ydW4gPSAoZikgLT5cbiAgICAgICAgICB0ZW1wbGF0ZUluc3RhbmNlRnVuYyA9IFBhY2thZ2UuYmxhemUuQmxhemUuVGVtcGxhdGUuX2N1cnJlbnRUZW1wbGF0ZUluc3RhbmNlRnVuY1xuXG4gICAgICAgICAgY29tcCA9IFRyYWNrZXIuYXV0b3J1biAoYykgLT5cbiAgICAgICAgICAgIFBhY2thZ2UuYmxhemUuQmxhemUuX3dpdGhDdXJyZW50VmlldyBjdXJyZW50VmlldywgLT5cbiAgICAgICAgICAgICAgUGFja2FnZS5ibGF6ZS5CbGF6ZS5UZW1wbGF0ZS5fd2l0aFRlbXBsYXRlSW5zdGFuY2VGdW5jIHRlbXBsYXRlSW5zdGFuY2VGdW5jLCAtPlxuICAgICAgICAgICAgICAgIGYuY2FsbCBjdXJyZW50VmlldywgY1xuXG4gICAgICAgICAgc3RvcENvbXB1dGF0aW9uID0gLT5cbiAgICAgICAgICAgIGNvbXAuc3RvcCgpXG4gICAgICAgICAgY3VycmVudFZpZXcub25WaWV3RGVzdHJveWVkIHN0b3BDb21wdXRhdGlvblxuICAgICAgICAgIGNvbXAub25TdG9wIC0+XG4gICAgICAgICAgICBjdXJyZW50Vmlldy5yZW1vdmVWaWV3RGVzdHJveWVkTGlzdGVuZXIgc3RvcENvbXB1dGF0aW9uXG5cbiAgICAgICAgICBjb21wXG5cbiAgICAgIGVsc2VcbiAgICAgICAgYXV0b3J1biA9IChmKSAtPlxuICAgICAgICAgIGN1cnJlbnRWaWV3LmF1dG9ydW4gZlxuXG4gICAgZWxzZVxuICAgICAgYXV0b3J1biA9IFRyYWNrZXIuYXV0b3J1blxuXG4gICAgc3RhcnRBdXRvcnVuID0gLT5cbiAgICAgIGhhbmRsZSA9IGF1dG9ydW4gKGNvbXB1dGF0aW9uKSAtPlxuICAgICAgICB2YWx1ZSA9IGZ1bmMoKVxuXG4gICAgICAgIHVubGVzcyBsYXN0VmFsdWVcbiAgICAgICAgICBsYXN0VmFsdWUgPSBuZXcgUmVhY3RpdmVWYXIgdmFsdWUsIGVxdWFsc0Z1bmNcbiAgICAgICAgZWxzZVxuICAgICAgICAgIGxhc3RWYWx1ZS5zZXQgdmFsdWVcblxuICAgICAgICB1bmxlc3MgZG9udFN0b3BcbiAgICAgICAgICBUcmFja2VyLmFmdGVyRmx1c2ggLT5cbiAgICAgICAgICAgICMgSWYgdGhlcmUgYXJlIG5vIGRlcGVuZGVudHMgYW55bW9yZSwgc3RvcCB0aGUgYXV0b3J1bi4gV2Ugd2lsbCBydW5cbiAgICAgICAgICAgICMgaXQgYWdhaW4gaW4gdGhlIGdldHRlcidzIGZsdXNoIGNhbGwgaWYgbmVlZGVkLlxuICAgICAgICAgICAgZ2V0dGVyLnN0b3AoKSB1bmxlc3MgbGFzdFZhbHVlLmRlcC5oYXNEZXBlbmRlbnRzKClcblxuICAgICAgIyBJZiBzb21ldGhpbmcgc3RvcHMgb3VyIGF1dG9ydW4gZnJvbSB0aGUgb3V0c2lkZSwgd2Ugd2FudCB0byBrbm93IHRoYXQgYW5kIHVwZGF0ZSBpbnRlcm5hbCBzdGF0ZSBhY2NvcmRpbmdseS5cbiAgICAgICMgVGhpcyBtZWFucyB0aGF0IGlmIGNvbXB1dGVkIGZpZWxkIHdhcyBjcmVhdGVkIGluc2lkZSBhbiBhdXRvcnVuLCBhbmQgdGhhdCBhdXRvcnVuIGlzIGludmFsaWRlZCBvdXIgYXV0b3J1biBpc1xuICAgICAgIyBzdG9wcGVkLiBCdXQgdGhlbiBjb21wdXRlZCBmaWVsZCBtaWdodCBiZSBzdGlsbCBhcm91bmQgYW5kIGl0IG1pZ2h0IGJlIGFza2VkIGFnYWluIGZvciB0aGUgdmFsdWUuIFdlIHdhbnQgdG9cbiAgICAgICMgcmVzdGFydCBvdXIgYXV0b3J1biBpbiB0aGF0IGNhc2UuIEluc3RlYWQgb2YgdHJ5aW5nIHRvIHJlY29tcHV0ZSB0aGUgc3RvcHBlZCBhdXRvcnVuLlxuICAgICAgaWYgaGFuZGxlLm9uU3RvcFxuICAgICAgICBoYW5kbGUub25TdG9wIC0+XG4gICAgICAgICAgaGFuZGxlID0gbnVsbFxuICAgICAgZWxzZVxuICAgICAgICAjIFhYWCBDT01QQVQgV0lUSCBNRVRFT1IgMS4xLjBcbiAgICAgICAgb3JpZ2luYWxTdG9wID0gaGFuZGxlLnN0b3BcbiAgICAgICAgaGFuZGxlLnN0b3AgPSAtPlxuICAgICAgICAgIG9yaWdpbmFsU3RvcC5jYWxsIGhhbmRsZSBpZiBoYW5kbGVcbiAgICAgICAgICBoYW5kbGUgPSBudWxsXG5cbiAgICBzdGFydEF1dG9ydW4oKVxuXG4gICAgZ2V0dGVyID0gLT5cbiAgICAgICMgV2UgYWx3YXlzIGZsdXNoIHNvIHRoYXQgeW91IGdldCB0aGUgbW9zdCByZWNlbnQgdmFsdWUuIFRoaXMgaXMgYSBub29wIGlmIGF1dG9ydW4gd2FzIG5vdCBpbnZhbGlkYXRlZC5cbiAgICAgIGdldHRlci5mbHVzaCgpXG4gICAgICBsYXN0VmFsdWUuZ2V0KClcblxuICAgICMgV2UgbWluZ2xlIHRoZSBwcm90b3R5cGUgc28gdGhhdCBnZXR0ZXIgaW5zdGFuY2VvZiBDb21wdXRlZEZpZWxkIGlzIHRydWUuXG4gICAgaWYgT2JqZWN0LnNldFByb3RvdHlwZU9mXG4gICAgICBPYmplY3Quc2V0UHJvdG90eXBlT2YgZ2V0dGVyLCBAY29uc3RydWN0b3I6OlxuICAgIGVsc2VcbiAgICAgIGdldHRlci5fX3Byb3RvX18gPSBAY29uc3RydWN0b3I6OlxuXG4gICAgZ2V0dGVyLnRvU3RyaW5nID0gLT5cbiAgICAgIFwiQ29tcHV0ZWRGaWVsZHsje0AoKX19XCJcblxuICAgIGdldHRlci5hcHBseSA9IC0+XG4gICAgICBnZXR0ZXIoKVxuXG4gICAgZ2V0dGVyLmNhbGwgPSAtPlxuICAgICAgZ2V0dGVyKClcblxuICAgICMgSWYgdGhpcyBhdXRvcnVuIGlzIG5lc3RlZCBpbiB0aGUgb3V0c2lkZSBhdXRvcnVuIGl0IGdldHMgc3RvcHBlZCBhdXRvbWF0aWNhbGx5IHdoZW4gdGhlIG91dHNpZGUgYXV0b3J1biBnZXRzXG4gICAgIyBpbnZhbGlkYXRlZCwgc28gbm8gbmVlZCB0byBjYWxsIGRlc3Ryb3kuIEJ1dCBvdGhlcndpc2UgeW91IHNob3VsZCBjYWxsIGRlc3Ryb3kgd2hlbiB0aGUgZmllbGQgaXMgbm90IG5lZWRlZCBhbnltb3JlLlxuICAgIGdldHRlci5zdG9wID0gLT5cbiAgICAgIGhhbmRsZT8uc3RvcCgpXG4gICAgICBoYW5kbGUgPSBudWxsXG5cbiAgICAjIEZvciB0ZXN0cy5cbiAgICBnZXR0ZXIuX2lzUnVubmluZyA9IC0+XG4gICAgICAhIWhhbmRsZVxuXG4gICAgIyBTb21ldGltZXMgeW91IHdhbnQgdG8gZm9yY2UgcmVjb21wdXRhdGlvbiBvZiB0aGUgbmV3IHZhbHVlIGJlZm9yZSB0aGUgZ2xvYmFsIFRyYWNrZXIgZmx1c2ggaXMgZG9uZS5cbiAgICAjIFRoaXMgaXMgYSBub29wIGlmIGF1dG9ydW4gd2FzIG5vdCBpbnZhbGlkYXRlZC5cbiAgICBnZXR0ZXIuZmx1c2ggPSAtPlxuICAgICAgVHJhY2tlci5ub25yZWFjdGl2ZSAtPlxuICAgICAgICBpZiBoYW5kbGVcbiAgICAgICAgICBoYW5kbGUuZmx1c2goKVxuICAgICAgICBlbHNlXG4gICAgICAgICAgIyBJZiB0aGVyZSBpcyBubyBhdXRvcnVuLCBjcmVhdGUgaXQgbm93LiBUaGlzIHdpbGwgZG8gaW5pdGlhbCByZWNvbXB1dGF0aW9uIGFzIHdlbGwuIElmIHRoZXJlXG4gICAgICAgICAgIyB3aWxsIGJlIG5vIGRlcGVuZGVudHMgYWZ0ZXIgdGhlIGdsb2JhbCBmbHVzaCwgYXV0b3J1biB3aWxsIHN0b3AgKGFnYWluKS5cbiAgICAgICAgICBzdGFydEF1dG9ydW4oKVxuXG4gICAgcmV0dXJuIGdldHRlclxuIiwiICAgICAgICAgICAgICAgICAgXG5cbkNvbXB1dGVkRmllbGQgPSAoZnVuY3Rpb24oKSB7XG4gIGZ1bmN0aW9uIENvbXB1dGVkRmllbGQoZnVuYywgZXF1YWxzRnVuYywgZG9udFN0b3ApIHtcbiAgICB2YXIgYXV0b3J1biwgY3VycmVudFZpZXcsIGdldHRlciwgaGFuZGxlLCBsYXN0VmFsdWUsIHJlZiwgcmVmMSwgc3RhcnRBdXRvcnVuO1xuICAgIGlmIChfLmlzQm9vbGVhbihlcXVhbHNGdW5jKSkge1xuICAgICAgZG9udFN0b3AgPSBlcXVhbHNGdW5jO1xuICAgICAgZXF1YWxzRnVuYyA9IG51bGw7XG4gICAgfVxuICAgIGhhbmRsZSA9IG51bGw7XG4gICAgbGFzdFZhbHVlID0gbnVsbDtcbiAgICBpZiAoY3VycmVudFZpZXcgPSAocmVmID0gUGFja2FnZS5ibGF6ZSkgIT0gbnVsbCA/IChyZWYxID0gcmVmLkJsYXplKSAhPSBudWxsID8gcmVmMS5jdXJyZW50VmlldyA6IHZvaWQgMCA6IHZvaWQgMCkge1xuICAgICAgaWYgKGN1cnJlbnRWaWV3Ll9pc0luUmVuZGVyKSB7XG4gICAgICAgIGF1dG9ydW4gPSBmdW5jdGlvbihmKSB7XG4gICAgICAgICAgdmFyIGNvbXAsIHN0b3BDb21wdXRhdGlvbiwgdGVtcGxhdGVJbnN0YW5jZUZ1bmM7XG4gICAgICAgICAgdGVtcGxhdGVJbnN0YW5jZUZ1bmMgPSBQYWNrYWdlLmJsYXplLkJsYXplLlRlbXBsYXRlLl9jdXJyZW50VGVtcGxhdGVJbnN0YW5jZUZ1bmM7XG4gICAgICAgICAgY29tcCA9IFRyYWNrZXIuYXV0b3J1bihmdW5jdGlvbihjKSB7XG4gICAgICAgICAgICByZXR1cm4gUGFja2FnZS5ibGF6ZS5CbGF6ZS5fd2l0aEN1cnJlbnRWaWV3KGN1cnJlbnRWaWV3LCBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIFBhY2thZ2UuYmxhemUuQmxhemUuVGVtcGxhdGUuX3dpdGhUZW1wbGF0ZUluc3RhbmNlRnVuYyh0ZW1wbGF0ZUluc3RhbmNlRnVuYywgZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGYuY2FsbChjdXJyZW50VmlldywgYyk7XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgc3RvcENvbXB1dGF0aW9uID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICByZXR1cm4gY29tcC5zdG9wKCk7XG4gICAgICAgICAgfTtcbiAgICAgICAgICBjdXJyZW50Vmlldy5vblZpZXdEZXN0cm95ZWQoc3RvcENvbXB1dGF0aW9uKTtcbiAgICAgICAgICBjb21wLm9uU3RvcChmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHJldHVybiBjdXJyZW50Vmlldy5yZW1vdmVWaWV3RGVzdHJveWVkTGlzdGVuZXIoc3RvcENvbXB1dGF0aW9uKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICByZXR1cm4gY29tcDtcbiAgICAgICAgfTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGF1dG9ydW4gPSBmdW5jdGlvbihmKSB7XG4gICAgICAgICAgcmV0dXJuIGN1cnJlbnRWaWV3LmF1dG9ydW4oZik7XG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGF1dG9ydW4gPSBUcmFja2VyLmF1dG9ydW47XG4gICAgfVxuICAgIHN0YXJ0QXV0b3J1biA9IGZ1bmN0aW9uKCkge1xuICAgICAgdmFyIG9yaWdpbmFsU3RvcDtcbiAgICAgIGhhbmRsZSA9IGF1dG9ydW4oZnVuY3Rpb24oY29tcHV0YXRpb24pIHtcbiAgICAgICAgdmFyIHZhbHVlO1xuICAgICAgICB2YWx1ZSA9IGZ1bmMoKTtcbiAgICAgICAgaWYgKCFsYXN0VmFsdWUpIHtcbiAgICAgICAgICBsYXN0VmFsdWUgPSBuZXcgUmVhY3RpdmVWYXIodmFsdWUsIGVxdWFsc0Z1bmMpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGxhc3RWYWx1ZS5zZXQodmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghZG9udFN0b3ApIHtcbiAgICAgICAgICByZXR1cm4gVHJhY2tlci5hZnRlckZsdXNoKGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgaWYgKCFsYXN0VmFsdWUuZGVwLmhhc0RlcGVuZGVudHMoKSkge1xuICAgICAgICAgICAgICByZXR1cm4gZ2V0dGVyLnN0b3AoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICBpZiAoaGFuZGxlLm9uU3RvcCkge1xuICAgICAgICByZXR1cm4gaGFuZGxlLm9uU3RvcChmdW5jdGlvbigpIHtcbiAgICAgICAgICByZXR1cm4gaGFuZGxlID0gbnVsbDtcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBvcmlnaW5hbFN0b3AgPSBoYW5kbGUuc3RvcDtcbiAgICAgICAgcmV0dXJuIGhhbmRsZS5zdG9wID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgaWYgKGhhbmRsZSkge1xuICAgICAgICAgICAgb3JpZ2luYWxTdG9wLmNhbGwoaGFuZGxlKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIGhhbmRsZSA9IG51bGw7XG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfTtcbiAgICBzdGFydEF1dG9ydW4oKTtcbiAgICBnZXR0ZXIgPSBmdW5jdGlvbigpIHtcbiAgICAgIGdldHRlci5mbHVzaCgpO1xuICAgICAgcmV0dXJuIGxhc3RWYWx1ZS5nZXQoKTtcbiAgICB9O1xuICAgIGlmIChPYmplY3Quc2V0UHJvdG90eXBlT2YpIHtcbiAgICAgIE9iamVjdC5zZXRQcm90b3R5cGVPZihnZXR0ZXIsIHRoaXMuY29uc3RydWN0b3IucHJvdG90eXBlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgZ2V0dGVyLl9fcHJvdG9fXyA9IHRoaXMuY29uc3RydWN0b3IucHJvdG90eXBlO1xuICAgIH1cbiAgICBnZXR0ZXIudG9TdHJpbmcgPSBmdW5jdGlvbigpIHtcbiAgICAgIHJldHVybiBcIkNvbXB1dGVkRmllbGR7XCIgKyAodGhpcygpKSArIFwifVwiO1xuICAgIH07XG4gICAgZ2V0dGVyLmFwcGx5ID0gZnVuY3Rpb24oKSB7XG4gICAgICByZXR1cm4gZ2V0dGVyKCk7XG4gICAgfTtcbiAgICBnZXR0ZXIuY2FsbCA9IGZ1bmN0aW9uKCkge1xuICAgICAgcmV0dXJuIGdldHRlcigpO1xuICAgIH07XG4gICAgZ2V0dGVyLnN0b3AgPSBmdW5jdGlvbigpIHtcbiAgICAgIGlmIChoYW5kbGUgIT0gbnVsbCkge1xuICAgICAgICBoYW5kbGUuc3RvcCgpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGhhbmRsZSA9IG51bGw7XG4gICAgfTtcbiAgICBnZXR0ZXIuX2lzUnVubmluZyA9IGZ1bmN0aW9uKCkge1xuICAgICAgcmV0dXJuICEhaGFuZGxlO1xuICAgIH07XG4gICAgZ2V0dGVyLmZsdXNoID0gZnVuY3Rpb24oKSB7XG4gICAgICByZXR1cm4gVHJhY2tlci5ub25yZWFjdGl2ZShmdW5jdGlvbigpIHtcbiAgICAgICAgaWYgKGhhbmRsZSkge1xuICAgICAgICAgIHJldHVybiBoYW5kbGUuZmx1c2goKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm4gc3RhcnRBdXRvcnVuKCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH07XG4gICAgcmV0dXJuIGdldHRlcjtcbiAgfVxuXG4gIHJldHVybiBDb21wdXRlZEZpZWxkO1xuXG59KSgpO1xuIl19
