(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var check = Package.check.check;
var Match = Package.check.Match;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var _ = Package.underscore._;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var EJSON = Package.ejson.EJSON;
var WebApp = Package.webapp.WebApp;
var WebAppInternals = Package.webapp.WebAppInternals;
var main = Package.webapp.main;
var Log = Package.logging.Log;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var Random = Package.random.Random;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var __coffeescriptShare;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/alethes_pages/lib/pages.coffee                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var Pages,
    slice = [].slice,
    indexOf = [].indexOf || function (item) {
  for (var i = 0, l = this.length; i < l; i++) {
    if (i in this && this[i] === item) return i;
  }

  return -1;
};

this.__Pages = Pages = function () {
  Pages.prototype.settings = {
    dataMargin: [true, Number, 3],
    divWrapper: [true, Match.OneOf(Match.Optional(String), Match.Optional(Boolean)), "pagesCont"],
    fields: [true, Object, {}],
    filters: [true, Object, {}],
    itemTemplate: [true, String, "_pagesItemDefault"],
    navShowEdges: [true, Boolean, false],
    navShowFirst: [true, Boolean, true],
    navShowLast: [true, Boolean, true],
    resetOnReload: [true, Boolean, false],
    paginationMargin: [true, Number, 3],
    perPage: [true, Number, 10],
    route: [true, String, "/page/"],
    router: [true, Match.Optional(String), void 0],
    routerTemplate: [true, String, "pages"],
    routerLayout: [true, Match.Optional(String), void 0],
    sort: [true, Object, {}],
    auth: [false, Match.Optional(Function), void 0],
    availableSettings: [false, Object, {}],
    fastRender: [false, Boolean, false],
    homeRoute: [false, Match.OneOf(String, Array, Boolean), "/"],
    infinite: [false, Boolean, false],
    infiniteItemsLimit: [false, Number, 2e308],
    infiniteTrigger: [false, Number, .9],
    infiniteRateLimit: [false, Number, 1],
    infiniteStep: [false, Number, 10],
    initPage: [false, Number, 1],
    maxSubscriptions: [false, Number, 20],
    navTemplate: [false, String, "_pagesNavCont"],
    onDeniedSetting: [false, Function, function (k, v, e) {
      return typeof console !== "undefined" && console !== null ? console.log("Changing " + k + " not allowed.") : void 0;
    }],
    pageCountFrequency: [false, Number, 10000],
    pageSizeLimit: [false, Number, 60],
    pageTemplate: [false, String, "_pagesPageCont"],
    rateLimit: [false, Number, 1],
    routeSettings: [false, Match.Optional(Function), void 0],
    scrollBoxSelector: [String, void 0],
    table: [false, Match.OneOf(Boolean, Object), false],
    tableItemTemplate: [false, String, "_pagesTableItem"],
    tableTemplate: [false, String, "_pagesTable"],
    templateName: [false, Match.Optional(String), void 0]
  };
  Pages.prototype._nInstances = 0;
  Pages.prototype.collections = {};
  Pages.prototype.instances = {};
  Pages.prototype.methods = {
    "CountPages": function (sub) {
      var n;
      n = sub.get("nPublishedPages");

      if (n != null) {
        return n;
      }

      n = Math.ceil(this.Collection.find({
        $and: [sub.get("filters"), sub.get("realFilters") || {}]
      }).count() / sub.get("perPage"));
      return n || 1;
    },
    "Set": function (k, v, sub) {
      var _k, _v, changes;

      if (this.settings[k] == null) {
        this.error("invalid-option", "Invalid option name: " + k + ".");
      }

      check(k, String);
      check(v, this.settings[k][1]);
      check(sub, Match.Where(function (sub) {
        var ref;
        return ((ref = sub.connection) != null ? ref.id : void 0) != null;
      }));

      if (!this.availableSettings[k] || _.isFunction(this.availableSettings[k]) && !this.availableSettings[k](v, sub)) {
        this.error("forbidden-option", "Changing " + k + " not allowed.");
      }

      changes = 0;

      if (v != null) {
        changes = this._set(k, v, {
          cid: sub.connection.id
        });
      } else if (!_.isString(k)) {
        for (_k in meteorBabelHelpers.sanitizeForInObject(k)) {
          _v = k[_k];
          changes += this.set(_k, _v, {
            cid: sub.connection.id
          });
        }
      }

      return changes;
    },
    "Unsubscribe": function () {
      var cid, k, ref, sub, subs;
      cid = arguments[arguments.length - 1].connection.id;
      subs = {};
      ref = this.subscriptions;

      for (k in meteorBabelHelpers.sanitizeForInObject(ref)) {
        sub = ref[k];

        if (k === "length" || k === "order") {
          continue;
        }

        if (sub.connection.id === cid) {
          sub.stop();
          delete this.subscriptions[k];
        }
      }

      this.subscriptions.length = 0;
      return true;
    }
  };

  function Pages(collection, settings) {
    if (settings == null) {
      settings = {};
    }

    if (!(this instanceof Meteor.Pagination)) {
      throw new Meteor.Error("missing-new", "The Meteor.Pagination instance has to be initiated with `new`");
    }

    this.init = this.beforeFirstReady = true;

    if (this.debug == null) {
      this.debug = typeof PAGES_DEBUG !== "undefined" && PAGES_DEBUG !== null && PAGES_DEBUG || (typeof process !== "undefined" && process !== null ? process.env.PAGES_DEBUG : void 0);
    }

    this.subscriptions = {
      length: 0,
      order: []
    };
    this.userSettings = {};
    this._currentPage = 1;
    this.setCollection(collection);
    this.setInitial(settings);
    this.setDefaults();
    this.setRouter();
    this[(Meteor.isServer ? "server" : "client") + "Init"]();
    this.registerInstance();
    this;
  }

  Pages.prototype.error = function (code, msg) {
    if (code == null) {
      msg = code;
    }

    throw new Meteor.Error(code, msg);
  };

  Pages.prototype.serverInit = function () {
    var self;
    this.setMethods();
    self = this;
    Meteor.onConnection(function (_this) {
      return function (connection) {
        return connection.onClose(function () {
          return delete _this.userSettings[connection.id];
        });
      };
    }(this));
    return Meteor.publish(this.id, function (page) {
      return self.publish.call(self, page, this);
    });
  };

  Pages.prototype.clientInit = function () {
    this.requested = {};
    this.received = {};
    this.queue = [];
    this.nextPageCount = this.now();
    this.groundDB = Package["ground:db"] != null;

    if (this.infinite) {
      this.sess("limit", 10);
      this.lastOffsetHeight = 0;
    }

    if (this.maxSubscriptions < 1) {
      this.maxSubscriptions = 1;
    }

    this.setTemplates();
    Tracker.autorun(function (_this) {
      return function () {
        Meteor.status();

        if (typeof Meteor.userId === "function") {
          Meteor.userId();
        }

        _this.countPages();

        return _this.reload();
      };
    }(this));

    if (this.templateName == null) {
      this.templateName = this.name;
    }

    return Template[this.templateName].onRendered(function (_this) {
      return function () {
        if (_this.infinite) {
          return _this.setInfiniteTrigger();
        }
      };
    }(this));
  };

  Pages.prototype.reload = _.throttle(function () {
    this.unsubscribe();
    return this.countPages(function (_this) {
      return function (total) {
        var p;
        p = _this.currentPage();

        if (p == null || _this.resetOnReload || p > total) {
          p = 1;
        }

        _this.sess("currentPage", false);

        return _this.sess("currentPage", p);
      };
    }(this));
  }, 1000, {
    trailing: false
  });

  Pages.prototype.unsubscribe = function (page, cid) {
    var k, ref, ref1, sub;

    if (this.beforeFirstReady) {
      return;
    }

    if (page == null) {
      ref = this.subscriptions;

      for (k in meteorBabelHelpers.sanitizeForInObject(ref)) {
        sub = ref[k];

        if (k === "length" || k === "order") {
          continue;
        }

        sub.stop();
        delete this.subscriptions[k];
      }

      this.subscriptions.length = 0;
      this.initPage = null;
      this.requested = {};
      this.received = {};
      this.queue = [];
    } else if (Meteor.isServer) {
      check(cid, String);

      if ((ref1 = this.subscriptions[cid]) != null ? ref1[page] : void 0) {
        this.subscriptions[cid][page].stop();
        delete this.subscriptions[cid][page];
        this.subscriptions.length--;
      }
    } else if (this.subscriptions[page]) {
      this.subscriptions[page].stop();
      delete this.subscriptions[page];
      delete this.requested[page];
      delete this.received[page];
      this.subscriptions.order = _.without(this.subscriptions.order, Number(page));
      this.subscriptions.length--;
    }

    return true;
  };

  Pages.prototype.setDefaults = function () {
    var k, ref, results, v;
    ref = this.settings;
    results = [];

    for (k in meteorBabelHelpers.sanitizeForInObject(ref)) {
      v = ref[k];

      if (v[2] != null) {
        results.push(this[k] != null ? this[k] : this[k] = v[2]);
      } else {
        results.push(void 0);
      }
    }

    return results;
  };

  Pages.prototype.syncSettings = function (cb) {
    var S, k, ref, v;
    S = {};
    ref = this.settings;

    for (k in meteorBabelHelpers.sanitizeForInObject(ref)) {
      v = ref[k];

      if (v[0]) {
        S[k] = this[k];
      }
    }

    return this.set(S, cb != null ? {
      cb: cb.bind(this)
    } : null);
  };

  Pages.prototype.setMethods = function () {
    var f, n, nm, ref, self;
    nm = {};
    self = this;
    ref = this.methods;

    for (n in meteorBabelHelpers.sanitizeForInObject(ref)) {
      f = ref[n];

      nm[this.getMethodName(n)] = function (f) {
        return function () {
          var arg, k, r, v;

          arg = function () {
            var results;
            results = [];

            for (k in meteorBabelHelpers.sanitizeForInObject(arguments)) {
              v = arguments[k];
              results.push(v);
            }

            return results;
          }.apply(this, arguments);

          arg.push(this);
          this.get = _.bind(function (self, k) {
            return self.get(k, this.connection.id);
          }, this, self);
          r = f.apply(self, arg);
          return r;
        };
      }(f);
    }

    return Meteor.methods(nm);
  };

  Pages.prototype.getMethodName = function (name) {
    return this.id + "/" + name;
  };

  Pages.prototype.call = function () {
    var args, last;
    args = 1 <= arguments.length ? slice.call(arguments, 0) : [];
    check(args, Array);

    if (args.length < 1) {
      this.error("method-name-missing", "Method name not provided in a method call.");
    }

    args[0] = this.getMethodName(args[0]);
    last = args.length - 1;

    if (_.isFunction(args[last])) {
      args[last] = args[last].bind(this);
    }

    return Meteor.call.apply(this, args);
  };

  Pages.prototype.sess = function (k, v) {
    if (typeof Session === "undefined" || Session === null) {
      return;
    }

    k = this.id + "." + k;

    if (arguments.length === 2) {
      return Session.set(k, v);
    } else {
      return Session.get(k);
    }
  };

  Pages.prototype.get = function (setting, connectionId) {
    var ref, ref1;
    return (ref = (ref1 = this.userSettings[connectionId]) != null ? ref1[setting] : void 0) != null ? ref : this[setting];
  };

  Pages.prototype.set = function () {
    var _k, _v, ch, k, opts;

    k = arguments[0], opts = 2 <= arguments.length ? slice.call(arguments, 1) : [];
    ch = 0;

    switch (opts.length) {
      case 0:
        if (_.isObject(k)) {
          for (_k in meteorBabelHelpers.sanitizeForInObject(k)) {
            _v = k[_k];
            ch += this._set(_k, _v);
          }
        }

        break;

      case 1:
        if (_.isObject(k)) {
          if (_.isFunction(opts[0])) {
            opts[0] = {
              cb: opts[0]
            };
          }

          for (_k in meteorBabelHelpers.sanitizeForInObject(k)) {
            _v = k[_k];
            ch += this._set(_k, _v, opts[0]);
          }
        } else {
          check(k, String);
          ch = this._set(k, opts[0]);
        }

        break;

      case 2:
        if (_.isFunction(opts[1])) {
          opts[1] = {
            cb: opts[1]
          };
        }

        ch = this._set(k, opts[0], opts[1]);
        break;

      case 3:
        check(opts[1], Object);
        check(opts[2], Function);
        opts[2] = {
          cb: opts[2]
        };
        ch = this._set(k, opts[1], opts[2]);
    }

    if (Meteor.isClient && ch) {
      this.reload();
    }

    return ch;
  };

  Pages.prototype.setInitial = function (settings) {
    this.setInitDone = false;
    this.set(settings);
    return this.setInitDone = true;
  };

  Pages.prototype.sanitizeRegex = function (v) {
    var lis;

    if (_.isRegExp(v)) {
      v = v.toString();
      lis = v.lastIndexOf("/");
      v = {
        $regex: v.slice(1, lis),
        $options: v.slice(1 + lis)
      };
    }

    return v;
  };

  Pages.prototype.sanitizeRegexObj = function (obj) {
    var k, v;

    if (_.isRegExp(obj)) {
      return this.sanitizeRegex(obj);
    }

    for (k in meteorBabelHelpers.sanitizeForInObject(obj)) {
      v = obj[k];

      if (_.isRegExp(v)) {
        obj[k] = this.sanitizeRegex(v);
      } else if ("object" === (typeof v === "undefined" ? "undefined" : _typeof(v))) {
        obj[k] = this.sanitizeRegexObj(v);
      }
    }

    return obj;
  };

  Pages.prototype._set = function (k, v, opts) {
    var base, ch, name1, oldV, ref, ref1, ref2;

    if (opts == null) {
      opts = {};
    }

    check(k, String);
    ch = 1;

    if (Meteor.isServer || this[k] == null || ((ref = this.settings[k]) != null ? ref[0] : void 0) || opts.init) {
      if (((ref1 = this.settings[k]) != null ? ref1[1] : void 0) != null && ((ref2 = this.settings[k]) != null ? ref2[1] : void 0) !== true) {
        check(v, this.settings[k][1]);
      }

      this.sanitizeRegexObj(v);
      oldV = this.get(k, opts != null ? opts.cid : void 0);

      if (this.valuesEqual(v, oldV)) {
        return 0;
      }

      if (Meteor.isClient) {
        this[k] = v;

        if (this.setInitDone) {
          this.call("Set", k, v, function (e, r) {
            if (e) {
              this[k] = oldV;
              return this.onDeniedSetting.call(this, k, v, e);
            }

            return typeof opts.cb === "function" ? opts.cb(ch) : void 0;
          });
        }
      } else {
        if (opts.cid) {
          if (ch != null) {
            if ((base = this.userSettings)[name1 = opts.cid] == null) {
              base[name1] = {};
            }

            this.userSettings[opts.cid][k] = v;
          }
        } else {
          this[k] = v;
        }

        if (typeof opts.cb === "function") {
          opts.cb(ch);
        }
      }
    } else {
      this.onDeniedSetting.call(this, k, v);
    }

    return ch;
  };

  Pages.prototype.valuesEqual = function (v1, v2) {
    if (_.isFunction(v1)) {
      return _.isFunction(v2) && v1.toString() === v2.toString();
    } else {
      return _.isEqual(v1, v2);
    }
  };

  Pages.prototype.setId = function (name) {
    var n;

    if (this.templateName) {
      name = this.templateName;
    }

    while (name in Pages.prototype.instances) {
      n = name.match(/[0-9]+$/);

      if (n != null) {
        name = name.slice(0, name.length - n[0].length) + (parseInt(n) + 1);
      } else {
        name = name + "2";
      }
    }

    this.id = "pages_" + name;
    return this.name = name;
  };

  Pages.prototype.registerInstance = function () {
    Pages.prototype._nInstances++;
    return Pages.prototype.instances[this.name] = this;
  };

  Pages.prototype.setCollection = function (collection) {
    var e;

    if ((typeof collection === "undefined" ? "undefined" : _typeof(collection)) === "object") {
      Pages.prototype.collections[collection._name] = collection;
      this.Collection = collection;
    } else {
      try {
        this.Collection = new Mongo.Collection(collection);
        Pages.prototype.collections[collection] = this.Collection;
      } catch (error) {
        e = error;
        this.Collection = Pages.prototype.collections[collection];
        this.Collection instanceof Mongo.Collection || this.error("collection-inaccessible", "The '" + collection + "' collection was created outside of <Meteor.Pagination>. Pass the collection object instead of the collection's name to the <Meteor.Pagination> constructor.");
      }
    }

    return this.setId(this.Collection._name);
  };

  Pages.prototype.linkTo = function (page) {
    var params, ref;

    if ((ref = Router.current()) != null ? ref.params : void 0) {
      params = Router.current().params;
      params.page = page;
      return Router.routes[this.name + "_page"].path(params);
    }
  };

  Pages.prototype.setRouter = function () {
    var init, l, pr, ref, self, t;

    if (this.router === "iron-router") {
      if (this.route.indexOf(":page") === -1) {
        if (this.route[0] !== "/") {
          this.route = "/" + this.route;
        }

        if (this.route[this.route.length - 1] !== "/") {
          this.route += "/";
        }

        pr = this.route = this.route + ":page";
      }

      t = this.routerTemplate;
      l = (ref = this.routerLayout) != null ? ref : void 0;
      self = this;
      init = true;
      Router.map(function () {
        var hr, j, k, len, ref1, results;

        if (!self.infinite) {
          this.route(self.name + "_page", {
            path: pr,
            template: t,
            layoutTemplate: l,
            onBeforeAction: function () {
              var page;
              page = parseInt(this.params.page);

              if (self.init) {
                self.sess("oldPage", page);
                self.sess("currentPage", page);
              }

              if (self.routeSettings != null) {
                self.routeSettings(this);
              }

              Tracker.nonreactive(function (_this) {
                return function () {
                  return self.onNavClick(page);
                };
              }(this));
              return this.next();
            }
          });
        }

        if (self.homeRoute) {
          if (_.isString(self.homeRoute)) {
            self.homeRoute = [self.homeRoute];
          }

          ref1 = self.homeRoute;
          results = [];

          for (k = j = 0, len = ref1.length; j < len; k = ++j) {
            hr = ref1[k];
            results.push(this.route(self.name + "_home" + k, {
              path: hr,
              template: t,
              layoutTemplate: l,
              onBeforeAction: function () {
                if (self.routeSettings != null) {
                  self.routeSettings(this);
                }

                if (self.init) {
                  self.sess("oldPage", 1);
                  self.sess("currentPage", 1);
                }

                return this.next();
              }
            }));
          }

          return results;
        }
      });

      if (Meteor.isServer && this.fastRender) {
        self = this;
        FastRender.route(pr, function (params) {
          return this.subscribe(self.id, parseInt(params.page));
        });
        return FastRender.route(this.homeRoute, function () {
          return this.subscribe(self.id, 1);
        });
      }
    }
  };

  Pages.prototype.isEmpty = function () {
    return this.isReady() && this.Collection.find(_.object([["_" + this.id + "_i", 0]])).count() === 0;
  };

  Pages.prototype.setPerPage = function () {
    return this.perPage = this.pageSizeLimit < this.perPage ? this.pageSizeLimit : this.perPage;
  };

  Pages.prototype.setTemplates = function () {
    var helpers, i, j, len, name, ref, tn;
    name = this.templateName || this.name;

    if (this.table && this.itemTemplate === "_pagesItemDefault") {
      this.itemTemplate = this.tableItemTemplate;
    }

    ref = [this.navTemplate, this.pageTemplate, this.itemTemplate, this.tableTemplate];

    for (j = 0, len = ref.length; j < len; j++) {
      i = ref[j];
      tn = this.id + i;
      Template[tn] = new Blaze.Template("Template." + tn, Template[i].renderFunction);
      Template[tn].__eventMaps = Template[tn].__eventMaps.concat(Template[i].__eventMaps);
      helpers = {
        pagesData: this
      };

      _.each(Template[i].__helpers, function (_this) {
        return function (helper, name) {
          if (name[0] === " ") {
            return helpers[name.slice(1)] = _.bind(helper, _this);
          }
        };
      }(this));

      Template[tn].helpers(helpers);
    }

    return Template[name].helpers({
      pagesData: this,
      pagesNav: Template[this.id + this.navTemplate],
      pages: Template[this.id + this.pageTemplate]
    });
  };

  Pages.prototype.countPages = _.throttle(function (cb) {
    var n, ref;

    if (!Meteor.status().connected && Package["ground:db"] != null) {
      n = ((ref = this.Collection.findOne({}, {
        sort: _.object([["_" + this.id + "_p", -1]])
      })) != null ? ref["_" + this.id + "_p"] : void 0) || 0;
      this.setTotalPages(n);
      return typeof cb === "function" ? cb(n) : void 0;
    } else {
      return this.call("CountPages", function (_this) {
        return function (e, r) {
          var now;

          if (e != null) {
            throw e;
          }

          _this.setTotalPages(r);

          now = _this.now();

          if (_this.nextPageCount < now) {
            _this.nextPageCount = now + _this.pageCountFrequency;
            setTimeout(_.bind(_this.countPages, _this), _this.pageCountFrequency);
          }

          return typeof cb === "function" ? cb(r) : void 0;
        };
      }(this));
    }
  }, 1000);

  Pages.prototype.setTotalPages = function (n) {
    this.sess("totalPages", n);

    if (this.sess("currentPage") > n) {
      return this.sess("currentPage", 1);
    }
  };

  Pages.prototype.enforceSubscriptionLimit = function (cid) {
    var ref;

    if (Meteor.isServer) {
      check(cid, String);

      if (((ref = this.subscriptions[cid]) != null ? ref.length : void 0) >= this.maxSubscriptions) {
        return this.error("subscription-limit-reached", "Subscription limit reached. Unable to open a new subscription.");
      }
    } else {
      while (this.subscriptions.length >= this.maxSubscriptions) {
        this.unsubscribe(this.subscriptions.order[0]);
      }

      return true;
    }
  };

  Pages.prototype.publish = function (page, sub) {
    var base, c, cid, get, handle, handle2, init, n, name1, query, self, set;
    check(page, Number);
    check(sub, Match.Where(function (s) {
      return s.ready != null;
    }));
    cid = sub.connection.id;
    init = true;

    if ((base = this.subscriptions)[name1 = sub.connection.id] == null) {
      base[name1] = {
        length: 0
      };
    }

    this.enforceSubscriptionLimit(cid);
    get = sub.get = _.bind(function (cid, k) {
      return this.get(k, cid);
    }, this, cid);
    set = sub.set = _.bind(function (cid, k, v) {
      return this.set(k, v, {
        cid: cid
      });
    }, this, cid);
    query = _.bind(function (sub, get, set) {
      var c, filters, options, r, ref, ref1, skip;

      if ((ref = this.userSettings[cid]) != null) {
        delete ref.realFilters;
      }

      if ((ref1 = this.userSettings[cid]) != null) {
        delete ref1.nPublishedPages;
      }

      this.setPerPage();
      skip = (page - 1) * get("perPage");

      if (skip < 0) {
        skip = 0;
      }

      filters = get("filters");
      options = {
        sort: get("sort"),
        fields: get("fields"),
        skip: skip,
        limit: get("perPage")
      };

      if (this.auth != null) {
        r = this.auth.call(this, skip, sub);

        if (!r) {
          set("nPublishedPages", 0);
          sub.ready();
          return this.ready();
        } else if (_.isNumber(r)) {
          set("nPublishedPages", r);

          if (page > r) {
            sub.ready();
            return this.ready();
          }
        } else if (_.isArray(r) && r.length === 2) {
          if (_.isFunction(r[0].fetch)) {
            c = r;
          } else {
            filters = r[0];
            options = r[1];
          }
        } else if (_.isFunction(r.fetch)) {
          c = r;
        }
      }

      if (!EJSON.equals({}, filters) && !EJSON.equals(get("filters"), filters)) {
        set("realFilters", filters);
      }

      return c || this.Collection.find(filters, options);
    }, this, sub, get, set);
    c = query();
    self = this;
    handle = c.observe({
      addedAt: _.bind(function (sub, query, doc, at) {
        var id;

        if (init) {
          return;
        }

        doc["_" + this.id + "_p"] = page;
        doc["_" + this.id + "_i"] = at;
        id = doc._id;
        delete doc._id;
        return query().forEach(function (_this) {
          return function (o, i) {
            if (i === at) {
              return sub.added(_this.Collection._name, id, doc);
            } else {
              return sub.changed(_this.Collection._name, o._id, _.object([["_" + _this.id + "_i", i]]));
            }
          };
        }(this));
      }, this, sub, query)
    });
    handle2 = c.observeChanges({
      movedBefore: _.bind(function (sub, query, id, before) {
        return query().forEach(function (_this) {
          return function (o, i) {
            return sub.changed(_this.Collection._name, o._id, _.object([["_" + _this.id + "_i", i]]));
          };
        }(this));
      }, this, sub, query),
      changed: _.bind(function (sub, query, id, fields) {
        var e;

        try {
          return sub.changed(this.Collection._name, id, fields);
        } catch (error) {
          e = error;
        }
      }, this, sub, query),
      removed: _.bind(function (sub, query, id) {
        var e;

        try {
          sub.removed(this.Collection._name, id);
          return query().forEach(function (_this) {
            return function (o, i) {
              return sub.changed(_this.Collection._name, o._id, _.object([["_" + _this.id + "_i", i]]));
            };
          }(this));
        } catch (error) {
          e = error;
        }
      }, this, sub, query)
    });
    n = 0;
    c.forEach(function (_this) {
      return function (doc, index, cursor) {
        n++;
        doc["_" + _this.id + "_p"] = page;
        doc["_" + _this.id + "_i"] = index;
        return sub.added(_this.Collection._name, doc._id, doc);
      };
    }(this));
    init = false;
    sub.onStop(_.bind(function (page) {
      delete this.subscriptions[sub.connection.id][page];
      this.subscriptions[sub.connection.id].length--;
      handle.stop();
      return handle2.stop();
    }, this, page));
    this.subscriptions[sub.connection.id][page] = sub;
    this.subscriptions[sub.connection.id].length++;
    return sub.ready();
  };

  Pages.prototype.loading = function (p) {
    if (!this.fastRender && p === this.currentPage()) {
      return this.sess("ready", false);
    }
  };

  Pages.prototype.now = function () {
    return new Date().getTime();
  };

  Pages.prototype.log = function () {
    var a, i, j, len;
    a = ["Pages: " + this.name + " -"];

    for (j = 0, len = arguments.length; j < len; j++) {
      i = arguments[j];
      a.push(i);
    }

    return this.debug && console.log.apply(console, a);
  };

  Pages.prototype.logRequest = function (p) {
    this.timeLastRequest = this.now();
    this.requesting = p;
    return this.requested[p] = 1;
  };

  Pages.prototype.logResponse = function (p) {
    delete this.requested[p];
    return this.received[p] = 1;
  };

  Pages.prototype.clearQueue = function () {
    return this.queue = [];
  };

  Pages.prototype.neighbors = function (page) {
    var d, j, maxMargin, n, np, pp, ref;
    n = [];

    if (this.dataMargin === 0 || this.maxSubscriptions < 2) {
      return n;
    }

    maxMargin = Math.floor((this.maxSubscriptions - 1) / 2);

    for (d = j = 1, ref = _.min([maxMargin, this.dataMargin]); 1 <= ref ? j <= ref : j >= ref; d = 1 <= ref ? ++j : --j) {
      np = page + d;

      if (np <= this.sess("totalPages")) {
        n.push(np);
      }

      pp = page - d;

      if (pp > 0) {
        n.push(pp);
      }
    }

    return n;
  };

  Pages.prototype.queueNeighbors = function (page) {
    var j, len, p, ref, results;
    ref = this.neighbors(page);
    results = [];

    for (j = 0, len = ref.length; j < len; j++) {
      p = ref[j];

      if (!this.received[p] && !this.requested[p] && indexOf.call(this.queue, p) < 0) {
        results.push(this.queue.push(p));
      } else {
        results.push(void 0);
      }
    }

    return results;
  };

  Pages.prototype.paginationNavItem = function (label, page, disabled, active) {
    if (active == null) {
      active = false;
    }

    return {
      p: label,
      n: page,
      active: active ? "active" : "",
      disabled: disabled ? "disabled" : ""
    };
  };

  Pages.prototype.navigationNeighbors = function () {
    var from, i, j, k, len, m, n, p, page, ref, ref1, to, total;
    page = this.currentPage();
    total = this.sess("totalPages");
    from = page - this.paginationMargin;
    to = page + this.paginationMargin;

    if (from < 1) {
      to += 1 - from;
      from = 1;
    }

    if (to > total) {
      from -= to - total;
      to = total;
    }

    if (from < 1) {
      from = 1;
    }

    if (to > total) {
      to = total;
    }

    n = [];

    if (this.navShowFirst || this.navShowEdges) {
      n.push(this.paginationNavItem("«", 1, page === 1));
    }

    n.push(this.paginationNavItem("<", page - 1, page === 1));

    for (p = j = ref = from, ref1 = to; ref <= ref1 ? j <= ref1 : j >= ref1; p = ref <= ref1 ? ++j : --j) {
      n.push(this.paginationNavItem(p, p, page > total, p === page));
    }

    n.push(this.paginationNavItem(">", page + 1, page >= total));

    if (this.navShowLast || this.navShowEdges) {
      n.push(this.paginationNavItem("»", total, page >= total));
    }

    for (k = m = 0, len = n.length; m < len; k = ++m) {
      i = n[k];
      n[k]['_p'] = this;
    }

    return n;
  };

  Pages.prototype.onNavClick = function (n) {
    if (n <= this.sess("totalPages") && n > 0) {
      Tracker.nonreactive(function (_this) {
        return function () {
          var cp;
          cp = _this.sess("currentPage");

          if (_this.received[cp]) {
            return _this.sess("oldPage", cp);
          }
        };
      }(this));
      return this.sess("currentPage", n);
    }
  };

  Pages.prototype.setInfiniteTrigger = function () {
    this.scrollBoxSelector = this.scrollBoxSelector || window;
    this.scrollBox = $(this.scrollBoxSelector);
    return this.scrollBox.scroll(_.bind(_.throttle(function () {
      var l, oh, t;
      t = this.infiniteTrigger;
      oh = this.scrollBox[0].scrollHeight;

      if (this.lastOffsetHeight != null && this.lastOffsetHeight > oh) {
        return;
      }

      this.lastOffsetHeight = oh;

      if (t > 1) {
        l = oh - t;
      } else if (t > 0) {
        l = oh * t;
      } else {
        return;
      }

      if (this.scrollBox.scrollTop() + this.scrollBox[0].offsetHeight >= l) {
        return this.sess("limit", this.sess("limit") + this.infiniteStep); /*
                                                                           if @lastPage < @sess "totalPages"
                                                                             console.log "i want page #{@lastPage + 1}"
                                                                             @sess("currentPage", @lastPage + 1)
                                                                            */
      }
    }, this.infiniteRateLimit * 1000), this));
  };

  Pages.prototype.checkQueue = _.throttle(function () {
    var cp, i, k, neighbors, ref, results, results1, v;
    cp = this.currentPage();
    neighbors = this.neighbors(cp);

    if (!this.received[cp]) {
      this.clearQueue();
      this.requestPage(cp);
      cp = String(cp);
      ref = this.requested;
      results = [];

      for (k in meteorBabelHelpers.sanitizeForInObject(ref)) {
        v = ref[k];

        if (k !== cp) {
          if (this.subscriptions[k] != null) {
            this.subscriptions[k].stop();
            delete this.subscriptions[k];
            this.subscriptions.length--;
          }

          results.push(delete this.requested[k]);
        } else {
          results.push(void 0);
        }
      }

      return results;
    } else if (this.queue.length) {
      results1 = [];

      while (this.queue.length > 0) {
        i = this.queue.shift();

        if (indexOf.call(neighbors, i) >= 0) {
          this.requestPage(i);
          break;
        } else {
          results1.push(void 0);
        }
      }

      return results1;
    }
  }, 500);

  Pages.prototype.currentPage = function () {
    if (Meteor.isClient && this.sess("currentPage") != null) {
      return this.sess("currentPage");
    } else {
      return this._currentPage;
    }
  };

  Pages.prototype.isReady = function () {
    return this.sess("ready");
  };

  Pages.prototype.ready = function (p) {
    if (p === true || p === this.currentPage() && typeof Session !== "undefined" && Session !== null) {
      return this.sess("ready", true);
    }
  };

  Pages.prototype.checkInitPage = function () {
    var ref, ref1, ref2;

    if (this.init && !this.initPage) {
      if (this.router) {
        if ((ref = Router.current()) != null) {
          if ((ref1 = ref.route) != null) {
            ref1.getName();
          }
        }

        try {
          this.initPage = parseInt((ref2 = Router.current().route.params(location.href)) != null ? ref2.page : void 0) || 1;
        } catch (error) {
          return;
        }
      } else {
        this.initPage = 1;
      }
    }

    this.init = false;
    this.sess("oldPage", this.initPage);
    return this.sess("currentPage", this.initPage);
  };

  Pages.prototype.getPage = function (page) {
    var c, n, total;

    if (Meteor.isClient) {
      if (page == null) {
        page = this.currentPage();
      }

      page = parseInt(page);

      if (page === 0 / 0) {
        return;
      }

      total = this.sess("totalPages");

      if (total === 0) {
        return this.ready(true);
      }

      if (page <= total) {
        this.requestPage(page);
        this.queueNeighbors(page);
        this.checkQueue();
      }

      if (this.infinite) {
        n = this.Collection.find({}, {
          fields: this.fields,
          sort: this.sort
        }).count();
        c = this.Collection.find({}, {
          fields: this.fields,
          sort: this.sort,
          skip: n > this.infiniteItemsLimit ? n - this.infiniteItemsLimit : 0,
          limit: this.sess("limit") || this.infiniteItemsLimit
        });
      } else {
        c = this.Collection.find(_.object([["_" + this.id + "_p", page]]), {
          fields: this.fields,
          sort: _.object([["_" + this.id + "_i", 1]])
        });
        c.observeChanges({
          added: function (_this) {
            return function () {
              return _this.countPages();
            };
          }(this),
          removed: function (_this) {
            return function () {
              /* !! */_this.requestPage(_this.sess("currentPage"));

              return _this.countPages();
            };
          }(this)
        });
      }

      return c.fetch();
    }
  };

  Pages.prototype.requestPage = function (page) {
    if (!page || this.requested[page] || this.received[page]) {
      return;
    }

    this.log("Requesting page " + page);
    this.logRequest(page);

    if (!Meteor.status().connected && this.groundDB) {
      if (this.Collection.findOne(_.object([["_" + this.id + "_p", page]]))) {
        return this.onPage(page);
      } else {
        return setTimeout(_.bind(function (page) {
          if (this.currentPage() === page && !this.received[page]) {
            delete this.requested[page];
            return this.requestPage(page);
          }
        }, this, page), 500);
      }
    } else {
      this.enforceSubscriptionLimit();
      return Meteor.defer(_.bind(function (page) {
        this.subscriptions[page] = Meteor.subscribe(this.id, page, {
          onReady: _.bind(function (page) {
            return this.onPage(page);
          }, this, page),
          onError: function (_this) {
            return function (e) {
              if (e.error === "subscription-limit-reached") {
                return setTimeout(_.bind(function (page) {
                  if (this.currentPage() === page && !this.received[page]) {
                    delete this.requested[page];
                    return this.requestPage(page);
                  }
                }, _this, page), 500);
              } else {
                return _this.error(e.message);
              }
            };
          }(this)
        });
        this.subscriptions.order.push(page);
        return this.subscriptions.length++;
      }, this, page));
    }
  };

  Pages.prototype.onPage = function (page) {
    this.log("Received page " + page);
    this.beforeFirstReady = false;
    this.logResponse(page);
    this.ready(page);

    if (this.infinite) {
      this.lastPage = page;
    }

    this.countPages();
    return this.checkQueue();
  };

  return Pages;
}();

Meteor.Pagination = Pages;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['alethes:pages'] = {};

})();

//# sourceURL=meteor://💻app/packages/alethes_pages.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvYWxldGhlc19wYWdlcy9saWIvcGFnZXMuY29mZmVlIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvcGFnZXMuY29mZmVlIl0sIm5hbWVzIjpbIlBhZ2VzIiwic2xpY2UiLCJpbmRleE9mIiwiaXRlbSIsImkiLCJsIiwibGVuZ3RoIiwiX19QYWdlcyIsInByb3RvdHlwZSIsInNldHRpbmdzIiwiZGF0YU1hcmdpbiIsIk51bWJlciIsImRpdldyYXBwZXIiLCJNYXRjaCIsIk9uZU9mIiwiT3B0aW9uYWwiLCJTdHJpbmciLCJCb29sZWFuIiwiZmllbGRzIiwiT2JqZWN0IiwiZmlsdGVycyIsIml0ZW1UZW1wbGF0ZSIsIm5hdlNob3dFZGdlcyIsIm5hdlNob3dGaXJzdCIsIm5hdlNob3dMYXN0IiwicmVzZXRPblJlbG9hZCIsInBhZ2luYXRpb25NYXJnaW4iLCJwZXJQYWdlIiwicm91dGUiLCJyb3V0ZXIiLCJyb3V0ZXJUZW1wbGF0ZSIsInJvdXRlckxheW91dCIsInNvcnQiLCJhdXRoIiwiRnVuY3Rpb24iLCJhdmFpbGFibGVTZXR0aW5ncyIsImZhc3RSZW5kZXIiLCJob21lUm91dGUiLCJBcnJheSIsImluZmluaXRlIiwiaW5maW5pdGVJdGVtc0xpbWl0IiwiaW5maW5pdGVUcmlnZ2VyIiwiaW5maW5pdGVSYXRlTGltaXQiLCJpbmZpbml0ZVN0ZXAiLCJpbml0UGFnZSIsIm1heFN1YnNjcmlwdGlvbnMiLCJuYXZUZW1wbGF0ZSIsIm9uRGVuaWVkU2V0dGluZyIsImsiLCJ2IiwiZSIsImNvbnNvbGUiLCJsb2ciLCJwYWdlQ291bnRGcmVxdWVuY3kiLCJwYWdlU2l6ZUxpbWl0IiwicGFnZVRlbXBsYXRlIiwicmF0ZUxpbWl0Iiwicm91dGVTZXR0aW5ncyIsInNjcm9sbEJveFNlbGVjdG9yIiwidGFibGUiLCJ0YWJsZUl0ZW1UZW1wbGF0ZSIsInRhYmxlVGVtcGxhdGUiLCJ0ZW1wbGF0ZU5hbWUiLCJfbkluc3RhbmNlcyIsImNvbGxlY3Rpb25zIiwiaW5zdGFuY2VzIiwibWV0aG9kcyIsInN1YiIsIm4iLCJnZXQiLCJNYXRoIiwiY2VpbCIsIkNvbGxlY3Rpb24iLCJmaW5kIiwiJGFuZCIsImNvdW50IiwiX2siLCJfdiIsImNoYW5nZXMiLCJlcnJvciIsImNoZWNrIiwiV2hlcmUiLCJyZWYiLCJjb25uZWN0aW9uIiwiaWQiLCJfIiwiaXNGdW5jdGlvbiIsIl9zZXQiLCJjaWQiLCJpc1N0cmluZyIsInNldCIsInN1YnMiLCJhcmd1bWVudHMiLCJzdWJzY3JpcHRpb25zIiwic3RvcCIsImNvbGxlY3Rpb24iLCJNZXRlb3IiLCJQYWdpbmF0aW9uIiwiRXJyb3IiLCJpbml0IiwiYmVmb3JlRmlyc3RSZWFkeSIsImRlYnVnIiwiUEFHRVNfREVCVUciLCJwcm9jZXNzIiwiZW52Iiwib3JkZXIiLCJ1c2VyU2V0dGluZ3MiLCJfY3VycmVudFBhZ2UiLCJzZXRDb2xsZWN0aW9uIiwic2V0SW5pdGlhbCIsInNldERlZmF1bHRzIiwic2V0Um91dGVyIiwiaXNTZXJ2ZXIiLCJyZWdpc3Rlckluc3RhbmNlIiwiY29kZSIsIm1zZyIsInNlcnZlckluaXQiLCJzZWxmIiwic2V0TWV0aG9kcyIsIm9uQ29ubmVjdGlvbiIsIl90aGlzIiwib25DbG9zZSIsInB1Ymxpc2giLCJwYWdlIiwiY2FsbCIsImNsaWVudEluaXQiLCJyZXF1ZXN0ZWQiLCJyZWNlaXZlZCIsInF1ZXVlIiwibmV4dFBhZ2VDb3VudCIsIm5vdyIsImdyb3VuZERCIiwiUGFja2FnZSIsInNlc3MiLCJsYXN0T2Zmc2V0SGVpZ2h0Iiwic2V0VGVtcGxhdGVzIiwiVHJhY2tlciIsImF1dG9ydW4iLCJzdGF0dXMiLCJ1c2VySWQiLCJjb3VudFBhZ2VzIiwicmVsb2FkIiwibmFtZSIsIlRlbXBsYXRlIiwib25SZW5kZXJlZCIsInNldEluZmluaXRlVHJpZ2dlciIsInRocm90dGxlIiwidW5zdWJzY3JpYmUiLCJ0b3RhbCIsInAiLCJjdXJyZW50UGFnZSIsInRyYWlsaW5nIiwicmVmMSIsIndpdGhvdXQiLCJyZXN1bHRzIiwicHVzaCIsInN5bmNTZXR0aW5ncyIsImNiIiwiUyIsImJpbmQiLCJmIiwibm0iLCJnZXRNZXRob2ROYW1lIiwiYXJnIiwiciIsImFwcGx5IiwiYXJncyIsImxhc3QiLCJTZXNzaW9uIiwic2V0dGluZyIsImNvbm5lY3Rpb25JZCIsImNoIiwib3B0cyIsImlzT2JqZWN0IiwiaXNDbGllbnQiLCJzZXRJbml0RG9uZSIsInNhbml0aXplUmVnZXgiLCJsaXMiLCJpc1JlZ0V4cCIsInRvU3RyaW5nIiwibGFzdEluZGV4T2YiLCIkcmVnZXgiLCIkb3B0aW9ucyIsInNhbml0aXplUmVnZXhPYmoiLCJvYmoiLCJiYXNlIiwibmFtZTEiLCJvbGRWIiwicmVmMiIsInZhbHVlc0VxdWFsIiwidjEiLCJ2MiIsImlzRXF1YWwiLCJzZXRJZCIsIm1hdGNoIiwicGFyc2VJbnQiLCJfbmFtZSIsIk1vbmdvIiwibGlua1RvIiwicGFyYW1zIiwiUm91dGVyIiwiY3VycmVudCIsInJvdXRlcyIsInBhdGgiLCJwciIsInQiLCJtYXAiLCJociIsImoiLCJsZW4iLCJ0ZW1wbGF0ZSIsImxheW91dFRlbXBsYXRlIiwib25CZWZvcmVBY3Rpb24iLCJub25yZWFjdGl2ZSIsIm9uTmF2Q2xpY2siLCJuZXh0IiwiRmFzdFJlbmRlciIsInN1YnNjcmliZSIsImlzRW1wdHkiLCJpc1JlYWR5Iiwib2JqZWN0Iiwic2V0UGVyUGFnZSIsImhlbHBlcnMiLCJ0biIsIkJsYXplIiwicmVuZGVyRnVuY3Rpb24iLCJfX2V2ZW50TWFwcyIsImNvbmNhdCIsInBhZ2VzRGF0YSIsImVhY2giLCJfX2hlbHBlcnMiLCJoZWxwZXIiLCJwYWdlc05hdiIsInBhZ2VzIiwiY29ubmVjdGVkIiwiZmluZE9uZSIsInNldFRvdGFsUGFnZXMiLCJzZXRUaW1lb3V0IiwiZW5mb3JjZVN1YnNjcmlwdGlvbkxpbWl0IiwiYyIsImhhbmRsZSIsImhhbmRsZTIiLCJxdWVyeSIsInMiLCJyZWFkeSIsIm9wdGlvbnMiLCJza2lwIiwicmVhbEZpbHRlcnMiLCJuUHVibGlzaGVkUGFnZXMiLCJsaW1pdCIsImlzTnVtYmVyIiwiaXNBcnJheSIsImZldGNoIiwiRUpTT04iLCJlcXVhbHMiLCJvYnNlcnZlIiwiYWRkZWRBdCIsImRvYyIsImF0IiwiX2lkIiwiZm9yRWFjaCIsIm8iLCJhZGRlZCIsImNoYW5nZWQiLCJvYnNlcnZlQ2hhbmdlcyIsIm1vdmVkQmVmb3JlIiwiYmVmb3JlIiwicmVtb3ZlZCIsImluZGV4IiwiY3Vyc29yIiwib25TdG9wIiwibG9hZGluZyIsIkRhdGUiLCJnZXRUaW1lIiwiYSIsImxvZ1JlcXVlc3QiLCJ0aW1lTGFzdFJlcXVlc3QiLCJyZXF1ZXN0aW5nIiwibG9nUmVzcG9uc2UiLCJjbGVhclF1ZXVlIiwibmVpZ2hib3JzIiwiZCIsIm1heE1hcmdpbiIsIm5wIiwicHAiLCJmbG9vciIsIm1pbiIsInF1ZXVlTmVpZ2hib3JzIiwicGFnaW5hdGlvbk5hdkl0ZW0iLCJsYWJlbCIsImRpc2FibGVkIiwiYWN0aXZlIiwibmF2aWdhdGlvbk5laWdoYm9ycyIsImZyb20iLCJtIiwidG8iLCJjcCIsIndpbmRvdyIsInNjcm9sbEJveCIsIiQiLCJzY3JvbGwiLCJvaCIsInNjcm9sbEhlaWdodCIsInNjcm9sbFRvcCIsIm9mZnNldEhlaWdodCIsImNoZWNrUXVldWUiLCJyZXN1bHRzMSIsInJlcXVlc3RQYWdlIiwic2hpZnQiLCJjaGVja0luaXRQYWdlIiwiZ2V0TmFtZSIsImxvY2F0aW9uIiwiaHJlZiIsImdldFBhZ2UiLCJvblBhZ2UiLCJkZWZlciIsIm9uUmVhZHkiLCJvbkVycm9yIiwibWVzc2FnZSIsImxhc3RQYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBQUEsS0FBQTtBQUFBLElBQUFDLFFBQUEsR0FBQUEsS0FBQTtBQUFBLElDRUVDLFVBQVUsR0FBR0EsT0FBSCxJQUFjLFVBQVNDLElBQVQsRUFBZTtBQUFFLE9BQUssSUFBSUMsSUFBSSxDQUFSLEVBQVdDLElBQUksS0FBS0MsTUFBekIsRUFBaUNGLElBQUlDLENBQXJDLEVBQXdDRCxHQUF4QyxFQUE2QztBQUFFLFFBQUlBLEtBQUssSUFBTCxJQUFhLEtBQUtBLENBQUwsTUFBWUQsSUFBN0IsRUFBbUMsT0FBT0MsQ0FBUDtBQUFXOztBQUFDLFNBQU8sQ0FBQyxDQUFSO0FBQVksQ0RGcko7O0FBQUEsS0FBQ0csT0FBRCxHQUFpQlAsUUFBQTtBQ0tmQSxRQUFNUSxTQUFOLENESEFDLFFDR0EsR0RDRTtBQUFBQyxnQkFBWSxDQUFDLElBQUQsRUFBT0MsTUFBUCxFQUFlLENBQWYsQ0FBWjtBQUNBQyxnQkFBWSxDQUFDLElBQUQsRUFBT0MsTUFBTUMsS0FBTixDQUNqQkQsTUFBTUUsUUFBTixDQUFlQyxNQUFmLENBRGlCLEVBRWpCSCxNQUFNRSxRQUFOLENBQWVFLE9BQWYsQ0FGaUIsQ0FBUCxFQUdULFdBSFMsQ0FEWjtBQUtBQyxZQUFRLENBQUMsSUFBRCxFQUFPQyxNQUFQLEVBQWUsRUFBZixDQUxSO0FBTUFDLGFBQVMsQ0FBQyxJQUFELEVBQU9ELE1BQVAsRUFBZSxFQUFmLENBTlQ7QUFPQUUsa0JBQWMsQ0FBQyxJQUFELEVBQU9MLE1BQVAsRUFBZSxtQkFBZixDQVBkO0FBUUFNLGtCQUFjLENBQUMsSUFBRCxFQUFPTCxPQUFQLEVBQWdCLEtBQWhCLENBUmQ7QUFTQU0sa0JBQWMsQ0FBQyxJQUFELEVBQU9OLE9BQVAsRUFBZ0IsSUFBaEIsQ0FUZDtBQVVBTyxpQkFBYSxDQUFDLElBQUQsRUFBT1AsT0FBUCxFQUFnQixJQUFoQixDQVZiO0FBV0FRLG1CQUFlLENBQUMsSUFBRCxFQUFPUixPQUFQLEVBQWdCLEtBQWhCLENBWGY7QUFZQVMsc0JBQWtCLENBQUMsSUFBRCxFQUFPZixNQUFQLEVBQWUsQ0FBZixDQVpsQjtBQWFBZ0IsYUFBUyxDQUFDLElBQUQsRUFBT2hCLE1BQVAsRUFBZSxFQUFmLENBYlQ7QUFlQWlCLFdBQU8sQ0FBQyxJQUFELEVBQU9aLE1BQVAsRUFBZSxRQUFmLENBZlA7QUFnQkFhLFlBQVEsQ0FBQyxJQUFELEVBQU9oQixNQUFNRSxRQUFOLENBQWVDLE1BQWYsQ0FBUCxFQUErQixNQUEvQixDQWhCUjtBQWlCQWMsb0JBQWdCLENBQUMsSUFBRCxFQUFPZCxNQUFQLEVBQWUsT0FBZixDQWpCaEI7QUFrQkFlLGtCQUFjLENBQUMsSUFBRCxFQUFPbEIsTUFBTUUsUUFBTixDQUFlQyxNQUFmLENBQVAsRUFBK0IsTUFBL0IsQ0FsQmQ7QUFtQkFnQixVQUFNLENBQUMsSUFBRCxFQUFPYixNQUFQLEVBQWUsRUFBZixDQW5CTjtBQXVCQWMsVUFBTSxDQUFDLEtBQUQsRUFBUXBCLE1BQU1FLFFBQU4sQ0FBZW1CLFFBQWYsQ0FBUixFQUFrQyxNQUFsQyxDQXZCTjtBQXdCQUMsdUJBQW1CLENBQUMsS0FBRCxFQUFRaEIsTUFBUixFQUFnQixFQUFoQixDQXhCbkI7QUF5QkFpQixnQkFBWSxDQUFDLEtBQUQsRUFBUW5CLE9BQVIsRUFBaUIsS0FBakIsQ0F6Qlo7QUEwQkFvQixlQUFXLENBQUMsS0FBRCxFQUFReEIsTUFBTUMsS0FBTixDQUFZRSxNQUFaLEVBQW9Cc0IsS0FBcEIsRUFBMkJyQixPQUEzQixDQUFSLEVBQTZDLEdBQTdDLENBMUJYO0FBMkJBc0IsY0FBVSxDQUFDLEtBQUQsRUFBUXRCLE9BQVIsRUFBaUIsS0FBakIsQ0EzQlY7QUE0QkF1Qix3QkFBb0IsQ0FBQyxLQUFELEVBQVE3QixNQUFSLEVBQWdCLEtBQWhCLENBNUJwQjtBQTZCQThCLHFCQUFpQixDQUFDLEtBQUQsRUFBUTlCLE1BQVIsRUFBZ0IsRUFBaEIsQ0E3QmpCO0FBOEJBK0IsdUJBQW1CLENBQUMsS0FBRCxFQUFRL0IsTUFBUixFQUFnQixDQUFoQixDQTlCbkI7QUErQkFnQyxrQkFBYyxDQUFDLEtBQUQsRUFBUWhDLE1BQVIsRUFBZ0IsRUFBaEIsQ0EvQmQ7QUFnQ0FpQyxjQUFVLENBQUMsS0FBRCxFQUFRakMsTUFBUixFQUFnQixDQUFoQixDQWhDVjtBQWlDQWtDLHNCQUFrQixDQUFDLEtBQUQsRUFBUWxDLE1BQVIsRUFBZ0IsRUFBaEIsQ0FqQ2xCO0FBa0NBbUMsaUJBQWEsQ0FBQyxLQUFELEVBQVE5QixNQUFSLEVBQWdCLGVBQWhCLENBbENiO0FBbUNBK0IscUJBQWlCLENBQUMsS0FBRCxFQUFRYixRQUFSLEVBQWtCLFVBQUNjLENBQUQsRUFBSUMsQ0FBSixFQUFPQyxDQUFQO0FDTC9CLGFBQU8sT0FBT0MsT0FBUCxLQUFtQixXQUFuQixJQUFrQ0EsWUFBWSxJQUE5QyxHREtxQ0EsUUFBU0MsR0FBVCxDQUFhLGNBQVlKLENBQVosR0FBYyxlQUEzQixDQ0xyQyxHREtxQyxNQ0w1QztBREthLE1BbkNqQjtBQW9DQUssd0JBQW9CLENBQUMsS0FBRCxFQUFRMUMsTUFBUixFQUFnQixLQUFoQixDQXBDcEI7QUFxQ0EyQyxtQkFBZSxDQUFDLEtBQUQsRUFBUTNDLE1BQVIsRUFBZ0IsRUFBaEIsQ0FyQ2Y7QUFzQ0E0QyxrQkFBYyxDQUFDLEtBQUQsRUFBUXZDLE1BQVIsRUFBZ0IsZ0JBQWhCLENBdENkO0FBdUNBd0MsZUFBVyxDQUFDLEtBQUQsRUFBUTdDLE1BQVIsRUFBZ0IsQ0FBaEIsQ0F2Q1g7QUF3Q0E4QyxtQkFBZSxDQUFDLEtBQUQsRUFBUTVDLE1BQU1FLFFBQU4sQ0FBZW1CLFFBQWYsQ0FBUixFQUFrQyxNQUFsQyxDQXhDZjtBQXlDQXdCLHVCQUFtQixDQUFFMUMsTUFBRixFQUFVLE1BQVYsQ0F6Q25CO0FBMENBMkMsV0FBTyxDQUFDLEtBQUQsRUFBUTlDLE1BQU1DLEtBQU4sQ0FBWUcsT0FBWixFQUFxQkUsTUFBckIsQ0FBUixFQUFzQyxLQUF0QyxDQTFDUDtBQTJDQXlDLHVCQUFtQixDQUFDLEtBQUQsRUFBUTVDLE1BQVIsRUFBZ0IsaUJBQWhCLENBM0NuQjtBQTRDQTZDLG1CQUFlLENBQUMsS0FBRCxFQUFRN0MsTUFBUixFQUFnQixhQUFoQixDQTVDZjtBQTZDQThDLGtCQUFjLENBQUMsS0FBRCxFQUFRakQsTUFBTUUsUUFBTixDQUFlQyxNQUFmLENBQVIsRUFBZ0MsTUFBaEM7QUE3Q2QsR0NERjtBQThDQWhCLFFBQU1RLFNBQU4sQ0RJQXVELFdDSkEsR0RJYSxDQ0piO0FBRUEvRCxRQUFNUSxTQUFOLENER0F3RCxXQ0hBLEdER2EsRUNIYjtBQUVBaEUsUUFBTVEsU0FBTixDREVBeUQsU0NGQSxHREVXLEVDRlg7QUFFQWpFLFFBQU1RLFNBQU4sQ0RFQTBELE9DRkEsR0RJRTtBQUFBLGtCQUFjLFVBQUNDLEdBQUQ7QUFDWixVQUFBQyxDQUFBO0FBQUFBLFVBQUlELElBQUlFLEdBQUosQ0FBUSxpQkFBUixDQUFKOztBQUNBLFVBQWFELEtBQUEsSUFBYjtBQUFBLGVBQU9BLENBQVA7QUNBQzs7QURFREEsVUFBSUUsS0FBS0MsSUFBTCxDQUFVLEtBQUNDLFVBQUQsQ0FBWUMsSUFBWixDQUNaO0FBQUFDLGNBQU0sQ0FDSlAsSUFBSUUsR0FBSixDQUFRLFNBQVIsQ0FESSxFQUVKRixJQUFJRSxHQUFKLENBQVEsYUFBUixLQUEwQixFQUZ0QjtBQUFOLE9BRFksRUFLWk0sS0FMWSxLQUtEUixJQUFJRSxHQUFKLENBQVEsU0FBUixDQUxULENBQUo7QUNFQSxhRElBRCxLQUFLLENDSkw7QURORjtBQVlBLFdBQU8sVUFBQ3BCLENBQUQsRUFBSUMsQ0FBSixFQUFPa0IsR0FBUDtBQUNMLFVBQUFTLEVBQUEsRUFBQUMsRUFBQSxFQUFBQyxPQUFBOztBQUFBLFVBQUksS0FBQXJFLFFBQUEsQ0FBQXVDLENBQUEsU0FBSjtBQUNFLGFBQUMrQixLQUFELENBQU8sZ0JBQVAsRUFBeUIsMEJBQXdCL0IsQ0FBeEIsR0FBMEIsR0FBbkQ7QUNGRDs7QURHRGdDLFlBQU1oQyxDQUFOLEVBQVNoQyxNQUFUO0FBQ0FnRSxZQUFNL0IsQ0FBTixFQUFTLEtBQUN4QyxRQUFELENBQVV1QyxDQUFWLEVBQWEsQ0FBYixDQUFUO0FBQ0FnQyxZQUFNYixHQUFOLEVBQVd0RCxNQUFNb0UsS0FBTixDQUFZLFVBQUNkLEdBQUQ7QUFDckIsWUFBQWUsR0FBQTtBQ0RBLGVEQ0EsRUFBQUEsTUFBQWYsSUFBQWdCLFVBQUEsWUFBQUQsSUFBQUUsRUFBQSxrQkNEQTtBREFTLFFBQVg7O0FBR0EsVUFBRyxDQUFDLEtBQUNqRCxpQkFBRCxDQUFtQmEsQ0FBbkIsQ0FBRCxJQUEyQnFDLEVBQUVDLFVBQUYsQ0FBYSxLQUFDbkQsaUJBQUQsQ0FBbUJhLENBQW5CLENBQWIsS0FBd0MsQ0FBQyxLQUFDYixpQkFBRCxDQUFtQmEsQ0FBbkIsRUFBc0JDLENBQXRCLEVBQXlCa0IsR0FBekIsQ0FBdkU7QUFDRSxhQUFDWSxLQUFELENBQU8sa0JBQVAsRUFBMkIsY0FBWS9CLENBQVosR0FBYyxlQUF6QztBQ0FEOztBREVEOEIsZ0JBQVUsQ0FBVjs7QUFDQSxVQUFHN0IsS0FBQSxJQUFIO0FBQ0U2QixrQkFBVSxLQUFDUyxJQUFELENBQU12QyxDQUFOLEVBQVNDLENBQVQsRUFBWTtBQUFBdUMsZUFBS3JCLElBQUlnQixVQUFKLENBQWVDO0FBQXBCLFNBQVosQ0FBVjtBQURGLGFBRUssSUFBRyxDQUFDQyxFQUFFSSxRQUFGLENBQVd6QyxDQUFYLENBQUo7QUFDSCxhQUFBNEIsRUFBQSwyQ0FBQTVCLENBQUE7QUNFRTZCLGVBQUs3QixFQUFFNEIsRUFBRixDQUFMO0FEREFFLHFCQUFXLEtBQUNZLEdBQUQsQ0FBS2QsRUFBTCxFQUFTQyxFQUFULEVBQWE7QUFBQVcsaUJBQUtyQixJQUFJZ0IsVUFBSixDQUFlQztBQUFwQixXQUFiLENBQVg7QUFGQztBQ1FKOztBQUNELGFETkFOLE9DTUE7QURuQ0Y7QUErQkEsbUJBQWU7QUFDYixVQUFBVSxHQUFBLEVBQUF4QyxDQUFBLEVBQUFrQyxHQUFBLEVBQUFmLEdBQUEsRUFBQXdCLElBQUE7QUFBQUgsWUFBTUksVUFBVUEsVUFBVXRGLE1BQVYsR0FBbUIsQ0FBN0IsRUFBZ0M2RSxVQUFoQyxDQUEyQ0MsRUFBakQ7QUFDQU8sYUFBTyxFQUFQO0FBQ0FULFlBQUEsS0FBQVcsYUFBQTs7QUFBQSxXQUFBN0MsQ0FBQSwyQ0FBQWtDLEdBQUE7QUNTRWYsY0FBTWUsSUFBSWxDLENBQUosQ0FBTjs7QURSQSxZQUFhQSxNQUFNLFFBQU4sSUFBQUEsTUFBZ0IsT0FBN0I7QUFBQTtBQ1dDOztBRFZELFlBQUdtQixJQUFJZ0IsVUFBSixDQUFlQyxFQUFmLEtBQXFCSSxHQUF4QjtBQUNFckIsY0FBSTJCLElBQUo7QUFDQSxpQkFBTyxLQUFDRCxhQUFELENBQWU3QyxDQUFmLENBQVA7QUNZRDtBRGhCSDs7QUFLQSxXQUFDNkMsYUFBRCxDQUFldkYsTUFBZixHQUF3QixDQUF4QjtBQ2NBLGFEYkEsSUNhQTtBRHJERjtBQUFBLEdDSkY7O0FEOENhLFdBQUFOLEtBQUEsQ0FBQytGLFVBQUQsRUFBYXRGLFFBQWI7QUNnQlgsUUFBSUEsWUFBWSxJQUFoQixFQUFzQjtBRGhCRUEsaUJBQVcsRUFBWDtBQ2tCdkI7O0FEakJELFVBQU8sZ0JBQWF1RixPQUFPQyxVQUEzQjtBQUNFLFlBQU0sSUFBSUQsT0FBT0UsS0FBWCxDQUFpQixhQUFqQixFQUFnQywrREFBaEMsQ0FBTjtBQ21CRDs7QURmRCxTQUFDQyxJQUFELEdBQVEsS0FBQ0MsZ0JBQUQsR0FBb0IsSUFBNUI7O0FDaUJBLFFBQUksS0FBS0MsS0FBTCxJQUFjLElBQWxCLEVBQXdCO0FEaEJ4QixXQUFDQSxLQUFELEdBQVcsT0FBQUMsV0FBQSxvQkFBQUEsZ0JBQUEsUUFBaUJBLFdBQWxCLFlBQUFDLE9BQUEsb0JBQUFBLFlBQUEsT0FBa0NBLFFBQVNDLEdBQVQsQ0FBYUYsV0FBL0MsR0FBK0MsTUFBL0MsQ0FBVjtBQ2tCQzs7QURqQkQsU0FBQ1QsYUFBRCxHQUFpQjtBQUFBdkYsY0FBUSxDQUFSO0FBQVdtRyxhQUFPO0FBQWxCLEtBQWpCO0FBQ0EsU0FBQ0MsWUFBRCxHQUFnQixFQUFoQjtBQUNBLFNBQUNDLFlBQUQsR0FBZ0IsQ0FBaEI7QUFJQSxTQUFDQyxhQUFELENBQWViLFVBQWY7QUFDQSxTQUFDYyxVQUFELENBQVlwRyxRQUFaO0FBQ0EsU0FBQ3FHLFdBQUQ7QUFDQSxTQUFDQyxTQUFEO0FBQ0EsU0FBRSxDQUFJZixPQUFPZ0IsUUFBUCxHQUFxQixRQUFyQixHQUFtQyxRQUF2QyxJQUFtRCxNQUFyRDtBQUNBLFNBQUNDLGdCQUFEO0FBQ0E7QUFwQlc7O0FDeUNiakgsUUFBTVEsU0FBTixDRG5CQXVFLEtDbUJBLEdEbkJPLFVBQUNtQyxJQUFELEVBQU9DLEdBQVA7QUFDTCxRQUFnQkQsUUFBQSxJQUFoQjtBQUFBQyxZQUFNRCxJQUFOO0FDcUJDOztBRHBCRCxVQUFNLElBQUlsQixPQUFPRSxLQUFYLENBQWlCZ0IsSUFBakIsRUFBdUJDLEdBQXZCLENBQU47QUFGSyxHQ21CUDs7QUFPQW5ILFFBQU1RLFNBQU4sQ0RwQkE0RyxVQ29CQSxHRHBCWTtBQUNWLFFBQUFDLElBQUE7QUFBQSxTQUFDQyxVQUFEO0FBQ0FELFdBQU8sSUFBUDtBQUlBckIsV0FBT3VCLFlBQVAsQ0FBb0IsVUFBQUMsS0FBQTtBQ21CbEIsYURuQmtCLFVBQUNyQyxVQUFEO0FDb0JoQixlRG5CRkEsV0FBV3NDLE9BQVgsQ0FBbUI7QUNvQmYsaUJEbkJGLE9BQU9ELE1BQUNkLFlBQUQsQ0FBY3ZCLFdBQVdDLEVBQXpCLENDbUJMO0FEcEJKLFVDbUJFO0FEcEJnQixPQ21CbEI7QURuQmtCLFdBQXBCO0FDeUJBLFdEbkJBWSxPQUFPMEIsT0FBUCxDQUFlLEtBQUN0QyxFQUFoQixFQUFvQixVQUFDdUMsSUFBRDtBQ29CbEIsYURuQkFOLEtBQUtLLE9BQUwsQ0FBYUUsSUFBYixDQUFrQlAsSUFBbEIsRUFBd0JNLElBQXhCLEVBQThCLElBQTlCLENDbUJBO0FEcEJGLE1DbUJBO0FEL0JVLEdDb0JaOztBQWdCQTNILFFBQU1RLFNBQU4sQ0RuQkFxSCxVQ21CQSxHRG5CWTtBQUNWLFNBQUNDLFNBQUQsR0FBYSxFQUFiO0FBQ0EsU0FBQ0MsUUFBRCxHQUFZLEVBQVo7QUFDQSxTQUFDQyxLQUFELEdBQVMsRUFBVDtBQUNBLFNBQUNDLGFBQUQsR0FBaUIsS0FBQ0MsR0FBRCxFQUFqQjtBQUNBLFNBQUNDLFFBQUQsR0FBWUMsUUFBQSxvQkFBWjs7QUFDQSxRQUFHLEtBQUM3RixRQUFKO0FBQ0UsV0FBQzhGLElBQUQsQ0FBTSxPQUFOLEVBQWUsRUFBZjtBQUNBLFdBQUNDLGdCQUFELEdBQW9CLENBQXBCO0FDb0JEOztBRG5CRCxRQUFHLEtBQUN6RixnQkFBRCxHQUFvQixDQUF2QjtBQUNFLFdBQUNBLGdCQUFELEdBQW9CLENBQXBCO0FDcUJEOztBRHBCRCxTQUFDMEYsWUFBRDtBQUNBQyxZQUFRQyxPQUFSLENBQWdCLFVBQUFqQixLQUFBO0FDc0JkLGFEdEJjO0FBRWR4QixlQUFPMEMsTUFBUDs7QUNzQkUsWUFBSSxPQUFPMUMsT0FBTzJDLE1BQWQsS0FBeUIsVUFBN0IsRUFBeUM7QURyQjNDM0MsaUJBQU8yQyxNQUFQO0FDdUJHOztBRHRCSG5CLGNBQUNvQixVQUFEOztBQ3dCRSxlRHZCRnBCLE1BQUNxQixNQUFELEVDdUJFO0FENUJZLE9Dc0JkO0FEdEJjLFdBQWhCOztBQytCQSxRQUFJLEtBQUsvRSxZQUFMLElBQXFCLElBQXpCLEVBQStCO0FEekIvQixXQUFDQSxZQUFELEdBQWlCLEtBQUNnRixJQUFsQjtBQzJCQzs7QUFDRCxXRDNCQUMsU0FBUyxLQUFDakYsWUFBVixFQUF3QmtGLFVBQXhCLENBQW1DLFVBQUF4QixLQUFBO0FDNEJqQyxhRDVCaUM7QUFDakMsWUFBeUJBLE1BQUNqRixRQUExQjtBQzZCSSxpQkQ3QkppRixNQUFDeUIsa0JBQUQsRUM2Qkk7QUFDRDtBRC9COEIsT0M0QmpDO0FENUJpQyxXQUFuQyxDQzJCQTtBRDlDVSxHQ21CWjs7QUFvQ0FqSixRQUFNUSxTQUFOLENEL0JBcUksTUMrQkEsR0QvQlF4RCxFQUFFNkQsUUFBRixDQUFXO0FBRWpCLFNBQUNDLFdBQUQ7QUMrQkEsV0Q5QkEsS0FBQ1AsVUFBRCxDQUFZLFVBQUFwQixLQUFBO0FDK0JWLGFEL0JVLFVBQUM0QixLQUFEO0FBQ1YsWUFBQUMsQ0FBQTtBQUFBQSxZQUFJN0IsTUFBQzhCLFdBQUQsRUFBSjs7QUFDQSxZQUFlRCxLQUFBLElBQUwsSUFBWTdCLE1BQUMvRixhQUFiLElBQThCNEgsSUFBSUQsS0FBNUM7QUFBQUMsY0FBSSxDQUFKO0FDa0NHOztBRGpDSDdCLGNBQUNhLElBQUQsQ0FBTSxhQUFOLEVBQXFCLEtBQXJCOztBQ21DRSxlRGxDRmIsTUFBQ2EsSUFBRCxDQUFNLGFBQU4sRUFBcUJnQixDQUFyQixDQ2tDRTtBRHRDUSxPQytCVjtBRC9CVSxXQUFaLENDOEJBO0FEakNNLEtBUU4sSUFSTSxFQVFBO0FBQUFFLGNBQVU7QUFBVixHQVJBLENDK0JSOztBQWlCQXZKLFFBQU1RLFNBQU4sQ0R0Q0EySSxXQ3NDQSxHRHRDYSxVQUFDeEIsSUFBRCxFQUFPbkMsR0FBUDtBQUNYLFFBQUF4QyxDQUFBLEVBQUFrQyxHQUFBLEVBQUFzRSxJQUFBLEVBQUFyRixHQUFBOztBQUFBLFFBQVcsS0FBQ2lDLGdCQUFaO0FBQUE7QUN5Q0M7O0FEdkNELFFBQUl1QixRQUFBLElBQUo7QUFDRXpDLFlBQUEsS0FBQVcsYUFBQTs7QUFBQSxXQUFBN0MsQ0FBQSwyQ0FBQWtDLEdBQUE7QUMwQ0VmLGNBQU1lLElBQUlsQyxDQUFKLENBQU47O0FEekNBLFlBQWFBLE1BQU0sUUFBTixJQUFBQSxNQUFnQixPQUE3QjtBQUFBO0FDNENDOztBRDNDRG1CLFlBQUkyQixJQUFKO0FBQ0EsZUFBTyxLQUFDRCxhQUFELENBQWU3QyxDQUFmLENBQVA7QUFIRjs7QUFJQSxXQUFDNkMsYUFBRCxDQUFldkYsTUFBZixHQUF3QixDQUF4QjtBQUNBLFdBQUNzQyxRQUFELEdBQVksSUFBWjtBQUNBLFdBQUNrRixTQUFELEdBQWEsRUFBYjtBQUNBLFdBQUNDLFFBQUQsR0FBWSxFQUFaO0FBQ0EsV0FBQ0MsS0FBRCxHQUFTLEVBQVQ7QUFURixXQVVLLElBQUdoQyxPQUFPZ0IsUUFBVjtBQUNIaEMsWUFBTVEsR0FBTixFQUFXeEUsTUFBWDs7QUFDQSxXQUFBd0ksT0FBQSxLQUFBM0QsYUFBQSxDQUFBTCxHQUFBLGFBQUFnRSxLQUF3QjdCLElBQXhCLElBQXdCLE1BQXhCO0FBQ0UsYUFBQzlCLGFBQUQsQ0FBZUwsR0FBZixFQUFvQm1DLElBQXBCLEVBQTBCN0IsSUFBMUI7QUFDQSxlQUFPLEtBQUNELGFBQUQsQ0FBZUwsR0FBZixFQUFvQm1DLElBQXBCLENBQVA7QUFDQSxhQUFDOUIsYUFBRCxDQUFldkYsTUFBZjtBQUxDO0FBQUEsV0FNQSxJQUFHLEtBQUN1RixhQUFELENBQWU4QixJQUFmLENBQUg7QUFFSCxXQUFDOUIsYUFBRCxDQUFlOEIsSUFBZixFQUFxQjdCLElBQXJCO0FBQ0EsYUFBTyxLQUFDRCxhQUFELENBQWU4QixJQUFmLENBQVA7QUFDQSxhQUFPLEtBQUNHLFNBQUQsQ0FBV0gsSUFBWCxDQUFQO0FBQ0EsYUFBTyxLQUFDSSxRQUFELENBQVVKLElBQVYsQ0FBUDtBQUNBLFdBQUM5QixhQUFELENBQWVZLEtBQWYsR0FBdUJwQixFQUFFb0UsT0FBRixDQUFVLEtBQUM1RCxhQUFELENBQWVZLEtBQXpCLEVBQWdDOUYsT0FBT2dILElBQVAsQ0FBaEMsQ0FBdkI7QUFDQSxXQUFDOUIsYUFBRCxDQUFldkYsTUFBZjtBQzhDRDs7QUFDRCxXRDlDQSxJQzhDQTtBRHpFVyxHQ3NDYjs7QUFzQ0FOLFFBQU1RLFNBQU4sQ0QvQ0FzRyxXQytDQSxHRC9DYTtBQUNYLFFBQUE5RCxDQUFBLEVBQUFrQyxHQUFBLEVBQUF3RSxPQUFBLEVBQUF6RyxDQUFBO0FBQUFpQyxVQUFBLEtBQUF6RSxRQUFBO0FBQUFpSixjQUFBOztBQ2tEQSxTRGxEQTFHLENDa0RBLDJDRGxEQWtDLEdDa0RBLEdEbERBO0FDbURFakMsVUFBSWlDLElBQUlsQyxDQUFKLENBQUo7O0FEbERBLFVBQUdDLEVBQUEsVUFBSDtBQ29ERXlHLGdCQUFRQyxJQUFSLENBQWEsS0FBSzNHLENBQUwsS0FBVyxJQUFYLEdEbkRiLEtBQUVBLENBQUYsQ0NtRGEsR0RuRGIsS0FBRUEsQ0FBRixJQUFRQyxFQUFFLENBQUYsQ0NtRFI7QURwREY7QUNzREV5RyxnQkFBUUMsSUFBUixDQUFhLEtBQUssQ0FBbEI7QUFDRDtBRHhESDs7QUMwREEsV0FBT0QsT0FBUDtBRDNEVyxHQytDYjs7QUFlQTFKLFFBQU1RLFNBQU4sQ0R6REFvSixZQ3lEQSxHRHpEYyxVQUFDQyxFQUFEO0FBQ1osUUFBQUMsQ0FBQSxFQUFBOUcsQ0FBQSxFQUFBa0MsR0FBQSxFQUFBakMsQ0FBQTtBQUFBNkcsUUFBSSxFQUFKO0FBQ0E1RSxVQUFBLEtBQUF6RSxRQUFBOztBQUFBLFNBQUF1QyxDQUFBLDJDQUFBa0MsR0FBQTtBQzRERWpDLFVBQUlpQyxJQUFJbEMsQ0FBSixDQUFKOztBRDNEQSxVQUFHQyxFQUFFLENBQUYsQ0FBSDtBQUNFNkcsVUFBRTlHLENBQUYsSUFBTyxLQUFFQSxDQUFGLENBQVA7QUM2REQ7QUQvREg7O0FDaUVBLFdEOURBLEtBQUMwQyxHQUFELENBQUtvRSxDQUFMLEVBQVdELE1BQUEsT0FBUztBQUFDQSxVQUFJQSxHQUFHRSxJQUFILENBQVEsSUFBUjtBQUFMLEtBQVQsR0FBK0IsSUFBMUMsQ0M4REE7QURuRVksR0N5RGQ7O0FBZUEvSixRQUFNUSxTQUFOLENEL0RBOEcsVUMrREEsR0QvRFk7QUFDVixRQUFBMEMsQ0FBQSxFQUFBNUYsQ0FBQSxFQUFBNkYsRUFBQSxFQUFBL0UsR0FBQSxFQUFBbUMsSUFBQTtBQUFBNEMsU0FBSyxFQUFMO0FBQ0E1QyxXQUFPLElBQVA7QUFDQW5DLFVBQUEsS0FBQWhCLE9BQUE7O0FBQUEsU0FBQUUsQ0FBQSwyQ0FBQWMsR0FBQTtBQ2tFRThFLFVBQUk5RSxJQUFJZCxDQUFKLENBQUo7O0FEakVBNkYsU0FBRyxLQUFDQyxhQUFELENBQWU5RixDQUFmLENBQUgsSUFBd0IsVUFBQzRGLENBQUQ7QUNtRXRCLGVEbEVBO0FBQ0UsY0FBQUcsR0FBQSxFQUFBbkgsQ0FBQSxFQUFBb0gsQ0FBQSxFQUFBbkgsQ0FBQTs7QUFBQWtILGdCQUFBO0FDb0VFLGdCQUFJVCxPQUFKO0FEcEVLQSxzQkFBQTs7QUNzRUwsaUJEdEVLMUcsQ0NzRUwsMkNEdEVLNEMsU0NzRUwsR0R0RUs7QUN1RUgzQyxrQkFBSTJDLFVBQVU1QyxDQUFWLENBQUo7QUFDQTBHLHNCQUFRQyxJQUFSLENEeEVHMUcsQ0N3RUg7QUR4RUc7O0FDMEVMLG1CQUFPeUcsT0FBUDtBQUNELFdEM0VELENDMkVHVyxLRDNFSCxDQzJFUyxJRDNFVCxFQzJFZXpFLFNEM0VmOztBQUNBdUUsY0FBSVIsSUFBSixDQUFTLElBQVQ7QUFDQSxlQUFDdEYsR0FBRCxHQUFPZ0IsRUFBRTBFLElBQUYsQ0FBUSxVQUFDMUMsSUFBRCxFQUFPckUsQ0FBUDtBQzRFYixtQkQ1RTBCcUUsS0FBS2hELEdBQUwsQ0FBU3JCLENBQVQsRUFBWSxLQUFDbUMsVUFBRCxDQUFZQyxFQUF4QixDQzRFMUI7QUQ1RVksV0FBUCxFQUFrRCxJQUFsRCxFQUFxRGlDLElBQXJELENBQVA7QUFDQStDLGNBQUlKLEVBQUVLLEtBQUYsQ0FBUWhELElBQVIsRUFBYzhDLEdBQWQsQ0FBSjtBQzhFQSxpQkQ3RUFDLENDNkVBO0FEbEZGLFNDa0VBO0FEbkVxQixRQU9yQkosQ0FQcUIsQ0FBdkI7QUFERjs7QUN3RkEsV0Q5RUFoRSxPQUFPOUIsT0FBUCxDQUFlK0YsRUFBZixDQzhFQTtBRDNGVSxHQytEWjs7QUErQkFqSyxRQUFNUSxTQUFOLENEN0VBMEosYUM2RUEsR0Q3RWUsVUFBQ3BCLElBQUQ7QUM4RWIsV0Q3RUcsS0FBQzFELEVBQUQsR0FBSSxHQUFKLEdBQU8wRCxJQzZFVjtBRDlFYSxHQzZFZjs7QUFJQTlJLFFBQU1RLFNBQU4sQ0QzRUFvSCxJQzJFQSxHRDNFTTtBQUNKLFFBQUEwQyxJQUFBLEVBQUFDLElBQUE7QUFES0QsV0FBQSxLQUFBMUUsVUFBQXRGLE1BQUEsR0FBQUwsTUFBQTJILElBQUEsQ0FBQWhDLFNBQUE7QUFDTFosVUFBTXNGLElBQU4sRUFBWWhJLEtBQVo7O0FBQ0EsUUFBR2dJLEtBQUtoSyxNQUFMLEdBQWMsQ0FBakI7QUFDRSxXQUFDeUUsS0FBRCxDQUFPLHFCQUFQLEVBQThCLDRDQUE5QjtBQzhFRDs7QUQ3RUR1RixTQUFLLENBQUwsSUFBVSxLQUFDSixhQUFELENBQWVJLEtBQUssQ0FBTCxDQUFmLENBQVY7QUFDQUMsV0FBT0QsS0FBS2hLLE1BQUwsR0FBYyxDQUFyQjs7QUFDQSxRQUFHK0UsRUFBRUMsVUFBRixDQUFhZ0YsS0FBS0MsSUFBTCxDQUFiLENBQUg7QUFDRUQsV0FBS0MsSUFBTCxJQUFhRCxLQUFLQyxJQUFMLEVBQVdSLElBQVgsQ0FBZ0IsSUFBaEIsQ0FBYjtBQytFRDs7QUFDRCxXRC9FQS9ELE9BQU80QixJQUFQLENBQVl5QyxLQUFaLENBQWtCLElBQWxCLEVBQXFCQyxJQUFyQixDQytFQTtBRHZGSSxHQzJFTjs7QUFlQXRLLFFBQU1RLFNBQU4sQ0Q5RUE2SCxJQzhFQSxHRDlFTSxVQUFDckYsQ0FBRCxFQUFJQyxDQUFKO0FBQ0osUUFBWSxPQUFBdUgsT0FBQSxvQkFBQUEsWUFBQSxJQUFaO0FBQUE7QUNnRkM7O0FEL0VEeEgsUUFBTyxLQUFDb0MsRUFBRCxHQUFJLEdBQUosR0FBT3BDLENBQWQ7O0FBQ0EsUUFBRzRDLFVBQVV0RixNQUFWLEtBQW9CLENBQXZCO0FDaUZFLGFEaEZBa0ssUUFBUTlFLEdBQVIsQ0FBWTFDLENBQVosRUFBZUMsQ0FBZixDQ2dGQTtBRGpGRjtBQ21GRSxhRGhGQXVILFFBQVFuRyxHQUFSLENBQVlyQixDQUFaLENDZ0ZBO0FBQ0Q7QUR2RkcsR0M4RU47O0FBWUFoRCxRQUFNUSxTQUFOLENEN0VBNkQsR0M2RUEsR0Q3RUssVUFBQ29HLE9BQUQsRUFBVUMsWUFBVjtBQUNILFFBQUF4RixHQUFBLEVBQUFzRSxJQUFBO0FDOEVBLFdBQU8sQ0FBQ3RFLE1BQU0sQ0FBQ3NFLE9BQU8sS0FBSzlDLFlBQUwsQ0FBa0JnRSxZQUFsQixDQUFSLEtBQTRDLElBQTVDLEdBQW1EbEIsS0FBS2lCLE9BQUwsQ0FBbkQsR0FBbUUsS0FBSyxDQUEvRSxLQUFxRixJQUFyRixHQUE0RnZGLEdBQTVGLEdEOUVpQyxLQUFFdUYsT0FBRixDQzhFeEM7QUQvRUcsR0M2RUw7O0FBS0F6SyxRQUFNUSxTQUFOLENEN0VBa0YsR0M2RUEsR0Q3RUs7QUFDSCxRQUFBZCxFQUFBLEVBQUFDLEVBQUEsRUFBQThGLEVBQUEsRUFBQTNILENBQUEsRUFBQTRILElBQUE7O0FBREk1SCxRQUFBNEMsVUFBQSxJQUFHZ0YsT0FBQSxLQUFBaEYsVUFBQXRGLE1BQUEsR0FBQUwsTUFBQTJILElBQUEsQ0FBQWhDLFNBQUEsU0FBSDtBQUNKK0UsU0FBSyxDQUFMOztBQUNBLFlBQU9DLEtBQUt0SyxNQUFaO0FBQUEsV0FDTyxDQURQO0FBR0ksWUFBRytFLEVBQUV3RixRQUFGLENBQVc3SCxDQUFYLENBQUg7QUFDRSxlQUFBNEIsRUFBQSwyQ0FBQTVCLENBQUE7QUMrRUU2QixpQkFBSzdCLEVBQUU0QixFQUFGLENBQUw7QUQ5RUErRixrQkFBTSxLQUFDcEYsSUFBRCxDQUFNWCxFQUFOLEVBQVVDLEVBQVYsQ0FBTjtBQUZKO0FDbUZDOztBRHJGRTs7QUFEUCxXQU1PLENBTlA7QUFPSSxZQUFHUSxFQUFFd0YsUUFBRixDQUFXN0gsQ0FBWCxDQUFIO0FBR0UsY0FBR3FDLEVBQUVDLFVBQUYsQ0FBYXNGLEtBQUssQ0FBTCxDQUFiLENBQUg7QUFDRUEsaUJBQUssQ0FBTCxJQUFVO0FBQUFmLGtCQUFJZSxLQUFLLENBQUw7QUFBSixhQUFWO0FDbUZEOztBRGxGRCxlQUFBaEcsRUFBQSwyQ0FBQTVCLENBQUE7QUNvRkU2QixpQkFBSzdCLEVBQUU0QixFQUFGLENBQUw7QURuRkErRixrQkFBTSxLQUFDcEYsSUFBRCxDQUFNWCxFQUFOLEVBQVVDLEVBQVYsRUFBYytGLEtBQUssQ0FBTCxDQUFkLENBQU47QUFOSjtBQUFBO0FBU0U1RixnQkFBTWhDLENBQU4sRUFBU2hDLE1BQVQ7QUFDQTJKLGVBQUssS0FBQ3BGLElBQUQsQ0FBTXZDLENBQU4sRUFBUzRILEtBQUssQ0FBTCxDQUFULENBQUw7QUNxRkQ7O0FEaEdFOztBQU5QLFdBa0JPLENBbEJQO0FBb0JJLFlBQUd2RixFQUFFQyxVQUFGLENBQWFzRixLQUFLLENBQUwsQ0FBYixDQUFIO0FBQ0VBLGVBQUssQ0FBTCxJQUFVO0FBQUFmLGdCQUFJZSxLQUFLLENBQUw7QUFBSixXQUFWO0FDd0ZEOztBRHZGREQsYUFBSyxLQUFDcEYsSUFBRCxDQUFNdkMsQ0FBTixFQUFTNEgsS0FBSyxDQUFMLENBQVQsRUFBa0JBLEtBQUssQ0FBTCxDQUFsQixDQUFMO0FBSkc7O0FBbEJQLFdBdUJPLENBdkJQO0FBd0JJNUYsY0FBTTRGLEtBQUssQ0FBTCxDQUFOLEVBQWV6SixNQUFmO0FBQ0E2RCxjQUFNNEYsS0FBSyxDQUFMLENBQU4sRUFBZTFJLFFBQWY7QUFDQTBJLGFBQUssQ0FBTCxJQUFVO0FBQUFmLGNBQUllLEtBQUssQ0FBTDtBQUFKLFNBQVY7QUFDQUQsYUFBSyxLQUFDcEYsSUFBRCxDQUFNdkMsQ0FBTixFQUFTNEgsS0FBSyxDQUFMLENBQVQsRUFBa0JBLEtBQUssQ0FBTCxDQUFsQixDQUFMO0FBM0JKOztBQTRCQSxRQUFHNUUsT0FBTzhFLFFBQVAsSUFBb0JILEVBQXZCO0FBQ0UsV0FBQzlCLE1BQUQ7QUM2RkQ7O0FBQ0QsV0Q3RkE4QixFQzZGQTtBRDdIRyxHQzZFTDs7QUFtREEzSyxRQUFNUSxTQUFOLENEOUZBcUcsVUM4RkEsR0Q5RlksVUFBQ3BHLFFBQUQ7QUFDVixTQUFDc0ssV0FBRCxHQUFlLEtBQWY7QUFDQSxTQUFDckYsR0FBRCxDQUFLakYsUUFBTDtBQytGQSxXRDlGQSxLQUFDc0ssV0FBRCxHQUFlLElDOEZmO0FEakdVLEdDOEZaOztBQU1BL0ssUUFBTVEsU0FBTixDRDdGQXdLLGFDNkZBLEdEN0ZlLFVBQUMvSCxDQUFEO0FBQ2IsUUFBQWdJLEdBQUE7O0FBQUEsUUFBRzVGLEVBQUU2RixRQUFGLENBQVdqSSxDQUFYLENBQUg7QUFDRUEsVUFBSUEsRUFBRWtJLFFBQUYsRUFBSjtBQUNBRixZQUFNaEksRUFBRW1JLFdBQUYsQ0FBYyxHQUFkLENBQU47QUFDQW5JLFVBQUk7QUFBQW9JLGdCQUFRcEksRUFBRWhELEtBQUYsQ0FBRSxDQUFGLEVBQUVnTCxHQUFGLENBQVI7QUFBc0JLLGtCQUFVckksRUFBRWhELEtBQUYsQ0FBRSxJQUFBZ0wsR0FBRjtBQUFoQyxPQUFKO0FDa0dEOztBQUNELFdEbEdBaEksQ0NrR0E7QUR2R2EsR0M2RmY7O0FBYUFqRCxRQUFNUSxTQUFOLENEakdBK0ssZ0JDaUdBLEdEakdrQixVQUFDQyxHQUFEO0FBQ2hCLFFBQUF4SSxDQUFBLEVBQUFDLENBQUE7O0FBQUEsUUFBR29DLEVBQUU2RixRQUFGLENBQVdNLEdBQVgsQ0FBSDtBQUNFLGFBQU8sS0FBQ1IsYUFBRCxDQUFlUSxHQUFmLENBQVA7QUNtR0Q7O0FEbEdELFNBQUF4SSxDQUFBLDJDQUFBd0ksR0FBQTtBQ29HRXZJLFVBQUl1SSxJQUFJeEksQ0FBSixDQUFKOztBRG5HQSxVQUFHcUMsRUFBRTZGLFFBQUYsQ0FBV2pJLENBQVgsQ0FBSDtBQUNFdUksWUFBSXhJLENBQUosSUFBUyxLQUFDZ0ksYUFBRCxDQUFlL0gsQ0FBZixDQUFUO0FBREYsYUFFSyxJQUFHLHFCQUFtQkEsQ0FBbkIseUNBQW1CQSxDQUFuQixFQUFIO0FBQ0h1SSxZQUFJeEksQ0FBSixJQUFTLEtBQUN1SSxnQkFBRCxDQUFrQnRJLENBQWxCLENBQVQ7QUNxR0Q7QUR6R0g7O0FDMkdBLFdEdEdBdUksR0NzR0E7QUQ5R2dCLEdDaUdsQjs7QUFnQkF4TCxRQUFNUSxTQUFOLENEckdBK0UsSUNxR0EsR0RyR00sVUFBQ3ZDLENBQUQsRUFBSUMsQ0FBSixFQUFPMkgsSUFBUDtBQUNKLFFBQUFhLElBQUEsRUFBQWQsRUFBQSxFQUFBZSxLQUFBLEVBQUFDLElBQUEsRUFBQXpHLEdBQUEsRUFBQXNFLElBQUEsRUFBQW9DLElBQUE7O0FDc0dBLFFBQUloQixRQUFRLElBQVosRUFBa0I7QUR2R1BBLGFBQU8sRUFBUDtBQ3lHVjs7QUR4R0Q1RixVQUFNaEMsQ0FBTixFQUFTaEMsTUFBVDtBQUNBMkosU0FBSyxDQUFMOztBQUtBLFFBQUczRSxPQUFPZ0IsUUFBUCxJQUFvQixLQUFBaEUsQ0FBQSxTQUFwQixNQUFBa0MsTUFBQSxLQUFBekUsUUFBQSxDQUFBdUMsQ0FBQSxhQUFBa0MsSUFBMkMsQ0FBM0MsSUFBMkMsTUFBM0MsS0FBaUQwRixLQUFLekUsSUFBekQ7QUFHRSxVQUFHLEVBQUFxRCxPQUFBLEtBQUEvSSxRQUFBLENBQUF1QyxDQUFBLGFBQUF3RyxLQUFBLDBCQUFBb0MsT0FBQSxLQUFBbkwsUUFBQSxDQUFBdUMsQ0FBQSxhQUFBNEksS0FBb0MsQ0FBcEMsSUFBb0MsTUFBcEMsTUFBNEMsSUFBL0M7QUFDRTVHLGNBQU0vQixDQUFOLEVBQVMsS0FBQ3hDLFFBQUQsQ0FBVXVDLENBQVYsRUFBYSxDQUFiLENBQVQ7QUNvR0Q7O0FEbEdELFdBQUN1SSxnQkFBRCxDQUFrQnRJLENBQWxCO0FBSUEwSSxhQUFPLEtBQUN0SCxHQUFELENBQUtyQixDQUFMLEVBQUE0SCxRQUFBLE9BQVFBLEtBQU1wRixHQUFkLEdBQWMsTUFBZCxDQUFQOztBQUVBLFVBQWEsS0FBQ3FHLFdBQUQsQ0FBYTVJLENBQWIsRUFBZ0IwSSxJQUFoQixDQUFiO0FBQUEsZUFBTyxDQUFQO0FDaUdDOztBRC9GRCxVQUFHM0YsT0FBTzhFLFFBQVY7QUFDRSxhQUFFOUgsQ0FBRixJQUFPQyxDQUFQOztBQUNBLFlBQUcsS0FBQzhILFdBQUo7QUFFRSxlQUFDbkQsSUFBRCxDQUFNLEtBQU4sRUFBYTVFLENBQWIsRUFBZ0JDLENBQWhCLEVBQW1CLFVBQUNDLENBQUQsRUFBSWtILENBQUo7QUFDakIsZ0JBQUdsSCxDQUFIO0FBQ0UsbUJBQUVGLENBQUYsSUFBTzJJLElBQVA7QUFDQSxxQkFBTyxLQUFDNUksZUFBRCxDQUFpQjZFLElBQWpCLENBQXNCLElBQXRCLEVBQXlCNUUsQ0FBekIsRUFBNEJDLENBQTVCLEVBQStCQyxDQUEvQixDQUFQO0FDZ0dEOztBQUNELG1CQUFPLE9BQU8wSCxLQUFLZixFQUFaLEtBQW1CLFVBQW5CLEdEaEdQZSxLQUFLZixFQUFMLENBQVNjLEVBQVQsQ0NnR08sR0RoR0UsTUNnR1Q7QURwR0Y7QUFKSjtBQUFBO0FBWUUsWUFBR0MsS0FBS3BGLEdBQVI7QUFDRSxjQUFHbUYsTUFBQSxJQUFIO0FDaUdFLGdCQUFJLENBQUNjLE9BQU8sS0FBSy9FLFlBQWIsRUFBMkJnRixRQUFRZCxLQUFLcEYsR0FBeEMsS0FBZ0QsSUFBcEQsRUFBMEQ7QUFDeERpRyxtQkFBS0MsS0FBTCxJRGpHeUIsRUNpR3pCO0FBQ0Q7O0FEakdELGlCQUFDaEYsWUFBRCxDQUFja0UsS0FBS3BGLEdBQW5CLEVBQXdCeEMsQ0FBeEIsSUFBNkJDLENBQTdCO0FBSEo7QUFBQTtBQUtFLGVBQUVELENBQUYsSUFBT0MsQ0FBUDtBQ29HRDs7QUFDRCxZQUFJLE9BQU8ySCxLQUFLZixFQUFaLEtBQW1CLFVBQXZCLEVBQW1DO0FEbkduQ2UsZUFBS2YsRUFBTCxDQUFTYyxFQUFUO0FBbkJGO0FBZEY7QUFBQTtBQW1DRSxXQUFDNUgsZUFBRCxDQUFpQjZFLElBQWpCLENBQXNCLElBQXRCLEVBQXlCNUUsQ0FBekIsRUFBNEJDLENBQTVCO0FDdUdEOztBQUNELFdEdkdBMEgsRUN1R0E7QURsSkksR0NxR047O0FBZ0RBM0ssUUFBTVEsU0FBTixDRHhHQXFMLFdDd0dBLEdEeEdhLFVBQUNDLEVBQUQsRUFBS0MsRUFBTDtBQUNYLFFBQUcxRyxFQUFFQyxVQUFGLENBQWF3RyxFQUFiLENBQUg7QUN5R0UsYUR4R0F6RyxFQUFFQyxVQUFGLENBQWF5RyxFQUFiLEtBQXFCRCxHQUFHWCxRQUFILE9BQWlCWSxHQUFHWixRQUFILEVDd0d0QztBRHpHRjtBQzJHRSxhRHhHQTlGLEVBQUUyRyxPQUFGLENBQVVGLEVBQVYsRUFBY0MsRUFBZCxDQ3dHQTtBQUNEO0FEN0dVLEdDd0diOztBQVFBL0wsUUFBTVEsU0FBTixDRHhHQXlMLEtDd0dBLEdEeEdPLFVBQUNuRCxJQUFEO0FBQ0wsUUFBQTFFLENBQUE7O0FBQUEsUUFBRyxLQUFDTixZQUFKO0FBQ0VnRixhQUFPLEtBQUNoRixZQUFSO0FDMEdEOztBRHpHRCxXQUFNZ0YsUUFBUTlJLE1BQUtRLFNBQUwsQ0FBT3lELFNBQXJCO0FBQ0VHLFVBQUkwRSxLQUFLb0QsS0FBTCxDQUFXLFNBQVgsQ0FBSjs7QUFDQSxVQUFHOUgsS0FBQSxJQUFIO0FBQ0UwRSxlQUFPQSxLQUFLN0ksS0FBTCxDQUFLLENBQUwsRUFBSzZJLEtBQUF4SSxNQUFBLEdBQUE4RCxFQUFBLEdBQUE5RCxNQUFMLEtBQXlDNkwsU0FBUy9ILENBQVQsSUFBYyxDQUF2RCxDQUFQO0FBREY7QUFHRTBFLGVBQU9BLE9BQU8sR0FBZDtBQzJHRDtBRGhISDs7QUFNQSxTQUFDMUQsRUFBRCxHQUFNLFdBQVcwRCxJQUFqQjtBQzZHQSxXRDVHQSxLQUFDQSxJQUFELEdBQVFBLElDNEdSO0FEdEhLLEdDd0dQOztBQWlCQTlJLFFBQU1RLFNBQU4sQ0QzR0F5RyxnQkMyR0EsR0QzR2tCO0FBQ2hCakgsVUFBS1EsU0FBTCxDQUFPdUQsV0FBUDtBQzRHQSxXRDNHQS9ELE1BQUtRLFNBQUwsQ0FBT3lELFNBQVAsQ0FBaUIsS0FBQzZFLElBQWxCLElBQTBCLElDMkcxQjtBRDdHZ0IsR0MyR2xCOztBQUtBOUksUUFBTVEsU0FBTixDRDFHQW9HLGFDMEdBLEdEMUdlLFVBQUNiLFVBQUQ7QUFDYixRQUFBN0MsQ0FBQTs7QUFBQSxRQUFHLFFBQU82QyxVQUFQLHlDQUFPQSxVQUFQLE9BQXFCLFFBQXhCO0FBQ0UvRixZQUFLUSxTQUFMLENBQU93RCxXQUFQLENBQW1CK0IsV0FBV3FHLEtBQTlCLElBQXVDckcsVUFBdkM7QUFDQSxXQUFDdkIsVUFBRCxHQUFjdUIsVUFBZDtBQUZGO0FBSUU7QUFDRSxhQUFDdkIsVUFBRCxHQUFjLElBQUk2SCxNQUFNN0gsVUFBVixDQUFxQnVCLFVBQXJCLENBQWQ7QUFDQS9GLGNBQUtRLFNBQUwsQ0FBT3dELFdBQVAsQ0FBbUIrQixVQUFuQixJQUFpQyxLQUFDdkIsVUFBbEM7QUFGRixlQUFBTyxLQUFBO0FBR003QixZQUFBNkIsS0FBQTtBQUNKLGFBQUNQLFVBQUQsR0FBY3hFLE1BQUtRLFNBQUwsQ0FBT3dELFdBQVAsQ0FBbUIrQixVQUFuQixDQUFkO0FBQ0EsYUFBQ3ZCLFVBQUQsWUFBdUI2SCxNQUFNN0gsVUFBN0IsSUFBMkMsS0FBQ08sS0FBRCxDQUFPLHlCQUFQLEVBQWtDLFVBQVFnQixVQUFSLEdBQW1CLDhKQUFyRCxDQUEzQztBQVRKO0FDdUhDOztBQUNELFdEM0dBLEtBQUNrRyxLQUFELENBQU8sS0FBQ3pILFVBQUQsQ0FBWTRILEtBQW5CLENDMkdBO0FEekhhLEdDMEdmOztBQWtCQXBNLFFBQU1RLFNBQU4sQ0R4R0E4TCxNQ3dHQSxHRHhHUSxVQUFDM0UsSUFBRDtBQUNOLFFBQUE0RSxNQUFBLEVBQUFySCxHQUFBOztBQUFBLFNBQUFBLE1BQUFzSCxPQUFBQyxPQUFBLGNBQUF2SCxJQUFxQnFILE1BQXJCLEdBQXFCLE1BQXJCO0FBQ0VBLGVBQVNDLE9BQU9DLE9BQVAsR0FBaUJGLE1BQTFCO0FBQ0FBLGFBQU81RSxJQUFQLEdBQWNBLElBQWQ7QUMwR0EsYUR6R0E2RSxPQUFPRSxNQUFQLENBQWlCLEtBQUM1RCxJQUFELEdBQU0sT0FBdkIsRUFBK0I2RCxJQUEvQixDQUFvQ0osTUFBcEMsQ0N5R0E7QUFDRDtBRDlHSyxHQ3dHUjs7QUFTQXZNLFFBQU1RLFNBQU4sQ0QzR0F1RyxTQzJHQSxHRDNHVztBQUNULFFBQUFaLElBQUEsRUFBQTlGLENBQUEsRUFBQXVNLEVBQUEsRUFBQTFILEdBQUEsRUFBQW1DLElBQUEsRUFBQXdGLENBQUE7O0FBQUEsUUFBRyxLQUFDaEwsTUFBRCxLQUFXLGFBQWQ7QUFDRSxVQUFHLEtBQUNELEtBQUQsQ0FBTzFCLE9BQVAsQ0FBZSxPQUFmLE1BQTJCLENBQUMsQ0FBL0I7QUFDRSxZQUFHLEtBQUMwQixLQUFELENBQU8sQ0FBUCxNQUFlLEdBQWxCO0FBQ0UsZUFBQ0EsS0FBRCxHQUFTLE1BQU0sS0FBQ0EsS0FBaEI7QUM2R0Q7O0FENUdELFlBQUcsS0FBQ0EsS0FBRCxDQUFPLEtBQUNBLEtBQUQsQ0FBT3RCLE1BQVAsR0FBZ0IsQ0FBdkIsTUFBK0IsR0FBbEM7QUFDRSxlQUFDc0IsS0FBRCxJQUFVLEdBQVY7QUM4R0Q7O0FEN0dEZ0wsYUFBSyxLQUFDaEwsS0FBRCxHQUFZLEtBQUNBLEtBQUQsR0FBTyxPQUF4QjtBQytHRDs7QUQ5R0RpTCxVQUFJLEtBQUMvSyxjQUFMO0FBQ0F6QixVQUFBLENBQUE2RSxNQUFBLEtBQUFuRCxZQUFBLFlBQUFtRCxHQUFBLEdBQW9CLE1BQXBCO0FBQ0FtQyxhQUFPLElBQVA7QUFDQWxCLGFBQU8sSUFBUDtBQUVBcUcsYUFBT00sR0FBUCxDQUFXO0FBQ1QsWUFBQUMsRUFBQSxFQUFBQyxDQUFBLEVBQUFoSyxDQUFBLEVBQUFpSyxHQUFBLEVBQUF6RCxJQUFBLEVBQUFFLE9BQUE7O0FBQUEsYUFBT3JDLEtBQUs5RSxRQUFaO0FBSUUsZUFBQ1gsS0FBRCxDQUFVeUYsS0FBS3lCLElBQUwsR0FBVSxPQUFwQixFQUNFO0FBQUE2RCxrQkFBTUMsRUFBTjtBQUNBTSxzQkFBVUwsQ0FEVjtBQUVBTSw0QkFBZ0I5TSxDQUZoQjtBQUdBK00sNEJBQWdCO0FBQ2Qsa0JBQUF6RixJQUFBO0FBQUFBLHFCQUFPd0UsU0FBUyxLQUFDSSxNQUFELENBQVE1RSxJQUFqQixDQUFQOztBQUNBLGtCQUFHTixLQUFLbEIsSUFBUjtBQUNFa0IscUJBQUtnQixJQUFMLENBQVUsU0FBVixFQUFxQlYsSUFBckI7QUFDQU4scUJBQUtnQixJQUFMLENBQVUsYUFBVixFQUF5QlYsSUFBekI7QUM4R0Q7O0FEN0dELGtCQUFHTixLQUFBNUQsYUFBQSxRQUFIO0FBQ0U0RCxxQkFBSzVELGFBQUwsQ0FBbUIsSUFBbkI7QUMrR0Q7O0FEOUdEK0Usc0JBQVE2RSxXQUFSLENBQW9CLFVBQUE3RixLQUFBO0FDZ0hsQix1QkRoSGtCO0FDaUhoQix5QkRoSEZILEtBQUtpRyxVQUFMLENBQWdCM0YsSUFBaEIsQ0NnSEU7QURqSGdCLGlCQ2dIbEI7QURoSGtCLHFCQUFwQjtBQ29IQSxxQkRsSEEsS0FBQzRGLElBQUQsRUNrSEE7QUQ5SEY7QUFBQSxXQURGO0FDa0lEOztBRGpIRCxZQUFHbEcsS0FBS2hGLFNBQVI7QUFDRSxjQUFHZ0QsRUFBRUksUUFBRixDQUFXNEIsS0FBS2hGLFNBQWhCLENBQUg7QUFDRWdGLGlCQUFLaEYsU0FBTCxHQUFpQixDQUFDZ0YsS0FBS2hGLFNBQU4sQ0FBakI7QUNtSEQ7O0FEbEhEbUgsaUJBQUFuQyxLQUFBaEYsU0FBQTtBQUFBcUgsb0JBQUE7O0FDcUhBLGVEckhBMUcsSUFBQWdLLElBQUEsR0FBQUMsTUFBQXpELEtBQUFsSixNQ3FIQSxFRHJIQTBNLElBQUFDLEdDcUhBLEVEckhBakssSUFBQSxFQUFBZ0ssQ0NxSEEsRURySEE7QUNzSEVELGlCQUFLdkQsS0FBS3hHLENBQUwsQ0FBTDtBQUNBMEcsb0JBQVFDLElBQVIsQ0R0SEEsS0FBQy9ILEtBQUQsQ0FBVXlGLEtBQUt5QixJQUFMLEdBQVUsT0FBVixHQUFpQjlGLENBQTNCLEVBQ0U7QUFBQTJKLG9CQUFNSSxFQUFOO0FBQ0FHLHdCQUFVTCxDQURWO0FBRUFNLDhCQUFnQjlNLENBRmhCO0FBR0ErTSw4QkFBZ0I7QUFDZCxvQkFBRy9GLEtBQUE1RCxhQUFBLFFBQUg7QUFDRTRELHVCQUFLNUQsYUFBTCxDQUFtQixJQUFuQjtBQ3VIRDs7QUR0SEQsb0JBQUc0RCxLQUFLbEIsSUFBUjtBQUNFa0IsdUJBQUtnQixJQUFMLENBQVUsU0FBVixFQUFxQixDQUFyQjtBQUNBaEIsdUJBQUtnQixJQUFMLENBQVUsYUFBVixFQUF5QixDQUF6QjtBQ3dIRDs7QUFDRCx1QkR4SEEsS0FBQ2tGLElBQUQsRUN3SEE7QURqSUY7QUFBQSxhQURGLENDc0hBO0FEdkhGOztBQ3VJQSxpQkFBTzdELE9BQVA7QUFDRDtBRGpLSDs7QUF3Q0EsVUFBRzFELE9BQU9nQixRQUFQLElBQW9CLEtBQUM1RSxVQUF4QjtBQUNFaUYsZUFBTyxJQUFQO0FBQ0FtRyxtQkFBVzVMLEtBQVgsQ0FBaUJnTCxFQUFqQixFQUFxQixVQUFDTCxNQUFEO0FDNEhuQixpQkQzSEEsS0FBQ2tCLFNBQUQsQ0FBV3BHLEtBQUtqQyxFQUFoQixFQUFvQitHLFNBQVNJLE9BQU81RSxJQUFoQixDQUFwQixDQzJIQTtBRDVIRjtBQzhIQSxlRDVIQTZGLFdBQVc1TCxLQUFYLENBQWlCLEtBQUNTLFNBQWxCLEVBQTZCO0FDNkgzQixpQkQ1SEEsS0FBQ29MLFNBQUQsQ0FBV3BHLEtBQUtqQyxFQUFoQixFQUFvQixDQUFwQixDQzRIQTtBRDdIRixVQzRIQTtBRHBMSjtBQ3dMQztBRHpMUSxHQzJHWDs7QUFpRkFwRixRQUFNUSxTQUFOLENEaElBa04sT0NnSUEsR0RoSVM7QUNpSVAsV0RoSUEsS0FBQ0MsT0FBRCxNQUFlLEtBQUNuSixVQUFELENBQVlDLElBQVosQ0FBaUJZLEVBQUV1SSxNQUFGLENBQVMsQ0FBQyxDQUFDLE1BQUksS0FBQ3hJLEVBQUwsR0FBUSxJQUFULEVBQWMsQ0FBZCxDQUFELENBQVQsQ0FBakIsRUFBOENULEtBQTlDLE9BQXlELENDZ0l4RTtBRGpJTyxHQ2dJVDs7QUFJQTNFLFFBQU1RLFNBQU4sQ0RqSUFxTixVQ2lJQSxHRGpJWTtBQ2tJVixXRGpJQSxLQUFDbE0sT0FBRCxHQUFjLEtBQUMyQixhQUFELEdBQWlCLEtBQUMzQixPQUFsQixHQUErQixLQUFDMkIsYUFBaEMsR0FBbUQsS0FBQzNCLE9DaUlsRTtBRGxJVSxHQ2lJWjs7QUFJQTNCLFFBQU1RLFNBQU4sQ0RsSUErSCxZQ2tJQSxHRGxJYztBQUNaLFFBQUF1RixPQUFBLEVBQUExTixDQUFBLEVBQUE0TSxDQUFBLEVBQUFDLEdBQUEsRUFBQW5FLElBQUEsRUFBQTVELEdBQUEsRUFBQTZJLEVBQUE7QUFBQWpGLFdBQU8sS0FBQ2hGLFlBQUQsSUFBaUIsS0FBQ2dGLElBQXpCOztBQUNBLFFBQUcsS0FBQ25GLEtBQUQsSUFBVyxLQUFDdEMsWUFBRCxLQUFpQixtQkFBL0I7QUFDRSxXQUFDQSxZQUFELEdBQWdCLEtBQUN1QyxpQkFBakI7QUNvSUQ7O0FEbElEc0IsVUFBQSxNQUFBcEMsV0FBQSxPQUFBUyxZQUFBLE9BQUFsQyxZQUFBLE9BQUF3QyxhQUFBOztBQUFBLFNBQUFtSixJQUFBLEdBQUFDLE1BQUEvSCxJQUFBNUUsTUFBQSxFQUFBME0sSUFBQUMsR0FBQSxFQUFBRCxHQUFBO0FDcUlFNU0sVUFBSThFLElBQUk4SCxDQUFKLENBQUo7QURwSUFlLFdBQUssS0FBQzNJLEVBQUQsR0FBTWhGLENBQVg7QUFDQTJJLGVBQVNnRixFQUFULElBQWUsSUFBSUMsTUFBTWpGLFFBQVYsQ0FBbUIsY0FBWWdGLEVBQS9CLEVBQXFDaEYsU0FBUzNJLENBQVQsRUFBWTZOLGNBQWpELENBQWY7QUFDQWxGLGVBQVNnRixFQUFULEVBQWFHLFdBQWIsR0FBMkJuRixTQUFTZ0YsRUFBVCxFQUFhRyxXQUFiLENBQXlCQyxNQUF6QixDQUFnQ3BGLFNBQVMzSSxDQUFULEVBQVk4TixXQUE1QyxDQUEzQjtBQUNBSixnQkFBVTtBQUFBTSxtQkFBVztBQUFYLE9BQVY7O0FBQ0EvSSxRQUFFZ0osSUFBRixDQUFPdEYsU0FBUzNJLENBQVQsRUFBWWtPLFNBQW5CLEVBQThCLFVBQUE5RyxLQUFBO0FDd0k1QixlRHhJNEIsVUFBQytHLE1BQUQsRUFBU3pGLElBQVQ7QUFDNUIsY0FBR0EsS0FBSyxDQUFMLE1BQVcsR0FBZDtBQ3lJSSxtQkR4SUZnRixRQUFRaEYsS0FBSzdJLEtBQUwsQ0FBVyxDQUFYLENBQVIsSUFBeUJvRixFQUFFMEUsSUFBRixDQUFPd0UsTUFBUCxFQUFlL0csS0FBZixDQ3dJdkI7QUFDRDtBRDNJeUIsU0N3STVCO0FEeEk0QixhQUE5Qjs7QUFHQXVCLGVBQVNnRixFQUFULEVBQWFELE9BQWIsQ0FBcUJBLE9BQXJCO0FBUkY7O0FDcUpBLFdEeklBL0UsU0FBU0QsSUFBVCxFQUFlZ0YsT0FBZixDQUNFO0FBQUFNLGlCQUFXLElBQVg7QUFDQUksZ0JBQVV6RixTQUFTLEtBQUMzRCxFQUFELEdBQU0sS0FBQ3RDLFdBQWhCLENBRFY7QUFFQTJMLGFBQU8xRixTQUFTLEtBQUMzRCxFQUFELEdBQU0sS0FBQzdCLFlBQWhCO0FBRlAsS0FERixDQ3lJQTtBRDFKWSxHQ2tJZDs7QUErQkF2RCxRQUFNUSxTQUFOLENEeklBb0ksVUN5SUEsR0R6SVl2RCxFQUFFNkQsUUFBRixDQUFXLFVBQUNXLEVBQUQ7QUFFckIsUUFBQXpGLENBQUEsRUFBQWMsR0FBQTs7QUFBQSxRQUFHLENBQUNjLE9BQU8wQyxNQUFQLEdBQWdCZ0csU0FBakIsSUFBK0J0RyxRQUFBLG9CQUFsQztBQUNFaEUsVUFBQSxFQUFBYyxNQUFBLEtBQUFWLFVBQUEsQ0FBQW1LLE9BQUE7QUMwSUUzTSxjQUFNcUQsRUFBRXVJLE1BQUYsQ0FBUyxDQUFDLENBQUMsTUFBTSxLQUFLeEksRUFBWCxHQUFnQixJQUFqQixFQUF1QixDQUFDLENBQXhCLENBQUQsQ0FBVDtBRDFJUixhQzJJTyxJRDNJUCxHQzJJY0YsSUQzSXFELE1BQUksS0FBQ0UsRUFBTCxHQUFRLElDMkk3RCxDRDNJZCxHQUFtRSxNQUFuRSxLQUFtRixDQUFuRjtBQUNBLFdBQUN3SixhQUFELENBQWV4SyxDQUFmO0FDNElBLGFBQU8sT0FBT3lGLEVBQVAsS0FBYyxVQUFkLEdEM0lQQSxHQUFJekYsQ0FBSixDQzJJTyxHRDNJSCxNQzJJSjtBRDlJRjtBQ2dKRSxhRDNJQSxLQUFDd0QsSUFBRCxDQUFNLFlBQU4sRUFBb0IsVUFBQUosS0FBQTtBQzRJbEIsZUQ1SWtCLFVBQUN0RSxDQUFELEVBQUlrSCxDQUFKO0FBQ2xCLGNBQUFsQyxHQUFBOztBQUFBLGNBQVloRixLQUFBLElBQVo7QUFBQSxrQkFBTUEsQ0FBTjtBQytJRzs7QUQ5SUhzRSxnQkFBQ29ILGFBQUQsQ0FBZXhFLENBQWY7O0FBQ0FsQyxnQkFBTVYsTUFBQ1UsR0FBRCxFQUFOOztBQUNBLGNBQUdWLE1BQUNTLGFBQUQsR0FBaUJDLEdBQXBCO0FBQ0VWLGtCQUFDUyxhQUFELEdBQWlCQyxNQUFNVixNQUFDbkUsa0JBQXhCO0FBQ0F3TCx1QkFBV3hKLEVBQUUwRSxJQUFGLENBQU92QyxNQUFDb0IsVUFBUixFQUFvQnBCLEtBQXBCLENBQVgsRUFBbUNBLE1BQUNuRSxrQkFBcEM7QUNnSkM7O0FBQ0QsaUJBQU8sT0FBT3dHLEVBQVAsS0FBYyxVQUFkLEdEaEpUQSxHQUFJTyxDQUFKLENDZ0pTLEdEaEpMLE1DZ0pGO0FEdkpnQixTQzRJbEI7QUQ1SWtCLGFBQXBCLENDMklBO0FBZUQ7QURqS1MsS0FlVixJQWZVLENDeUlaOztBQTJCQXBLLFFBQU1RLFNBQU4sQ0RuSkFvTyxhQ21KQSxHRG5KZSxVQUFDeEssQ0FBRDtBQUNiLFNBQUNpRSxJQUFELENBQU0sWUFBTixFQUFvQmpFLENBQXBCOztBQUNBLFFBQUcsS0FBQ2lFLElBQUQsQ0FBTSxhQUFOLElBQXVCakUsQ0FBMUI7QUNvSkUsYURuSkEsS0FBQ2lFLElBQUQsQ0FBTSxhQUFOLEVBQXFCLENBQXJCLENDbUpBO0FBQ0Q7QUR2SlksR0NtSmY7O0FBT0FySSxRQUFNUSxTQUFOLENEbkpBc08sd0JDbUpBLEdEbkowQixVQUFDdEosR0FBRDtBQUN4QixRQUFBTixHQUFBOztBQUFBLFFBQUdjLE9BQU9nQixRQUFWO0FBQ0VoQyxZQUFNUSxHQUFOLEVBQVd4RSxNQUFYOztBQUNBLFlBQUFrRSxNQUFBLEtBQUFXLGFBQUEsQ0FBQUwsR0FBQSxhQUFBTixJQUF3QjVFLE1BQXhCLEdBQXdCLE1BQXhCLEtBQWtDLEtBQUN1QyxnQkFBbkM7QUFDRSxlQUFPLEtBQUNrQyxLQUFELENBQU8sNEJBQVAsRUFBcUMsZ0VBQXJDLENBQVA7QUFISjtBQUFBO0FBS0UsYUFBTSxLQUFDYyxhQUFELENBQWV2RixNQUFmLElBQXlCLEtBQUN1QyxnQkFBaEM7QUFDRSxhQUFDc0csV0FBRCxDQUFhLEtBQUN0RCxhQUFELENBQWVZLEtBQWYsQ0FBcUIsQ0FBckIsQ0FBYjtBQURGOztBQ3dKQSxhRHRKQSxJQ3NKQTtBQUNEO0FEL0p1QixHQ21KMUI7O0FBZUF6RyxRQUFNUSxTQUFOLENEbEpBa0gsT0NrSkEsR0RsSlMsVUFBQ0MsSUFBRCxFQUFPeEQsR0FBUDtBQUNQLFFBQUFzSCxJQUFBLEVBQUFzRCxDQUFBLEVBQUF2SixHQUFBLEVBQUFuQixHQUFBLEVBQUEySyxNQUFBLEVBQUFDLE9BQUEsRUFBQTlJLElBQUEsRUFBQS9CLENBQUEsRUFBQXNILEtBQUEsRUFBQXdELEtBQUEsRUFBQTdILElBQUEsRUFBQTNCLEdBQUE7QUFBQVYsVUFBTTJDLElBQU4sRUFBWWhILE1BQVo7QUFDQXFFLFVBQU1iLEdBQU4sRUFBV3RELE1BQU1vRSxLQUFOLENBQVksVUFBQ2tLLENBQUQ7QUNvSnJCLGFEbkpBQSxFQUFBQyxLQUFBLFFDbUpBO0FEcEpTLE1BQVg7QUFFQTVKLFVBQU1yQixJQUFJZ0IsVUFBSixDQUFlQyxFQUFyQjtBQUNBZSxXQUFPLElBQVA7O0FDcUpBLFFBQUksQ0FBQ3NGLE9BQU8sS0FBSzVGLGFBQWIsRUFBNEI2RixRQUFRdkgsSUFBSWdCLFVBQUosQ0FBZUMsRUFBbkQsS0FBMEQsSUFBOUQsRUFBb0U7QUFDbEVxRyxXQUFLQyxLQUFMLElEbEptQztBQUFBcEwsZ0JBQVE7QUFBUixPQ2tKbkM7QUFHRDs7QURuSkQsU0FBQ3dPLHdCQUFELENBQTBCdEosR0FBMUI7QUFLQW5CLFVBQU1GLElBQUlFLEdBQUosR0FBVWdCLEVBQUUwRSxJQUFGLENBQVEsVUFBQ3ZFLEdBQUQsRUFBTXhDLENBQU47QUNpSnRCLGFEakprQyxLQUFDcUIsR0FBRCxDQUFLckIsQ0FBTCxFQUFRd0MsR0FBUixDQ2lKbEM7QURqSnFCLEtBQVAsRUFBa0MsSUFBbEMsRUFBcUNBLEdBQXJDLENBQWhCO0FBQ0FFLFVBQU12QixJQUFJdUIsR0FBSixHQUFVTCxFQUFFMEUsSUFBRixDQUFRLFVBQUN2RSxHQUFELEVBQU14QyxDQUFOLEVBQVNDLENBQVQ7QUNtSnRCLGFEbkpxQyxLQUFDeUMsR0FBRCxDQUFLMUMsQ0FBTCxFQUFRQyxDQUFSLEVBQVc7QUFBQXVDLGFBQUtBO0FBQUwsT0FBWCxDQ21KckM7QURuSnFCLEtBQVAsRUFBNkMsSUFBN0MsRUFBZ0RBLEdBQWhELENBQWhCO0FBRUEwSixZQUFRN0osRUFBRTBFLElBQUYsQ0FBUSxVQUFDNUYsR0FBRCxFQUFNRSxHQUFOLEVBQVdxQixHQUFYO0FBRWQsVUFBQXFKLENBQUEsRUFBQTNOLE9BQUEsRUFBQWlPLE9BQUEsRUFBQWpGLENBQUEsRUFBQWxGLEdBQUEsRUFBQXNFLElBQUEsRUFBQThGLElBQUE7O0FDcUpBLFVBQUksQ0FBQ3BLLE1BQU0sS0FBS3dCLFlBQUwsQ0FBa0JsQixHQUFsQixDQUFQLEtBQWtDLElBQXRDLEVBQTRDO0FEcko1QyxlQUFBTixJQUEyQnFLLFdBQTNCO0FDdUpDOztBQUNELFVBQUksQ0FBQy9GLE9BQU8sS0FBSzlDLFlBQUwsQ0FBa0JsQixHQUFsQixDQUFSLEtBQW1DLElBQXZDLEVBQTZDO0FEdko3QyxlQUFBZ0UsS0FBMkJnRyxlQUEzQjtBQ3lKQzs7QUR2SkQsV0FBQzNCLFVBQUQ7QUFFQXlCLGFBQU8sQ0FBQzNILE9BQU8sQ0FBUixJQUFhdEQsSUFBSSxTQUFKLENBQXBCOztBQUNBLFVBQVlpTCxPQUFPLENBQW5CO0FBQUFBLGVBQU8sQ0FBUDtBQ3lKQzs7QUR2SkRsTyxnQkFBVWlELElBQUksU0FBSixDQUFWO0FBRUFnTCxnQkFDRTtBQUFBck4sY0FBTXFDLElBQUksTUFBSixDQUFOO0FBQ0FuRCxnQkFBUW1ELElBQUksUUFBSixDQURSO0FBRUFpTCxjQUFNQSxJQUZOO0FBR0FHLGVBQU9wTCxJQUFJLFNBQUo7QUFIUCxPQURGOztBQVFBLFVBQUcsS0FBQXBDLElBQUEsUUFBSDtBQUNFbUksWUFBSSxLQUFDbkksSUFBRCxDQUFNMkYsSUFBTixDQUFXLElBQVgsRUFBYzBILElBQWQsRUFBb0JuTCxHQUFwQixDQUFKOztBQUNBLFlBQUcsQ0FBQ2lHLENBQUo7QUFDRTFFLGNBQUksaUJBQUosRUFBdUIsQ0FBdkI7QUFDQXZCLGNBQUlpTCxLQUFKO0FBQ0EsaUJBQU8sS0FBQ0EsS0FBRCxFQUFQO0FBSEYsZUFJSyxJQUFHL0osRUFBRXFLLFFBQUYsQ0FBV3RGLENBQVgsQ0FBSDtBQUNIMUUsY0FBSSxpQkFBSixFQUF1QjBFLENBQXZCOztBQUNBLGNBQUd6QyxPQUFPeUMsQ0FBVjtBQUNFakcsZ0JBQUlpTCxLQUFKO0FBQ0EsbUJBQU8sS0FBQ0EsS0FBRCxFQUFQO0FBSkM7QUFBQSxlQUtBLElBQUcvSixFQUFFc0ssT0FBRixDQUFVdkYsQ0FBVixLQUFpQkEsRUFBRTlKLE1BQUYsS0FBWSxDQUFoQztBQUNILGNBQUcrRSxFQUFFQyxVQUFGLENBQWE4RSxFQUFFLENBQUYsRUFBS3dGLEtBQWxCLENBQUg7QUFDRWIsZ0JBQUkzRSxDQUFKO0FBREY7QUFHRWhKLHNCQUFVZ0osRUFBRSxDQUFGLENBQVY7QUFDQWlGLHNCQUFVakYsRUFBRSxDQUFGLENBQVY7QUFMQztBQUFBLGVBTUEsSUFBRy9FLEVBQUVDLFVBQUYsQ0FBYThFLEVBQUV3RixLQUFmLENBQUg7QUFDSGIsY0FBSTNFLENBQUo7QUFsQko7QUMyS0M7O0FEdkpELFVBQUcsQ0FBQ3lGLE1BQU1DLE1BQU4sQ0FBYSxFQUFiLEVBQWlCMU8sT0FBakIsQ0FBRCxJQUErQixDQUFDeU8sTUFBTUMsTUFBTixDQUFhekwsSUFBSSxTQUFKLENBQWIsRUFBNkJqRCxPQUE3QixDQUFuQztBQUNFc0UsWUFBSSxhQUFKLEVBQW1CdEUsT0FBbkI7QUN5SkQ7O0FBQ0QsYUR0SkEyTixLQUFLLEtBQUN2SyxVQUFELENBQVlDLElBQVosQ0FBaUJyRCxPQUFqQixFQUEwQmlPLE9BQTFCLENDc0pMO0FEbk1hLEtBQVAsRUErQ0wsSUEvQ0ssRUErQ0ZsTCxHQS9DRSxFQStDR0UsR0EvQ0gsRUErQ1FxQixHQS9DUixDQUFSO0FBaURBcUosUUFBSUcsT0FBSjtBQUtBN0gsV0FBTyxJQUFQO0FBU0EySCxhQUFTRCxFQUFFZ0IsT0FBRixDQUNQO0FBQUFDLGVBQVMzSyxFQUFFMEUsSUFBRixDQUFRLFVBQUM1RixHQUFELEVBQU0rSyxLQUFOLEVBQWFlLEdBQWIsRUFBa0JDLEVBQWxCO0FBQ2YsWUFBQTlLLEVBQUE7O0FBQUEsWUFBV2UsSUFBWDtBQUFBO0FDMklDOztBRHpJRDhKLFlBQUksTUFBSSxLQUFDN0ssRUFBTCxHQUFRLElBQVosSUFBbUJ1QyxJQUFuQjtBQUNBc0ksWUFBSSxNQUFJLEtBQUM3SyxFQUFMLEdBQVEsSUFBWixJQUFtQjhLLEVBQW5CO0FBQ0E5SyxhQUFLNkssSUFBSUUsR0FBVDtBQUNBLGVBQU9GLElBQUlFLEdBQVg7QUMySUEsZUR6SUFqQixRQUFRa0IsT0FBUixDQUFnQixVQUFBNUksS0FBQTtBQzBJZCxpQkQxSWMsVUFBQzZJLENBQUQsRUFBSWpRLENBQUo7QUFDZCxnQkFBR0EsTUFBSzhQLEVBQVI7QUMySUkscUJEMUlGL0wsSUFBSW1NLEtBQUosQ0FBVTlJLE1BQUNoRCxVQUFELENBQVk0SCxLQUF0QixFQUE2QmhILEVBQTdCLEVBQWlDNkssR0FBakMsQ0MwSUU7QUQzSUo7QUM2SUkscUJEMUlGOUwsSUFBSW9NLE9BQUosQ0FBWS9JLE1BQUNoRCxVQUFELENBQVk0SCxLQUF4QixFQUErQmlFLEVBQUVGLEdBQWpDLEVBQXNDOUssRUFBRXVJLE1BQUYsQ0FBUyxDQUFDLENBQUMsTUFBSXBHLE1BQUNwQyxFQUFMLEdBQVEsSUFBVCxFQUFjaEYsQ0FBZCxDQUFELENBQVQsQ0FBdEMsQ0MwSUU7QUFDRDtBRC9JVyxXQzBJZDtBRDFJYyxlQUFoQixDQ3lJQTtBRGpKYyxPQUFQLEVBYU4sSUFiTSxFQWFIK0QsR0FiRyxFQWFFK0ssS0FiRjtBQUFULEtBRE8sQ0FBVDtBQWtCQUQsY0FBVUYsRUFBRXlCLGNBQUYsQ0FDUjtBQUFBQyxtQkFBYXBMLEVBQUUwRSxJQUFGLENBQVEsVUFBQzVGLEdBQUQsRUFBTStLLEtBQU4sRUFBYTlKLEVBQWIsRUFBaUJzTCxNQUFqQjtBQzRJbkIsZUQxSUF4QixRQUFRa0IsT0FBUixDQUFnQixVQUFBNUksS0FBQTtBQzJJZCxpQkQzSWMsVUFBQzZJLENBQUQsRUFBSWpRLENBQUo7QUM0SVosbUJEM0lGK0QsSUFBSW9NLE9BQUosQ0FBWS9JLE1BQUNoRCxVQUFELENBQVk0SCxLQUF4QixFQUErQmlFLEVBQUVGLEdBQWpDLEVBQXNDOUssRUFBRXVJLE1BQUYsQ0FBUyxDQUFDLENBQUMsTUFBSXBHLE1BQUNwQyxFQUFMLEdBQVEsSUFBVCxFQUFjaEYsQ0FBZCxDQUFELENBQVQsQ0FBdEMsQ0MySUU7QUQ1SVksV0MySWQ7QUQzSWMsZUFBaEIsQ0MwSUE7QUQ1SWtCLE9BQVAsRUFJVixJQUpVLEVBSVArRCxHQUpPLEVBSUYrSyxLQUpFLENBQWI7QUFNQXFCLGVBQVNsTCxFQUFFMEUsSUFBRixDQUFRLFVBQUM1RixHQUFELEVBQU0rSyxLQUFOLEVBQWE5SixFQUFiLEVBQWlCbEUsTUFBakI7QUFFZixZQUFBZ0MsQ0FBQTs7QUFBQTtBQzZJRSxpQkQ1SUFpQixJQUFJb00sT0FBSixDQUFZLEtBQUMvTCxVQUFELENBQVk0SCxLQUF4QixFQUErQmhILEVBQS9CLEVBQW1DbEUsTUFBbkMsQ0M0SUE7QUQ3SUYsaUJBQUE2RCxLQUFBO0FBRU03QixjQUFBNkIsS0FBQTtBQzhJTDtBRGxKYSxPQUFQLEVBS04sSUFMTSxFQUtIWixHQUxHLEVBS0UrSyxLQUxGLENBTlQ7QUFhQXlCLGVBQVN0TCxFQUFFMEUsSUFBRixDQUFRLFVBQUM1RixHQUFELEVBQU0rSyxLQUFOLEVBQWE5SixFQUFiO0FBRWYsWUFBQWxDLENBQUE7O0FBQUE7QUFDRWlCLGNBQUl3TSxPQUFKLENBQVksS0FBQ25NLFVBQUQsQ0FBWTRILEtBQXhCLEVBQStCaEgsRUFBL0I7QUM4SUEsaUJEN0lBOEosUUFBUWtCLE9BQVIsQ0FBZ0IsVUFBQTVJLEtBQUE7QUM4SWQsbUJEOUljLFVBQUM2SSxDQUFELEVBQUlqUSxDQUFKO0FDK0laLHFCRDlJRitELElBQUlvTSxPQUFKLENBQVkvSSxNQUFDaEQsVUFBRCxDQUFZNEgsS0FBeEIsRUFBK0JpRSxFQUFFRixHQUFqQyxFQUFzQzlLLEVBQUV1SSxNQUFGLENBQVMsQ0FBQyxDQUFDLE1BQUlwRyxNQUFDcEMsRUFBTCxHQUFRLElBQVQsRUFBY2hGLENBQWQsQ0FBRCxDQUFULENBQXRDLENDOElFO0FEL0lZLGFDOElkO0FEOUljLGlCQUFoQixDQzZJQTtBRC9JRixpQkFBQTJFLEtBQUE7QUFJTTdCLGNBQUE2QixLQUFBO0FDa0pMO0FEeEphLE9BQVAsRUFPTixJQVBNLEVBT0haLEdBUEcsRUFPRStLLEtBUEY7QUFiVCxLQURRLENBQVY7QUF5QkE5SyxRQUFJLENBQUo7QUFDQTJLLE1BQUVxQixPQUFGLENBQVUsVUFBQTVJLEtBQUE7QUNpSlIsYURqSlEsVUFBQ3lJLEdBQUQsRUFBTVcsS0FBTixFQUFhQyxNQUFiO0FBQ1J6TTtBQUNBNkwsWUFBSSxNQUFJekksTUFBQ3BDLEVBQUwsR0FBUSxJQUFaLElBQW1CdUMsSUFBbkI7QUFDQXNJLFlBQUksTUFBSXpJLE1BQUNwQyxFQUFMLEdBQVEsSUFBWixJQUFtQndMLEtBQW5CO0FDa0pFLGVEakpGek0sSUFBSW1NLEtBQUosQ0FBVTlJLE1BQUNoRCxVQUFELENBQVk0SCxLQUF0QixFQUE2QjZELElBQUlFLEdBQWpDLEVBQXNDRixHQUF0QyxDQ2lKRTtBRHJKTSxPQ2lKUjtBRGpKUSxXQUFWO0FBTUE5SixXQUFPLEtBQVA7QUFFQWhDLFFBQUkyTSxNQUFKLENBQVd6TCxFQUFFMEUsSUFBRixDQUFRLFVBQUNwQyxJQUFEO0FBRWpCLGFBQU8sS0FBQzlCLGFBQUQsQ0FBZTFCLElBQUlnQixVQUFKLENBQWVDLEVBQTlCLEVBQWtDdUMsSUFBbEMsQ0FBUDtBQUNBLFdBQUM5QixhQUFELENBQWUxQixJQUFJZ0IsVUFBSixDQUFlQyxFQUE5QixFQUFrQzlFLE1BQWxDO0FBQ0EwTyxhQUFPbEosSUFBUDtBQ2lKQSxhRGhKQW1KLFFBQVFuSixJQUFSLEVDZ0pBO0FEckpnQixLQUFQLEVBTVIsSUFOUSxFQU1MNkIsSUFOSyxDQUFYO0FBT0EsU0FBQzlCLGFBQUQsQ0FBZTFCLElBQUlnQixVQUFKLENBQWVDLEVBQTlCLEVBQWtDdUMsSUFBbEMsSUFBMEN4RCxHQUExQztBQUNBLFNBQUMwQixhQUFELENBQWUxQixJQUFJZ0IsVUFBSixDQUFlQyxFQUE5QixFQUFrQzlFLE1BQWxDO0FDaUpBLFdEaEpBNkQsSUFBSWlMLEtBQUosRUNnSkE7QUQvUk8sR0NrSlQ7O0FBZ0pBcFAsUUFBTVEsU0FBTixDRC9JQXVRLE9DK0lBLEdEL0lTLFVBQUMxSCxDQUFEO0FBQ1AsUUFBRyxDQUFDLEtBQUNqSCxVQUFGLElBQWlCaUgsTUFBSyxLQUFDQyxXQUFELEVBQXpCO0FDZ0pFLGFEL0lBLEtBQUNqQixJQUFELENBQU0sT0FBTixFQUFlLEtBQWYsQ0MrSUE7QUFDRDtBRGxKTSxHQytJVDs7QUFNQXJJLFFBQU1RLFNBQU4sQ0RqSkEwSCxHQ2lKQSxHRGpKSztBQ2tKSCxXRGpKQyxJQUFJOEksSUFBSixFQUFELENBQWFDLE9BQWIsRUNpSkE7QURsSkcsR0NpSkw7O0FBSUFqUixRQUFNUSxTQUFOLENEbEpBNEMsR0NrSkEsR0RsSks7QUFDSCxRQUFBOE4sQ0FBQSxFQUFBOVEsQ0FBQSxFQUFBNE0sQ0FBQSxFQUFBQyxHQUFBO0FBQUFpRSxRQUFJLENBQUMsWUFBVSxLQUFDcEksSUFBWCxHQUFnQixJQUFqQixDQUFKOztBQUNBLFNBQUFrRSxJQUFBLEdBQUFDLE1BQUFySCxVQUFBdEYsTUFBQSxFQUFBME0sSUFBQUMsR0FBQSxFQUFBRCxHQUFBO0FDb0pFNU0sVUFBSXdGLFVBQVVvSCxDQUFWLENBQUo7QURuSkFrRSxRQUFFdkgsSUFBRixDQUFPdkosQ0FBUDtBQURGOztBQ3VKQSxXRHJKQSxLQUFDaUcsS0FBRCxJQUFXbEQsUUFBUUMsR0FBUixDQUFZaUgsS0FBWixDQUFrQmxILE9BQWxCLEVBQTJCK04sQ0FBM0IsQ0NxSlg7QUR6SkcsR0NrSkw7O0FBVUFsUixRQUFNUSxTQUFOLENEdEpBMlEsVUNzSkEsR0R0SlksVUFBQzlILENBQUQ7QUFDVixTQUFDK0gsZUFBRCxHQUFtQixLQUFDbEosR0FBRCxFQUFuQjtBQUNBLFNBQUNtSixVQUFELEdBQWNoSSxDQUFkO0FDdUpBLFdEdEpBLEtBQUN2QixTQUFELENBQVd1QixDQUFYLElBQWdCLENDc0poQjtBRHpKVSxHQ3NKWjs7QUFNQXJKLFFBQU1RLFNBQU4sQ0R2SkE4USxXQ3VKQSxHRHZKYSxVQUFDakksQ0FBRDtBQUNYLFdBQU8sS0FBQ3ZCLFNBQUQsQ0FBV3VCLENBQVgsQ0FBUDtBQ3dKQSxXRHZKQSxLQUFDdEIsUUFBRCxDQUFVc0IsQ0FBVixJQUFlLENDdUpmO0FEekpXLEdDdUpiOztBQUtBckosUUFBTVEsU0FBTixDRHhKQStRLFVDd0pBLEdEeEpZO0FDeUpWLFdEeEpBLEtBQUN2SixLQUFELEdBQVMsRUN3SlQ7QUR6SlUsR0N3Slo7O0FBSUFoSSxRQUFNUSxTQUFOLENEekpBZ1IsU0N5SkEsR0R6SlcsVUFBQzdKLElBQUQ7QUFDVCxRQUFBOEosQ0FBQSxFQUFBekUsQ0FBQSxFQUFBMEUsU0FBQSxFQUFBdE4sQ0FBQSxFQUFBdU4sRUFBQSxFQUFBQyxFQUFBLEVBQUExTSxHQUFBO0FBQUFkLFFBQUksRUFBSjs7QUFDQSxRQUFHLEtBQUMxRCxVQUFELEtBQWUsQ0FBZixJQUFvQixLQUFDbUMsZ0JBQUQsR0FBb0IsQ0FBM0M7QUFDRSxhQUFPdUIsQ0FBUDtBQzJKRDs7QUQxSkRzTixnQkFBWXBOLEtBQUt1TixLQUFMLENBQVcsQ0FBQyxLQUFDaFAsZ0JBQUQsR0FBb0IsQ0FBckIsSUFBMEIsQ0FBckMsQ0FBWjs7QUFDQSxTQUFTNE8sSUFBQXpFLElBQUEsR0FBQTlILE1BQUFHLEVBQUF5TSxHQUFBLEVBQUFKLFNBQUEsT0FBQWhSLFVBQUEsRUFBVCxFQUFTLEtBQUF3RSxHQUFBLEdBQUE4SCxLQUFBOUgsR0FBQSxHQUFBOEgsS0FBQTlILEdBQVQsRUFBU3VNLElBQUEsS0FBQXZNLEdBQUEsS0FBQThILENBQUEsS0FBQUEsQ0FBVDtBQUNFMkUsV0FBS2hLLE9BQU84SixDQUFaOztBQUNBLFVBQUdFLE1BQU0sS0FBQ3RKLElBQUQsQ0FBTSxZQUFOLENBQVQ7QUFDRWpFLFVBQUV1RixJQUFGLENBQU9nSSxFQUFQO0FDNEpEOztBRDNKREMsV0FBS2pLLE9BQU84SixDQUFaOztBQUNBLFVBQUdHLEtBQUssQ0FBUjtBQUNFeE4sVUFBRXVGLElBQUYsQ0FBT2lJLEVBQVA7QUM2SkQ7QURuS0g7O0FDcUtBLFdEOUpBeE4sQ0M4SkE7QUQxS1MsR0N5Slg7O0FBb0JBcEUsUUFBTVEsU0FBTixDRC9KQXVSLGNDK0pBLEdEL0pnQixVQUFDcEssSUFBRDtBQUNkLFFBQUFxRixDQUFBLEVBQUFDLEdBQUEsRUFBQTVELENBQUEsRUFBQW5FLEdBQUEsRUFBQXdFLE9BQUE7QUFBQXhFLFVBQUEsS0FBQXNNLFNBQUEsQ0FBQTdKLElBQUE7QUFBQStCLGNBQUE7O0FDa0tBLFNEbEtBc0QsSUFBQSxHQUFBQyxNQUFBL0gsSUFBQTVFLE1Da0tBLEVEbEtBME0sSUFBQUMsR0NrS0EsRURsS0FELEdDa0tBLEVEbEtBO0FDbUtFM0QsVUFBSW5FLElBQUk4SCxDQUFKLENBQUo7O0FEbEtBLFVBQWtCLENBQUMsS0FBQ2pGLFFBQUQsQ0FBVXNCLENBQVYsQ0FBRCxJQUFrQixDQUFDLEtBQUN2QixTQUFELENBQVd1QixDQUFYLENBQW5CLElBQXFDbkosUUFBQTBILElBQUEsQ0FBUyxLQUFDSSxLQUFWLEVBQUFxQixDQUFBLEtBQXZEO0FDb0tFSyxnQkFBUUMsSUFBUixDRHBLRixLQUFDM0IsS0FBRCxDQUFPMkIsSUFBUCxDQUFZTixDQUFaLENDb0tFO0FEcEtGO0FDc0tFSyxnQkFBUUMsSUFBUixDQUFhLEtBQUssQ0FBbEI7QUFDRDtBRHhLSDs7QUMwS0EsV0FBT0QsT0FBUDtBRDNLYyxHQytKaEI7O0FBZUExSixRQUFNUSxTQUFOLENEMUtBd1IsaUJDMEtBLEdEMUttQixVQUFDQyxLQUFELEVBQVF0SyxJQUFSLEVBQWN1SyxRQUFkLEVBQXdCQyxNQUF4QjtBQzJLakIsUUFBSUEsVUFBVSxJQUFkLEVBQW9CO0FEM0txQkEsZUFBUyxLQUFUO0FDNkt4Qzs7QUFDRCxXRDdLQTtBQUFBOUksU0FBRzRJLEtBQUg7QUFDQTdOLFNBQUd1RCxJQURIO0FBRUF3SyxjQUFXQSxTQUFZLFFBQVosR0FBMEIsRUFGckM7QUFHQUQsZ0JBQWFBLFdBQWMsVUFBZCxHQUE4QjtBQUgzQyxLQzZLQTtBRDlLaUIsR0MwS25COztBQVlBbFMsUUFBTVEsU0FBTixDRGhMQTRSLG1CQ2dMQSxHRGhMcUI7QUFDbkIsUUFBQUMsSUFBQSxFQUFBalMsQ0FBQSxFQUFBNE0sQ0FBQSxFQUFBaEssQ0FBQSxFQUFBaUssR0FBQSxFQUFBcUYsQ0FBQSxFQUFBbE8sQ0FBQSxFQUFBaUYsQ0FBQSxFQUFBMUIsSUFBQSxFQUFBekMsR0FBQSxFQUFBc0UsSUFBQSxFQUFBK0ksRUFBQSxFQUFBbkosS0FBQTtBQUFBekIsV0FBTyxLQUFDMkIsV0FBRCxFQUFQO0FBQ0FGLFlBQVEsS0FBQ2YsSUFBRCxDQUFNLFlBQU4sQ0FBUjtBQUNBZ0ssV0FBTzFLLE9BQU8sS0FBQ2pHLGdCQUFmO0FBQ0E2USxTQUFLNUssT0FBTyxLQUFDakcsZ0JBQWI7O0FBQ0EsUUFBRzJRLE9BQU8sQ0FBVjtBQUNJRSxZQUFNLElBQUlGLElBQVY7QUFDQUEsYUFBTyxDQUFQO0FDa0xIOztBRGpMRCxRQUFHRSxLQUFLbkosS0FBUjtBQUNJaUosY0FBUUUsS0FBS25KLEtBQWI7QUFDQW1KLFdBQUtuSixLQUFMO0FDbUxIOztBRGxMRCxRQUFZaUosT0FBTyxDQUFuQjtBQUFBQSxhQUFPLENBQVA7QUNxTEM7O0FEcExELFFBQWNFLEtBQUtuSixLQUFuQjtBQUFBbUosV0FBS25KLEtBQUw7QUN1TEM7O0FEdExEaEYsUUFBSSxFQUFKOztBQUNBLFFBQUcsS0FBQzdDLFlBQUQsSUFBaUIsS0FBQ0QsWUFBckI7QUFDRThDLFFBQUV1RixJQUFGLENBQU8sS0FBQ3FJLGlCQUFELENBQW1CLEdBQW5CLEVBQXdCLENBQXhCLEVBQTJCckssU0FBUSxDQUFuQyxDQUFQO0FDd0xEOztBRHZMRHZELE1BQUV1RixJQUFGLENBQU8sS0FBQ3FJLGlCQUFELENBQW1CLEdBQW5CLEVBQXdCckssT0FBTyxDQUEvQixFQUFrQ0EsU0FBUSxDQUExQyxDQUFQOztBQUNBLFNBQVMwQixJQUFBMkQsSUFBQTlILE1BQUFtTixJQUFBLEVBQUE3SSxPQUFBK0ksRUFBVCxFQUFTck4sT0FBQXNFLElBQUEsR0FBQXdELEtBQUF4RCxJQUFBLEdBQUF3RCxLQUFBeEQsSUFBVCxFQUFTSCxJQUFBbkUsT0FBQXNFLElBQUEsS0FBQXdELENBQUEsS0FBQUEsQ0FBVDtBQUNFNUksUUFBRXVGLElBQUYsQ0FBTyxLQUFDcUksaUJBQUQsQ0FBbUIzSSxDQUFuQixFQUFzQkEsQ0FBdEIsRUFBeUIxQixPQUFPeUIsS0FBaEMsRUFBdUNDLE1BQUsxQixJQUE1QyxDQUFQO0FBREY7O0FBRUF2RCxNQUFFdUYsSUFBRixDQUFPLEtBQUNxSSxpQkFBRCxDQUFtQixHQUFuQixFQUF3QnJLLE9BQU8sQ0FBL0IsRUFBa0NBLFFBQVF5QixLQUExQyxDQUFQOztBQUNBLFFBQUcsS0FBQzVILFdBQUQsSUFBZ0IsS0FBQ0YsWUFBcEI7QUFDRThDLFFBQUV1RixJQUFGLENBQU8sS0FBQ3FJLGlCQUFELENBQW1CLEdBQW5CLEVBQXdCNUksS0FBeEIsRUFBK0J6QixRQUFReUIsS0FBdkMsQ0FBUDtBQzBMRDs7QUR6TEQsU0FBQXBHLElBQUFzUCxJQUFBLEdBQUFyRixNQUFBN0ksRUFBQTlELE1BQUEsRUFBQWdTLElBQUFyRixHQUFBLEVBQUFqSyxJQUFBLEVBQUFzUCxDQUFBO0FDMkxFbFMsVUFBSWdFLEVBQUVwQixDQUFGLENBQUo7QUQxTEFvQixRQUFFcEIsQ0FBRixFQUFLLElBQUwsSUFBYSxJQUFiO0FBREY7O0FDOExBLFdENUxBb0IsQ0M0TEE7QURwTm1CLEdDZ0xyQjs7QUF1Q0FwRSxRQUFNUSxTQUFOLENEN0xBOE0sVUM2TEEsR0Q3TFksVUFBQ2xKLENBQUQ7QUFDVixRQUFHQSxLQUFLLEtBQUNpRSxJQUFELENBQU0sWUFBTixDQUFMLElBQTZCakUsSUFBSSxDQUFwQztBQUNFb0UsY0FBUTZFLFdBQVIsQ0FBb0IsVUFBQTdGLEtBQUE7QUM4TGxCLGVEOUxrQjtBQUNsQixjQUFBZ0wsRUFBQTtBQUFBQSxlQUFLaEwsTUFBQ2EsSUFBRCxDQUFNLGFBQU4sQ0FBTDs7QUFDQSxjQUFHYixNQUFDTyxRQUFELENBQVV5SyxFQUFWLENBQUg7QUNnTUksbUJEL0xGaEwsTUFBQ2EsSUFBRCxDQUFNLFNBQU4sRUFBaUJtSyxFQUFqQixDQytMRTtBQUNEO0FEbk1lLFNDOExsQjtBRDlMa0IsYUFBcEI7QUNzTUEsYURsTUEsS0FBQ25LLElBQUQsQ0FBTSxhQUFOLEVBQXFCakUsQ0FBckIsQ0NrTUE7QUFDRDtBRHpNUyxHQzZMWjs7QUFlQXBFLFFBQU1RLFNBQU4sQ0RwTUF5SSxrQkNvTUEsR0RwTW9CO0FBQ2xCLFNBQUN2RixpQkFBRCxHQUFxQixLQUFDQSxpQkFBRCxJQUFzQitPLE1BQTNDO0FBQ0EsU0FBQ0MsU0FBRCxHQUFhQyxFQUFFLEtBQUNqUCxpQkFBSCxDQUFiO0FDcU1BLFdEcE1BLEtBQUNnUCxTQUFELENBQVdFLE1BQVgsQ0FBa0J2TixFQUFFMEUsSUFBRixDQUNoQjFFLEVBQUU2RCxRQUFGLENBQVc7QUFDVCxVQUFBN0ksQ0FBQSxFQUFBd1MsRUFBQSxFQUFBaEcsQ0FBQTtBQUFBQSxVQUFJLEtBQUNwSyxlQUFMO0FBQ0FvUSxXQUFLLEtBQUNILFNBQUQsQ0FBVyxDQUFYLEVBQWNJLFlBQW5COztBQUNBLFVBQVcsS0FBQXhLLGdCQUFBLFlBQXVCLEtBQUNBLGdCQUFELEdBQW9CdUssRUFBdEQ7QUFBQTtBQ3NNRDs7QURyTUMsV0FBQ3ZLLGdCQUFELEdBQW9CdUssRUFBcEI7O0FBQ0EsVUFBR2hHLElBQUksQ0FBUDtBQUNFeE0sWUFBSXdTLEtBQUtoRyxDQUFUO0FBREYsYUFFSyxJQUFHQSxJQUFJLENBQVA7QUFDSHhNLFlBQUl3UyxLQUFLaEcsQ0FBVDtBQURHO0FBR0g7QUN1TUg7O0FEck1DLFVBQUksS0FBQzZGLFNBQUQsQ0FBV0ssU0FBWCxLQUF5QixLQUFDTCxTQUFELENBQVcsQ0FBWCxFQUFjTSxZQUF2QyxJQUF1RDNTLENBQTNEO0FDdU1BLGVEdE1FLEtBQUNnSSxJQUFELENBQU0sT0FBTixFQUFlLEtBQUNBLElBQUQsQ0FBTSxPQUFOLElBQWlCLEtBQUMxRixZQUFqQyxDQ3NNRixDRHZNQSxDQUdFOzs7OztBQzJNSDtBRDFORCxPQXFCRSxLQUFDRCxpQkFBRCxHQUFxQixJQXJCdkIsQ0FEZ0IsRUF1QmYsSUF2QmUsQ0FBbEIsQ0NvTUE7QUR2TWtCLEdDb01wQjs7QUE4QkExQyxRQUFNUSxTQUFOLENEdE1BeVMsVUNzTUEsR0R0TVk1TixFQUFFNkQsUUFBRixDQUFXO0FBRXJCLFFBQUFzSixFQUFBLEVBQUFwUyxDQUFBLEVBQUE0QyxDQUFBLEVBQUF3TyxTQUFBLEVBQUF0TSxHQUFBLEVBQUF3RSxPQUFBLEVBQUF3SixRQUFBLEVBQUFqUSxDQUFBO0FBQUF1UCxTQUFLLEtBQUNsSixXQUFELEVBQUw7QUFDQWtJLGdCQUFZLEtBQUNBLFNBQUQsQ0FBV2dCLEVBQVgsQ0FBWjs7QUFLQSxRQUFHLENBQUMsS0FBQ3pLLFFBQUQsQ0FBVXlLLEVBQVYsQ0FBSjtBQUVFLFdBQUNqQixVQUFEO0FBQ0EsV0FBQzRCLFdBQUQsQ0FBYVgsRUFBYjtBQUNBQSxXQUFLeFIsT0FBT3dSLEVBQVAsQ0FBTDtBQUNBdE4sWUFBQSxLQUFBNEMsU0FBQTtBQUFBNEIsZ0JBQUE7O0FDbU1BLFdEbk1BMUcsQ0NtTUEsMkNEbk1Ba0MsR0NtTUEsR0RuTUE7QUNvTUVqQyxZQUFJaUMsSUFBSWxDLENBQUosQ0FBSjs7QURuTUEsWUFBR0EsTUFBT3dQLEVBQVY7QUFDRSxjQUFHLEtBQUEzTSxhQUFBLENBQUE3QyxDQUFBLFNBQUg7QUFDRSxpQkFBQzZDLGFBQUQsQ0FBZTdDLENBQWYsRUFBa0I4QyxJQUFsQjtBQUNBLG1CQUFPLEtBQUNELGFBQUQsQ0FBZTdDLENBQWYsQ0FBUDtBQUNBLGlCQUFDNkMsYUFBRCxDQUFldkYsTUFBZjtBQ3FNRDs7QUFDRG9KLGtCQUFRQyxJQUFSLENEck1BLE9BQU8sS0FBQzdCLFNBQUQsQ0FBVzlFLENBQVgsQ0NxTVA7QUQxTUY7QUM0TUUwRyxrQkFBUUMsSUFBUixDQUFhLEtBQUssQ0FBbEI7QUFDRDtBRDlNSDs7QUNnTkEsYUFBT0QsT0FBUDtBRHJORixXQWVLLElBQUcsS0FBQzFCLEtBQUQsQ0FBTzFILE1BQVY7QUFFSDRTLGlCQUFBOztBQ3VNQSxhRHZNTSxLQUFDbEwsS0FBRCxDQUFPMUgsTUFBUCxHQUFnQixDQ3VNdEIsRUR2TUE7QUFDRUYsWUFBSSxLQUFDNEgsS0FBRCxDQUFPb0wsS0FBUCxFQUFKOztBQUNBLFlBQUdsVCxRQUFBMEgsSUFBQSxDQUFLNEosU0FBTCxFQUFBcFIsQ0FBQSxNQUFIO0FBRUUsZUFBQytTLFdBQUQsQ0FBYS9TLENBQWI7QUFDQTtBQUhGO0FDMk1FOFMsbUJBQVN2SixJQUFULENBQWMsS0FBSyxDQUFuQjtBQUNEO0FEOU1IOztBQ2dOQSxhQUFPdUosUUFBUDtBQUNEO0FEMU9TLEtBK0JWLEdBL0JVLENDc01aOztBQXVDQWxULFFBQU1RLFNBQU4sQ0Q1TUE4SSxXQzRNQSxHRDVNYTtBQUNYLFFBQUd0RCxPQUFPOEUsUUFBUCxJQUFvQixLQUFBekMsSUFBQSx1QkFBdkI7QUM2TUUsYUQ1TUEsS0FBQ0EsSUFBRCxDQUFNLGFBQU4sQ0M0TUE7QUQ3TUY7QUMrTUUsYUQ1TUEsS0FBQzFCLFlDNE1EO0FBQ0Q7QURqTlUsR0M0TWI7O0FBUUEzRyxRQUFNUSxTQUFOLENEOU1BbU4sT0M4TUEsR0Q5TVM7QUMrTVAsV0Q5TUEsS0FBQ3RGLElBQUQsQ0FBTSxPQUFOLENDOE1BO0FEL01PLEdDOE1UOztBQUlBckksUUFBTVEsU0FBTixDRC9NQTRPLEtDK01BLEdEL01PLFVBQUMvRixDQUFEO0FBQ0wsUUFBR0EsTUFBSyxJQUFMLElBQWFBLE1BQUssS0FBQ0MsV0FBRCxFQUFMLElBQXdCLE9BQUFrQixPQUFBLG9CQUFBQSxZQUFBLElBQXhDO0FDZ05FLGFEL01BLEtBQUNuQyxJQUFELENBQU0sT0FBTixFQUFlLElBQWYsQ0MrTUE7QUFDRDtBRGxOSSxHQytNUDs7QUFNQXJJLFFBQU1RLFNBQU4sQ0RqTkE2UyxhQ2lOQSxHRGpOZTtBQUNiLFFBQUFuTyxHQUFBLEVBQUFzRSxJQUFBLEVBQUFvQyxJQUFBOztBQUFBLFFBQUcsS0FBQ3pGLElBQUQsSUFBVSxDQUFDLEtBQUN2RCxRQUFmO0FBQ0UsVUFBRyxLQUFDZixNQUFKO0FDbU5FLFlBQUksQ0FBQ3FELE1BQU1zSCxPQUFPQyxPQUFQLEVBQVAsS0FBNEIsSUFBaEMsRUFBc0M7QUFDcEMsY0FBSSxDQUFDakQsT0FBT3RFLElBQUl0RCxLQUFaLEtBQXNCLElBQTFCLEVBQWdDO0FBQzlCNEgsaUJEcE5xQjhKLE9Db05yQjtBQUNEO0FBQ0Y7O0FEck5EO0FBQ0UsZUFBQzFRLFFBQUQsR0FBWXVKLFNBQUEsQ0FBQVAsT0FBQVksT0FBQUMsT0FBQSxHQUFBN0ssS0FBQSxDQUFBMkssTUFBQSxDQUFBZ0gsU0FBQUMsSUFBQSxhQUFBNUgsS0FBdURqRSxJQUF2RCxHQUF1RCxNQUF2RCxLQUFnRSxDQUE1RTtBQURGLGlCQUFBNUMsS0FBQTtBQUdFO0FBTEo7QUFBQTtBQU9FLGFBQUNuQyxRQUFELEdBQVksQ0FBWjtBQVJKO0FDaU9DOztBRHhORCxTQUFDdUQsSUFBRCxHQUFRLEtBQVI7QUFDQSxTQUFDa0MsSUFBRCxDQUFNLFNBQU4sRUFBaUIsS0FBQ3pGLFFBQWxCO0FDME5BLFdEek5BLEtBQUN5RixJQUFELENBQU0sYUFBTixFQUFxQixLQUFDekYsUUFBdEIsQ0N5TkE7QURyT2EsR0NpTmY7O0FBdUJBNUMsUUFBTVEsU0FBTixDRDFOQWlULE9DME5BLEdEMU5TLFVBQUM5TCxJQUFEO0FBQ1AsUUFBQW9ILENBQUEsRUFBQTNLLENBQUEsRUFBQWdGLEtBQUE7O0FBQUEsUUFBR3BELE9BQU84RSxRQUFWO0FBQ0UsVUFBMkJuRCxRQUFBLElBQTNCO0FBQUFBLGVBQU8sS0FBQzJCLFdBQUQsRUFBUDtBQzZOQzs7QUQ1TkQzQixhQUFPd0UsU0FBU3hFLElBQVQsQ0FBUDs7QUFDQSxVQUFXQSxTQUFRLEtBQW5CO0FBQUE7QUMrTkM7O0FEOU5EeUIsY0FBUSxLQUFDZixJQUFELENBQU0sWUFBTixDQUFSOztBQUNBLFVBQXVCZSxVQUFTLENBQWhDO0FBQUEsZUFBTyxLQUFDZ0csS0FBRCxDQUFPLElBQVAsQ0FBUDtBQ2lPQzs7QUQ3TkQsVUFBR3pILFFBQVF5QixLQUFYO0FBQ0UsYUFBQytKLFdBQUQsQ0FBYXhMLElBQWI7QUFDQSxhQUFDb0ssY0FBRCxDQUFnQnBLLElBQWhCO0FBQ0EsYUFBQ3NMLFVBQUQ7QUMrTkQ7O0FEek5ELFVBQUcsS0FBQzFRLFFBQUo7QUFDRTZCLFlBQUksS0FBQ0ksVUFBRCxDQUFZQyxJQUFaLENBQWlCLEVBQWpCLEVBQ0Y7QUFBQXZELGtCQUFRLEtBQUNBLE1BQVQ7QUFDQWMsZ0JBQU0sS0FBQ0E7QUFEUCxTQURFLEVBR0YyQyxLQUhFLEVBQUo7QUFJQW9LLFlBQUksS0FBQ3ZLLFVBQUQsQ0FBWUMsSUFBWixDQUFpQixFQUFqQixFQUNGO0FBQUF2RCxrQkFBUSxLQUFDQSxNQUFUO0FBQ0FjLGdCQUFNLEtBQUNBLElBRFA7QUFFQXNOLGdCQUFTbEwsSUFBSSxLQUFDNUIsa0JBQUwsR0FBNkI0QixJQUFJLEtBQUM1QixrQkFBbEMsR0FBMEQsQ0FGbkU7QUFHQWlOLGlCQUFPLEtBQUNwSCxJQUFELENBQU0sT0FBTixLQUFrQixLQUFDN0Y7QUFIMUIsU0FERSxDQUFKO0FBTEY7QUFZRXVNLFlBQUksS0FBQ3ZLLFVBQUQsQ0FBWUMsSUFBWixDQUNGWSxFQUFFdUksTUFBRixDQUFTLENBQ1AsQ0FBQyxNQUFJLEtBQUN4SSxFQUFMLEdBQVEsSUFBVCxFQUFjdUMsSUFBZCxDQURPLENBQVQsQ0FERSxFQUlGO0FBQUF6RyxrQkFBUSxLQUFDQSxNQUFUO0FBQ0FjLGdCQUFNcUQsRUFBRXVJLE1BQUYsQ0FBUyxDQUNiLENBQUMsTUFBSSxLQUFDeEksRUFBTCxHQUFRLElBQVQsRUFBYyxDQUFkLENBRGEsQ0FBVDtBQUROLFNBSkUsQ0FBSjtBQVNBMkosVUFBRXlCLGNBQUYsQ0FDRTtBQUFBRixpQkFBTyxVQUFBOUksS0FBQTtBQ3NOTCxtQkR0Tks7QUN1TkgscUJEdE5GQSxNQUFDb0IsVUFBRCxFQ3NORTtBRHZORyxhQ3NOTDtBRHROSyxpQkFBUDtBQUVBK0gsbUJBQVMsVUFBQW5KLEtBQUE7QUN5TlAsbUJEek5PO0FBR1Asc0JBR0FBLE1BQUMyTCxXQUFELENBQWEzTCxNQUFDYSxJQUFELENBQU0sYUFBTixDQUFiOztBQ3VORSxxQkR0TkZiLE1BQUNvQixVQUFELEVDc05FO0FEN05LLGFDeU5QO0FEek5PO0FBRlQsU0FERjtBQ29PRDs7QUFDRCxhRHpOQW1HLEVBQUVhLEtBQUYsRUN5TkE7QUFDRDtBRDlRTSxHQzBOVDs7QUF1REE1UCxRQUFNUSxTQUFOLENEek5BMlMsV0N5TkEsR0R6TmEsVUFBQ3hMLElBQUQ7QUFDWCxRQUFXLENBQUNBLElBQUQsSUFBUyxLQUFDRyxTQUFELENBQVdILElBQVgsQ0FBVCxJQUE2QixLQUFDSSxRQUFELENBQVVKLElBQVYsQ0FBeEM7QUFBQTtBQzJOQzs7QUQxTkQsU0FBQ3ZFLEdBQUQsQ0FBSyxxQkFBbUJ1RSxJQUF4QjtBQUNBLFNBQUN3SixVQUFELENBQVl4SixJQUFaOztBQUNBLFFBQUcsQ0FBQzNCLE9BQU8wQyxNQUFQLEdBQWdCZ0csU0FBakIsSUFBK0IsS0FBQ3ZHLFFBQW5DO0FBQ0UsVUFBRyxLQUFDM0QsVUFBRCxDQUFZbUssT0FBWixDQUFvQnRKLEVBQUV1SSxNQUFGLENBQVMsQ0FBQyxDQUFDLE1BQUksS0FBQ3hJLEVBQUwsR0FBUSxJQUFULEVBQWN1QyxJQUFkLENBQUQsQ0FBVCxDQUFwQixDQUFIO0FDNE5FLGVEM05BLEtBQUMrTCxNQUFELENBQVEvTCxJQUFSLENDMk5BO0FENU5GO0FDOE5FLGVEM05Ba0gsV0FBWXhKLEVBQUUwRSxJQUFGLENBQU8sVUFBQ3BDLElBQUQ7QUFDakIsY0FBRyxLQUFDMkIsV0FBRCxPQUFrQjNCLElBQWxCLElBQTJCLENBQUMsS0FBQ0ksUUFBRCxDQUFVSixJQUFWLENBQS9CO0FBQ0UsbUJBQU8sS0FBQ0csU0FBRCxDQUFXSCxJQUFYLENBQVA7QUM0TkEsbUJEM05BLEtBQUN3TCxXQUFELENBQWF4TCxJQUFiLENDMk5BO0FBQ0Q7QUQvTlMsV0FJVixJQUpVLEVBSVBBLElBSk8sQ0FBWixFQUtFLEdBTEYsQ0MyTkE7QUQvTko7QUFBQTtBQVdFLFdBQUNtSCx3QkFBRDtBQzZOQSxhRDVOQTlJLE9BQU8yTixLQUFQLENBQWF0TyxFQUFFMEUsSUFBRixDQUFRLFVBQUNwQyxJQUFEO0FBRW5CLGFBQUM5QixhQUFELENBQWU4QixJQUFmLElBQXVCM0IsT0FBT3lILFNBQVAsQ0FBaUIsS0FBQ3JJLEVBQWxCLEVBQXNCdUMsSUFBdEIsRUFDckI7QUFBQWlNLG1CQUFTdk8sRUFBRTBFLElBQUYsQ0FBTyxVQUFDcEMsSUFBRDtBQzROZCxtQkQzTkEsS0FBQytMLE1BQUQsQ0FBUS9MLElBQVIsQ0MyTkE7QUQ1Tk8sYUFFUCxJQUZPLEVBRUpBLElBRkksQ0FBVDtBQUdBa00sbUJBQVMsVUFBQXJNLEtBQUE7QUM0TlAsbUJENU5PLFVBQUN0RSxDQUFEO0FBQ1Asa0JBQUdBLEVBQUU2QixLQUFGLEtBQVcsNEJBQWQ7QUM2TkksdUJENU5GOEosV0FBWXhKLEVBQUUwRSxJQUFGLENBQU8sVUFBQ3BDLElBQUQ7QUFDakIsc0JBQUcsS0FBQzJCLFdBQUQsT0FBa0IzQixJQUFsQixJQUEyQixDQUFDLEtBQUNJLFFBQUQsQ0FBVUosSUFBVixDQUEvQjtBQUNFLDJCQUFPLEtBQUNHLFNBQUQsQ0FBV0gsSUFBWCxDQUFQO0FDNk5FLDJCRDVORixLQUFDd0wsV0FBRCxDQUFheEwsSUFBYixDQzRORTtBQUNEO0FEaE9PLG1CQUlWSCxLQUpVLEVBSVBHLElBSk8sQ0FBWixFQUtFLEdBTEYsQ0M0TkU7QUQ3Tko7QUNvT0ksdUJENU5GSCxNQUFDekMsS0FBRCxDQUFPN0IsRUFBRTRRLE9BQVQsQ0M0TkU7QUFDRDtBRHRPSSxhQzROUDtBRDVOTztBQUhULFNBRHFCLENBQXZCO0FBY0EsYUFBQ2pPLGFBQUQsQ0FBZVksS0FBZixDQUFxQmtELElBQXJCLENBQTBCaEMsSUFBMUI7QUNpT0EsZURoT0EsS0FBQzlCLGFBQUQsQ0FBZXZGLE1BQWYsRUNnT0E7QURqUGtCLE9BQVAsRUFtQlYsSUFuQlUsRUFtQlBxSCxJQW5CTyxDQUFiLENDNE5BO0FBdUJEO0FEblFVLEdDeU5iOztBQTZDQTNILFFBQU1RLFNBQU4sQ0QvTkFrVCxNQytOQSxHRC9OUSxVQUFDL0wsSUFBRDtBQUNOLFNBQUN2RSxHQUFELENBQUssbUJBQWlCdUUsSUFBdEI7QUFDQSxTQUFDdkIsZ0JBQUQsR0FBb0IsS0FBcEI7QUFDQSxTQUFDa0wsV0FBRCxDQUFhM0osSUFBYjtBQUNBLFNBQUN5SCxLQUFELENBQU96SCxJQUFQOztBQUNBLFFBQUcsS0FBQ3BGLFFBQUo7QUFDRSxXQUFDd1IsUUFBRCxHQUFZcE0sSUFBWjtBQ2dPRDs7QUQvTkQsU0FBQ2lCLFVBQUQ7QUNpT0EsV0RoT0EsS0FBQ3FLLFVBQUQsRUNnT0E7QUR4T00sR0MrTlI7O0FBWUEsU0FBT2pULEtBQVA7QUFFRCxDRG5zQ2dCLEVBQWpCOztBQWcrQkFnRyxPQUFPQyxVQUFQLEdBQW9CakcsS0FBcEIsQyIsImZpbGUiOiIvcGFja2FnZXMvYWxldGhlc19wYWdlcy5qcyIsInNvdXJjZXNDb250ZW50IjpbIkBfX1BhZ2VzID0gY2xhc3MgUGFnZXNcblxuICBzZXR0aW5nczpcbiAgICBcbiAgICAjc2V0dGluZ05hbWU6IFtjYW5CZU1hZGVBdmFpbGFibGVUb1RoZUNsaWVudCwgZXhwZWN0ZWRUeXBlcyhzKSwgZGVmYXVsdFZhbHVlXVxuICAgIFxuICAgIGRhdGFNYXJnaW46IFt0cnVlLCBOdW1iZXIsIDNdXG4gICAgZGl2V3JhcHBlcjogW3RydWUsIE1hdGNoLk9uZU9mKFxuICAgICAgTWF0Y2guT3B0aW9uYWwoU3RyaW5nKVxuICAgICAgTWF0Y2guT3B0aW9uYWwoQm9vbGVhbilcbiAgICApLCBcInBhZ2VzQ29udFwiXSAjSWYgZGVmaW5lZCwgc2hvdWxkIGJlIHRoZSB3cmFwcGVyJ3MgQ1NTIGNsYXNzbmFtZVxuICAgIGZpZWxkczogW3RydWUsIE9iamVjdCwge31dXG4gICAgZmlsdGVyczogW3RydWUsIE9iamVjdCwge31dXG4gICAgaXRlbVRlbXBsYXRlOiBbdHJ1ZSwgU3RyaW5nLCBcIl9wYWdlc0l0ZW1EZWZhdWx0XCJdXG4gICAgbmF2U2hvd0VkZ2VzOiBbdHJ1ZSwgQm9vbGVhbiwgZmFsc2VdICNJZiB0cnVlLCBvdmVycmlkZXMgbmF2U2hvd0ZpcnN0IGFuZCBuYXZTaG93TGFzdFxuICAgIG5hdlNob3dGaXJzdDogW3RydWUsIEJvb2xlYW4sIHRydWVdICNJZiB0cnVlLCBvdmVycmlkZXMgbmF2U2hvd0VkZ2VzXG4gICAgbmF2U2hvd0xhc3Q6IFt0cnVlLCBCb29sZWFuLCB0cnVlXSAjSWYgdHJ1ZSwgb3ZlcnJpZGVzIG5hdlNob3dFZGdlc1xuICAgIHJlc2V0T25SZWxvYWQ6IFt0cnVlLCBCb29sZWFuLCBmYWxzZV1cbiAgICBwYWdpbmF0aW9uTWFyZ2luOiBbdHJ1ZSwgTnVtYmVyLCAzXVxuICAgIHBlclBhZ2U6IFt0cnVlLCBOdW1iZXIsIDEwXVxuICAgICNyZXF1ZXN0VGltZW91dDogW3RydWUsIE51bWJlciwgMl1cbiAgICByb3V0ZTogW3RydWUsIFN0cmluZywgXCIvcGFnZS9cIl1cbiAgICByb3V0ZXI6IFt0cnVlLCBNYXRjaC5PcHRpb25hbChTdHJpbmcpLCB1bmRlZmluZWRdICNDYW4gYmUgYW55IHR5cGUuIFVzZSBvbmx5IGluIGNvbXBhcmlzb25zLiBFeHBlY3RzIFN0cmluZyBvciBCb29sZWFuXG4gICAgcm91dGVyVGVtcGxhdGU6IFt0cnVlLCBTdHJpbmcsIFwicGFnZXNcIl1cbiAgICByb3V0ZXJMYXlvdXQ6IFt0cnVlLCBNYXRjaC5PcHRpb25hbChTdHJpbmcpLCB1bmRlZmluZWRdXG4gICAgc29ydDogW3RydWUsIE9iamVjdCwge31dXG4gICAgXG4gICAgIyBVbmF2YWlsYWJsZSB0byB0aGUgY2xpZW50IGFmdGVyIGluaXRpYWxpemF0aW9uXG4gICAgXG4gICAgYXV0aDogW2ZhbHNlLCBNYXRjaC5PcHRpb25hbChGdW5jdGlvbiksIHVuZGVmaW5lZF1cbiAgICBhdmFpbGFibGVTZXR0aW5nczogW2ZhbHNlLCBPYmplY3QsIHt9XVxuICAgIGZhc3RSZW5kZXI6IFtmYWxzZSwgQm9vbGVhbiwgZmFsc2VdXG4gICAgaG9tZVJvdXRlOiBbZmFsc2UsIE1hdGNoLk9uZU9mKFN0cmluZywgQXJyYXksIEJvb2xlYW4pLCBcIi9cIl1cbiAgICBpbmZpbml0ZTogW2ZhbHNlLCBCb29sZWFuLCBmYWxzZV1cbiAgICBpbmZpbml0ZUl0ZW1zTGltaXQ6IFtmYWxzZSwgTnVtYmVyLCBJbmZpbml0eV1cbiAgICBpbmZpbml0ZVRyaWdnZXI6IFtmYWxzZSwgTnVtYmVyLCAuOV1cbiAgICBpbmZpbml0ZVJhdGVMaW1pdDogW2ZhbHNlLCBOdW1iZXIsIDFdXG4gICAgaW5maW5pdGVTdGVwOiBbZmFsc2UsIE51bWJlciwgMTBdXG4gICAgaW5pdFBhZ2U6IFtmYWxzZSwgTnVtYmVyLCAxXVxuICAgIG1heFN1YnNjcmlwdGlvbnM6IFtmYWxzZSwgTnVtYmVyLCAyMF1cbiAgICBuYXZUZW1wbGF0ZTogW2ZhbHNlLCBTdHJpbmcsIFwiX3BhZ2VzTmF2Q29udFwiXVxuICAgIG9uRGVuaWVkU2V0dGluZzogW2ZhbHNlLCBGdW5jdGlvbiwgKGssIHYsIGUpIC0+IGNvbnNvbGU/LmxvZyBcIkNoYW5naW5nICN7a30gbm90IGFsbG93ZWQuXCJdXG4gICAgcGFnZUNvdW50RnJlcXVlbmN5OiBbZmFsc2UsIE51bWJlciwgMTAwMDBdXG4gICAgcGFnZVNpemVMaW1pdDogW2ZhbHNlLCBOdW1iZXIsIDYwXVxuICAgIHBhZ2VUZW1wbGF0ZTogW2ZhbHNlLCBTdHJpbmcsIFwiX3BhZ2VzUGFnZUNvbnRcIl1cbiAgICByYXRlTGltaXQ6IFtmYWxzZSwgTnVtYmVyLCAxXVxuICAgIHJvdXRlU2V0dGluZ3M6IFtmYWxzZSwgTWF0Y2guT3B0aW9uYWwoRnVuY3Rpb24pLCB1bmRlZmluZWRdXG4gICAgc2Nyb2xsQm94U2VsZWN0b3I6IFsgU3RyaW5nLCB1bmRlZmluZWQgXVxuICAgIHRhYmxlOiBbZmFsc2UsIE1hdGNoLk9uZU9mKEJvb2xlYW4sIE9iamVjdCksIGZhbHNlXVxuICAgIHRhYmxlSXRlbVRlbXBsYXRlOiBbZmFsc2UsIFN0cmluZywgXCJfcGFnZXNUYWJsZUl0ZW1cIl1cbiAgICB0YWJsZVRlbXBsYXRlOiBbZmFsc2UsIFN0cmluZywgXCJfcGFnZXNUYWJsZVwiXVxuICAgIHRlbXBsYXRlTmFtZTogW2ZhbHNlLCBNYXRjaC5PcHRpb25hbChTdHJpbmcpLCB1bmRlZmluZWRdICNEZWZhdWx0cyB0byBjb2xsZWN0aW9uIG5hbWVcbiAgXG4gICMgUHJvdG90eXBlIHZhcmlhYmxlcyAoc2hhcmVkIGJldHdlZW4gaW5zdGFuY2VzKVxuICBcbiAgX25JbnN0YW5jZXM6IDBcbiAgY29sbGVjdGlvbnM6IHt9XG4gIGluc3RhbmNlczoge31cbiAgXG4gIG1ldGhvZHM6XG4gICAgXG4gICAgXCJDb3VudFBhZ2VzXCI6IChzdWIpIC0+XG4gICAgICBuID0gc3ViLmdldCBcIm5QdWJsaXNoZWRQYWdlc1wiXG4gICAgICByZXR1cm4gbiAgaWYgbj9cblxuICAgICAgbiA9IE1hdGguY2VpbCBAQ29sbGVjdGlvbi5maW5kKFxuICAgICAgICAkYW5kOiBbXG4gICAgICAgICAgc3ViLmdldChcImZpbHRlcnNcIiksXG4gICAgICAgICAgc3ViLmdldChcInJlYWxGaWx0ZXJzXCIpIG9yIHt9XG4gICAgICAgIF1cbiAgICAgICkuY291bnQoKSAvIChzdWIuZ2V0IFwicGVyUGFnZVwiKVxuICAgICAgbiBvciAxXG4gICAgXG4gICAgXCJTZXRcIjogKGssIHYsIHN1YikgLT5cbiAgICAgIGlmICFAc2V0dGluZ3Nba10/XG4gICAgICAgIEBlcnJvciBcImludmFsaWQtb3B0aW9uXCIsIFwiSW52YWxpZCBvcHRpb24gbmFtZTogI3trfS5cIlxuICAgICAgY2hlY2sgaywgU3RyaW5nXG4gICAgICBjaGVjayB2LCBAc2V0dGluZ3Nba11bMV1cbiAgICAgIGNoZWNrIHN1YiwgTWF0Y2guV2hlcmUgKHN1YikgLT5cbiAgICAgICAgc3ViLmNvbm5lY3Rpb24/LmlkP1xuXG4gICAgICBpZiAhQGF2YWlsYWJsZVNldHRpbmdzW2tdIG9yIChfLmlzRnVuY3Rpb24oQGF2YWlsYWJsZVNldHRpbmdzW2tdKSBhbmQgIUBhdmFpbGFibGVTZXR0aW5nc1trXSB2LCBzdWIpXG4gICAgICAgIEBlcnJvciBcImZvcmJpZGRlbi1vcHRpb25cIiwgXCJDaGFuZ2luZyAje2t9IG5vdCBhbGxvd2VkLlwiXG4gICAgICBcbiAgICAgIGNoYW5nZXMgPSAwXG4gICAgICBpZiB2P1xuICAgICAgICBjaGFuZ2VzID0gQF9zZXQgaywgdiwgY2lkOiBzdWIuY29ubmVjdGlvbi5pZFxuICAgICAgZWxzZSBpZiAhXy5pc1N0cmluZyBrXG4gICAgICAgIGZvciBfaywgX3Ygb2Yga1xuICAgICAgICAgIGNoYW5nZXMgKz0gQHNldCBfaywgX3YsIGNpZDogc3ViLmNvbm5lY3Rpb24uaWRcbiAgICAgIGNoYW5nZXNcbiAgICBcbiAgICBcIlVuc3Vic2NyaWJlXCI6IC0+XG4gICAgICBjaWQgPSBhcmd1bWVudHNbYXJndW1lbnRzLmxlbmd0aCAtIDFdLmNvbm5lY3Rpb24uaWRcbiAgICAgIHN1YnMgPSB7fVxuICAgICAgZm9yIGssIHN1YiBvZiBAc3Vic2NyaXB0aW9uc1xuICAgICAgICBjb250aW51ZSAgaWYgayBpbiBbXCJsZW5ndGhcIiwgXCJvcmRlclwiXVxuICAgICAgICBpZiBzdWIuY29ubmVjdGlvbi5pZCBpcyBjaWRcbiAgICAgICAgICBzdWIuc3RvcCgpXG4gICAgICAgICAgZGVsZXRlIEBzdWJzY3JpcHRpb25zW2tdXG4gICAgICBAc3Vic2NyaXB0aW9ucy5sZW5ndGggPSAwXG4gICAgICB0cnVlXG4gIFxuICBjb25zdHJ1Y3RvcjogKGNvbGxlY3Rpb24sIHNldHRpbmdzID0ge30pIC0+XG4gICAgdW5sZXNzIEAgaW5zdGFuY2VvZiBNZXRlb3IuUGFnaW5hdGlvblxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvciBcIm1pc3NpbmctbmV3XCIsIFwiVGhlIE1ldGVvci5QYWdpbmF0aW9uIGluc3RhbmNlIGhhcyB0byBiZSBpbml0aWF0ZWQgd2l0aCBgbmV3YFwiXG4gICAgXG4gICAgIyBJbnN0YW5jZSB2YXJpYWJsZXNcbiAgICBcbiAgICBAaW5pdCA9IEBiZWZvcmVGaXJzdFJlYWR5ID0gdHJ1ZVxuICAgIEBkZWJ1ZyA/PSAoUEFHRVNfREVCVUc/IGFuZCBQQUdFU19ERUJVRykgb3IgcHJvY2Vzcz8uZW52LlBBR0VTX0RFQlVHXG4gICAgQHN1YnNjcmlwdGlvbnMgPSBsZW5ndGg6IDAsIG9yZGVyOiBbXVxuICAgIEB1c2VyU2V0dGluZ3MgPSB7fVxuICAgIEBfY3VycmVudFBhZ2UgPSAxXG5cbiAgICAjIFNldHVwXG5cbiAgICBAc2V0Q29sbGVjdGlvbiBjb2xsZWN0aW9uXG4gICAgQHNldEluaXRpYWwgc2V0dGluZ3NcbiAgICBAc2V0RGVmYXVsdHMoKVxuICAgIEBzZXRSb3V0ZXIoKVxuICAgIEBbKGlmIE1ldGVvci5pc1NlcnZlciB0aGVuIFwic2VydmVyXCIgZWxzZSBcImNsaWVudFwiKSArIFwiSW5pdFwiXSgpXG4gICAgQHJlZ2lzdGVySW5zdGFuY2UoKVxuICAgIEBcbiAgICBcbiAgZXJyb3I6IChjb2RlLCBtc2cpIC0+XG4gICAgbXNnID0gY29kZSAgaWYgIWNvZGU/XG4gICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvciBjb2RlLCBtc2dcblxuICAjIFNlcnZlciBpbml0aWFsaXNhdGlvblxuICBcbiAgc2VydmVySW5pdDogLT5cbiAgICBAc2V0TWV0aG9kcygpXG4gICAgc2VsZiA9IEBcbiAgICBcbiAgICAjIFJlbW92ZSB0aGUgcGVyLWNvbm5lY3Rpb24gc2V0dGluZ3Mgd2hlbiBhIGNsaWVudCBkaXNjb25uZWN0cyBmcm9tIHRoZSBzZXJ2ZXJcbiAgICBcbiAgICBNZXRlb3Iub25Db25uZWN0aW9uIChjb25uZWN0aW9uKSA9PlxuICAgICAgY29ubmVjdGlvbi5vbkNsb3NlID0+XG4gICAgICAgIGRlbGV0ZSBAdXNlclNldHRpbmdzW2Nvbm5lY3Rpb24uaWRdXG4gICAgICAgIFxuICAgICMgUHVibGlzaCB0aGUgY29sbGVjdGlvbiB0aGF0IHdlJ3JlIHBhZ2luYXRpbmcsIHRha2luZyBhIHBhZ2UgbnVtYmVyIGFzIGEgcGFyYW1ldGVyLlxuICAgICAgICBcbiAgICBNZXRlb3IucHVibGlzaCBAaWQsIChwYWdlKSAtPlxuICAgICAgc2VsZi5wdWJsaXNoLmNhbGwgc2VsZiwgcGFnZSwgQFxuICBcbiAgIyBDbGllbnQgaW5pdGlhbGlzYXRpb25cbiAgXG4gIGNsaWVudEluaXQ6IC0+XG4gICAgQHJlcXVlc3RlZCA9IHt9XG4gICAgQHJlY2VpdmVkID0ge31cbiAgICBAcXVldWUgPSBbXVxuICAgIEBuZXh0UGFnZUNvdW50ID0gQG5vdygpXG4gICAgQGdyb3VuZERCID0gUGFja2FnZVtcImdyb3VuZDpkYlwiXT9cbiAgICBpZiBAaW5maW5pdGVcbiAgICAgIEBzZXNzIFwibGltaXRcIiwgMTBcbiAgICAgIEBsYXN0T2Zmc2V0SGVpZ2h0ID0gMFxuICAgIGlmIEBtYXhTdWJzY3JpcHRpb25zIDwgMVxuICAgICAgQG1heFN1YnNjcmlwdGlvbnMgPSAxXG4gICAgQHNldFRlbXBsYXRlcygpXG4gICAgVHJhY2tlci5hdXRvcnVuID0+XG4gICAgICAjQGxvZyBcIlN0YXR1cyBjaGFuZ2VkXCJcbiAgICAgIE1ldGVvci5zdGF0dXMoKVxuICAgICAgTWV0ZW9yLnVzZXJJZD8oKVxuICAgICAgQGNvdW50UGFnZXMoKVxuICAgICAgQHJlbG9hZCgpXG4gICAgQHRlbXBsYXRlTmFtZSA/PSBAbmFtZVxuICAgIFRlbXBsYXRlW0B0ZW1wbGF0ZU5hbWVdLm9uUmVuZGVyZWQgPT5cbiAgICAgIEBzZXRJbmZpbml0ZVRyaWdnZXIoKSBpZiBAaW5maW5pdGVcbiAgXG4gICNTdG9wcyBhbGwgc3Vic2NyaXB0aW9ucyBhbmQgcmVsb2FkcyB0aGUgY3VycmVudCBwYWdlLCBwcm92aWRlZCBpdCdzIGF2YWlsYWJsZSBhbmQgQHJlc2V0T25SZWxvYWQgaXNuJ3QgdHJ1ZS5cbiAgXG4gIHJlbG9hZDogXy50aHJvdHRsZSAtPlxuICAgICNAbG9nIFwiUmVsb2FkaW5nXCJcbiAgICBAdW5zdWJzY3JpYmUoKVxuICAgIEBjb3VudFBhZ2VzICh0b3RhbCkgPT5cbiAgICAgIHAgPSBAY3VycmVudFBhZ2UoKVxuICAgICAgcCA9IDEgIGlmIChub3QgcD8pIG9yIEByZXNldE9uUmVsb2FkIG9yIHAgPiB0b3RhbFxuICAgICAgQHNlc3MgXCJjdXJyZW50UGFnZVwiLCBmYWxzZVxuICAgICAgQHNlc3MgXCJjdXJyZW50UGFnZVwiLCBwXG4gICwgMTAwMCwgdHJhaWxpbmc6IGZhbHNlXG4gIFxuICB1bnN1YnNjcmliZTogKHBhZ2UsIGNpZCkgLT5cbiAgICByZXR1cm4gIGlmIEBiZWZvcmVGaXJzdFJlYWR5XG4gICAgI0Bsb2cgXCJVbnN1YnNjcmliaW5nICN7cGFnZX0gI3tjaWR9XCJcbiAgICBpZiAhcGFnZT9cbiAgICAgIGZvciBrLCBzdWIgb2YgQHN1YnNjcmlwdGlvbnNcbiAgICAgICAgY29udGludWUgIGlmIGsgaW4gW1wibGVuZ3RoXCIsIFwib3JkZXJcIl1cbiAgICAgICAgc3ViLnN0b3AoKVxuICAgICAgICBkZWxldGUgQHN1YnNjcmlwdGlvbnNba11cbiAgICAgIEBzdWJzY3JpcHRpb25zLmxlbmd0aCA9IDBcbiAgICAgIEBpbml0UGFnZSA9IG51bGxcbiAgICAgIEByZXF1ZXN0ZWQgPSB7fVxuICAgICAgQHJlY2VpdmVkID0ge31cbiAgICAgIEBxdWV1ZSA9IFtdXG4gICAgZWxzZSBpZiBNZXRlb3IuaXNTZXJ2ZXJcbiAgICAgIGNoZWNrIGNpZCwgU3RyaW5nXG4gICAgICBpZiBAc3Vic2NyaXB0aW9uc1tjaWRdP1twYWdlXVxuICAgICAgICBAc3Vic2NyaXB0aW9uc1tjaWRdW3BhZ2VdLnN0b3AoKVxuICAgICAgICBkZWxldGUgQHN1YnNjcmlwdGlvbnNbY2lkXVtwYWdlXVxuICAgICAgICBAc3Vic2NyaXB0aW9ucy5sZW5ndGgtLVxuICAgIGVsc2UgaWYgQHN1YnNjcmlwdGlvbnNbcGFnZV1cbiAgICAgICNAbG9nIFwiU3RvcHBpbmcgc3ViICN7cGFnZX1cIlxuICAgICAgQHN1YnNjcmlwdGlvbnNbcGFnZV0uc3RvcCgpXG4gICAgICBkZWxldGUgQHN1YnNjcmlwdGlvbnNbcGFnZV1cbiAgICAgIGRlbGV0ZSBAcmVxdWVzdGVkW3BhZ2VdXG4gICAgICBkZWxldGUgQHJlY2VpdmVkW3BhZ2VdXG4gICAgICBAc3Vic2NyaXB0aW9ucy5vcmRlciA9IF8ud2l0aG91dCBAc3Vic2NyaXB0aW9ucy5vcmRlciwgTnVtYmVyIHBhZ2VcbiAgICAgIEBzdWJzY3JpcHRpb25zLmxlbmd0aC0tXG4gICAgdHJ1ZVxuICBcbiAgc2V0RGVmYXVsdHM6IC0+XG4gICAgZm9yIGssIHYgb2YgQHNldHRpbmdzXG4gICAgICBpZiB2WzJdP1xuICAgICAgICBAW2tdID89IHZbMl1cbiAgXG4gIHN5bmNTZXR0aW5nczogKGNiKSAtPlxuICAgIFMgPSB7fVxuICAgIGZvciBrLCB2IG9mIEBzZXR0aW5nc1xuICAgICAgaWYgdlswXVxuICAgICAgICBTW2tdID0gQFtrXVxuICAgIEBzZXQgUywgaWYgY2I/IHRoZW4ge2NiOiBjYi5iaW5kKEApfSBlbHNlIG51bGxcbiAgXG4gICMgQ3JlYXRlcyBzZXJ2ZXItc2lkZSBtZXRob2RzIGZvciB0aGlzIHBhZ2luYXRpb24gKmluc3RhbmNlKiBieSBwcmVmaXhpbmcgdGhlbSB3aXRoIG91ciB1bmlxdWUgaWRcbiAgXG4gIHNldE1ldGhvZHM6IC0+XG4gICAgbm0gPSB7fVxuICAgIHNlbGYgPSBAXG4gICAgZm9yIG4sIGYgb2YgQG1ldGhvZHNcbiAgICAgIG5tW0BnZXRNZXRob2ROYW1lIG5dID0gKChmKSAtPlxuICAgICAgICAtPlxuICAgICAgICAgIGFyZyA9ICh2IGZvciBrLCB2IG9mIGFyZ3VtZW50cylcbiAgICAgICAgICBhcmcucHVzaCBAXG4gICAgICAgICAgQGdldCA9IF8uYmluZCAoKHNlbGYsIGspIC0+IHNlbGYuZ2V0IGssIEBjb25uZWN0aW9uLmlkKSwgQCwgc2VsZlxuICAgICAgICAgIHIgPSBmLmFwcGx5IHNlbGYsIGFyZ1xuICAgICAgICAgIHJcbiAgICAgICkoZilcbiAgICAgIFxuICAgIE1ldGVvci5tZXRob2RzIG5tXG4gIFxuICAjIEdldCdzIHRoZSBzZXJ2ZXIncyBtZXRob2QgbmFtZSBmb3IgdGhpcyBwYWdpbmF0aW9uIGluc3RhbmNlXG4gIFxuICBnZXRNZXRob2ROYW1lOiAobmFtZSkgLT5cbiAgICBcIiN7QGlkfS8je25hbWV9XCJcbiAgXG4gICMgQ2FsbHMgdGhpcyBpbnN0YW5jZSdzIHZlcnNpb24gb2YgYSBnaXZlbiBzZXJ2ZXIgbWV0aG9kIChmaXJzdCBhcmd1bWVudCkuXG4gICMgSWYgdGhlIGxhc3QgYXJndW1lbnQgaXMgYSBmdW5jdGlvbiBjYWxsYmFjaywgaXQncyBib3VuZCB0byB0aGlzIGluc3RhbmNlXG4gICAgXG4gIGNhbGw6IChhcmdzLi4uKSAtPlxuICAgIGNoZWNrIGFyZ3MsIEFycmF5XG4gICAgaWYgYXJncy5sZW5ndGggPCAxXG4gICAgICBAZXJyb3IgXCJtZXRob2QtbmFtZS1taXNzaW5nXCIsIFwiTWV0aG9kIG5hbWUgbm90IHByb3ZpZGVkIGluIGEgbWV0aG9kIGNhbGwuXCJcbiAgICBhcmdzWzBdID0gQGdldE1ldGhvZE5hbWUgYXJnc1swXVxuICAgIGxhc3QgPSBhcmdzLmxlbmd0aCAtIDFcbiAgICBpZiBfLmlzRnVuY3Rpb24gYXJnc1tsYXN0XVxuICAgICAgYXJnc1tsYXN0XSA9IGFyZ3NbbGFzdF0uYmluZCBAXG4gICAgTWV0ZW9yLmNhbGwuYXBwbHkgQCwgYXJnc1xuICBcbiAgIyBTZXRzL2dldHMgYSBzZXNzaW9uIHZhcmlhYmxlIGZvciB0aGlzIGluc3RhbmNlXG4gIFxuICBzZXNzOiAoaywgdikgLT5cbiAgICByZXR1cm4gIGlmICFTZXNzaW9uP1xuICAgIGsgPSBcIiN7QGlkfS4je2t9XCJcbiAgICBpZiBhcmd1bWVudHMubGVuZ3RoIGlzIDJcbiAgICAgIFNlc3Npb24uc2V0IGssIHZcbiAgICBlbHNlXG4gICAgICBTZXNzaW9uLmdldCBrXG4gICAgICBcbiAgIyBHZXRzIGEgZ2l2ZW4gc2V0dGluZ1xuICAjICAgICAgXG4gICMgV2hlbiB0aGVyZSdzIGEgY29ubmVjdGlvbiBpZCB3ZSBzdG9yZSB0aGlzIHNldHRpbmcgb24gYSBwZXItY29ubmVjdGlvbiBiYXNpcywgb3RoZXJ3aXNlIHdlIGp1c3RcbiAgIyBzZXQgdGhlIHNldHRpbmcgb24gdGhpcyBwYWdpbmF0aW9uIGluc3RhbmNlXG5cbiAgZ2V0OiAoc2V0dGluZywgY29ubmVjdGlvbklkKSAtPlxuICAgIEB1c2VyU2V0dGluZ3NbY29ubmVjdGlvbklkXT9bc2V0dGluZ10gPyBAW3NldHRpbmddXG4gIFxuICMgU2V0cyB0aGUgb3B0aW9ucyBmb3IgdGhpcyBpbnN0YW5jZVxuICAgIFxuICBzZXQ6IChrLCBvcHRzLi4uKSAtPlxuICAgIGNoID0gMFxuICAgIHN3aXRjaCBvcHRzLmxlbmd0aFxuICAgICAgd2hlbiAwXG4gICAgICAgICMgc2V0IDxvYmplY3Q+IChzZXQgdGhlIHZhbHVlIG9mIGVhY2ggcHJvcGVydHkgaW4gb2JqZWN0KVxuICAgICAgICBpZiBfLmlzT2JqZWN0IGtcbiAgICAgICAgICBmb3IgX2ssIF92IG9mIGtcbiAgICAgICAgICAgIGNoICs9IEBfc2V0IF9rLCBfdlxuICAgICAgd2hlbiAxXG4gICAgICAgIGlmIF8uaXNPYmplY3Qga1xuICAgICAgICAgICMgc2V0IDxvYmplY3Q+LCBjYWxsYmFja1xuICAgICAgICAgICMgV2Ugd3JhcCB0aGUgY2FsbGJhY2sgYW5kIGFzc29jaWF0ZSB3aXRoIGVhY2ggcHJvcGVydHkgb2YgdGhlIG9iamVjdCBiZWluZyBzZXRcbiAgICAgICAgICBpZiBfLmlzRnVuY3Rpb24gb3B0c1swXVxuICAgICAgICAgICAgb3B0c1swXSA9IGNiOiBvcHRzWzBdXG4gICAgICAgICAgZm9yIF9rLCBfdiBvZiBrXG4gICAgICAgICAgICBjaCArPSBAX3NldCBfaywgX3YsIG9wdHNbMF1cbiAgICAgICAgZWxzZVxuICAgICAgICAgICMgc2V0IDxuYW1lPiwgPHZhbHVlPlxuICAgICAgICAgIGNoZWNrIGssIFN0cmluZ1xuICAgICAgICAgIGNoID0gQF9zZXQgaywgb3B0c1swXVxuICAgICAgd2hlbiAyXG4gICAgICAgICAjIHNldCA8bmFtZT4sIDx2YWx1ZT4sIFs8Y2FsbGJhY2sgZm4+XVxuICAgICAgICBpZiBfLmlzRnVuY3Rpb24gb3B0c1sxXVxuICAgICAgICAgIG9wdHNbMV0gPSBjYjogb3B0c1sxXVxuICAgICAgICBjaCA9IEBfc2V0IGssIG9wdHNbMF0sIG9wdHNbMV1cbiAgICAgIHdoZW4gM1xuICAgICAgICBjaGVjayBvcHRzWzFdLCBPYmplY3RcbiAgICAgICAgY2hlY2sgb3B0c1syXSwgRnVuY3Rpb25cbiAgICAgICAgb3B0c1syXSA9IGNiOiBvcHRzWzJdXG4gICAgICAgIGNoID0gQF9zZXQgaywgb3B0c1sxXSwgb3B0c1syXVxuICAgIGlmIE1ldGVvci5pc0NsaWVudCBhbmQgY2hcbiAgICAgIEByZWxvYWQoKVxuICAgIGNoXG5cbiAgc2V0SW5pdGlhbDogKHNldHRpbmdzKSAtPlxuICAgIEBzZXRJbml0RG9uZSA9IGZhbHNlXG4gICAgQHNldCBzZXR0aW5nc1xuICAgIEBzZXRJbml0RG9uZSA9IHRydWVcblxuICAjQ29udmVydHMgYSByZWd1bGFyIGV4cHJlc3Npb24gaW50byBhIHF1ZXJ5IG9iamVjdCB0aGF0IGNhbiBiZSBzZW50IHZpYSBtZXRob2RzIHRvIHRoZSBzZXJ2ZXJcblxuICBzYW5pdGl6ZVJlZ2V4OiAodikgLT5cbiAgICBpZiBfLmlzUmVnRXhwIHZcbiAgICAgIHYgPSB2LnRvU3RyaW5nKClcbiAgICAgIGxpcyA9IHYubGFzdEluZGV4T2YoXCIvXCIpXG4gICAgICB2ID0gJHJlZ2V4OiB2WzEgLi4uIGxpc10sICRvcHRpb25zOiB2WzEgKyBsaXMgLi4gXVxuICAgIHZcblxuICAjU2FuaXRpemVzIGFsbCByZWd1bGFyIGV4cHJlc3Npb25zIHdpdGhpbiBhbiBvYmplY3QgdXNpbmcgOjpzYW5pdGl6ZVJlZ2V4KClcbiAgXG4gIHNhbml0aXplUmVnZXhPYmo6IChvYmopIC0+XG4gICAgaWYgXy5pc1JlZ0V4cCBvYmpcbiAgICAgIHJldHVybiBAc2FuaXRpemVSZWdleCBvYmpcbiAgICBmb3IgaywgdiBvZiBvYmpcbiAgICAgIGlmIF8uaXNSZWdFeHAgdlxuICAgICAgICBvYmpba10gPSBAc2FuaXRpemVSZWdleCB2XG4gICAgICBlbHNlIGlmIFwib2JqZWN0XCIgaXMgdHlwZW9mIHZcbiAgICAgICAgb2JqW2tdID0gQHNhbml0aXplUmVnZXhPYmogdlxuICAgIG9ialxuXG4gICMgU2V0cyBhIHNwZWNpZmljIG9wdGlvblxuICAgICAgXG4gIF9zZXQ6IChrLCB2LCBvcHRzID0ge30pIC0+XG4gICAgY2hlY2sgaywgU3RyaW5nXG4gICAgY2ggPSAxXG4gICAgXG4gICAgIyBDaGVjayB0aGF0IHdlJ3JlIHRoZSBzZXJ2ZXIsIG9yIHRoYXQgd2UncmUgYmVpbmcgaW5pdGlhbGlzZWQsIG9yIHRoYXQgdGhpcyBzZXR0aW5nIGNhbiBiZSBjaGFuZ2VkXG4gICAgIyBhZnRlciBpbml0aWFsaXphdGlvbiwgb3IgdGhhdCB0aGUgc2V0dGluZyBkb2Vzbid0IHlldCBleGlzdCBvbiB0aGlzIGluc3RhbmNlLlxuICAgIFxuICAgIGlmIE1ldGVvci5pc1NlcnZlciBvciAhQFtrXT8gb3IgQHNldHRpbmdzW2tdP1swXSBvciBvcHRzLmluaXRcbiAgICBcbiAgICAgICMgQ2hlY2sgdGhlIHR5cGUgb2YgdGhlIHZhbHVlIGFnYWluc3QgdGhlIEBzZXR0aW5ncyBhcnJheVxuICAgICAgaWYgQHNldHRpbmdzW2tdP1sxXT8gYW5kIEBzZXR0aW5nc1trXT9bMV0gaXNudCB0cnVlXG4gICAgICAgIGNoZWNrIHYsIEBzZXR0aW5nc1trXVsxXVxuICAgICAgXG4gICAgICBAc2FuaXRpemVSZWdleE9iaiB2XG4gICAgICBcbiAgICAgICMgU2V0IHRoZSBwYXJhbWV0ZXIgb24gdGhpcyBpbnN0YW5jZSAoY2xpZW50KSAgXG4gICAgICBcbiAgICAgIG9sZFYgPSBAZ2V0IGssIG9wdHM/LmNpZFxuXG4gICAgICByZXR1cm4gMCAgaWYgQHZhbHVlc0VxdWFsIHYsIG9sZFZcblxuICAgICAgaWYgTWV0ZW9yLmlzQ2xpZW50XG4gICAgICAgIEBba10gPSB2XG4gICAgICAgIGlmIEBzZXRJbml0RG9uZVxuICAgICAgICAgICMgQ2hhbmdlIHRoZSBzZXR0aW5nIGZvciB0aGUgY29ycmVzcG9uZGluZyBpbnN0YW5jZSBvbiB0aGUgc2VydmVyXG4gICAgICAgICAgQGNhbGwgXCJTZXRcIiwgaywgdiwgKGUsIHIpIC0+XG4gICAgICAgICAgICBpZiBlXG4gICAgICAgICAgICAgIEBba10gPSBvbGRWXG4gICAgICAgICAgICAgIHJldHVybiBAb25EZW5pZWRTZXR0aW5nLmNhbGwgQCwgaywgdiwgZVxuICAgICAgICAgICAgb3B0cy5jYj8gY2hcbiAgICAgIGVsc2VcbiAgICAgICAgIyBXaGVuIHRoZXJlJ3MgYSBjb25uZWN0aW9uIGlkIHdlIHN0b3JlIHRoaXMgc2V0dGluZyBvbiBhIHBlci1jb25uZWN0aW9uIGJhc2lzLCBvdGhlcndpc2Ugd2UganVzdFxuICAgICAgICAjIHNldCB0aGUgc2V0dGluZyBvbiB0aGlzIHBhZ2luYXRpb24gaW5zdGFuY2VcbiAgICAgICAgaWYgb3B0cy5jaWRcbiAgICAgICAgICBpZiBjaD9cbiAgICAgICAgICAgIEB1c2VyU2V0dGluZ3Nbb3B0cy5jaWRdID89IHt9XG4gICAgICAgICAgICBAdXNlclNldHRpbmdzW29wdHMuY2lkXVtrXSA9IHZcbiAgICAgICAgZWxzZVxuICAgICAgICAgIEBba10gPSB2XG4gICAgICAgIFxuICAgICAgICBvcHRzLmNiPyBjaFxuICAgIGVsc2VcbiAgICAgIEBvbkRlbmllZFNldHRpbmcuY2FsbCBALCBrLCB2XG4gICAgY2hcbiAgICBcbiAgdmFsdWVzRXF1YWw6ICh2MSwgdjIpIC0+XG4gICAgaWYgXy5pc0Z1bmN0aW9uIHYxXG4gICAgICBfLmlzRnVuY3Rpb24odjIpIGFuZCB2MS50b1N0cmluZygpIGlzIHYyLnRvU3RyaW5nKClcbiAgICBlbHNlXG4gICAgICBfLmlzRXF1YWwgdjEsIHYyXG4gIFxuICAjIFxuICBcbiAgc2V0SWQ6IChuYW1lKSAtPlxuICAgIGlmIEB0ZW1wbGF0ZU5hbWVcbiAgICAgIG5hbWUgPSBAdGVtcGxhdGVOYW1lXG4gICAgd2hpbGUgbmFtZSBvZiBQYWdlczo6aW5zdGFuY2VzXG4gICAgICBuID0gbmFtZS5tYXRjaCAvWzAtOV0rJC9cbiAgICAgIGlmIG4/XG4gICAgICAgIG5hbWUgPSBuYW1lWzAgLi4uIG5hbWUubGVuZ3RoIC0gblswXS5sZW5ndGhdICsgKHBhcnNlSW50KG4pICsgMSlcbiAgICAgIGVsc2VcbiAgICAgICAgbmFtZSA9IG5hbWUgKyBcIjJcIlxuICAgIEBpZCA9IFwicGFnZXNfXCIgKyBuYW1lXG4gICAgQG5hbWUgPSBuYW1lXG4gIFxuICAjXG4gIFxuICByZWdpc3Rlckluc3RhbmNlOiAtPlxuICAgIFBhZ2VzOjpfbkluc3RhbmNlcysrXG4gICAgUGFnZXM6Omluc3RhbmNlc1tAbmFtZV0gPSBAXG4gIFxuICAjIFNldCB0aGUgY29sbGVjdGlvbiBvbiB3aGljaCB0aGlzIGluc3RhbmNlIG9wZXJhdGVzLiBDcmVhdGVzIGEgbmV3IG9uZSBpZiBhIG5hbWUgaXMgcGFzc2VkIGluLlxuICBcbiAgc2V0Q29sbGVjdGlvbjogKGNvbGxlY3Rpb24pIC0+XG4gICAgaWYgdHlwZW9mIGNvbGxlY3Rpb24gaXMgXCJvYmplY3RcIlxuICAgICAgUGFnZXM6OmNvbGxlY3Rpb25zW2NvbGxlY3Rpb24uX25hbWVdID0gY29sbGVjdGlvblxuICAgICAgQENvbGxlY3Rpb24gPSBjb2xsZWN0aW9uXG4gICAgZWxzZVxuICAgICAgdHJ5XG4gICAgICAgIEBDb2xsZWN0aW9uID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24gY29sbGVjdGlvblxuICAgICAgICBQYWdlczo6Y29sbGVjdGlvbnNbY29sbGVjdGlvbl0gPSBAQ29sbGVjdGlvblxuICAgICAgY2F0Y2ggZVxuICAgICAgICBAQ29sbGVjdGlvbiA9IFBhZ2VzOjpjb2xsZWN0aW9uc1tjb2xsZWN0aW9uXVxuICAgICAgICBAQ29sbGVjdGlvbiBpbnN0YW5jZW9mIE1vbmdvLkNvbGxlY3Rpb24gb3IgQGVycm9yIFwiY29sbGVjdGlvbi1pbmFjY2Vzc2libGVcIiwgXCJUaGUgJyN7Y29sbGVjdGlvbn0nIGNvbGxlY3Rpb24gXG4gICAgICAgIHdhcyBjcmVhdGVkIG91dHNpZGUgb2YgPE1ldGVvci5QYWdpbmF0aW9uPi4gUGFzcyB0aGUgY29sbGVjdGlvbiBvYmplY3RcbiAgICAgICAgaW5zdGVhZCBvZiB0aGUgY29sbGVjdGlvbidzIG5hbWUgdG8gdGhlIDxNZXRlb3IuUGFnaW5hdGlvbj4gY29uc3RydWN0b3IuXCJcbiAgICBcbiAgICBAc2V0SWQgQENvbGxlY3Rpb24uX25hbWVcbiAgICBcbiAgICAjIENyZWF0ZSBhIGNvbGxlY3Rpb24gYmFzZWQgb24gdGhlIGluc3RhbmNlJ3MgdW5pcXVlIGlkXG4gICAgXG4gICAgIyBAUGFnaW5hdGVkQ29sbGVjdGlvbiA9IG5ldyBNb25nby5Db2xsZWN0aW9uIEBpZFxuICBcbiAgbGlua1RvOiAocGFnZSktPlxuICAgIGlmIFJvdXRlci5jdXJyZW50KCk/LnBhcmFtc1xuICAgICAgcGFyYW1zID0gUm91dGVyLmN1cnJlbnQoKS5wYXJhbXNcbiAgICAgIHBhcmFtcy5wYWdlID0gcGFnZVxuICAgICAgUm91dGVyLnJvdXRlc1tcIiN7QG5hbWV9X3BhZ2VcIl0ucGF0aCBwYXJhbXNcbiAgXG4gIHNldFJvdXRlcjogLT5cbiAgICBpZiBAcm91dGVyIGlzIFwiaXJvbi1yb3V0ZXJcIlxuICAgICAgaWYgQHJvdXRlLmluZGV4T2YoXCI6cGFnZVwiKSBpcyAtMVxuICAgICAgICBpZiBAcm91dGVbMF0gaXNudCBcIi9cIlxuICAgICAgICAgIEByb3V0ZSA9IFwiL1wiICsgQHJvdXRlXG4gICAgICAgIGlmIEByb3V0ZVtAcm91dGUubGVuZ3RoIC0gMV0gaXNudCBcIi9cIlxuICAgICAgICAgIEByb3V0ZSArPSBcIi9cIlxuICAgICAgICBwciA9IEByb3V0ZSA9IFwiI3tAcm91dGV9OnBhZ2VcIlxuICAgICAgdCA9IEByb3V0ZXJUZW1wbGF0ZVxuICAgICAgbCA9IEByb3V0ZXJMYXlvdXQgPyB1bmRlZmluZWRcbiAgICAgIHNlbGYgPSBAXG4gICAgICBpbml0ID0gdHJ1ZVxuICAgICAgXG4gICAgICBSb3V0ZXIubWFwIC0+XG4gICAgICAgIHVubGVzcyBzZWxmLmluZmluaXRlXG4gICAgICAgIFxuICAgICAgICAgICMgQ3JlYXRlIGEgcm91dGUgdGhhdCB0YWtlcyBhIHBhZ2UgbnVtYmVyXG4gICAgICAgICBcbiAgICAgICAgICBAcm91dGUgXCIje3NlbGYubmFtZX1fcGFnZVwiLFxuICAgICAgICAgICAgcGF0aDogcHJcbiAgICAgICAgICAgIHRlbXBsYXRlOiB0XG4gICAgICAgICAgICBsYXlvdXRUZW1wbGF0ZTogbFxuICAgICAgICAgICAgb25CZWZvcmVBY3Rpb246IC0+XG4gICAgICAgICAgICAgIHBhZ2UgPSBwYXJzZUludCBAcGFyYW1zLnBhZ2VcbiAgICAgICAgICAgICAgaWYgc2VsZi5pbml0XG4gICAgICAgICAgICAgICAgc2VsZi5zZXNzIFwib2xkUGFnZVwiLCBwYWdlXG4gICAgICAgICAgICAgICAgc2VsZi5zZXNzIFwiY3VycmVudFBhZ2VcIiwgcGFnZVxuICAgICAgICAgICAgICBpZiBzZWxmLnJvdXRlU2V0dGluZ3M/XG4gICAgICAgICAgICAgICAgc2VsZi5yb3V0ZVNldHRpbmdzIEBcbiAgICAgICAgICAgICAgVHJhY2tlci5ub25yZWFjdGl2ZSA9PlxuICAgICAgICAgICAgICAgIHNlbGYub25OYXZDbGljayBwYWdlXG4gICAgICAgICAgICAgIEBuZXh0KCkgICAgICAgICAgICAgICBcbiAgICAgICAgXG4gICAgICAgICMgQ3JlYXRlIG9uZSBvciBtb3JlIHJvdXRlcyBmb3IgdGhlIGhvbWUgKGZpcnN0KSBwYWdlXG4gICAgICAgICAgICAgIFxuICAgICAgICBpZiBzZWxmLmhvbWVSb3V0ZVxuICAgICAgICAgIGlmIF8uaXNTdHJpbmcgc2VsZi5ob21lUm91dGVcbiAgICAgICAgICAgIHNlbGYuaG9tZVJvdXRlID0gW3NlbGYuaG9tZVJvdXRlXVxuICAgICAgICAgIGZvciBociwgayBpbiBzZWxmLmhvbWVSb3V0ZVxuICAgICAgICAgICAgQHJvdXRlIFwiI3tzZWxmLm5hbWV9X2hvbWUje2t9XCIsXG4gICAgICAgICAgICAgIHBhdGg6IGhyXG4gICAgICAgICAgICAgIHRlbXBsYXRlOiB0XG4gICAgICAgICAgICAgIGxheW91dFRlbXBsYXRlOiBsXG4gICAgICAgICAgICAgIG9uQmVmb3JlQWN0aW9uOiAtPlxuICAgICAgICAgICAgICAgIGlmIHNlbGYucm91dGVTZXR0aW5ncz9cbiAgICAgICAgICAgICAgICAgIHNlbGYucm91dGVTZXR0aW5ncyBAXG4gICAgICAgICAgICAgICAgaWYgc2VsZi5pbml0XG4gICAgICAgICAgICAgICAgICBzZWxmLnNlc3MgXCJvbGRQYWdlXCIsIDFcbiAgICAgICAgICAgICAgICAgIHNlbGYuc2VzcyBcImN1cnJlbnRQYWdlXCIsIDFcbiAgICAgICAgICAgICAgICBAbmV4dCgpXG4gICAgICAgICAgICAgICAgICAgICAgXG4gICAgICAjIElmIHVzaW5nIEZhc3RSZW5kZXIsIHNldCBpdCB1cCBmb3IgdGhlc2Ugcm91dGVzXG4gICAgICAgICAgICAgICAgXG4gICAgICBpZiBNZXRlb3IuaXNTZXJ2ZXIgYW5kIEBmYXN0UmVuZGVyXG4gICAgICAgIHNlbGYgPSBAXG4gICAgICAgIEZhc3RSZW5kZXIucm91dGUgcHIsIChwYXJhbXMpIC0+XG4gICAgICAgICAgQHN1YnNjcmliZSBzZWxmLmlkLCBwYXJzZUludCBwYXJhbXMucGFnZVxuICAgICAgICBGYXN0UmVuZGVyLnJvdXRlIEBob21lUm91dGUsIC0+XG4gICAgICAgICAgQHN1YnNjcmliZSBzZWxmLmlkLCAxICBcblxuICBpc0VtcHR5OiAtPlxuICAgIEBpc1JlYWR5KCkgYW5kIEBDb2xsZWN0aW9uLmZpbmQoXy5vYmplY3QgW1tcIl8je0BpZH1faVwiLCAwXV0pLmNvdW50KCkgaXMgMFxuICBcbiAgc2V0UGVyUGFnZTogLT5cbiAgICBAcGVyUGFnZSA9IGlmIEBwYWdlU2l6ZUxpbWl0IDwgQHBlclBhZ2UgdGhlbiBAcGFnZVNpemVMaW1pdCBlbHNlIEBwZXJQYWdlXG4gIFxuICBzZXRUZW1wbGF0ZXM6IC0+XG4gICAgbmFtZSA9IEB0ZW1wbGF0ZU5hbWUgb3IgQG5hbWVcbiAgICBpZiBAdGFibGUgYW5kIEBpdGVtVGVtcGxhdGUgaXMgXCJfcGFnZXNJdGVtRGVmYXVsdFwiXG4gICAgICBAaXRlbVRlbXBsYXRlID0gQHRhYmxlSXRlbVRlbXBsYXRlXG4gICAgXG4gICAgZm9yIGkgaW4gW0BuYXZUZW1wbGF0ZSwgQHBhZ2VUZW1wbGF0ZSwgQGl0ZW1UZW1wbGF0ZSwgQHRhYmxlVGVtcGxhdGVdXG4gICAgICB0biA9IEBpZCArIGlcbiAgICAgIFRlbXBsYXRlW3RuXSA9IG5ldyBCbGF6ZS5UZW1wbGF0ZSBcIlRlbXBsYXRlLiN7dG59XCIsIFRlbXBsYXRlW2ldLnJlbmRlckZ1bmN0aW9uXG4gICAgICBUZW1wbGF0ZVt0bl0uX19ldmVudE1hcHMgPSBUZW1wbGF0ZVt0bl0uX19ldmVudE1hcHMuY29uY2F0IFRlbXBsYXRlW2ldLl9fZXZlbnRNYXBzXG4gICAgICBoZWxwZXJzID0gcGFnZXNEYXRhOiBAXG4gICAgICBfLmVhY2ggVGVtcGxhdGVbaV0uX19oZWxwZXJzLCAoaGVscGVyLCBuYW1lKSA9PlxuICAgICAgICBpZiBuYW1lWzBdIGlzIFwiIFwiXG4gICAgICAgICAgaGVscGVyc1tuYW1lLnNsaWNlKDEpXSA9IF8uYmluZCBoZWxwZXIsIEAgXG4gICAgICBUZW1wbGF0ZVt0bl0uaGVscGVycyBoZWxwZXJzXG4gICAgICBcbiAgICAjIFNldCBvdXIgaGVscGVycyBvbiB0aGUgbWFpbiB0ZW1wbGF0ZSBzZXQgZm9yIHRoaXMgcGFnaW5hdGlvbiAgXG4gICAgICBcbiAgICBUZW1wbGF0ZVtuYW1lXS5oZWxwZXJzXG4gICAgICBwYWdlc0RhdGE6IEBcbiAgICAgIHBhZ2VzTmF2OiBUZW1wbGF0ZVtAaWQgKyBAbmF2VGVtcGxhdGVdXG4gICAgICBwYWdlczogVGVtcGxhdGVbQGlkICsgQHBhZ2VUZW1wbGF0ZV1cbiAgXG4gICMgR2V0IHRoZSBudW1iZXIgb2YgcGFnZXMgZnJvbSB0aGUgc2VydmVyXG4gICAgICBcbiAgY291bnRQYWdlczogXy50aHJvdHRsZSAoY2IpIC0+XG4gICAgI0Bsb2cgXCJDb3VudGluZyBwYWdlc1wiXG4gICAgaWYgIU1ldGVvci5zdGF0dXMoKS5jb25uZWN0ZWQgYW5kIFBhY2thZ2VbXCJncm91bmQ6ZGJcIl0/XG4gICAgICBuID0gQENvbGxlY3Rpb24uZmluZE9uZSh7fSwge3NvcnQ6IF8ub2JqZWN0IFtbXCJfI3tAaWR9X3BcIiwgLTFdXX0pP1tcIl8je0BpZH1fcFwiXSBvciAwXG4gICAgICBAc2V0VG90YWxQYWdlcyBuXG4gICAgICBjYj8gblxuICAgIGVsc2VcbiAgICAgIEBjYWxsIFwiQ291bnRQYWdlc1wiLCAoZSwgcikgPT5cbiAgICAgICAgdGhyb3cgZSAgaWYgZT9cbiAgICAgICAgQHNldFRvdGFsUGFnZXMgclxuICAgICAgICBub3cgPSBAbm93KClcbiAgICAgICAgaWYgQG5leHRQYWdlQ291bnQgPCBub3dcbiAgICAgICAgICBAbmV4dFBhZ2VDb3VudCA9IG5vdyArIEBwYWdlQ291bnRGcmVxdWVuY3lcbiAgICAgICAgICBzZXRUaW1lb3V0IF8uYmluZChAY291bnRQYWdlcywgQCksIEBwYWdlQ291bnRGcmVxdWVuY3lcbiAgICAgICAgY2I/IHJcbiAgLCAxMDAwXG5cbiAgc2V0VG90YWxQYWdlczogKG4pIC0+XG4gICAgQHNlc3MgXCJ0b3RhbFBhZ2VzXCIsIG5cbiAgICBpZiBAc2VzcyhcImN1cnJlbnRQYWdlXCIpID4gblxuICAgICAgQHNlc3MgXCJjdXJyZW50UGFnZVwiLCAxXG5cbiAgIyBNYWtlcyBzdXJlIHRoZSBudW1iZXIgb2Ygc2ltdWx0YW5lb3VzbHkgYWN0aXZlIHN1YnNjcmlwdGlvbnMgaXMgbGVzcyB0aGVuIEBtYXhTdWJzY3JpcHRpb25zXG5cbiAgZW5mb3JjZVN1YnNjcmlwdGlvbkxpbWl0OiAoY2lkKSAtPlxuICAgIGlmIE1ldGVvci5pc1NlcnZlclxuICAgICAgY2hlY2sgY2lkLCBTdHJpbmdcbiAgICAgIGlmIEBzdWJzY3JpcHRpb25zW2NpZF0/Lmxlbmd0aCA+PSBAbWF4U3Vic2NyaXB0aW9uc1xuICAgICAgICByZXR1cm4gQGVycm9yIFwic3Vic2NyaXB0aW9uLWxpbWl0LXJlYWNoZWRcIiwgXCJTdWJzY3JpcHRpb24gbGltaXQgcmVhY2hlZC4gVW5hYmxlIHRvIG9wZW4gYSBuZXcgc3Vic2NyaXB0aW9uLlwiXG4gICAgZWxzZVxuICAgICAgd2hpbGUgQHN1YnNjcmlwdGlvbnMubGVuZ3RoID49IEBtYXhTdWJzY3JpcHRpb25zXG4gICAgICAgIEB1bnN1YnNjcmliZSBAc3Vic2NyaXB0aW9ucy5vcmRlclswXVxuICAgICAgdHJ1ZVxuICBcbiAgIyBDYWxsZWQgZnJvbSB0aGUgTWV0ZW9yLnB1Ymxpc2ggY2FsbCBtYWRlIGR1cmluZyBpbml0LCB0aGlzIHB1Ymxpc2hlcyB0aGUgcGFnaW5hdGVkIGNvbGxlY3Rpb25cbiAgI1xuICAjIFwidGhpc1wiIHdpbGwgYmUgdGhlIHBhZ2luYXRpb24gaW5zdGFuY2VcbiAgIyBcInBhZ2VcIiBpcyB0aGUgcGFnZSBudW1iZXIgdG8gcHVibGlzaFxuICAjIFwic3ViXCIgaXMgdGhlIHB1Ymxpc2ggaGFuZGxlciBvYmplY3Qgd2hpY2ggKHRoZSBcInRoaXNcIiBvYmplY3Qgd2hlbiB0aGUgZnVuY3Rpb24gcGFzc2VkIHRvIE1ldGVvci5wdWJsaXNoIGlzIGNhbGxlZClcbiAgXG4gIHB1Ymxpc2g6IChwYWdlLCBzdWIpIC0+XG4gICAgY2hlY2sgcGFnZSwgTnVtYmVyXG4gICAgY2hlY2sgc3ViLCBNYXRjaC5XaGVyZSAocykgLT5cbiAgICAgIHMucmVhZHk/XG4gICAgY2lkID0gc3ViLmNvbm5lY3Rpb24uaWRcbiAgICBpbml0ID0gdHJ1ZVxuXG4gICAgI0Bsb2cgXCJQdWJsaXNoaW5nIHBhZ2UgI3twYWdlfVwiXG5cbiAgICBAc3Vic2NyaXB0aW9uc1tzdWIuY29ubmVjdGlvbi5pZF0gPz0gbGVuZ3RoOiAwXG5cbiAgICBAZW5mb3JjZVN1YnNjcmlwdGlvbkxpbWl0IGNpZFxuXG4gICAgIyBDcmVhdGUgZ2V0IGFuZCBzZXQgZnVuY3Rpb25zIGZvciB0aGlzIHNwZWNpZmljIGNvbm5lY3Rpb24gKHRoZSBzZXR0aW5ncyB3aWxsIGVuZCB1cCBpbiB0aGUgQHVzZXJTZXR0aW5ncyxcbiAgICAjIHN0b3JlZCBpbiBhbiBvYmplY3QgaW5kZXhlZCB1bmRlciB0aGUgY29sbGVjdGlvbiBpZClcbiAgICBcbiAgICBnZXQgPSBzdWIuZ2V0ID0gXy5iaW5kICgoY2lkLCBrKSAtPiBAZ2V0IGssIGNpZCksIEAsIGNpZFxuICAgIHNldCA9IHN1Yi5zZXQgPSBfLmJpbmQgKChjaWQsIGssIHYpIC0+IEBzZXQgaywgdiwgY2lkOiBjaWQpLCBALCBjaWRcbiAgICBcbiAgICBxdWVyeSA9IF8uYmluZCAoKHN1YiwgZ2V0LCBzZXQpIC0+XG5cbiAgICAgIGRlbGV0ZSBAdXNlclNldHRpbmdzW2NpZF0/LnJlYWxGaWx0ZXJzXG4gICAgICBkZWxldGUgQHVzZXJTZXR0aW5nc1tjaWRdPy5uUHVibGlzaGVkUGFnZXNcbiAgICAgIFxuICAgICAgQHNldFBlclBhZ2UoKVxuICAgICAgXG4gICAgICBza2lwID0gKHBhZ2UgLSAxKSAqIGdldCBcInBlclBhZ2VcIlxuICAgICAgc2tpcCA9IDAgaWYgc2tpcCA8IDBcbiAgICAgIFxuICAgICAgZmlsdGVycyA9IGdldCBcImZpbHRlcnNcIlxuICAgICAgXG4gICAgICBvcHRpb25zID0gXG4gICAgICAgIHNvcnQ6IGdldCBcInNvcnRcIlxuICAgICAgICBmaWVsZHM6IGdldCBcImZpZWxkc1wiXG4gICAgICAgIHNraXA6IHNraXBcbiAgICAgICAgbGltaXQ6IGdldCBcInBlclBhZ2VcIlxuICAgICAgXG4gICAgICAjIENhbGwgdGhlIGF1dGhlbnRpY2F0aW9uIGZ1bmN0aW9uIGlmIGl0J3Mgc3VwcGxpZWRcbiAgICAgIFxuICAgICAgaWYgQGF1dGg/XG4gICAgICAgIHIgPSBAYXV0aC5jYWxsIEAsIHNraXAsIHN1YlxuICAgICAgICBpZiAhclxuICAgICAgICAgIHNldCBcIm5QdWJsaXNoZWRQYWdlc1wiLCAwXG4gICAgICAgICAgc3ViLnJlYWR5KClcbiAgICAgICAgICByZXR1cm4gQHJlYWR5KClcbiAgICAgICAgZWxzZSBpZiBfLmlzTnVtYmVyIHJcbiAgICAgICAgICBzZXQgXCJuUHVibGlzaGVkUGFnZXNcIiwgclxuICAgICAgICAgIGlmIHBhZ2UgPiByXG4gICAgICAgICAgICBzdWIucmVhZHkoKVxuICAgICAgICAgICAgcmV0dXJuIEByZWFkeSgpXG4gICAgICAgIGVsc2UgaWYgXy5pc0FycmF5KHIpIGFuZCByLmxlbmd0aCBpcyAyXG4gICAgICAgICAgaWYgXy5pc0Z1bmN0aW9uIHJbMF0uZmV0Y2hcbiAgICAgICAgICAgIGMgPSByXG4gICAgICAgICAgZWxzZVxuICAgICAgICAgICAgZmlsdGVycyA9IHJbMF1cbiAgICAgICAgICAgIG9wdGlvbnMgPSByWzFdXG4gICAgICAgIGVsc2UgaWYgXy5pc0Z1bmN0aW9uIHIuZmV0Y2hcbiAgICAgICAgICBjID0gclxuICAgICAgXG4gICAgICBpZiAhRUpTT04uZXF1YWxzKHt9LCBmaWx0ZXJzKSBhbmQgIUVKU09OLmVxdWFscyhnZXQoXCJmaWx0ZXJzXCIpLCBmaWx0ZXJzKVxuICAgICAgICBzZXQgXCJyZWFsRmlsdGVyc1wiLCBmaWx0ZXJzXG4gICAgICBcbiAgICAgICMgR2V0IGEgY3Vyc29yIHRvIHRoZSBiYXNlIGNvbGxlY3Rpb25cbiAgICAgICNAbG9nIFwiUHVibGlzaGluZ1wiLCBmaWx0ZXJzLCBvcHRpb25zXG4gICAgICBjIG9yIEBDb2xsZWN0aW9uLmZpbmQgZmlsdGVycywgb3B0aW9uc1xuICAgIFxuICAgICksIEAsIHN1YiwgZ2V0LCBzZXRcblxuICAgIGMgPSBxdWVyeSgpXG5cbiAgICAjd2F0Y2hDb2xsZWN0aW9uOiAtPlxuICAgICNjID0gQENvbGxlY3Rpb24uZmluZCgpXG4gICAgXG4gICAgc2VsZiA9IEBcbiAgICBcbiAgICAjIFdlIG5lZWQgdG8gY2FsbCBzdWIncyBhZGRlZCBjYWxsYmFjayB3aGVuIGEgbmV3IGRvY3VtZW50IGlzIGFkZGVkLCBob3dldmVyXG4gICAgIyBmb3IgdGhlIHB1cnBvc2VzIG9mIHBhZ2luYXRpb24gd2UgYWxzbyBuZWVkIHRvIGluY2x1ZGUgdGhlIGluZGV4IG9mIGVhY2ggZG9jdW1lbnQuXG4gICAgI1xuICAgICMgRnVydGhlcm1vcmUsIGFuIGFkZGVkIGRvY3VtZW50IG1pZ2h0IGluY3JlYXNlIHRoZSBpbmRleCBvZiBvdGhlciBkb2N1bWVudHMgb24gdGhpcyBwYWdlLlxuICAgICNcbiAgICAjIFdlIHRoZXJlZm9yZSBuZWVkIHRvIHVzZSB0aGUgb2JzZXJ2ZSBtZXRob2QgdG8gaGFuZGxlIHRoaXMuXG4gICAgXG4gICAgaGFuZGxlID0gYy5vYnNlcnZlXG4gICAgICBhZGRlZEF0OiBfLmJpbmQgKChzdWIsIHF1ZXJ5LCBkb2MsIGF0KSAtPlxuICAgICAgICByZXR1cm4gIGlmIGluaXRcbiAgICAgICAgI0Bsb2cgXCIje2RvYy5pZH0gYWRkZWQgYXQgI3twYWdlfSwgI3thdH1cIlxuICAgICAgICBkb2NbXCJfI3tAaWR9X3BcIl0gPSBwYWdlXG4gICAgICAgIGRvY1tcIl8je0BpZH1faVwiXSA9IGF0XG4gICAgICAgIGlkID0gZG9jLl9pZFxuICAgICAgICBkZWxldGUgZG9jLl9pZCAgXG4gICAgICAgICMgQWRkIHRvIEBDb2xsZWN0aW9uXG4gICAgICAgIHF1ZXJ5KCkuZm9yRWFjaCAobywgaSkgPT5cbiAgICAgICAgICBpZiBpIGlzIGF0XG4gICAgICAgICAgICBzdWIuYWRkZWQgQENvbGxlY3Rpb24uX25hbWUsIGlkLCBkb2NcbiAgICAgICAgICBlbHNlXG4gICAgICAgICAgICBzdWIuY2hhbmdlZCBAQ29sbGVjdGlvbi5fbmFtZSwgby5faWQsIF8ub2JqZWN0IFtbXCJfI3tAaWR9X2lcIiwgaV1dXG4gICAgICApLCBALCBzdWIsIHF1ZXJ5XG4gICAgXG4gICAgIyBGb3IgdGhlIG90aGVyIGNhc2VzIHRoZSBtb3JlIGVmZmljaWVudCBvYnNlcnZlQ2hhbmdlcyB3aWxsIHN1ZmZpY2UuLi5cbiAgICAgIFxuICAgIGhhbmRsZTIgPSBjLm9ic2VydmVDaGFuZ2VzXG4gICAgICBtb3ZlZEJlZm9yZTogXy5iaW5kICgoc3ViLCBxdWVyeSwgaWQsIGJlZm9yZSkgLT5cbiAgICAgICAgI0Bsb2cgXCIje2lkfSBtb3ZlZCBiZWZvcmUgI3tiZWZvcmV9XCJcbiAgICAgICAgcXVlcnkoKS5mb3JFYWNoIChvLCBpKSA9PlxuICAgICAgICAgIHN1Yi5jaGFuZ2VkIEBDb2xsZWN0aW9uLl9uYW1lLCBvLl9pZCwgXy5vYmplY3QgW1tcIl8je0BpZH1faVwiLCBpXV1cbiAgICAgICksIEAsIHN1YiwgcXVlcnlcbiAgICAgIFxuICAgICAgY2hhbmdlZDogXy5iaW5kICgoc3ViLCBxdWVyeSwgaWQsIGZpZWxkcykgLT5cbiAgICAgICAgI0Bsb2cgXCIje2lkfSBjaGFuZ2VkXCJcbiAgICAgICAgdHJ5XG4gICAgICAgICAgc3ViLmNoYW5nZWQgQENvbGxlY3Rpb24uX25hbWUsIGlkLCBmaWVsZHNcbiAgICAgICAgY2F0Y2ggZVxuICAgICAgKSwgQCwgc3ViLCBxdWVyeVxuICAgICAgXG4gICAgICByZW1vdmVkOiBfLmJpbmQgKChzdWIsIHF1ZXJ5LCBpZCkgLT5cbiAgICAgICAgI0Bsb2cgXCIje2lkfSByZW1vdmVkXCJcbiAgICAgICAgdHJ5XG4gICAgICAgICAgc3ViLnJlbW92ZWQgQENvbGxlY3Rpb24uX25hbWUsIGlkXG4gICAgICAgICAgcXVlcnkoKS5mb3JFYWNoIChvLCBpKSA9PlxuICAgICAgICAgICAgc3ViLmNoYW5nZWQgQENvbGxlY3Rpb24uX25hbWUsIG8uX2lkLCBfLm9iamVjdCBbW1wiXyN7QGlkfV9pXCIsIGldXVxuICAgICAgICBjYXRjaCBlXG4gICAgICApLCBALCBzdWIsIHF1ZXJ5XG4gICAgXG4gICAgIyBBZGQgdGhlIGRvY3VtZW50cyBmcm9tIHRoaXMgcXVlcnkgXG4gICAgXG4gICAgbiA9IDBcbiAgICBjLmZvckVhY2ggKGRvYywgaW5kZXgsIGN1cnNvcikgPT5cbiAgICAgIG4rK1xuICAgICAgZG9jW1wiXyN7QGlkfV9wXCJdID0gcGFnZVxuICAgICAgZG9jW1wiXyN7QGlkfV9pXCJdID0gaW5kZXhcbiAgICAgIHN1Yi5hZGRlZCBAQ29sbGVjdGlvbi5fbmFtZSwgZG9jLl9pZCwgZG9jXG5cbiAgICBpbml0ID0gZmFsc2VcblxuICAgIHN1Yi5vblN0b3AgXy5iaW5kICgocGFnZSkgLT5cbiAgICAgICNAbG9nIFwiI3tzdWIuY29ubmVjdGlvbi5pZH06IHBhZ2UgI3twYWdlfSBzdWJzY3JpcHRpb24gc3RvcHBlZFwiXG4gICAgICBkZWxldGUgQHN1YnNjcmlwdGlvbnNbc3ViLmNvbm5lY3Rpb24uaWRdW3BhZ2VdXG4gICAgICBAc3Vic2NyaXB0aW9uc1tzdWIuY29ubmVjdGlvbi5pZF0ubGVuZ3RoLS1cbiAgICAgIGhhbmRsZS5zdG9wKClcbiAgICAgIGhhbmRsZTIuc3RvcCgpXG4gICAgKSwgQCwgcGFnZVxuICAgIEBzdWJzY3JpcHRpb25zW3N1Yi5jb25uZWN0aW9uLmlkXVtwYWdlXSA9IHN1YlxuICAgIEBzdWJzY3JpcHRpb25zW3N1Yi5jb25uZWN0aW9uLmlkXS5sZW5ndGgrK1xuICAgIHN1Yi5yZWFkeSgpXG4gIFxuICAjIFNldHMgdGhlIHN0YXRlIG9mIHRoZSBjdXJyZW50IHBhZ2UgYXMgXCJsb2FkaW5nXCIgKHJlYWR5ID0gZmFsc2UpICBcbiAgXG4gIGxvYWRpbmc6IChwKSAtPlxuICAgIGlmICFAZmFzdFJlbmRlciBhbmQgcCBpcyBAY3VycmVudFBhZ2UoKVxuICAgICAgQHNlc3MgXCJyZWFkeVwiLCBmYWxzZVxuICBcbiAgbm93OiAtPlxuICAgIChuZXcgRGF0ZSgpKS5nZXRUaW1lKClcbiAgXG4gIGxvZzogLT5cbiAgICBhID0gW1wiUGFnZXM6ICN7QG5hbWV9IC1cIl1cbiAgICBmb3IgaSBpbiBhcmd1bWVudHNcbiAgICAgIGEucHVzaCBpXG4gICAgQGRlYnVnIGFuZCBjb25zb2xlLmxvZy5hcHBseSBjb25zb2xlLCBhXG4gIFxuICBsb2dSZXF1ZXN0OiAocCkgLT5cbiAgICBAdGltZUxhc3RSZXF1ZXN0ID0gQG5vdygpXG4gICAgQHJlcXVlc3RpbmcgPSBwXG4gICAgQHJlcXVlc3RlZFtwXSA9IDFcbiAgXG4gIGxvZ1Jlc3BvbnNlOiAocCkgLT5cbiAgICBkZWxldGUgQHJlcXVlc3RlZFtwXVxuICAgIEByZWNlaXZlZFtwXSA9IDFcbiAgXG4gIGNsZWFyUXVldWU6IC0+XG4gICAgQHF1ZXVlID0gW11cbiAgXG4gIG5laWdoYm9yczogKHBhZ2UpIC0+XG4gICAgbiA9IFtdXG4gICAgaWYgQGRhdGFNYXJnaW4gaXMgMCBvciBAbWF4U3Vic2NyaXB0aW9ucyA8IDJcbiAgICAgIHJldHVybiBuXG4gICAgbWF4TWFyZ2luID0gTWF0aC5mbG9vcigoQG1heFN1YnNjcmlwdGlvbnMgLSAxKSAvIDIpXG4gICAgZm9yIGQgaW4gWzEgLi4gXy5taW4gW21heE1hcmdpbiwgQGRhdGFNYXJnaW5dXVxuICAgICAgbnAgPSBwYWdlICsgZFxuICAgICAgaWYgbnAgPD0gQHNlc3MgXCJ0b3RhbFBhZ2VzXCJcbiAgICAgICAgbi5wdXNoIG5wXG4gICAgICBwcCA9IHBhZ2UgLSBkXG4gICAgICBpZiBwcCA+IDBcbiAgICAgICAgbi5wdXNoIHBwXG4gICAgblxuICBcbiAgcXVldWVOZWlnaGJvcnM6IChwYWdlKSAtPlxuICAgIGZvciBwIGluIEBuZWlnaGJvcnMgcGFnZVxuICAgICAgQHF1ZXVlLnB1c2ggcCAgaWYgIUByZWNlaXZlZFtwXSBhbmQgIUByZXF1ZXN0ZWRbcF0gYW5kIHAgbm90IGluIEBxdWV1ZVxuICBcbiAgcGFnaW5hdGlvbk5hdkl0ZW06IChsYWJlbCwgcGFnZSwgZGlzYWJsZWQsIGFjdGl2ZSA9IGZhbHNlKSAtPlxuICAgIHA6IGxhYmVsXG4gICAgbjogcGFnZVxuICAgIGFjdGl2ZTogaWYgYWN0aXZlIHRoZW4gXCJhY3RpdmVcIiBlbHNlIFwiXCJcbiAgICBkaXNhYmxlZDogaWYgZGlzYWJsZWQgdGhlbiBcImRpc2FibGVkXCIgZWxzZSBcIlwiXG4gIFxuICBuYXZpZ2F0aW9uTmVpZ2hib3JzOiAtPlxuICAgIHBhZ2UgPSBAY3VycmVudFBhZ2UoKVxuICAgIHRvdGFsID0gQHNlc3MgXCJ0b3RhbFBhZ2VzXCJcbiAgICBmcm9tID0gcGFnZSAtIEBwYWdpbmF0aW9uTWFyZ2luXG4gICAgdG8gPSBwYWdlICsgQHBhZ2luYXRpb25NYXJnaW5cbiAgICBpZiBmcm9tIDwgMVxuICAgICAgICB0byArPSAxIC0gZnJvbVxuICAgICAgICBmcm9tID0gMVxuICAgIGlmIHRvID4gdG90YWxcbiAgICAgICAgZnJvbSAtPSB0byAtIHRvdGFsXG4gICAgICAgIHRvID0gdG90YWxcbiAgICBmcm9tID0gMSBpZiBmcm9tIDwgMVxuICAgIHRvID0gdG90YWwgaWYgdG8gPiB0b3RhbFxuICAgIG4gPSBbXVxuICAgIGlmIEBuYXZTaG93Rmlyc3Qgb3IgQG5hdlNob3dFZGdlc1xuICAgICAgbi5wdXNoIEBwYWdpbmF0aW9uTmF2SXRlbSBcIsKrXCIsIDEsIHBhZ2UgPT0gMVxuICAgIG4ucHVzaCBAcGFnaW5hdGlvbk5hdkl0ZW0gXCI8XCIsIHBhZ2UgLSAxLCBwYWdlID09IDFcbiAgICBmb3IgcCBpbiBbZnJvbSAuLiB0b11cbiAgICAgIG4ucHVzaCBAcGFnaW5hdGlvbk5hdkl0ZW0gcCwgcCwgcGFnZSA+IHRvdGFsLCBwIGlzIHBhZ2VcbiAgICBuLnB1c2ggQHBhZ2luYXRpb25OYXZJdGVtIFwiPlwiLCBwYWdlICsgMSwgcGFnZSA+PSB0b3RhbFxuICAgIGlmIEBuYXZTaG93TGFzdCBvciBAbmF2U2hvd0VkZ2VzXG4gICAgICBuLnB1c2ggQHBhZ2luYXRpb25OYXZJdGVtIFwiwrtcIiwgdG90YWwsIHBhZ2UgPj0gdG90YWxcbiAgICBmb3IgaSwgayBpbiBuXG4gICAgICBuW2tdWydfcCddID0gQFxuICAgIG5cbiAgXG4gIG9uTmF2Q2xpY2s6IChuKSAtPlxuICAgIGlmIG4gPD0gQHNlc3MoXCJ0b3RhbFBhZ2VzXCIpIGFuZCBuID4gMFxuICAgICAgVHJhY2tlci5ub25yZWFjdGl2ZSA9PlxuICAgICAgICBjcCA9IEBzZXNzIFwiY3VycmVudFBhZ2VcIlxuICAgICAgICBpZiBAcmVjZWl2ZWRbY3BdXG4gICAgICAgICAgQHNlc3MgXCJvbGRQYWdlXCIsIGNwXG4gICAgICBAc2VzcyBcImN1cnJlbnRQYWdlXCIsIG5cbiAgXG4gIHNldEluZmluaXRlVHJpZ2dlcjogLT5cbiAgICBAc2Nyb2xsQm94U2VsZWN0b3IgPSBAc2Nyb2xsQm94U2VsZWN0b3IgfHwgd2luZG93XG4gICAgQHNjcm9sbEJveCA9ICQoQHNjcm9sbEJveFNlbGVjdG9yKVxuICAgIEBzY3JvbGxCb3guc2Nyb2xsIF8uYmluZCAoXG4gICAgICBfLnRocm90dGxlIC0+XG4gICAgICAgIHQgPSBAaW5maW5pdGVUcmlnZ2VyXG4gICAgICAgIG9oID0gQHNjcm9sbEJveFswXS5zY3JvbGxIZWlnaHRcbiAgICAgICAgcmV0dXJuICBpZiBAbGFzdE9mZnNldEhlaWdodD8gYW5kIEBsYXN0T2Zmc2V0SGVpZ2h0ID4gb2hcbiAgICAgICAgQGxhc3RPZmZzZXRIZWlnaHQgPSBvaFxuICAgICAgICBpZiB0ID4gMVxuICAgICAgICAgIGwgPSBvaCAtIHRcbiAgICAgICAgZWxzZSBpZiB0ID4gMFxuICAgICAgICAgIGwgPSBvaCAqIHRcbiAgICAgICAgZWxzZVxuICAgICAgICAgIHJldHVyblxuXG4gICAgICAgIGlmIChAc2Nyb2xsQm94LnNjcm9sbFRvcCgpICsgQHNjcm9sbEJveFswXS5vZmZzZXRIZWlnaHQgPj0gbClcbiAgICAgICAgICBAc2VzcyhcImxpbWl0XCIsIEBzZXNzKFwibGltaXRcIikgKyBAaW5maW5pdGVTdGVwKVxuICAgICAgICAgIFxuICAgICAgICAgICMjI1xuICAgICAgICAgIGlmIEBsYXN0UGFnZSA8IEBzZXNzIFwidG90YWxQYWdlc1wiXG4gICAgICAgICAgICBjb25zb2xlLmxvZyBcImkgd2FudCBwYWdlICN7QGxhc3RQYWdlICsgMX1cIlxuICAgICAgICAgICAgQHNlc3MoXCJjdXJyZW50UGFnZVwiLCBAbGFzdFBhZ2UgKyAxKVxuICAgICAgICAgICMjI1xuICAgICAgICAgIFxuICAgICAgLCBAaW5maW5pdGVSYXRlTGltaXQgKiAxMDAwXG4gICAgKSwgQFxuICBcbiAgY2hlY2tRdWV1ZTogXy50aHJvdHRsZSAtPlxuICAgICNAbG9nIFwiQ2hlY2tpbmcgcXVldWVcIlxuICAgIGNwID0gQGN1cnJlbnRQYWdlKClcbiAgICBuZWlnaGJvcnMgPSBAbmVpZ2hib3JzIGNwXG4gICAgXG4gICAgIyBJZiB3ZSBoYXZlbid0IHlldCByZWNlaXZlZCB0aGUgY3VycmVudCBwYWdlIHRoZW4gY2xlYXIgYWxsIHRoZSBvdGhlciBzdWJzY3JpcHRpb25zIGFuZCByZXF1ZXN0c1xuICAgICMgYW5kIGdldCB0aGUgY3VycmVudCBwYWdlXG4gICAgXG4gICAgaWYgIUByZWNlaXZlZFtjcF1cbiAgICAgICNAbG9nIFwiSGF2ZW4ndCB5ZXQgcmVjZWl2ZWQgdGhlIGN1cnJlbnQgcGFnZSAoI3tjcH0pLlwiXG4gICAgICBAY2xlYXJRdWV1ZSgpXG4gICAgICBAcmVxdWVzdFBhZ2UgY3BcbiAgICAgIGNwID0gU3RyaW5nIGNwXG4gICAgICBmb3IgaywgdiBvZiBAcmVxdWVzdGVkXG4gICAgICAgIGlmIGsgaXNudCBjcFxuICAgICAgICAgIGlmIEBzdWJzY3JpcHRpb25zW2tdP1xuICAgICAgICAgICAgQHN1YnNjcmlwdGlvbnNba10uc3RvcCgpXG4gICAgICAgICAgICBkZWxldGUgQHN1YnNjcmlwdGlvbnNba11cbiAgICAgICAgICAgIEBzdWJzY3JpcHRpb25zLmxlbmd0aC0tXG4gICAgICAgICAgZGVsZXRlIEByZXF1ZXN0ZWRba11cbiAgICBcbiAgICAjIElmIHdlIGRvIGhhdmUgdGhlIGN1cnJlbnQgcGFnZSB0aGVuIHF1ZXVlIHRoZSBuZWlnaGJvdXJzXG4gICAgXG4gICAgZWxzZSBpZiBAcXVldWUubGVuZ3RoXG4gICAgICAjQGxvZyBcIkN1cnJlbnQgcGFnZSAoI3tjcH0pIGFscmVhZHkgcmVjZWl2ZWQuXCJcbiAgICAgIHdoaWxlIEBxdWV1ZS5sZW5ndGggPiAwXG4gICAgICAgIGkgPSBAcXVldWUuc2hpZnQoKVxuICAgICAgICBpZiBpIGluIG5laWdoYm9yc1xuICAgICAgICAgICNAbG9nIG5laWdoYm9yc1xuICAgICAgICAgIEByZXF1ZXN0UGFnZSBpXG4gICAgICAgICAgYnJlYWtcbiAgLCA1MDBcbiAgXG4gIGN1cnJlbnRQYWdlOiAtPlxuICAgIGlmIE1ldGVvci5pc0NsaWVudCBhbmQgQHNlc3MoXCJjdXJyZW50UGFnZVwiKT9cbiAgICAgIEBzZXNzIFwiY3VycmVudFBhZ2VcIlxuICAgIGVsc2VcbiAgICAgIEBfY3VycmVudFBhZ2VcbiAgXG4gIGlzUmVhZHk6IC0+XG4gICAgQHNlc3MgXCJyZWFkeVwiXG4gIFxuICByZWFkeTogKHApIC0+XG4gICAgaWYgcCBpcyB0cnVlIG9yIHAgaXMgQGN1cnJlbnRQYWdlKCkgYW5kIFNlc3Npb24/XG4gICAgICBAc2VzcyBcInJlYWR5XCIsIHRydWVcbiAgXG4gIGNoZWNrSW5pdFBhZ2U6IC0+XG4gICAgaWYgQGluaXQgYW5kICFAaW5pdFBhZ2UgXG4gICAgICBpZiBAcm91dGVyXG4gICAgICAgIFJvdXRlci5jdXJyZW50KCk/LnJvdXRlPy5nZXROYW1lKClcbiAgICAgICAgdHJ5XG4gICAgICAgICAgQGluaXRQYWdlID0gcGFyc2VJbnQoUm91dGVyLmN1cnJlbnQoKS5yb3V0ZS5wYXJhbXMobG9jYXRpb24uaHJlZik/LnBhZ2UpIG9yIDFcbiAgICAgICAgY2F0Y2hcbiAgICAgICAgICByZXR1cm5cbiAgICAgIGVsc2VcbiAgICAgICAgQGluaXRQYWdlID0gMVxuICAgIEBpbml0ID0gZmFsc2VcbiAgICBAc2VzcyBcIm9sZFBhZ2VcIiwgQGluaXRQYWdlXG4gICAgQHNlc3MgXCJjdXJyZW50UGFnZVwiLCBAaW5pdFBhZ2VcbiAgXG4gIGdldFBhZ2U6IChwYWdlKSAtPlxuICAgIGlmIE1ldGVvci5pc0NsaWVudFxuICAgICAgcGFnZSA9IEBjdXJyZW50UGFnZSgpICBpZiAhcGFnZT9cbiAgICAgIHBhZ2UgPSBwYXJzZUludCBwYWdlXG4gICAgICByZXR1cm4gIGlmIHBhZ2UgaXMgTmFOXG4gICAgICB0b3RhbCA9IEBzZXNzIFwidG90YWxQYWdlc1wiXG4gICAgICByZXR1cm4gQHJlYWR5IHRydWUgIGlmIHRvdGFsIGlzIDBcbiAgICAgIFxuICAgICAgIyBSZXF1ZXN0IGRhdGEgZm9yIHRoZSBwYWdlXG4gICAgICBcbiAgICAgIGlmIHBhZ2UgPD0gdG90YWxcbiAgICAgICAgQHJlcXVlc3RQYWdlIHBhZ2VcbiAgICAgICAgQHF1ZXVlTmVpZ2hib3JzIHBhZ2VcbiAgICAgICAgQGNoZWNrUXVldWUoKVxuICAgICAgXG4gICAgICAjIFJldHVybiB0aGUgY29udGVudCBvZiB0aGlzIHBhZ2UgXG4gICAgICAjXG4gICAgICAjIFRoZSBjb250ZW50cyB3aWxsIGJlIHVwZGF0ZWQgKGFzIHdpbGwgdGhlIHBhZ2UpIGFzIGRhdGEgYXJyaXZlcyBmcm9tIHRoZSBzZXJ2ZXJcbiAgICAgIFxuICAgICAgaWYgQGluZmluaXRlXG4gICAgICAgIG4gPSBAQ29sbGVjdGlvbi5maW5kKHt9LFxuICAgICAgICAgIGZpZWxkczogQGZpZWxkc1xuICAgICAgICAgIHNvcnQ6IEBzb3J0XG4gICAgICAgICkuY291bnQoKVxuICAgICAgICBjID0gQENvbGxlY3Rpb24uZmluZCh7fSxcbiAgICAgICAgICBmaWVsZHM6IEBmaWVsZHNcbiAgICAgICAgICBzb3J0OiBAc29ydFxuICAgICAgICAgIHNraXA6IGlmIG4gPiBAaW5maW5pdGVJdGVtc0xpbWl0IHRoZW4gbiAtIEBpbmZpbml0ZUl0ZW1zTGltaXQgZWxzZSAwXG4gICAgICAgICAgbGltaXQ6IEBzZXNzKFwibGltaXRcIikgb3IgQGluZmluaXRlSXRlbXNMaW1pdFxuICAgICAgICApXG4gICAgICBlbHNlXG4gICAgICAgIGMgPSBAQ29sbGVjdGlvbi5maW5kKFxuICAgICAgICAgIF8ub2JqZWN0KFtcbiAgICAgICAgICAgIFtcIl8je0BpZH1fcFwiLCBwYWdlXVxuICAgICAgICAgIF0pLFxuICAgICAgICAgIGZpZWxkczogQGZpZWxkc1xuICAgICAgICAgIHNvcnQ6IF8ub2JqZWN0KFtcbiAgICAgICAgICAgIFtcIl8je0BpZH1faVwiLCAxXVxuICAgICAgICAgIF0pXG4gICAgICAgIClcbiAgICAgICAgYy5vYnNlcnZlQ2hhbmdlc1xuICAgICAgICAgIGFkZGVkOiA9PlxuICAgICAgICAgICAgQGNvdW50UGFnZXMoKVxuICAgICAgICAgIHJlbW92ZWQ6ID0+XG4gICAgICAgICAgICAjIyMjIyMjIyMjXG4gICAgICAgICAgICAjIyMjIyMjIyMjXG4gICAgICAgICAgICAjIyMgISEgIyMjXG4gICAgICAgICAgICAjIyMjIyMjIyMjXG4gICAgICAgICAgICAjIyMjIyMjIyMjXG4gICAgICAgICAgICBAcmVxdWVzdFBhZ2UgQHNlc3MgXCJjdXJyZW50UGFnZVwiXG4gICAgICAgICAgICBAY291bnRQYWdlcygpXG4gICAgICBcbiAgICAgIGMuZmV0Y2goKVxuICBcbiAgIyBTdWJzY3JpYmVzIHRvIHRoZSBnaXZlbiBwYWdlXG4gIFxuICByZXF1ZXN0UGFnZTogKHBhZ2UpIC0+XG4gICAgcmV0dXJuICBpZiAhcGFnZSBvciBAcmVxdWVzdGVkW3BhZ2VdIG9yIEByZWNlaXZlZFtwYWdlXVxuICAgIEBsb2cgXCJSZXF1ZXN0aW5nIHBhZ2UgI3twYWdlfVwiXG4gICAgQGxvZ1JlcXVlc3QgcGFnZVxuICAgIGlmICFNZXRlb3Iuc3RhdHVzKCkuY29ubmVjdGVkIGFuZCBAZ3JvdW5kREJcbiAgICAgIGlmIEBDb2xsZWN0aW9uLmZpbmRPbmUoXy5vYmplY3QgW1tcIl8je0BpZH1fcFwiLCBwYWdlXV0pXG4gICAgICAgIEBvblBhZ2UgcGFnZVxuICAgICAgZWxzZVxuICAgICAgICBzZXRUaW1lb3V0IChfLmJpbmQgKHBhZ2UpIC0+XG4gICAgICAgICAgaWYgQGN1cnJlbnRQYWdlKCkgaXMgcGFnZSBhbmQgIUByZWNlaXZlZFtwYWdlXVxuICAgICAgICAgICAgZGVsZXRlIEByZXF1ZXN0ZWRbcGFnZV1cbiAgICAgICAgICAgIEByZXF1ZXN0UGFnZSBwYWdlXG4gICAgICAgICwgQCwgcGFnZSlcbiAgICAgICAgLCA1MDBcbiAgICBlbHNlXG4gICAgICBAZW5mb3JjZVN1YnNjcmlwdGlvbkxpbWl0KClcbiAgICAgIE1ldGVvci5kZWZlciBfLmJpbmQgKChwYWdlKSAtPlxuICAgICAgICAjQGxvZyBcInN1YnNjcmliaW5nIHRvIHBhZ2UgI3twYWdlfVwiXG4gICAgICAgIEBzdWJzY3JpcHRpb25zW3BhZ2VdID0gTWV0ZW9yLnN1YnNjcmliZSBAaWQsIHBhZ2UsXG4gICAgICAgICAgb25SZWFkeTogXy5iaW5kIChwYWdlKSAtPlxuICAgICAgICAgICAgQG9uUGFnZSBwYWdlXG4gICAgICAgICAgLCBALCBwYWdlXG4gICAgICAgICAgb25FcnJvcjogKGUpID0+XG4gICAgICAgICAgICBpZiBlLmVycm9yIGlzIFwic3Vic2NyaXB0aW9uLWxpbWl0LXJlYWNoZWRcIlxuICAgICAgICAgICAgICBzZXRUaW1lb3V0IChfLmJpbmQgKHBhZ2UpIC0+XG4gICAgICAgICAgICAgICAgaWYgQGN1cnJlbnRQYWdlKCkgaXMgcGFnZSBhbmQgIUByZWNlaXZlZFtwYWdlXVxuICAgICAgICAgICAgICAgICAgZGVsZXRlIEByZXF1ZXN0ZWRbcGFnZV1cbiAgICAgICAgICAgICAgICAgIEByZXF1ZXN0UGFnZSBwYWdlXG4gICAgICAgICAgICAgICwgQCwgcGFnZSlcbiAgICAgICAgICAgICAgLCA1MDBcbiAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgQGVycm9yIGUubWVzc2FnZVxuICAgICAgICBAc3Vic2NyaXB0aW9ucy5vcmRlci5wdXNoIHBhZ2VcbiAgICAgICAgQHN1YnNjcmlwdGlvbnMubGVuZ3RoKytcbiAgICAgICAgI0Bsb2cgXCJOdW1iZXIgb2Ygc3Vic2NyaXB0aW9uczogI3tAc3Vic2NyaXB0aW9ucy5sZW5ndGh9XCJcbiAgICAgICksIEAsIHBhZ2VcbiAgXG4gICMgQ2FsbGVkIHdoZW4gYSBwYWdlIGhhcyBiZWVuIHJlY2VpdmVkXG4gIFxuICBvblBhZ2U6IChwYWdlKSAtPlxuICAgIEBsb2cgXCJSZWNlaXZlZCBwYWdlICN7cGFnZX1cIlxuICAgIEBiZWZvcmVGaXJzdFJlYWR5ID0gZmFsc2VcbiAgICBAbG9nUmVzcG9uc2UgcGFnZVxuICAgIEByZWFkeSBwYWdlXG4gICAgaWYgQGluZmluaXRlXG4gICAgICBAbGFzdFBhZ2UgPSBwYWdlXG4gICAgQGNvdW50UGFnZXMoKVxuICAgIEBjaGVja1F1ZXVlKClcblxuTWV0ZW9yLlBhZ2luYXRpb24gPSBQYWdlc1xuIiwidmFyIFBhZ2VzLFxuICBzbGljZSA9IFtdLnNsaWNlLFxuICBpbmRleE9mID0gW10uaW5kZXhPZiB8fCBmdW5jdGlvbihpdGVtKSB7IGZvciAodmFyIGkgPSAwLCBsID0gdGhpcy5sZW5ndGg7IGkgPCBsOyBpKyspIHsgaWYgKGkgaW4gdGhpcyAmJiB0aGlzW2ldID09PSBpdGVtKSByZXR1cm4gaTsgfSByZXR1cm4gLTE7IH07XG5cbnRoaXMuX19QYWdlcyA9IFBhZ2VzID0gKGZ1bmN0aW9uKCkge1xuICBQYWdlcy5wcm90b3R5cGUuc2V0dGluZ3MgPSB7XG4gICAgZGF0YU1hcmdpbjogW3RydWUsIE51bWJlciwgM10sXG4gICAgZGl2V3JhcHBlcjogW3RydWUsIE1hdGNoLk9uZU9mKE1hdGNoLk9wdGlvbmFsKFN0cmluZyksIE1hdGNoLk9wdGlvbmFsKEJvb2xlYW4pKSwgXCJwYWdlc0NvbnRcIl0sXG4gICAgZmllbGRzOiBbdHJ1ZSwgT2JqZWN0LCB7fV0sXG4gICAgZmlsdGVyczogW3RydWUsIE9iamVjdCwge31dLFxuICAgIGl0ZW1UZW1wbGF0ZTogW3RydWUsIFN0cmluZywgXCJfcGFnZXNJdGVtRGVmYXVsdFwiXSxcbiAgICBuYXZTaG93RWRnZXM6IFt0cnVlLCBCb29sZWFuLCBmYWxzZV0sXG4gICAgbmF2U2hvd0ZpcnN0OiBbdHJ1ZSwgQm9vbGVhbiwgdHJ1ZV0sXG4gICAgbmF2U2hvd0xhc3Q6IFt0cnVlLCBCb29sZWFuLCB0cnVlXSxcbiAgICByZXNldE9uUmVsb2FkOiBbdHJ1ZSwgQm9vbGVhbiwgZmFsc2VdLFxuICAgIHBhZ2luYXRpb25NYXJnaW46IFt0cnVlLCBOdW1iZXIsIDNdLFxuICAgIHBlclBhZ2U6IFt0cnVlLCBOdW1iZXIsIDEwXSxcbiAgICByb3V0ZTogW3RydWUsIFN0cmluZywgXCIvcGFnZS9cIl0sXG4gICAgcm91dGVyOiBbdHJ1ZSwgTWF0Y2guT3B0aW9uYWwoU3RyaW5nKSwgdm9pZCAwXSxcbiAgICByb3V0ZXJUZW1wbGF0ZTogW3RydWUsIFN0cmluZywgXCJwYWdlc1wiXSxcbiAgICByb3V0ZXJMYXlvdXQ6IFt0cnVlLCBNYXRjaC5PcHRpb25hbChTdHJpbmcpLCB2b2lkIDBdLFxuICAgIHNvcnQ6IFt0cnVlLCBPYmplY3QsIHt9XSxcbiAgICBhdXRoOiBbZmFsc2UsIE1hdGNoLk9wdGlvbmFsKEZ1bmN0aW9uKSwgdm9pZCAwXSxcbiAgICBhdmFpbGFibGVTZXR0aW5nczogW2ZhbHNlLCBPYmplY3QsIHt9XSxcbiAgICBmYXN0UmVuZGVyOiBbZmFsc2UsIEJvb2xlYW4sIGZhbHNlXSxcbiAgICBob21lUm91dGU6IFtmYWxzZSwgTWF0Y2guT25lT2YoU3RyaW5nLCBBcnJheSwgQm9vbGVhbiksIFwiL1wiXSxcbiAgICBpbmZpbml0ZTogW2ZhbHNlLCBCb29sZWFuLCBmYWxzZV0sXG4gICAgaW5maW5pdGVJdGVtc0xpbWl0OiBbZmFsc2UsIE51bWJlciwgMmUzMDhdLFxuICAgIGluZmluaXRlVHJpZ2dlcjogW2ZhbHNlLCBOdW1iZXIsIC45XSxcbiAgICBpbmZpbml0ZVJhdGVMaW1pdDogW2ZhbHNlLCBOdW1iZXIsIDFdLFxuICAgIGluZmluaXRlU3RlcDogW2ZhbHNlLCBOdW1iZXIsIDEwXSxcbiAgICBpbml0UGFnZTogW2ZhbHNlLCBOdW1iZXIsIDFdLFxuICAgIG1heFN1YnNjcmlwdGlvbnM6IFtmYWxzZSwgTnVtYmVyLCAyMF0sXG4gICAgbmF2VGVtcGxhdGU6IFtmYWxzZSwgU3RyaW5nLCBcIl9wYWdlc05hdkNvbnRcIl0sXG4gICAgb25EZW5pZWRTZXR0aW5nOiBbXG4gICAgICBmYWxzZSwgRnVuY3Rpb24sIGZ1bmN0aW9uKGssIHYsIGUpIHtcbiAgICAgICAgcmV0dXJuIHR5cGVvZiBjb25zb2xlICE9PSBcInVuZGVmaW5lZFwiICYmIGNvbnNvbGUgIT09IG51bGwgPyBjb25zb2xlLmxvZyhcIkNoYW5naW5nIFwiICsgayArIFwiIG5vdCBhbGxvd2VkLlwiKSA6IHZvaWQgMDtcbiAgICAgIH1cbiAgICBdLFxuICAgIHBhZ2VDb3VudEZyZXF1ZW5jeTogW2ZhbHNlLCBOdW1iZXIsIDEwMDAwXSxcbiAgICBwYWdlU2l6ZUxpbWl0OiBbZmFsc2UsIE51bWJlciwgNjBdLFxuICAgIHBhZ2VUZW1wbGF0ZTogW2ZhbHNlLCBTdHJpbmcsIFwiX3BhZ2VzUGFnZUNvbnRcIl0sXG4gICAgcmF0ZUxpbWl0OiBbZmFsc2UsIE51bWJlciwgMV0sXG4gICAgcm91dGVTZXR0aW5nczogW2ZhbHNlLCBNYXRjaC5PcHRpb25hbChGdW5jdGlvbiksIHZvaWQgMF0sXG4gICAgc2Nyb2xsQm94U2VsZWN0b3I6IFtTdHJpbmcsIHZvaWQgMF0sXG4gICAgdGFibGU6IFtmYWxzZSwgTWF0Y2guT25lT2YoQm9vbGVhbiwgT2JqZWN0KSwgZmFsc2VdLFxuICAgIHRhYmxlSXRlbVRlbXBsYXRlOiBbZmFsc2UsIFN0cmluZywgXCJfcGFnZXNUYWJsZUl0ZW1cIl0sXG4gICAgdGFibGVUZW1wbGF0ZTogW2ZhbHNlLCBTdHJpbmcsIFwiX3BhZ2VzVGFibGVcIl0sXG4gICAgdGVtcGxhdGVOYW1lOiBbZmFsc2UsIE1hdGNoLk9wdGlvbmFsKFN0cmluZyksIHZvaWQgMF1cbiAgfTtcblxuICBQYWdlcy5wcm90b3R5cGUuX25JbnN0YW5jZXMgPSAwO1xuXG4gIFBhZ2VzLnByb3RvdHlwZS5jb2xsZWN0aW9ucyA9IHt9O1xuXG4gIFBhZ2VzLnByb3RvdHlwZS5pbnN0YW5jZXMgPSB7fTtcblxuICBQYWdlcy5wcm90b3R5cGUubWV0aG9kcyA9IHtcbiAgICBcIkNvdW50UGFnZXNcIjogZnVuY3Rpb24oc3ViKSB7XG4gICAgICB2YXIgbjtcbiAgICAgIG4gPSBzdWIuZ2V0KFwiblB1Ymxpc2hlZFBhZ2VzXCIpO1xuICAgICAgaWYgKG4gIT0gbnVsbCkge1xuICAgICAgICByZXR1cm4gbjtcbiAgICAgIH1cbiAgICAgIG4gPSBNYXRoLmNlaWwodGhpcy5Db2xsZWN0aW9uLmZpbmQoe1xuICAgICAgICAkYW5kOiBbc3ViLmdldChcImZpbHRlcnNcIiksIHN1Yi5nZXQoXCJyZWFsRmlsdGVyc1wiKSB8fCB7fV1cbiAgICAgIH0pLmNvdW50KCkgLyAoc3ViLmdldChcInBlclBhZ2VcIikpKTtcbiAgICAgIHJldHVybiBuIHx8IDE7XG4gICAgfSxcbiAgICBcIlNldFwiOiBmdW5jdGlvbihrLCB2LCBzdWIpIHtcbiAgICAgIHZhciBfaywgX3YsIGNoYW5nZXM7XG4gICAgICBpZiAodGhpcy5zZXR0aW5nc1trXSA9PSBudWxsKSB7XG4gICAgICAgIHRoaXMuZXJyb3IoXCJpbnZhbGlkLW9wdGlvblwiLCBcIkludmFsaWQgb3B0aW9uIG5hbWU6IFwiICsgayArIFwiLlwiKTtcbiAgICAgIH1cbiAgICAgIGNoZWNrKGssIFN0cmluZyk7XG4gICAgICBjaGVjayh2LCB0aGlzLnNldHRpbmdzW2tdWzFdKTtcbiAgICAgIGNoZWNrKHN1YiwgTWF0Y2guV2hlcmUoZnVuY3Rpb24oc3ViKSB7XG4gICAgICAgIHZhciByZWY7XG4gICAgICAgIHJldHVybiAoKHJlZiA9IHN1Yi5jb25uZWN0aW9uKSAhPSBudWxsID8gcmVmLmlkIDogdm9pZCAwKSAhPSBudWxsO1xuICAgICAgfSkpO1xuICAgICAgaWYgKCF0aGlzLmF2YWlsYWJsZVNldHRpbmdzW2tdIHx8IChfLmlzRnVuY3Rpb24odGhpcy5hdmFpbGFibGVTZXR0aW5nc1trXSkgJiYgIXRoaXMuYXZhaWxhYmxlU2V0dGluZ3Nba10odiwgc3ViKSkpIHtcbiAgICAgICAgdGhpcy5lcnJvcihcImZvcmJpZGRlbi1vcHRpb25cIiwgXCJDaGFuZ2luZyBcIiArIGsgKyBcIiBub3QgYWxsb3dlZC5cIik7XG4gICAgICB9XG4gICAgICBjaGFuZ2VzID0gMDtcbiAgICAgIGlmICh2ICE9IG51bGwpIHtcbiAgICAgICAgY2hhbmdlcyA9IHRoaXMuX3NldChrLCB2LCB7XG4gICAgICAgICAgY2lkOiBzdWIuY29ubmVjdGlvbi5pZFxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSBpZiAoIV8uaXNTdHJpbmcoaykpIHtcbiAgICAgICAgZm9yIChfayBpbiBrKSB7XG4gICAgICAgICAgX3YgPSBrW19rXTtcbiAgICAgICAgICBjaGFuZ2VzICs9IHRoaXMuc2V0KF9rLCBfdiwge1xuICAgICAgICAgICAgY2lkOiBzdWIuY29ubmVjdGlvbi5pZFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gY2hhbmdlcztcbiAgICB9LFxuICAgIFwiVW5zdWJzY3JpYmVcIjogZnVuY3Rpb24oKSB7XG4gICAgICB2YXIgY2lkLCBrLCByZWYsIHN1Yiwgc3VicztcbiAgICAgIGNpZCA9IGFyZ3VtZW50c1thcmd1bWVudHMubGVuZ3RoIC0gMV0uY29ubmVjdGlvbi5pZDtcbiAgICAgIHN1YnMgPSB7fTtcbiAgICAgIHJlZiA9IHRoaXMuc3Vic2NyaXB0aW9ucztcbiAgICAgIGZvciAoayBpbiByZWYpIHtcbiAgICAgICAgc3ViID0gcmVmW2tdO1xuICAgICAgICBpZiAoayA9PT0gXCJsZW5ndGhcIiB8fCBrID09PSBcIm9yZGVyXCIpIHtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoc3ViLmNvbm5lY3Rpb24uaWQgPT09IGNpZCkge1xuICAgICAgICAgIHN1Yi5zdG9wKCk7XG4gICAgICAgICAgZGVsZXRlIHRoaXMuc3Vic2NyaXB0aW9uc1trXTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgdGhpcy5zdWJzY3JpcHRpb25zLmxlbmd0aCA9IDA7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gIH07XG5cbiAgZnVuY3Rpb24gUGFnZXMoY29sbGVjdGlvbiwgc2V0dGluZ3MpIHtcbiAgICBpZiAoc2V0dGluZ3MgPT0gbnVsbCkge1xuICAgICAgc2V0dGluZ3MgPSB7fTtcbiAgICB9XG4gICAgaWYgKCEodGhpcyBpbnN0YW5jZW9mIE1ldGVvci5QYWdpbmF0aW9uKSkge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIm1pc3NpbmctbmV3XCIsIFwiVGhlIE1ldGVvci5QYWdpbmF0aW9uIGluc3RhbmNlIGhhcyB0byBiZSBpbml0aWF0ZWQgd2l0aCBgbmV3YFwiKTtcbiAgICB9XG4gICAgdGhpcy5pbml0ID0gdGhpcy5iZWZvcmVGaXJzdFJlYWR5ID0gdHJ1ZTtcbiAgICBpZiAodGhpcy5kZWJ1ZyA9PSBudWxsKSB7XG4gICAgICB0aGlzLmRlYnVnID0gKCh0eXBlb2YgUEFHRVNfREVCVUcgIT09IFwidW5kZWZpbmVkXCIgJiYgUEFHRVNfREVCVUcgIT09IG51bGwpICYmIFBBR0VTX0RFQlVHKSB8fCAodHlwZW9mIHByb2Nlc3MgIT09IFwidW5kZWZpbmVkXCIgJiYgcHJvY2VzcyAhPT0gbnVsbCA/IHByb2Nlc3MuZW52LlBBR0VTX0RFQlVHIDogdm9pZCAwKTtcbiAgICB9XG4gICAgdGhpcy5zdWJzY3JpcHRpb25zID0ge1xuICAgICAgbGVuZ3RoOiAwLFxuICAgICAgb3JkZXI6IFtdXG4gICAgfTtcbiAgICB0aGlzLnVzZXJTZXR0aW5ncyA9IHt9O1xuICAgIHRoaXMuX2N1cnJlbnRQYWdlID0gMTtcbiAgICB0aGlzLnNldENvbGxlY3Rpb24oY29sbGVjdGlvbik7XG4gICAgdGhpcy5zZXRJbml0aWFsKHNldHRpbmdzKTtcbiAgICB0aGlzLnNldERlZmF1bHRzKCk7XG4gICAgdGhpcy5zZXRSb3V0ZXIoKTtcbiAgICB0aGlzWyhNZXRlb3IuaXNTZXJ2ZXIgPyBcInNlcnZlclwiIDogXCJjbGllbnRcIikgKyBcIkluaXRcIl0oKTtcbiAgICB0aGlzLnJlZ2lzdGVySW5zdGFuY2UoKTtcbiAgICB0aGlzO1xuICB9XG5cbiAgUGFnZXMucHJvdG90eXBlLmVycm9yID0gZnVuY3Rpb24oY29kZSwgbXNnKSB7XG4gICAgaWYgKGNvZGUgPT0gbnVsbCkge1xuICAgICAgbXNnID0gY29kZTtcbiAgICB9XG4gICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihjb2RlLCBtc2cpO1xuICB9O1xuXG4gIFBhZ2VzLnByb3RvdHlwZS5zZXJ2ZXJJbml0ID0gZnVuY3Rpb24oKSB7XG4gICAgdmFyIHNlbGY7XG4gICAgdGhpcy5zZXRNZXRob2RzKCk7XG4gICAgc2VsZiA9IHRoaXM7XG4gICAgTWV0ZW9yLm9uQ29ubmVjdGlvbigoZnVuY3Rpb24oX3RoaXMpIHtcbiAgICAgIHJldHVybiBmdW5jdGlvbihjb25uZWN0aW9uKSB7XG4gICAgICAgIHJldHVybiBjb25uZWN0aW9uLm9uQ2xvc2UoZnVuY3Rpb24oKSB7XG4gICAgICAgICAgcmV0dXJuIGRlbGV0ZSBfdGhpcy51c2VyU2V0dGluZ3NbY29ubmVjdGlvbi5pZF07XG4gICAgICAgIH0pO1xuICAgICAgfTtcbiAgICB9KSh0aGlzKSk7XG4gICAgcmV0dXJuIE1ldGVvci5wdWJsaXNoKHRoaXMuaWQsIGZ1bmN0aW9uKHBhZ2UpIHtcbiAgICAgIHJldHVybiBzZWxmLnB1Ymxpc2guY2FsbChzZWxmLCBwYWdlLCB0aGlzKTtcbiAgICB9KTtcbiAgfTtcblxuICBQYWdlcy5wcm90b3R5cGUuY2xpZW50SW5pdCA9IGZ1bmN0aW9uKCkge1xuICAgIHRoaXMucmVxdWVzdGVkID0ge307XG4gICAgdGhpcy5yZWNlaXZlZCA9IHt9O1xuICAgIHRoaXMucXVldWUgPSBbXTtcbiAgICB0aGlzLm5leHRQYWdlQ291bnQgPSB0aGlzLm5vdygpO1xuICAgIHRoaXMuZ3JvdW5kREIgPSBQYWNrYWdlW1wiZ3JvdW5kOmRiXCJdICE9IG51bGw7XG4gICAgaWYgKHRoaXMuaW5maW5pdGUpIHtcbiAgICAgIHRoaXMuc2VzcyhcImxpbWl0XCIsIDEwKTtcbiAgICAgIHRoaXMubGFzdE9mZnNldEhlaWdodCA9IDA7XG4gICAgfVxuICAgIGlmICh0aGlzLm1heFN1YnNjcmlwdGlvbnMgPCAxKSB7XG4gICAgICB0aGlzLm1heFN1YnNjcmlwdGlvbnMgPSAxO1xuICAgIH1cbiAgICB0aGlzLnNldFRlbXBsYXRlcygpO1xuICAgIFRyYWNrZXIuYXV0b3J1bigoZnVuY3Rpb24oX3RoaXMpIHtcbiAgICAgIHJldHVybiBmdW5jdGlvbigpIHtcbiAgICAgICAgTWV0ZW9yLnN0YXR1cygpO1xuICAgICAgICBpZiAodHlwZW9mIE1ldGVvci51c2VySWQgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgIE1ldGVvci51c2VySWQoKTtcbiAgICAgICAgfVxuICAgICAgICBfdGhpcy5jb3VudFBhZ2VzKCk7XG4gICAgICAgIHJldHVybiBfdGhpcy5yZWxvYWQoKTtcbiAgICAgIH07XG4gICAgfSkodGhpcykpO1xuICAgIGlmICh0aGlzLnRlbXBsYXRlTmFtZSA9PSBudWxsKSB7XG4gICAgICB0aGlzLnRlbXBsYXRlTmFtZSA9IHRoaXMubmFtZTtcbiAgICB9XG4gICAgcmV0dXJuIFRlbXBsYXRlW3RoaXMudGVtcGxhdGVOYW1lXS5vblJlbmRlcmVkKChmdW5jdGlvbihfdGhpcykge1xuICAgICAgcmV0dXJuIGZ1bmN0aW9uKCkge1xuICAgICAgICBpZiAoX3RoaXMuaW5maW5pdGUpIHtcbiAgICAgICAgICByZXR1cm4gX3RoaXMuc2V0SW5maW5pdGVUcmlnZ2VyKCk7XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgfSkodGhpcykpO1xuICB9O1xuXG4gIFBhZ2VzLnByb3RvdHlwZS5yZWxvYWQgPSBfLnRocm90dGxlKGZ1bmN0aW9uKCkge1xuICAgIHRoaXMudW5zdWJzY3JpYmUoKTtcbiAgICByZXR1cm4gdGhpcy5jb3VudFBhZ2VzKChmdW5jdGlvbihfdGhpcykge1xuICAgICAgcmV0dXJuIGZ1bmN0aW9uKHRvdGFsKSB7XG4gICAgICAgIHZhciBwO1xuICAgICAgICBwID0gX3RoaXMuY3VycmVudFBhZ2UoKTtcbiAgICAgICAgaWYgKChwID09IG51bGwpIHx8IF90aGlzLnJlc2V0T25SZWxvYWQgfHwgcCA+IHRvdGFsKSB7XG4gICAgICAgICAgcCA9IDE7XG4gICAgICAgIH1cbiAgICAgICAgX3RoaXMuc2VzcyhcImN1cnJlbnRQYWdlXCIsIGZhbHNlKTtcbiAgICAgICAgcmV0dXJuIF90aGlzLnNlc3MoXCJjdXJyZW50UGFnZVwiLCBwKTtcbiAgICAgIH07XG4gICAgfSkodGhpcykpO1xuICB9LCAxMDAwLCB7XG4gICAgdHJhaWxpbmc6IGZhbHNlXG4gIH0pO1xuXG4gIFBhZ2VzLnByb3RvdHlwZS51bnN1YnNjcmliZSA9IGZ1bmN0aW9uKHBhZ2UsIGNpZCkge1xuICAgIHZhciBrLCByZWYsIHJlZjEsIHN1YjtcbiAgICBpZiAodGhpcy5iZWZvcmVGaXJzdFJlYWR5KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChwYWdlID09IG51bGwpIHtcbiAgICAgIHJlZiA9IHRoaXMuc3Vic2NyaXB0aW9ucztcbiAgICAgIGZvciAoayBpbiByZWYpIHtcbiAgICAgICAgc3ViID0gcmVmW2tdO1xuICAgICAgICBpZiAoayA9PT0gXCJsZW5ndGhcIiB8fCBrID09PSBcIm9yZGVyXCIpIHtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBzdWIuc3RvcCgpO1xuICAgICAgICBkZWxldGUgdGhpcy5zdWJzY3JpcHRpb25zW2tdO1xuICAgICAgfVxuICAgICAgdGhpcy5zdWJzY3JpcHRpb25zLmxlbmd0aCA9IDA7XG4gICAgICB0aGlzLmluaXRQYWdlID0gbnVsbDtcbiAgICAgIHRoaXMucmVxdWVzdGVkID0ge307XG4gICAgICB0aGlzLnJlY2VpdmVkID0ge307XG4gICAgICB0aGlzLnF1ZXVlID0gW107XG4gICAgfSBlbHNlIGlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgICAgIGNoZWNrKGNpZCwgU3RyaW5nKTtcbiAgICAgIGlmICgocmVmMSA9IHRoaXMuc3Vic2NyaXB0aW9uc1tjaWRdKSAhPSBudWxsID8gcmVmMVtwYWdlXSA6IHZvaWQgMCkge1xuICAgICAgICB0aGlzLnN1YnNjcmlwdGlvbnNbY2lkXVtwYWdlXS5zdG9wKCk7XG4gICAgICAgIGRlbGV0ZSB0aGlzLnN1YnNjcmlwdGlvbnNbY2lkXVtwYWdlXTtcbiAgICAgICAgdGhpcy5zdWJzY3JpcHRpb25zLmxlbmd0aC0tO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAodGhpcy5zdWJzY3JpcHRpb25zW3BhZ2VdKSB7XG4gICAgICB0aGlzLnN1YnNjcmlwdGlvbnNbcGFnZV0uc3RvcCgpO1xuICAgICAgZGVsZXRlIHRoaXMuc3Vic2NyaXB0aW9uc1twYWdlXTtcbiAgICAgIGRlbGV0ZSB0aGlzLnJlcXVlc3RlZFtwYWdlXTtcbiAgICAgIGRlbGV0ZSB0aGlzLnJlY2VpdmVkW3BhZ2VdO1xuICAgICAgdGhpcy5zdWJzY3JpcHRpb25zLm9yZGVyID0gXy53aXRob3V0KHRoaXMuc3Vic2NyaXB0aW9ucy5vcmRlciwgTnVtYmVyKHBhZ2UpKTtcbiAgICAgIHRoaXMuc3Vic2NyaXB0aW9ucy5sZW5ndGgtLTtcbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG4gIH07XG5cbiAgUGFnZXMucHJvdG90eXBlLnNldERlZmF1bHRzID0gZnVuY3Rpb24oKSB7XG4gICAgdmFyIGssIHJlZiwgcmVzdWx0cywgdjtcbiAgICByZWYgPSB0aGlzLnNldHRpbmdzO1xuICAgIHJlc3VsdHMgPSBbXTtcbiAgICBmb3IgKGsgaW4gcmVmKSB7XG4gICAgICB2ID0gcmVmW2tdO1xuICAgICAgaWYgKHZbMl0gIT0gbnVsbCkge1xuICAgICAgICByZXN1bHRzLnB1c2godGhpc1trXSAhPSBudWxsID8gdGhpc1trXSA6IHRoaXNba10gPSB2WzJdKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJlc3VsdHMucHVzaCh2b2lkIDApO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0cztcbiAgfTtcblxuICBQYWdlcy5wcm90b3R5cGUuc3luY1NldHRpbmdzID0gZnVuY3Rpb24oY2IpIHtcbiAgICB2YXIgUywgaywgcmVmLCB2O1xuICAgIFMgPSB7fTtcbiAgICByZWYgPSB0aGlzLnNldHRpbmdzO1xuICAgIGZvciAoayBpbiByZWYpIHtcbiAgICAgIHYgPSByZWZba107XG4gICAgICBpZiAodlswXSkge1xuICAgICAgICBTW2tdID0gdGhpc1trXTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuc2V0KFMsIGNiICE9IG51bGwgPyB7XG4gICAgICBjYjogY2IuYmluZCh0aGlzKVxuICAgIH0gOiBudWxsKTtcbiAgfTtcblxuICBQYWdlcy5wcm90b3R5cGUuc2V0TWV0aG9kcyA9IGZ1bmN0aW9uKCkge1xuICAgIHZhciBmLCBuLCBubSwgcmVmLCBzZWxmO1xuICAgIG5tID0ge307XG4gICAgc2VsZiA9IHRoaXM7XG4gICAgcmVmID0gdGhpcy5tZXRob2RzO1xuICAgIGZvciAobiBpbiByZWYpIHtcbiAgICAgIGYgPSByZWZbbl07XG4gICAgICBubVt0aGlzLmdldE1ldGhvZE5hbWUobildID0gKGZ1bmN0aW9uKGYpIHtcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uKCkge1xuICAgICAgICAgIHZhciBhcmcsIGssIHIsIHY7XG4gICAgICAgICAgYXJnID0gKGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgdmFyIHJlc3VsdHM7XG4gICAgICAgICAgICByZXN1bHRzID0gW107XG4gICAgICAgICAgICBmb3IgKGsgaW4gYXJndW1lbnRzKSB7XG4gICAgICAgICAgICAgIHYgPSBhcmd1bWVudHNba107XG4gICAgICAgICAgICAgIHJlc3VsdHMucHVzaCh2KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiByZXN1bHRzO1xuICAgICAgICAgIH0pLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgICAgICAgYXJnLnB1c2godGhpcyk7XG4gICAgICAgICAgdGhpcy5nZXQgPSBfLmJpbmQoKGZ1bmN0aW9uKHNlbGYsIGspIHtcbiAgICAgICAgICAgIHJldHVybiBzZWxmLmdldChrLCB0aGlzLmNvbm5lY3Rpb24uaWQpO1xuICAgICAgICAgIH0pLCB0aGlzLCBzZWxmKTtcbiAgICAgICAgICByID0gZi5hcHBseShzZWxmLCBhcmcpO1xuICAgICAgICAgIHJldHVybiByO1xuICAgICAgICB9O1xuICAgICAgfSkoZik7XG4gICAgfVxuICAgIHJldHVybiBNZXRlb3IubWV0aG9kcyhubSk7XG4gIH07XG5cbiAgUGFnZXMucHJvdG90eXBlLmdldE1ldGhvZE5hbWUgPSBmdW5jdGlvbihuYW1lKSB7XG4gICAgcmV0dXJuIHRoaXMuaWQgKyBcIi9cIiArIG5hbWU7XG4gIH07XG5cbiAgUGFnZXMucHJvdG90eXBlLmNhbGwgPSBmdW5jdGlvbigpIHtcbiAgICB2YXIgYXJncywgbGFzdDtcbiAgICBhcmdzID0gMSA8PSBhcmd1bWVudHMubGVuZ3RoID8gc2xpY2UuY2FsbChhcmd1bWVudHMsIDApIDogW107XG4gICAgY2hlY2soYXJncywgQXJyYXkpO1xuICAgIGlmIChhcmdzLmxlbmd0aCA8IDEpIHtcbiAgICAgIHRoaXMuZXJyb3IoXCJtZXRob2QtbmFtZS1taXNzaW5nXCIsIFwiTWV0aG9kIG5hbWUgbm90IHByb3ZpZGVkIGluIGEgbWV0aG9kIGNhbGwuXCIpO1xuICAgIH1cbiAgICBhcmdzWzBdID0gdGhpcy5nZXRNZXRob2ROYW1lKGFyZ3NbMF0pO1xuICAgIGxhc3QgPSBhcmdzLmxlbmd0aCAtIDE7XG4gICAgaWYgKF8uaXNGdW5jdGlvbihhcmdzW2xhc3RdKSkge1xuICAgICAgYXJnc1tsYXN0XSA9IGFyZ3NbbGFzdF0uYmluZCh0aGlzKTtcbiAgICB9XG4gICAgcmV0dXJuIE1ldGVvci5jYWxsLmFwcGx5KHRoaXMsIGFyZ3MpO1xuICB9O1xuXG4gIFBhZ2VzLnByb3RvdHlwZS5zZXNzID0gZnVuY3Rpb24oaywgdikge1xuICAgIGlmICh0eXBlb2YgU2Vzc2lvbiA9PT0gXCJ1bmRlZmluZWRcIiB8fCBTZXNzaW9uID09PSBudWxsKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGsgPSB0aGlzLmlkICsgXCIuXCIgKyBrO1xuICAgIGlmIChhcmd1bWVudHMubGVuZ3RoID09PSAyKSB7XG4gICAgICByZXR1cm4gU2Vzc2lvbi5zZXQoaywgdik7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBTZXNzaW9uLmdldChrKTtcbiAgICB9XG4gIH07XG5cbiAgUGFnZXMucHJvdG90eXBlLmdldCA9IGZ1bmN0aW9uKHNldHRpbmcsIGNvbm5lY3Rpb25JZCkge1xuICAgIHZhciByZWYsIHJlZjE7XG4gICAgcmV0dXJuIChyZWYgPSAocmVmMSA9IHRoaXMudXNlclNldHRpbmdzW2Nvbm5lY3Rpb25JZF0pICE9IG51bGwgPyByZWYxW3NldHRpbmddIDogdm9pZCAwKSAhPSBudWxsID8gcmVmIDogdGhpc1tzZXR0aW5nXTtcbiAgfTtcblxuICBQYWdlcy5wcm90b3R5cGUuc2V0ID0gZnVuY3Rpb24oKSB7XG4gICAgdmFyIF9rLCBfdiwgY2gsIGssIG9wdHM7XG4gICAgayA9IGFyZ3VtZW50c1swXSwgb3B0cyA9IDIgPD0gYXJndW1lbnRzLmxlbmd0aCA/IHNsaWNlLmNhbGwoYXJndW1lbnRzLCAxKSA6IFtdO1xuICAgIGNoID0gMDtcbiAgICBzd2l0Y2ggKG9wdHMubGVuZ3RoKSB7XG4gICAgICBjYXNlIDA6XG4gICAgICAgIGlmIChfLmlzT2JqZWN0KGspKSB7XG4gICAgICAgICAgZm9yIChfayBpbiBrKSB7XG4gICAgICAgICAgICBfdiA9IGtbX2tdO1xuICAgICAgICAgICAgY2ggKz0gdGhpcy5fc2V0KF9rLCBfdik7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAxOlxuICAgICAgICBpZiAoXy5pc09iamVjdChrKSkge1xuICAgICAgICAgIGlmIChfLmlzRnVuY3Rpb24ob3B0c1swXSkpIHtcbiAgICAgICAgICAgIG9wdHNbMF0gPSB7XG4gICAgICAgICAgICAgIGNiOiBvcHRzWzBdXG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH1cbiAgICAgICAgICBmb3IgKF9rIGluIGspIHtcbiAgICAgICAgICAgIF92ID0ga1tfa107XG4gICAgICAgICAgICBjaCArPSB0aGlzLl9zZXQoX2ssIF92LCBvcHRzWzBdKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY2hlY2soaywgU3RyaW5nKTtcbiAgICAgICAgICBjaCA9IHRoaXMuX3NldChrLCBvcHRzWzBdKTtcbiAgICAgICAgfVxuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgMjpcbiAgICAgICAgaWYgKF8uaXNGdW5jdGlvbihvcHRzWzFdKSkge1xuICAgICAgICAgIG9wdHNbMV0gPSB7XG4gICAgICAgICAgICBjYjogb3B0c1sxXVxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgY2ggPSB0aGlzLl9zZXQoaywgb3B0c1swXSwgb3B0c1sxXSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAzOlxuICAgICAgICBjaGVjayhvcHRzWzFdLCBPYmplY3QpO1xuICAgICAgICBjaGVjayhvcHRzWzJdLCBGdW5jdGlvbik7XG4gICAgICAgIG9wdHNbMl0gPSB7XG4gICAgICAgICAgY2I6IG9wdHNbMl1cbiAgICAgICAgfTtcbiAgICAgICAgY2ggPSB0aGlzLl9zZXQoaywgb3B0c1sxXSwgb3B0c1syXSk7XG4gICAgfVxuICAgIGlmIChNZXRlb3IuaXNDbGllbnQgJiYgY2gpIHtcbiAgICAgIHRoaXMucmVsb2FkKCk7XG4gICAgfVxuICAgIHJldHVybiBjaDtcbiAgfTtcblxuICBQYWdlcy5wcm90b3R5cGUuc2V0SW5pdGlhbCA9IGZ1bmN0aW9uKHNldHRpbmdzKSB7XG4gICAgdGhpcy5zZXRJbml0RG9uZSA9IGZhbHNlO1xuICAgIHRoaXMuc2V0KHNldHRpbmdzKTtcbiAgICByZXR1cm4gdGhpcy5zZXRJbml0RG9uZSA9IHRydWU7XG4gIH07XG5cbiAgUGFnZXMucHJvdG90eXBlLnNhbml0aXplUmVnZXggPSBmdW5jdGlvbih2KSB7XG4gICAgdmFyIGxpcztcbiAgICBpZiAoXy5pc1JlZ0V4cCh2KSkge1xuICAgICAgdiA9IHYudG9TdHJpbmcoKTtcbiAgICAgIGxpcyA9IHYubGFzdEluZGV4T2YoXCIvXCIpO1xuICAgICAgdiA9IHtcbiAgICAgICAgJHJlZ2V4OiB2LnNsaWNlKDEsIGxpcyksXG4gICAgICAgICRvcHRpb25zOiB2LnNsaWNlKDEgKyBsaXMpXG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gdjtcbiAgfTtcblxuICBQYWdlcy5wcm90b3R5cGUuc2FuaXRpemVSZWdleE9iaiA9IGZ1bmN0aW9uKG9iaikge1xuICAgIHZhciBrLCB2O1xuICAgIGlmIChfLmlzUmVnRXhwKG9iaikpIHtcbiAgICAgIHJldHVybiB0aGlzLnNhbml0aXplUmVnZXgob2JqKTtcbiAgICB9XG4gICAgZm9yIChrIGluIG9iaikge1xuICAgICAgdiA9IG9ialtrXTtcbiAgICAgIGlmIChfLmlzUmVnRXhwKHYpKSB7XG4gICAgICAgIG9ialtrXSA9IHRoaXMuc2FuaXRpemVSZWdleCh2KTtcbiAgICAgIH0gZWxzZSBpZiAoXCJvYmplY3RcIiA9PT0gdHlwZW9mIHYpIHtcbiAgICAgICAgb2JqW2tdID0gdGhpcy5zYW5pdGl6ZVJlZ2V4T2JqKHYpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gb2JqO1xuICB9O1xuXG4gIFBhZ2VzLnByb3RvdHlwZS5fc2V0ID0gZnVuY3Rpb24oaywgdiwgb3B0cykge1xuICAgIHZhciBiYXNlLCBjaCwgbmFtZTEsIG9sZFYsIHJlZiwgcmVmMSwgcmVmMjtcbiAgICBpZiAob3B0cyA9PSBudWxsKSB7XG4gICAgICBvcHRzID0ge307XG4gICAgfVxuICAgIGNoZWNrKGssIFN0cmluZyk7XG4gICAgY2ggPSAxO1xuICAgIGlmIChNZXRlb3IuaXNTZXJ2ZXIgfHwgKHRoaXNba10gPT0gbnVsbCkgfHwgKChyZWYgPSB0aGlzLnNldHRpbmdzW2tdKSAhPSBudWxsID8gcmVmWzBdIDogdm9pZCAwKSB8fCBvcHRzLmluaXQpIHtcbiAgICAgIGlmICgoKChyZWYxID0gdGhpcy5zZXR0aW5nc1trXSkgIT0gbnVsbCA/IHJlZjFbMV0gOiB2b2lkIDApICE9IG51bGwpICYmICgocmVmMiA9IHRoaXMuc2V0dGluZ3Nba10pICE9IG51bGwgPyByZWYyWzFdIDogdm9pZCAwKSAhPT0gdHJ1ZSkge1xuICAgICAgICBjaGVjayh2LCB0aGlzLnNldHRpbmdzW2tdWzFdKTtcbiAgICAgIH1cbiAgICAgIHRoaXMuc2FuaXRpemVSZWdleE9iaih2KTtcbiAgICAgIG9sZFYgPSB0aGlzLmdldChrLCBvcHRzICE9IG51bGwgPyBvcHRzLmNpZCA6IHZvaWQgMCk7XG4gICAgICBpZiAodGhpcy52YWx1ZXNFcXVhbCh2LCBvbGRWKSkge1xuICAgICAgICByZXR1cm4gMDtcbiAgICAgIH1cbiAgICAgIGlmIChNZXRlb3IuaXNDbGllbnQpIHtcbiAgICAgICAgdGhpc1trXSA9IHY7XG4gICAgICAgIGlmICh0aGlzLnNldEluaXREb25lKSB7XG4gICAgICAgICAgdGhpcy5jYWxsKFwiU2V0XCIsIGssIHYsIGZ1bmN0aW9uKGUsIHIpIHtcbiAgICAgICAgICAgIGlmIChlKSB7XG4gICAgICAgICAgICAgIHRoaXNba10gPSBvbGRWO1xuICAgICAgICAgICAgICByZXR1cm4gdGhpcy5vbkRlbmllZFNldHRpbmcuY2FsbCh0aGlzLCBrLCB2LCBlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB0eXBlb2Ygb3B0cy5jYiA9PT0gXCJmdW5jdGlvblwiID8gb3B0cy5jYihjaCkgOiB2b2lkIDA7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlmIChvcHRzLmNpZCkge1xuICAgICAgICAgIGlmIChjaCAhPSBudWxsKSB7XG4gICAgICAgICAgICBpZiAoKGJhc2UgPSB0aGlzLnVzZXJTZXR0aW5ncylbbmFtZTEgPSBvcHRzLmNpZF0gPT0gbnVsbCkge1xuICAgICAgICAgICAgICBiYXNlW25hbWUxXSA9IHt9O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy51c2VyU2V0dGluZ3Nbb3B0cy5jaWRdW2tdID0gdjtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGhpc1trXSA9IHY7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHR5cGVvZiBvcHRzLmNiID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgICBvcHRzLmNiKGNoKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLm9uRGVuaWVkU2V0dGluZy5jYWxsKHRoaXMsIGssIHYpO1xuICAgIH1cbiAgICByZXR1cm4gY2g7XG4gIH07XG5cbiAgUGFnZXMucHJvdG90eXBlLnZhbHVlc0VxdWFsID0gZnVuY3Rpb24odjEsIHYyKSB7XG4gICAgaWYgKF8uaXNGdW5jdGlvbih2MSkpIHtcbiAgICAgIHJldHVybiBfLmlzRnVuY3Rpb24odjIpICYmIHYxLnRvU3RyaW5nKCkgPT09IHYyLnRvU3RyaW5nKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBfLmlzRXF1YWwodjEsIHYyKTtcbiAgICB9XG4gIH07XG5cbiAgUGFnZXMucHJvdG90eXBlLnNldElkID0gZnVuY3Rpb24obmFtZSkge1xuICAgIHZhciBuO1xuICAgIGlmICh0aGlzLnRlbXBsYXRlTmFtZSkge1xuICAgICAgbmFtZSA9IHRoaXMudGVtcGxhdGVOYW1lO1xuICAgIH1cbiAgICB3aGlsZSAobmFtZSBpbiBQYWdlcy5wcm90b3R5cGUuaW5zdGFuY2VzKSB7XG4gICAgICBuID0gbmFtZS5tYXRjaCgvWzAtOV0rJC8pO1xuICAgICAgaWYgKG4gIT0gbnVsbCkge1xuICAgICAgICBuYW1lID0gbmFtZS5zbGljZSgwLCBuYW1lLmxlbmd0aCAtIG5bMF0ubGVuZ3RoKSArIChwYXJzZUludChuKSArIDEpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbmFtZSA9IG5hbWUgKyBcIjJcIjtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhpcy5pZCA9IFwicGFnZXNfXCIgKyBuYW1lO1xuICAgIHJldHVybiB0aGlzLm5hbWUgPSBuYW1lO1xuICB9O1xuXG4gIFBhZ2VzLnByb3RvdHlwZS5yZWdpc3Rlckluc3RhbmNlID0gZnVuY3Rpb24oKSB7XG4gICAgUGFnZXMucHJvdG90eXBlLl9uSW5zdGFuY2VzKys7XG4gICAgcmV0dXJuIFBhZ2VzLnByb3RvdHlwZS5pbnN0YW5jZXNbdGhpcy5uYW1lXSA9IHRoaXM7XG4gIH07XG5cbiAgUGFnZXMucHJvdG90eXBlLnNldENvbGxlY3Rpb24gPSBmdW5jdGlvbihjb2xsZWN0aW9uKSB7XG4gICAgdmFyIGU7XG4gICAgaWYgKHR5cGVvZiBjb2xsZWN0aW9uID09PSBcIm9iamVjdFwiKSB7XG4gICAgICBQYWdlcy5wcm90b3R5cGUuY29sbGVjdGlvbnNbY29sbGVjdGlvbi5fbmFtZV0gPSBjb2xsZWN0aW9uO1xuICAgICAgdGhpcy5Db2xsZWN0aW9uID0gY29sbGVjdGlvbjtcbiAgICB9IGVsc2Uge1xuICAgICAgdHJ5IHtcbiAgICAgICAgdGhpcy5Db2xsZWN0aW9uID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oY29sbGVjdGlvbik7XG4gICAgICAgIFBhZ2VzLnByb3RvdHlwZS5jb2xsZWN0aW9uc1tjb2xsZWN0aW9uXSA9IHRoaXMuQ29sbGVjdGlvbjtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGUgPSBlcnJvcjtcbiAgICAgICAgdGhpcy5Db2xsZWN0aW9uID0gUGFnZXMucHJvdG90eXBlLmNvbGxlY3Rpb25zW2NvbGxlY3Rpb25dO1xuICAgICAgICB0aGlzLkNvbGxlY3Rpb24gaW5zdGFuY2VvZiBNb25nby5Db2xsZWN0aW9uIHx8IHRoaXMuZXJyb3IoXCJjb2xsZWN0aW9uLWluYWNjZXNzaWJsZVwiLCBcIlRoZSAnXCIgKyBjb2xsZWN0aW9uICsgXCInIGNvbGxlY3Rpb24gd2FzIGNyZWF0ZWQgb3V0c2lkZSBvZiA8TWV0ZW9yLlBhZ2luYXRpb24+LiBQYXNzIHRoZSBjb2xsZWN0aW9uIG9iamVjdCBpbnN0ZWFkIG9mIHRoZSBjb2xsZWN0aW9uJ3MgbmFtZSB0byB0aGUgPE1ldGVvci5QYWdpbmF0aW9uPiBjb25zdHJ1Y3Rvci5cIik7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0aGlzLnNldElkKHRoaXMuQ29sbGVjdGlvbi5fbmFtZSk7XG4gIH07XG5cbiAgUGFnZXMucHJvdG90eXBlLmxpbmtUbyA9IGZ1bmN0aW9uKHBhZ2UpIHtcbiAgICB2YXIgcGFyYW1zLCByZWY7XG4gICAgaWYgKChyZWYgPSBSb3V0ZXIuY3VycmVudCgpKSAhPSBudWxsID8gcmVmLnBhcmFtcyA6IHZvaWQgMCkge1xuICAgICAgcGFyYW1zID0gUm91dGVyLmN1cnJlbnQoKS5wYXJhbXM7XG4gICAgICBwYXJhbXMucGFnZSA9IHBhZ2U7XG4gICAgICByZXR1cm4gUm91dGVyLnJvdXRlc1t0aGlzLm5hbWUgKyBcIl9wYWdlXCJdLnBhdGgocGFyYW1zKTtcbiAgICB9XG4gIH07XG5cbiAgUGFnZXMucHJvdG90eXBlLnNldFJvdXRlciA9IGZ1bmN0aW9uKCkge1xuICAgIHZhciBpbml0LCBsLCBwciwgcmVmLCBzZWxmLCB0O1xuICAgIGlmICh0aGlzLnJvdXRlciA9PT0gXCJpcm9uLXJvdXRlclwiKSB7XG4gICAgICBpZiAodGhpcy5yb3V0ZS5pbmRleE9mKFwiOnBhZ2VcIikgPT09IC0xKSB7XG4gICAgICAgIGlmICh0aGlzLnJvdXRlWzBdICE9PSBcIi9cIikge1xuICAgICAgICAgIHRoaXMucm91dGUgPSBcIi9cIiArIHRoaXMucm91dGU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMucm91dGVbdGhpcy5yb3V0ZS5sZW5ndGggLSAxXSAhPT0gXCIvXCIpIHtcbiAgICAgICAgICB0aGlzLnJvdXRlICs9IFwiL1wiO1xuICAgICAgICB9XG4gICAgICAgIHByID0gdGhpcy5yb3V0ZSA9IHRoaXMucm91dGUgKyBcIjpwYWdlXCI7XG4gICAgICB9XG4gICAgICB0ID0gdGhpcy5yb3V0ZXJUZW1wbGF0ZTtcbiAgICAgIGwgPSAocmVmID0gdGhpcy5yb3V0ZXJMYXlvdXQpICE9IG51bGwgPyByZWYgOiB2b2lkIDA7XG4gICAgICBzZWxmID0gdGhpcztcbiAgICAgIGluaXQgPSB0cnVlO1xuICAgICAgUm91dGVyLm1hcChmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIGhyLCBqLCBrLCBsZW4sIHJlZjEsIHJlc3VsdHM7XG4gICAgICAgIGlmICghc2VsZi5pbmZpbml0ZSkge1xuICAgICAgICAgIHRoaXMucm91dGUoc2VsZi5uYW1lICsgXCJfcGFnZVwiLCB7XG4gICAgICAgICAgICBwYXRoOiBwcixcbiAgICAgICAgICAgIHRlbXBsYXRlOiB0LFxuICAgICAgICAgICAgbGF5b3V0VGVtcGxhdGU6IGwsXG4gICAgICAgICAgICBvbkJlZm9yZUFjdGlvbjogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgIHZhciBwYWdlO1xuICAgICAgICAgICAgICBwYWdlID0gcGFyc2VJbnQodGhpcy5wYXJhbXMucGFnZSk7XG4gICAgICAgICAgICAgIGlmIChzZWxmLmluaXQpIHtcbiAgICAgICAgICAgICAgICBzZWxmLnNlc3MoXCJvbGRQYWdlXCIsIHBhZ2UpO1xuICAgICAgICAgICAgICAgIHNlbGYuc2VzcyhcImN1cnJlbnRQYWdlXCIsIHBhZ2UpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGlmIChzZWxmLnJvdXRlU2V0dGluZ3MgIT0gbnVsbCkge1xuICAgICAgICAgICAgICAgIHNlbGYucm91dGVTZXR0aW5ncyh0aGlzKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBUcmFja2VyLm5vbnJlYWN0aXZlKChmdW5jdGlvbihfdGhpcykge1xuICAgICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBzZWxmLm9uTmF2Q2xpY2socGFnZSk7XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgfSkodGhpcykpO1xuICAgICAgICAgICAgICByZXR1cm4gdGhpcy5uZXh0KCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHNlbGYuaG9tZVJvdXRlKSB7XG4gICAgICAgICAgaWYgKF8uaXNTdHJpbmcoc2VsZi5ob21lUm91dGUpKSB7XG4gICAgICAgICAgICBzZWxmLmhvbWVSb3V0ZSA9IFtzZWxmLmhvbWVSb3V0ZV07XG4gICAgICAgICAgfVxuICAgICAgICAgIHJlZjEgPSBzZWxmLmhvbWVSb3V0ZTtcbiAgICAgICAgICByZXN1bHRzID0gW107XG4gICAgICAgICAgZm9yIChrID0gaiA9IDAsIGxlbiA9IHJlZjEubGVuZ3RoOyBqIDwgbGVuOyBrID0gKytqKSB7XG4gICAgICAgICAgICBociA9IHJlZjFba107XG4gICAgICAgICAgICByZXN1bHRzLnB1c2godGhpcy5yb3V0ZShzZWxmLm5hbWUgKyBcIl9ob21lXCIgKyBrLCB7XG4gICAgICAgICAgICAgIHBhdGg6IGhyLFxuICAgICAgICAgICAgICB0ZW1wbGF0ZTogdCxcbiAgICAgICAgICAgICAgbGF5b3V0VGVtcGxhdGU6IGwsXG4gICAgICAgICAgICAgIG9uQmVmb3JlQWN0aW9uOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICBpZiAoc2VsZi5yb3V0ZVNldHRpbmdzICE9IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgIHNlbGYucm91dGVTZXR0aW5ncyh0aGlzKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHNlbGYuaW5pdCkge1xuICAgICAgICAgICAgICAgICAgc2VsZi5zZXNzKFwib2xkUGFnZVwiLCAxKTtcbiAgICAgICAgICAgICAgICAgIHNlbGYuc2VzcyhcImN1cnJlbnRQYWdlXCIsIDEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5uZXh0KCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHJlc3VsdHM7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgaWYgKE1ldGVvci5pc1NlcnZlciAmJiB0aGlzLmZhc3RSZW5kZXIpIHtcbiAgICAgICAgc2VsZiA9IHRoaXM7XG4gICAgICAgIEZhc3RSZW5kZXIucm91dGUocHIsIGZ1bmN0aW9uKHBhcmFtcykge1xuICAgICAgICAgIHJldHVybiB0aGlzLnN1YnNjcmliZShzZWxmLmlkLCBwYXJzZUludChwYXJhbXMucGFnZSkpO1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIEZhc3RSZW5kZXIucm91dGUodGhpcy5ob21lUm91dGUsIGZ1bmN0aW9uKCkge1xuICAgICAgICAgIHJldHVybiB0aGlzLnN1YnNjcmliZShzZWxmLmlkLCAxKTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIFBhZ2VzLnByb3RvdHlwZS5pc0VtcHR5ID0gZnVuY3Rpb24oKSB7XG4gICAgcmV0dXJuIHRoaXMuaXNSZWFkeSgpICYmIHRoaXMuQ29sbGVjdGlvbi5maW5kKF8ub2JqZWN0KFtbXCJfXCIgKyB0aGlzLmlkICsgXCJfaVwiLCAwXV0pKS5jb3VudCgpID09PSAwO1xuICB9O1xuXG4gIFBhZ2VzLnByb3RvdHlwZS5zZXRQZXJQYWdlID0gZnVuY3Rpb24oKSB7XG4gICAgcmV0dXJuIHRoaXMucGVyUGFnZSA9IHRoaXMucGFnZVNpemVMaW1pdCA8IHRoaXMucGVyUGFnZSA/IHRoaXMucGFnZVNpemVMaW1pdCA6IHRoaXMucGVyUGFnZTtcbiAgfTtcblxuICBQYWdlcy5wcm90b3R5cGUuc2V0VGVtcGxhdGVzID0gZnVuY3Rpb24oKSB7XG4gICAgdmFyIGhlbHBlcnMsIGksIGosIGxlbiwgbmFtZSwgcmVmLCB0bjtcbiAgICBuYW1lID0gdGhpcy50ZW1wbGF0ZU5hbWUgfHwgdGhpcy5uYW1lO1xuICAgIGlmICh0aGlzLnRhYmxlICYmIHRoaXMuaXRlbVRlbXBsYXRlID09PSBcIl9wYWdlc0l0ZW1EZWZhdWx0XCIpIHtcbiAgICAgIHRoaXMuaXRlbVRlbXBsYXRlID0gdGhpcy50YWJsZUl0ZW1UZW1wbGF0ZTtcbiAgICB9XG4gICAgcmVmID0gW3RoaXMubmF2VGVtcGxhdGUsIHRoaXMucGFnZVRlbXBsYXRlLCB0aGlzLml0ZW1UZW1wbGF0ZSwgdGhpcy50YWJsZVRlbXBsYXRlXTtcbiAgICBmb3IgKGogPSAwLCBsZW4gPSByZWYubGVuZ3RoOyBqIDwgbGVuOyBqKyspIHtcbiAgICAgIGkgPSByZWZbal07XG4gICAgICB0biA9IHRoaXMuaWQgKyBpO1xuICAgICAgVGVtcGxhdGVbdG5dID0gbmV3IEJsYXplLlRlbXBsYXRlKFwiVGVtcGxhdGUuXCIgKyB0biwgVGVtcGxhdGVbaV0ucmVuZGVyRnVuY3Rpb24pO1xuICAgICAgVGVtcGxhdGVbdG5dLl9fZXZlbnRNYXBzID0gVGVtcGxhdGVbdG5dLl9fZXZlbnRNYXBzLmNvbmNhdChUZW1wbGF0ZVtpXS5fX2V2ZW50TWFwcyk7XG4gICAgICBoZWxwZXJzID0ge1xuICAgICAgICBwYWdlc0RhdGE6IHRoaXNcbiAgICAgIH07XG4gICAgICBfLmVhY2goVGVtcGxhdGVbaV0uX19oZWxwZXJzLCAoZnVuY3Rpb24oX3RoaXMpIHtcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uKGhlbHBlciwgbmFtZSkge1xuICAgICAgICAgIGlmIChuYW1lWzBdID09PSBcIiBcIikge1xuICAgICAgICAgICAgcmV0dXJuIGhlbHBlcnNbbmFtZS5zbGljZSgxKV0gPSBfLmJpbmQoaGVscGVyLCBfdGhpcyk7XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgfSkodGhpcykpO1xuICAgICAgVGVtcGxhdGVbdG5dLmhlbHBlcnMoaGVscGVycyk7XG4gICAgfVxuICAgIHJldHVybiBUZW1wbGF0ZVtuYW1lXS5oZWxwZXJzKHtcbiAgICAgIHBhZ2VzRGF0YTogdGhpcyxcbiAgICAgIHBhZ2VzTmF2OiBUZW1wbGF0ZVt0aGlzLmlkICsgdGhpcy5uYXZUZW1wbGF0ZV0sXG4gICAgICBwYWdlczogVGVtcGxhdGVbdGhpcy5pZCArIHRoaXMucGFnZVRlbXBsYXRlXVxuICAgIH0pO1xuICB9O1xuXG4gIFBhZ2VzLnByb3RvdHlwZS5jb3VudFBhZ2VzID0gXy50aHJvdHRsZShmdW5jdGlvbihjYikge1xuICAgIHZhciBuLCByZWY7XG4gICAgaWYgKCFNZXRlb3Iuc3RhdHVzKCkuY29ubmVjdGVkICYmIChQYWNrYWdlW1wiZ3JvdW5kOmRiXCJdICE9IG51bGwpKSB7XG4gICAgICBuID0gKChyZWYgPSB0aGlzLkNvbGxlY3Rpb24uZmluZE9uZSh7fSwge1xuICAgICAgICBzb3J0OiBfLm9iamVjdChbW1wiX1wiICsgdGhpcy5pZCArIFwiX3BcIiwgLTFdXSlcbiAgICAgIH0pKSAhPSBudWxsID8gcmVmW1wiX1wiICsgdGhpcy5pZCArIFwiX3BcIl0gOiB2b2lkIDApIHx8IDA7XG4gICAgICB0aGlzLnNldFRvdGFsUGFnZXMobik7XG4gICAgICByZXR1cm4gdHlwZW9mIGNiID09PSBcImZ1bmN0aW9uXCIgPyBjYihuKSA6IHZvaWQgMDtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIHRoaXMuY2FsbChcIkNvdW50UGFnZXNcIiwgKGZ1bmN0aW9uKF90aGlzKSB7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbihlLCByKSB7XG4gICAgICAgICAgdmFyIG5vdztcbiAgICAgICAgICBpZiAoZSAhPSBudWxsKSB7XG4gICAgICAgICAgICB0aHJvdyBlO1xuICAgICAgICAgIH1cbiAgICAgICAgICBfdGhpcy5zZXRUb3RhbFBhZ2VzKHIpO1xuICAgICAgICAgIG5vdyA9IF90aGlzLm5vdygpO1xuICAgICAgICAgIGlmIChfdGhpcy5uZXh0UGFnZUNvdW50IDwgbm93KSB7XG4gICAgICAgICAgICBfdGhpcy5uZXh0UGFnZUNvdW50ID0gbm93ICsgX3RoaXMucGFnZUNvdW50RnJlcXVlbmN5O1xuICAgICAgICAgICAgc2V0VGltZW91dChfLmJpbmQoX3RoaXMuY291bnRQYWdlcywgX3RoaXMpLCBfdGhpcy5wYWdlQ291bnRGcmVxdWVuY3kpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gdHlwZW9mIGNiID09PSBcImZ1bmN0aW9uXCIgPyBjYihyKSA6IHZvaWQgMDtcbiAgICAgICAgfTtcbiAgICAgIH0pKHRoaXMpKTtcbiAgICB9XG4gIH0sIDEwMDApO1xuXG4gIFBhZ2VzLnByb3RvdHlwZS5zZXRUb3RhbFBhZ2VzID0gZnVuY3Rpb24obikge1xuICAgIHRoaXMuc2VzcyhcInRvdGFsUGFnZXNcIiwgbik7XG4gICAgaWYgKHRoaXMuc2VzcyhcImN1cnJlbnRQYWdlXCIpID4gbikge1xuICAgICAgcmV0dXJuIHRoaXMuc2VzcyhcImN1cnJlbnRQYWdlXCIsIDEpO1xuICAgIH1cbiAgfTtcblxuICBQYWdlcy5wcm90b3R5cGUuZW5mb3JjZVN1YnNjcmlwdGlvbkxpbWl0ID0gZnVuY3Rpb24oY2lkKSB7XG4gICAgdmFyIHJlZjtcbiAgICBpZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gICAgICBjaGVjayhjaWQsIFN0cmluZyk7XG4gICAgICBpZiAoKChyZWYgPSB0aGlzLnN1YnNjcmlwdGlvbnNbY2lkXSkgIT0gbnVsbCA/IHJlZi5sZW5ndGggOiB2b2lkIDApID49IHRoaXMubWF4U3Vic2NyaXB0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5lcnJvcihcInN1YnNjcmlwdGlvbi1saW1pdC1yZWFjaGVkXCIsIFwiU3Vic2NyaXB0aW9uIGxpbWl0IHJlYWNoZWQuIFVuYWJsZSB0byBvcGVuIGEgbmV3IHN1YnNjcmlwdGlvbi5cIik7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHdoaWxlICh0aGlzLnN1YnNjcmlwdGlvbnMubGVuZ3RoID49IHRoaXMubWF4U3Vic2NyaXB0aW9ucykge1xuICAgICAgICB0aGlzLnVuc3Vic2NyaWJlKHRoaXMuc3Vic2NyaXB0aW9ucy5vcmRlclswXSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gIH07XG5cbiAgUGFnZXMucHJvdG90eXBlLnB1Ymxpc2ggPSBmdW5jdGlvbihwYWdlLCBzdWIpIHtcbiAgICB2YXIgYmFzZSwgYywgY2lkLCBnZXQsIGhhbmRsZSwgaGFuZGxlMiwgaW5pdCwgbiwgbmFtZTEsIHF1ZXJ5LCBzZWxmLCBzZXQ7XG4gICAgY2hlY2socGFnZSwgTnVtYmVyKTtcbiAgICBjaGVjayhzdWIsIE1hdGNoLldoZXJlKGZ1bmN0aW9uKHMpIHtcbiAgICAgIHJldHVybiBzLnJlYWR5ICE9IG51bGw7XG4gICAgfSkpO1xuICAgIGNpZCA9IHN1Yi5jb25uZWN0aW9uLmlkO1xuICAgIGluaXQgPSB0cnVlO1xuICAgIGlmICgoYmFzZSA9IHRoaXMuc3Vic2NyaXB0aW9ucylbbmFtZTEgPSBzdWIuY29ubmVjdGlvbi5pZF0gPT0gbnVsbCkge1xuICAgICAgYmFzZVtuYW1lMV0gPSB7XG4gICAgICAgIGxlbmd0aDogMFxuICAgICAgfTtcbiAgICB9XG4gICAgdGhpcy5lbmZvcmNlU3Vic2NyaXB0aW9uTGltaXQoY2lkKTtcbiAgICBnZXQgPSBzdWIuZ2V0ID0gXy5iaW5kKChmdW5jdGlvbihjaWQsIGspIHtcbiAgICAgIHJldHVybiB0aGlzLmdldChrLCBjaWQpO1xuICAgIH0pLCB0aGlzLCBjaWQpO1xuICAgIHNldCA9IHN1Yi5zZXQgPSBfLmJpbmQoKGZ1bmN0aW9uKGNpZCwgaywgdikge1xuICAgICAgcmV0dXJuIHRoaXMuc2V0KGssIHYsIHtcbiAgICAgICAgY2lkOiBjaWRcbiAgICAgIH0pO1xuICAgIH0pLCB0aGlzLCBjaWQpO1xuICAgIHF1ZXJ5ID0gXy5iaW5kKChmdW5jdGlvbihzdWIsIGdldCwgc2V0KSB7XG4gICAgICB2YXIgYywgZmlsdGVycywgb3B0aW9ucywgciwgcmVmLCByZWYxLCBza2lwO1xuICAgICAgaWYgKChyZWYgPSB0aGlzLnVzZXJTZXR0aW5nc1tjaWRdKSAhPSBudWxsKSB7XG4gICAgICAgIGRlbGV0ZSByZWYucmVhbEZpbHRlcnM7XG4gICAgICB9XG4gICAgICBpZiAoKHJlZjEgPSB0aGlzLnVzZXJTZXR0aW5nc1tjaWRdKSAhPSBudWxsKSB7XG4gICAgICAgIGRlbGV0ZSByZWYxLm5QdWJsaXNoZWRQYWdlcztcbiAgICAgIH1cbiAgICAgIHRoaXMuc2V0UGVyUGFnZSgpO1xuICAgICAgc2tpcCA9IChwYWdlIC0gMSkgKiBnZXQoXCJwZXJQYWdlXCIpO1xuICAgICAgaWYgKHNraXAgPCAwKSB7XG4gICAgICAgIHNraXAgPSAwO1xuICAgICAgfVxuICAgICAgZmlsdGVycyA9IGdldChcImZpbHRlcnNcIik7XG4gICAgICBvcHRpb25zID0ge1xuICAgICAgICBzb3J0OiBnZXQoXCJzb3J0XCIpLFxuICAgICAgICBmaWVsZHM6IGdldChcImZpZWxkc1wiKSxcbiAgICAgICAgc2tpcDogc2tpcCxcbiAgICAgICAgbGltaXQ6IGdldChcInBlclBhZ2VcIilcbiAgICAgIH07XG4gICAgICBpZiAodGhpcy5hdXRoICE9IG51bGwpIHtcbiAgICAgICAgciA9IHRoaXMuYXV0aC5jYWxsKHRoaXMsIHNraXAsIHN1Yik7XG4gICAgICAgIGlmICghcikge1xuICAgICAgICAgIHNldChcIm5QdWJsaXNoZWRQYWdlc1wiLCAwKTtcbiAgICAgICAgICBzdWIucmVhZHkoKTtcbiAgICAgICAgICByZXR1cm4gdGhpcy5yZWFkeSgpO1xuICAgICAgICB9IGVsc2UgaWYgKF8uaXNOdW1iZXIocikpIHtcbiAgICAgICAgICBzZXQoXCJuUHVibGlzaGVkUGFnZXNcIiwgcik7XG4gICAgICAgICAgaWYgKHBhZ2UgPiByKSB7XG4gICAgICAgICAgICBzdWIucmVhZHkoKTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnJlYWR5KCk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKF8uaXNBcnJheShyKSAmJiByLmxlbmd0aCA9PT0gMikge1xuICAgICAgICAgIGlmIChfLmlzRnVuY3Rpb24oclswXS5mZXRjaCkpIHtcbiAgICAgICAgICAgIGMgPSByO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBmaWx0ZXJzID0gclswXTtcbiAgICAgICAgICAgIG9wdGlvbnMgPSByWzFdO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIGlmIChfLmlzRnVuY3Rpb24oci5mZXRjaCkpIHtcbiAgICAgICAgICBjID0gcjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKCFFSlNPTi5lcXVhbHMoe30sIGZpbHRlcnMpICYmICFFSlNPTi5lcXVhbHMoZ2V0KFwiZmlsdGVyc1wiKSwgZmlsdGVycykpIHtcbiAgICAgICAgc2V0KFwicmVhbEZpbHRlcnNcIiwgZmlsdGVycyk7XG4gICAgICB9XG4gICAgICByZXR1cm4gYyB8fCB0aGlzLkNvbGxlY3Rpb24uZmluZChmaWx0ZXJzLCBvcHRpb25zKTtcbiAgICB9KSwgdGhpcywgc3ViLCBnZXQsIHNldCk7XG4gICAgYyA9IHF1ZXJ5KCk7XG4gICAgc2VsZiA9IHRoaXM7XG4gICAgaGFuZGxlID0gYy5vYnNlcnZlKHtcbiAgICAgIGFkZGVkQXQ6IF8uYmluZCgoZnVuY3Rpb24oc3ViLCBxdWVyeSwgZG9jLCBhdCkge1xuICAgICAgICB2YXIgaWQ7XG4gICAgICAgIGlmIChpbml0KSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGRvY1tcIl9cIiArIHRoaXMuaWQgKyBcIl9wXCJdID0gcGFnZTtcbiAgICAgICAgZG9jW1wiX1wiICsgdGhpcy5pZCArIFwiX2lcIl0gPSBhdDtcbiAgICAgICAgaWQgPSBkb2MuX2lkO1xuICAgICAgICBkZWxldGUgZG9jLl9pZDtcbiAgICAgICAgcmV0dXJuIHF1ZXJ5KCkuZm9yRWFjaCgoZnVuY3Rpb24oX3RoaXMpIHtcbiAgICAgICAgICByZXR1cm4gZnVuY3Rpb24obywgaSkge1xuICAgICAgICAgICAgaWYgKGkgPT09IGF0KSB7XG4gICAgICAgICAgICAgIHJldHVybiBzdWIuYWRkZWQoX3RoaXMuQ29sbGVjdGlvbi5fbmFtZSwgaWQsIGRvYyk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICByZXR1cm4gc3ViLmNoYW5nZWQoX3RoaXMuQ29sbGVjdGlvbi5fbmFtZSwgby5faWQsIF8ub2JqZWN0KFtbXCJfXCIgKyBfdGhpcy5pZCArIFwiX2lcIiwgaV1dKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfTtcbiAgICAgICAgfSkodGhpcykpO1xuICAgICAgfSksIHRoaXMsIHN1YiwgcXVlcnkpXG4gICAgfSk7XG4gICAgaGFuZGxlMiA9IGMub2JzZXJ2ZUNoYW5nZXMoe1xuICAgICAgbW92ZWRCZWZvcmU6IF8uYmluZCgoZnVuY3Rpb24oc3ViLCBxdWVyeSwgaWQsIGJlZm9yZSkge1xuICAgICAgICByZXR1cm4gcXVlcnkoKS5mb3JFYWNoKChmdW5jdGlvbihfdGhpcykge1xuICAgICAgICAgIHJldHVybiBmdW5jdGlvbihvLCBpKSB7XG4gICAgICAgICAgICByZXR1cm4gc3ViLmNoYW5nZWQoX3RoaXMuQ29sbGVjdGlvbi5fbmFtZSwgby5faWQsIF8ub2JqZWN0KFtbXCJfXCIgKyBfdGhpcy5pZCArIFwiX2lcIiwgaV1dKSk7XG4gICAgICAgICAgfTtcbiAgICAgICAgfSkodGhpcykpO1xuICAgICAgfSksIHRoaXMsIHN1YiwgcXVlcnkpLFxuICAgICAgY2hhbmdlZDogXy5iaW5kKChmdW5jdGlvbihzdWIsIHF1ZXJ5LCBpZCwgZmllbGRzKSB7XG4gICAgICAgIHZhciBlO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIHJldHVybiBzdWIuY2hhbmdlZCh0aGlzLkNvbGxlY3Rpb24uX25hbWUsIGlkLCBmaWVsZHMpO1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgIGUgPSBlcnJvcjtcbiAgICAgICAgfVxuICAgICAgfSksIHRoaXMsIHN1YiwgcXVlcnkpLFxuICAgICAgcmVtb3ZlZDogXy5iaW5kKChmdW5jdGlvbihzdWIsIHF1ZXJ5LCBpZCkge1xuICAgICAgICB2YXIgZTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBzdWIucmVtb3ZlZCh0aGlzLkNvbGxlY3Rpb24uX25hbWUsIGlkKTtcbiAgICAgICAgICByZXR1cm4gcXVlcnkoKS5mb3JFYWNoKChmdW5jdGlvbihfdGhpcykge1xuICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uKG8sIGkpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHN1Yi5jaGFuZ2VkKF90aGlzLkNvbGxlY3Rpb24uX25hbWUsIG8uX2lkLCBfLm9iamVjdChbW1wiX1wiICsgX3RoaXMuaWQgKyBcIl9pXCIsIGldXSkpO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICB9KSh0aGlzKSk7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgZSA9IGVycm9yO1xuICAgICAgICB9XG4gICAgICB9KSwgdGhpcywgc3ViLCBxdWVyeSlcbiAgICB9KTtcbiAgICBuID0gMDtcbiAgICBjLmZvckVhY2goKGZ1bmN0aW9uKF90aGlzKSB7XG4gICAgICByZXR1cm4gZnVuY3Rpb24oZG9jLCBpbmRleCwgY3Vyc29yKSB7XG4gICAgICAgIG4rKztcbiAgICAgICAgZG9jW1wiX1wiICsgX3RoaXMuaWQgKyBcIl9wXCJdID0gcGFnZTtcbiAgICAgICAgZG9jW1wiX1wiICsgX3RoaXMuaWQgKyBcIl9pXCJdID0gaW5kZXg7XG4gICAgICAgIHJldHVybiBzdWIuYWRkZWQoX3RoaXMuQ29sbGVjdGlvbi5fbmFtZSwgZG9jLl9pZCwgZG9jKTtcbiAgICAgIH07XG4gICAgfSkodGhpcykpO1xuICAgIGluaXQgPSBmYWxzZTtcbiAgICBzdWIub25TdG9wKF8uYmluZCgoZnVuY3Rpb24ocGFnZSkge1xuICAgICAgZGVsZXRlIHRoaXMuc3Vic2NyaXB0aW9uc1tzdWIuY29ubmVjdGlvbi5pZF1bcGFnZV07XG4gICAgICB0aGlzLnN1YnNjcmlwdGlvbnNbc3ViLmNvbm5lY3Rpb24uaWRdLmxlbmd0aC0tO1xuICAgICAgaGFuZGxlLnN0b3AoKTtcbiAgICAgIHJldHVybiBoYW5kbGUyLnN0b3AoKTtcbiAgICB9KSwgdGhpcywgcGFnZSkpO1xuICAgIHRoaXMuc3Vic2NyaXB0aW9uc1tzdWIuY29ubmVjdGlvbi5pZF1bcGFnZV0gPSBzdWI7XG4gICAgdGhpcy5zdWJzY3JpcHRpb25zW3N1Yi5jb25uZWN0aW9uLmlkXS5sZW5ndGgrKztcbiAgICByZXR1cm4gc3ViLnJlYWR5KCk7XG4gIH07XG5cbiAgUGFnZXMucHJvdG90eXBlLmxvYWRpbmcgPSBmdW5jdGlvbihwKSB7XG4gICAgaWYgKCF0aGlzLmZhc3RSZW5kZXIgJiYgcCA9PT0gdGhpcy5jdXJyZW50UGFnZSgpKSB7XG4gICAgICByZXR1cm4gdGhpcy5zZXNzKFwicmVhZHlcIiwgZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBQYWdlcy5wcm90b3R5cGUubm93ID0gZnVuY3Rpb24oKSB7XG4gICAgcmV0dXJuIChuZXcgRGF0ZSgpKS5nZXRUaW1lKCk7XG4gIH07XG5cbiAgUGFnZXMucHJvdG90eXBlLmxvZyA9IGZ1bmN0aW9uKCkge1xuICAgIHZhciBhLCBpLCBqLCBsZW47XG4gICAgYSA9IFtcIlBhZ2VzOiBcIiArIHRoaXMubmFtZSArIFwiIC1cIl07XG4gICAgZm9yIChqID0gMCwgbGVuID0gYXJndW1lbnRzLmxlbmd0aDsgaiA8IGxlbjsgaisrKSB7XG4gICAgICBpID0gYXJndW1lbnRzW2pdO1xuICAgICAgYS5wdXNoKGkpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5kZWJ1ZyAmJiBjb25zb2xlLmxvZy5hcHBseShjb25zb2xlLCBhKTtcbiAgfTtcblxuICBQYWdlcy5wcm90b3R5cGUubG9nUmVxdWVzdCA9IGZ1bmN0aW9uKHApIHtcbiAgICB0aGlzLnRpbWVMYXN0UmVxdWVzdCA9IHRoaXMubm93KCk7XG4gICAgdGhpcy5yZXF1ZXN0aW5nID0gcDtcbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0ZWRbcF0gPSAxO1xuICB9O1xuXG4gIFBhZ2VzLnByb3RvdHlwZS5sb2dSZXNwb25zZSA9IGZ1bmN0aW9uKHApIHtcbiAgICBkZWxldGUgdGhpcy5yZXF1ZXN0ZWRbcF07XG4gICAgcmV0dXJuIHRoaXMucmVjZWl2ZWRbcF0gPSAxO1xuICB9O1xuXG4gIFBhZ2VzLnByb3RvdHlwZS5jbGVhclF1ZXVlID0gZnVuY3Rpb24oKSB7XG4gICAgcmV0dXJuIHRoaXMucXVldWUgPSBbXTtcbiAgfTtcblxuICBQYWdlcy5wcm90b3R5cGUubmVpZ2hib3JzID0gZnVuY3Rpb24ocGFnZSkge1xuICAgIHZhciBkLCBqLCBtYXhNYXJnaW4sIG4sIG5wLCBwcCwgcmVmO1xuICAgIG4gPSBbXTtcbiAgICBpZiAodGhpcy5kYXRhTWFyZ2luID09PSAwIHx8IHRoaXMubWF4U3Vic2NyaXB0aW9ucyA8IDIpIHtcbiAgICAgIHJldHVybiBuO1xuICAgIH1cbiAgICBtYXhNYXJnaW4gPSBNYXRoLmZsb29yKCh0aGlzLm1heFN1YnNjcmlwdGlvbnMgLSAxKSAvIDIpO1xuICAgIGZvciAoZCA9IGogPSAxLCByZWYgPSBfLm1pbihbbWF4TWFyZ2luLCB0aGlzLmRhdGFNYXJnaW5dKTsgMSA8PSByZWYgPyBqIDw9IHJlZiA6IGogPj0gcmVmOyBkID0gMSA8PSByZWYgPyArK2ogOiAtLWopIHtcbiAgICAgIG5wID0gcGFnZSArIGQ7XG4gICAgICBpZiAobnAgPD0gdGhpcy5zZXNzKFwidG90YWxQYWdlc1wiKSkge1xuICAgICAgICBuLnB1c2gobnApO1xuICAgICAgfVxuICAgICAgcHAgPSBwYWdlIC0gZDtcbiAgICAgIGlmIChwcCA+IDApIHtcbiAgICAgICAgbi5wdXNoKHBwKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG47XG4gIH07XG5cbiAgUGFnZXMucHJvdG90eXBlLnF1ZXVlTmVpZ2hib3JzID0gZnVuY3Rpb24ocGFnZSkge1xuICAgIHZhciBqLCBsZW4sIHAsIHJlZiwgcmVzdWx0cztcbiAgICByZWYgPSB0aGlzLm5laWdoYm9ycyhwYWdlKTtcbiAgICByZXN1bHRzID0gW107XG4gICAgZm9yIChqID0gMCwgbGVuID0gcmVmLmxlbmd0aDsgaiA8IGxlbjsgaisrKSB7XG4gICAgICBwID0gcmVmW2pdO1xuICAgICAgaWYgKCF0aGlzLnJlY2VpdmVkW3BdICYmICF0aGlzLnJlcXVlc3RlZFtwXSAmJiBpbmRleE9mLmNhbGwodGhpcy5xdWV1ZSwgcCkgPCAwKSB7XG4gICAgICAgIHJlc3VsdHMucHVzaCh0aGlzLnF1ZXVlLnB1c2gocCkpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmVzdWx0cy5wdXNoKHZvaWQgMCk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiByZXN1bHRzO1xuICB9O1xuXG4gIFBhZ2VzLnByb3RvdHlwZS5wYWdpbmF0aW9uTmF2SXRlbSA9IGZ1bmN0aW9uKGxhYmVsLCBwYWdlLCBkaXNhYmxlZCwgYWN0aXZlKSB7XG4gICAgaWYgKGFjdGl2ZSA9PSBudWxsKSB7XG4gICAgICBhY3RpdmUgPSBmYWxzZTtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgIHA6IGxhYmVsLFxuICAgICAgbjogcGFnZSxcbiAgICAgIGFjdGl2ZTogYWN0aXZlID8gXCJhY3RpdmVcIiA6IFwiXCIsXG4gICAgICBkaXNhYmxlZDogZGlzYWJsZWQgPyBcImRpc2FibGVkXCIgOiBcIlwiXG4gICAgfTtcbiAgfTtcblxuICBQYWdlcy5wcm90b3R5cGUubmF2aWdhdGlvbk5laWdoYm9ycyA9IGZ1bmN0aW9uKCkge1xuICAgIHZhciBmcm9tLCBpLCBqLCBrLCBsZW4sIG0sIG4sIHAsIHBhZ2UsIHJlZiwgcmVmMSwgdG8sIHRvdGFsO1xuICAgIHBhZ2UgPSB0aGlzLmN1cnJlbnRQYWdlKCk7XG4gICAgdG90YWwgPSB0aGlzLnNlc3MoXCJ0b3RhbFBhZ2VzXCIpO1xuICAgIGZyb20gPSBwYWdlIC0gdGhpcy5wYWdpbmF0aW9uTWFyZ2luO1xuICAgIHRvID0gcGFnZSArIHRoaXMucGFnaW5hdGlvbk1hcmdpbjtcbiAgICBpZiAoZnJvbSA8IDEpIHtcbiAgICAgIHRvICs9IDEgLSBmcm9tO1xuICAgICAgZnJvbSA9IDE7XG4gICAgfVxuICAgIGlmICh0byA+IHRvdGFsKSB7XG4gICAgICBmcm9tIC09IHRvIC0gdG90YWw7XG4gICAgICB0byA9IHRvdGFsO1xuICAgIH1cbiAgICBpZiAoZnJvbSA8IDEpIHtcbiAgICAgIGZyb20gPSAxO1xuICAgIH1cbiAgICBpZiAodG8gPiB0b3RhbCkge1xuICAgICAgdG8gPSB0b3RhbDtcbiAgICB9XG4gICAgbiA9IFtdO1xuICAgIGlmICh0aGlzLm5hdlNob3dGaXJzdCB8fCB0aGlzLm5hdlNob3dFZGdlcykge1xuICAgICAgbi5wdXNoKHRoaXMucGFnaW5hdGlvbk5hdkl0ZW0oXCLCq1wiLCAxLCBwYWdlID09PSAxKSk7XG4gICAgfVxuICAgIG4ucHVzaCh0aGlzLnBhZ2luYXRpb25OYXZJdGVtKFwiPFwiLCBwYWdlIC0gMSwgcGFnZSA9PT0gMSkpO1xuICAgIGZvciAocCA9IGogPSByZWYgPSBmcm9tLCByZWYxID0gdG87IHJlZiA8PSByZWYxID8gaiA8PSByZWYxIDogaiA+PSByZWYxOyBwID0gcmVmIDw9IHJlZjEgPyArK2ogOiAtLWopIHtcbiAgICAgIG4ucHVzaCh0aGlzLnBhZ2luYXRpb25OYXZJdGVtKHAsIHAsIHBhZ2UgPiB0b3RhbCwgcCA9PT0gcGFnZSkpO1xuICAgIH1cbiAgICBuLnB1c2godGhpcy5wYWdpbmF0aW9uTmF2SXRlbShcIj5cIiwgcGFnZSArIDEsIHBhZ2UgPj0gdG90YWwpKTtcbiAgICBpZiAodGhpcy5uYXZTaG93TGFzdCB8fCB0aGlzLm5hdlNob3dFZGdlcykge1xuICAgICAgbi5wdXNoKHRoaXMucGFnaW5hdGlvbk5hdkl0ZW0oXCLCu1wiLCB0b3RhbCwgcGFnZSA+PSB0b3RhbCkpO1xuICAgIH1cbiAgICBmb3IgKGsgPSBtID0gMCwgbGVuID0gbi5sZW5ndGg7IG0gPCBsZW47IGsgPSArK20pIHtcbiAgICAgIGkgPSBuW2tdO1xuICAgICAgbltrXVsnX3AnXSA9IHRoaXM7XG4gICAgfVxuICAgIHJldHVybiBuO1xuICB9O1xuXG4gIFBhZ2VzLnByb3RvdHlwZS5vbk5hdkNsaWNrID0gZnVuY3Rpb24obikge1xuICAgIGlmIChuIDw9IHRoaXMuc2VzcyhcInRvdGFsUGFnZXNcIikgJiYgbiA+IDApIHtcbiAgICAgIFRyYWNrZXIubm9ucmVhY3RpdmUoKGZ1bmN0aW9uKF90aGlzKSB7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbigpIHtcbiAgICAgICAgICB2YXIgY3A7XG4gICAgICAgICAgY3AgPSBfdGhpcy5zZXNzKFwiY3VycmVudFBhZ2VcIik7XG4gICAgICAgICAgaWYgKF90aGlzLnJlY2VpdmVkW2NwXSkge1xuICAgICAgICAgICAgcmV0dXJuIF90aGlzLnNlc3MoXCJvbGRQYWdlXCIsIGNwKTtcbiAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICB9KSh0aGlzKSk7XG4gICAgICByZXR1cm4gdGhpcy5zZXNzKFwiY3VycmVudFBhZ2VcIiwgbik7XG4gICAgfVxuICB9O1xuXG4gIFBhZ2VzLnByb3RvdHlwZS5zZXRJbmZpbml0ZVRyaWdnZXIgPSBmdW5jdGlvbigpIHtcbiAgICB0aGlzLnNjcm9sbEJveFNlbGVjdG9yID0gdGhpcy5zY3JvbGxCb3hTZWxlY3RvciB8fCB3aW5kb3c7XG4gICAgdGhpcy5zY3JvbGxCb3ggPSAkKHRoaXMuc2Nyb2xsQm94U2VsZWN0b3IpO1xuICAgIHJldHVybiB0aGlzLnNjcm9sbEJveC5zY3JvbGwoXy5iaW5kKF8udGhyb3R0bGUoZnVuY3Rpb24oKSB7XG4gICAgICB2YXIgbCwgb2gsIHQ7XG4gICAgICB0ID0gdGhpcy5pbmZpbml0ZVRyaWdnZXI7XG4gICAgICBvaCA9IHRoaXMuc2Nyb2xsQm94WzBdLnNjcm9sbEhlaWdodDtcbiAgICAgIGlmICgodGhpcy5sYXN0T2Zmc2V0SGVpZ2h0ICE9IG51bGwpICYmIHRoaXMubGFzdE9mZnNldEhlaWdodCA+IG9oKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHRoaXMubGFzdE9mZnNldEhlaWdodCA9IG9oO1xuICAgICAgaWYgKHQgPiAxKSB7XG4gICAgICAgIGwgPSBvaCAtIHQ7XG4gICAgICB9IGVsc2UgaWYgKHQgPiAwKSB7XG4gICAgICAgIGwgPSBvaCAqIHQ7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAodGhpcy5zY3JvbGxCb3guc2Nyb2xsVG9wKCkgKyB0aGlzLnNjcm9sbEJveFswXS5vZmZzZXRIZWlnaHQgPj0gbCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXNzKFwibGltaXRcIiwgdGhpcy5zZXNzKFwibGltaXRcIikgKyB0aGlzLmluZmluaXRlU3RlcCk7XG5cbiAgICAgICAgLypcbiAgICAgICAgaWYgQGxhc3RQYWdlIDwgQHNlc3MgXCJ0b3RhbFBhZ2VzXCJcbiAgICAgICAgICBjb25zb2xlLmxvZyBcImkgd2FudCBwYWdlICN7QGxhc3RQYWdlICsgMX1cIlxuICAgICAgICAgIEBzZXNzKFwiY3VycmVudFBhZ2VcIiwgQGxhc3RQYWdlICsgMSlcbiAgICAgICAgICovXG4gICAgICB9XG4gICAgfSwgdGhpcy5pbmZpbml0ZVJhdGVMaW1pdCAqIDEwMDApLCB0aGlzKSk7XG4gIH07XG5cbiAgUGFnZXMucHJvdG90eXBlLmNoZWNrUXVldWUgPSBfLnRocm90dGxlKGZ1bmN0aW9uKCkge1xuICAgIHZhciBjcCwgaSwgaywgbmVpZ2hib3JzLCByZWYsIHJlc3VsdHMsIHJlc3VsdHMxLCB2O1xuICAgIGNwID0gdGhpcy5jdXJyZW50UGFnZSgpO1xuICAgIG5laWdoYm9ycyA9IHRoaXMubmVpZ2hib3JzKGNwKTtcbiAgICBpZiAoIXRoaXMucmVjZWl2ZWRbY3BdKSB7XG4gICAgICB0aGlzLmNsZWFyUXVldWUoKTtcbiAgICAgIHRoaXMucmVxdWVzdFBhZ2UoY3ApO1xuICAgICAgY3AgPSBTdHJpbmcoY3ApO1xuICAgICAgcmVmID0gdGhpcy5yZXF1ZXN0ZWQ7XG4gICAgICByZXN1bHRzID0gW107XG4gICAgICBmb3IgKGsgaW4gcmVmKSB7XG4gICAgICAgIHYgPSByZWZba107XG4gICAgICAgIGlmIChrICE9PSBjcCkge1xuICAgICAgICAgIGlmICh0aGlzLnN1YnNjcmlwdGlvbnNba10gIT0gbnVsbCkge1xuICAgICAgICAgICAgdGhpcy5zdWJzY3JpcHRpb25zW2tdLnN0b3AoKTtcbiAgICAgICAgICAgIGRlbGV0ZSB0aGlzLnN1YnNjcmlwdGlvbnNba107XG4gICAgICAgICAgICB0aGlzLnN1YnNjcmlwdGlvbnMubGVuZ3RoLS07XG4gICAgICAgICAgfVxuICAgICAgICAgIHJlc3VsdHMucHVzaChkZWxldGUgdGhpcy5yZXF1ZXN0ZWRba10pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJlc3VsdHMucHVzaCh2b2lkIDApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzdWx0cztcbiAgICB9IGVsc2UgaWYgKHRoaXMucXVldWUubGVuZ3RoKSB7XG4gICAgICByZXN1bHRzMSA9IFtdO1xuICAgICAgd2hpbGUgKHRoaXMucXVldWUubGVuZ3RoID4gMCkge1xuICAgICAgICBpID0gdGhpcy5xdWV1ZS5zaGlmdCgpO1xuICAgICAgICBpZiAoaW5kZXhPZi5jYWxsKG5laWdoYm9ycywgaSkgPj0gMCkge1xuICAgICAgICAgIHRoaXMucmVxdWVzdFBhZ2UoaSk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmVzdWx0czEucHVzaCh2b2lkIDApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzdWx0czE7XG4gICAgfVxuICB9LCA1MDApO1xuXG4gIFBhZ2VzLnByb3RvdHlwZS5jdXJyZW50UGFnZSA9IGZ1bmN0aW9uKCkge1xuICAgIGlmIChNZXRlb3IuaXNDbGllbnQgJiYgKHRoaXMuc2VzcyhcImN1cnJlbnRQYWdlXCIpICE9IG51bGwpKSB7XG4gICAgICByZXR1cm4gdGhpcy5zZXNzKFwiY3VycmVudFBhZ2VcIik7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiB0aGlzLl9jdXJyZW50UGFnZTtcbiAgICB9XG4gIH07XG5cbiAgUGFnZXMucHJvdG90eXBlLmlzUmVhZHkgPSBmdW5jdGlvbigpIHtcbiAgICByZXR1cm4gdGhpcy5zZXNzKFwicmVhZHlcIik7XG4gIH07XG5cbiAgUGFnZXMucHJvdG90eXBlLnJlYWR5ID0gZnVuY3Rpb24ocCkge1xuICAgIGlmIChwID09PSB0cnVlIHx8IHAgPT09IHRoaXMuY3VycmVudFBhZ2UoKSAmJiAodHlwZW9mIFNlc3Npb24gIT09IFwidW5kZWZpbmVkXCIgJiYgU2Vzc2lvbiAhPT0gbnVsbCkpIHtcbiAgICAgIHJldHVybiB0aGlzLnNlc3MoXCJyZWFkeVwiLCB0cnVlKTtcbiAgICB9XG4gIH07XG5cbiAgUGFnZXMucHJvdG90eXBlLmNoZWNrSW5pdFBhZ2UgPSBmdW5jdGlvbigpIHtcbiAgICB2YXIgcmVmLCByZWYxLCByZWYyO1xuICAgIGlmICh0aGlzLmluaXQgJiYgIXRoaXMuaW5pdFBhZ2UpIHtcbiAgICAgIGlmICh0aGlzLnJvdXRlcikge1xuICAgICAgICBpZiAoKHJlZiA9IFJvdXRlci5jdXJyZW50KCkpICE9IG51bGwpIHtcbiAgICAgICAgICBpZiAoKHJlZjEgPSByZWYucm91dGUpICE9IG51bGwpIHtcbiAgICAgICAgICAgIHJlZjEuZ2V0TmFtZSgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgIHRoaXMuaW5pdFBhZ2UgPSBwYXJzZUludCgocmVmMiA9IFJvdXRlci5jdXJyZW50KCkucm91dGUucGFyYW1zKGxvY2F0aW9uLmhyZWYpKSAhPSBudWxsID8gcmVmMi5wYWdlIDogdm9pZCAwKSB8fCAxO1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5pbml0UGFnZSA9IDE7XG4gICAgICB9XG4gICAgfVxuICAgIHRoaXMuaW5pdCA9IGZhbHNlO1xuICAgIHRoaXMuc2VzcyhcIm9sZFBhZ2VcIiwgdGhpcy5pbml0UGFnZSk7XG4gICAgcmV0dXJuIHRoaXMuc2VzcyhcImN1cnJlbnRQYWdlXCIsIHRoaXMuaW5pdFBhZ2UpO1xuICB9O1xuXG4gIFBhZ2VzLnByb3RvdHlwZS5nZXRQYWdlID0gZnVuY3Rpb24ocGFnZSkge1xuICAgIHZhciBjLCBuLCB0b3RhbDtcbiAgICBpZiAoTWV0ZW9yLmlzQ2xpZW50KSB7XG4gICAgICBpZiAocGFnZSA9PSBudWxsKSB7XG4gICAgICAgIHBhZ2UgPSB0aGlzLmN1cnJlbnRQYWdlKCk7XG4gICAgICB9XG4gICAgICBwYWdlID0gcGFyc2VJbnQocGFnZSk7XG4gICAgICBpZiAocGFnZSA9PT0gKDAvMCkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgdG90YWwgPSB0aGlzLnNlc3MoXCJ0b3RhbFBhZ2VzXCIpO1xuICAgICAgaWYgKHRvdGFsID09PSAwKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnJlYWR5KHRydWUpO1xuICAgICAgfVxuICAgICAgaWYgKHBhZ2UgPD0gdG90YWwpIHtcbiAgICAgICAgdGhpcy5yZXF1ZXN0UGFnZShwYWdlKTtcbiAgICAgICAgdGhpcy5xdWV1ZU5laWdoYm9ycyhwYWdlKTtcbiAgICAgICAgdGhpcy5jaGVja1F1ZXVlKCk7XG4gICAgICB9XG4gICAgICBpZiAodGhpcy5pbmZpbml0ZSkge1xuICAgICAgICBuID0gdGhpcy5Db2xsZWN0aW9uLmZpbmQoe30sIHtcbiAgICAgICAgICBmaWVsZHM6IHRoaXMuZmllbGRzLFxuICAgICAgICAgIHNvcnQ6IHRoaXMuc29ydFxuICAgICAgICB9KS5jb3VudCgpO1xuICAgICAgICBjID0gdGhpcy5Db2xsZWN0aW9uLmZpbmQoe30sIHtcbiAgICAgICAgICBmaWVsZHM6IHRoaXMuZmllbGRzLFxuICAgICAgICAgIHNvcnQ6IHRoaXMuc29ydCxcbiAgICAgICAgICBza2lwOiBuID4gdGhpcy5pbmZpbml0ZUl0ZW1zTGltaXQgPyBuIC0gdGhpcy5pbmZpbml0ZUl0ZW1zTGltaXQgOiAwLFxuICAgICAgICAgIGxpbWl0OiB0aGlzLnNlc3MoXCJsaW1pdFwiKSB8fCB0aGlzLmluZmluaXRlSXRlbXNMaW1pdFxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGMgPSB0aGlzLkNvbGxlY3Rpb24uZmluZChfLm9iamVjdChbW1wiX1wiICsgdGhpcy5pZCArIFwiX3BcIiwgcGFnZV1dKSwge1xuICAgICAgICAgIGZpZWxkczogdGhpcy5maWVsZHMsXG4gICAgICAgICAgc29ydDogXy5vYmplY3QoW1tcIl9cIiArIHRoaXMuaWQgKyBcIl9pXCIsIDFdXSlcbiAgICAgICAgfSk7XG4gICAgICAgIGMub2JzZXJ2ZUNoYW5nZXMoe1xuICAgICAgICAgIGFkZGVkOiAoZnVuY3Rpb24oX3RoaXMpIHtcbiAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIF90aGlzLmNvdW50UGFnZXMoKTtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfSkodGhpcyksXG4gICAgICAgICAgcmVtb3ZlZDogKGZ1bmN0aW9uKF90aGlzKSB7XG4gICAgICAgICAgICByZXR1cm4gZnVuY3Rpb24oKSB7XG5cbiAgICAgICAgICAgICAgLyogISEgKi9cbiAgICAgICAgICAgICAgX3RoaXMucmVxdWVzdFBhZ2UoX3RoaXMuc2VzcyhcImN1cnJlbnRQYWdlXCIpKTtcbiAgICAgICAgICAgICAgcmV0dXJuIF90aGlzLmNvdW50UGFnZXMoKTtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfSkodGhpcylcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gYy5mZXRjaCgpO1xuICAgIH1cbiAgfTtcblxuICBQYWdlcy5wcm90b3R5cGUucmVxdWVzdFBhZ2UgPSBmdW5jdGlvbihwYWdlKSB7XG4gICAgaWYgKCFwYWdlIHx8IHRoaXMucmVxdWVzdGVkW3BhZ2VdIHx8IHRoaXMucmVjZWl2ZWRbcGFnZV0pIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy5sb2coXCJSZXF1ZXN0aW5nIHBhZ2UgXCIgKyBwYWdlKTtcbiAgICB0aGlzLmxvZ1JlcXVlc3QocGFnZSk7XG4gICAgaWYgKCFNZXRlb3Iuc3RhdHVzKCkuY29ubmVjdGVkICYmIHRoaXMuZ3JvdW5kREIpIHtcbiAgICAgIGlmICh0aGlzLkNvbGxlY3Rpb24uZmluZE9uZShfLm9iamVjdChbW1wiX1wiICsgdGhpcy5pZCArIFwiX3BcIiwgcGFnZV1dKSkpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMub25QYWdlKHBhZ2UpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIHNldFRpbWVvdXQoXy5iaW5kKGZ1bmN0aW9uKHBhZ2UpIHtcbiAgICAgICAgICBpZiAodGhpcy5jdXJyZW50UGFnZSgpID09PSBwYWdlICYmICF0aGlzLnJlY2VpdmVkW3BhZ2VdKSB7XG4gICAgICAgICAgICBkZWxldGUgdGhpcy5yZXF1ZXN0ZWRbcGFnZV07XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5yZXF1ZXN0UGFnZShwYWdlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0sIHRoaXMsIHBhZ2UpLCA1MDApO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmVuZm9yY2VTdWJzY3JpcHRpb25MaW1pdCgpO1xuICAgICAgcmV0dXJuIE1ldGVvci5kZWZlcihfLmJpbmQoKGZ1bmN0aW9uKHBhZ2UpIHtcbiAgICAgICAgdGhpcy5zdWJzY3JpcHRpb25zW3BhZ2VdID0gTWV0ZW9yLnN1YnNjcmliZSh0aGlzLmlkLCBwYWdlLCB7XG4gICAgICAgICAgb25SZWFkeTogXy5iaW5kKGZ1bmN0aW9uKHBhZ2UpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLm9uUGFnZShwYWdlKTtcbiAgICAgICAgICB9LCB0aGlzLCBwYWdlKSxcbiAgICAgICAgICBvbkVycm9yOiAoZnVuY3Rpb24oX3RoaXMpIHtcbiAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbihlKSB7XG4gICAgICAgICAgICAgIGlmIChlLmVycm9yID09PSBcInN1YnNjcmlwdGlvbi1saW1pdC1yZWFjaGVkXCIpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gc2V0VGltZW91dChfLmJpbmQoZnVuY3Rpb24ocGFnZSkge1xuICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuY3VycmVudFBhZ2UoKSA9PT0gcGFnZSAmJiAhdGhpcy5yZWNlaXZlZFtwYWdlXSkge1xuICAgICAgICAgICAgICAgICAgICBkZWxldGUgdGhpcy5yZXF1ZXN0ZWRbcGFnZV07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnJlcXVlc3RQYWdlKHBhZ2UpO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0sIF90aGlzLCBwYWdlKSwgNTAwKTtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gX3RoaXMuZXJyb3IoZS5tZXNzYWdlKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICB9KSh0aGlzKVxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5zdWJzY3JpcHRpb25zLm9yZGVyLnB1c2gocGFnZSk7XG4gICAgICAgIHJldHVybiB0aGlzLnN1YnNjcmlwdGlvbnMubGVuZ3RoKys7XG4gICAgICB9KSwgdGhpcywgcGFnZSkpO1xuICAgIH1cbiAgfTtcblxuICBQYWdlcy5wcm90b3R5cGUub25QYWdlID0gZnVuY3Rpb24ocGFnZSkge1xuICAgIHRoaXMubG9nKFwiUmVjZWl2ZWQgcGFnZSBcIiArIHBhZ2UpO1xuICAgIHRoaXMuYmVmb3JlRmlyc3RSZWFkeSA9IGZhbHNlO1xuICAgIHRoaXMubG9nUmVzcG9uc2UocGFnZSk7XG4gICAgdGhpcy5yZWFkeShwYWdlKTtcbiAgICBpZiAodGhpcy5pbmZpbml0ZSkge1xuICAgICAgdGhpcy5sYXN0UGFnZSA9IHBhZ2U7XG4gICAgfVxuICAgIHRoaXMuY291bnRQYWdlcygpO1xuICAgIHJldHVybiB0aGlzLmNoZWNrUXVldWUoKTtcbiAgfTtcblxuICByZXR1cm4gUGFnZXM7XG5cbn0pKCk7XG5cbk1ldGVvci5QYWdpbmF0aW9uID0gUGFnZXM7XG4iXX0=
