var require = meteorInstall({"lib":{"schemas":{"actions-log.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/schemas/actions-log.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
// keep track of user interactions that may indicate attacks
// e.g. repeated actions faster than the UI would allow, indicating scripted actions
// these actions are recorded per user
ActionsLog = new Meteor.Collection('actions_log');
var Schema = new SimpleSchema({
    user_id: {
        type: String,
        label: "User id"
    },
    username: {
        type: String,
        label: "Username"
    },
    locked: {
        type: Boolean,
        label: "Locked",
        optional: true
    },
    verification_email_sent: {
        type: [Number],
        label: "Verification email sent"
    },
    image_uploaded: {
        type: [Number],
        label: "Image uploaded"
    },
    image_removed: {
        type: [Number],
        label: "Image removed"
    }
});
ActionsLog.attachSchema(Schema);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"images.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/schemas/images.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Images = new Meteor.Collection('images');
var Schema = new SimpleSchema({
    url: {
        type: String,
        label: "URL"
    },
    key: {
        type: String,
        label: "Key"
    },
    caption: {
        type: String,
        label: "Caption",
        optional: true
    },
    created_at: {
        type: Number,
        label: "Created at"
    },
    created_by: {
        type: String,
        label: "Created by"
    },
    created_by_username: {
        type: String,
        label: "Created by username"
    },
    used_by: {
        type: String,
        // e.g. pattern_id, user_id
        label: "Used by"
    },
    role: {
        type: String,
        // e.g. preview, avatar
        label: "Role"
    },
    width: {
        type: Number,
        label: "Width",
        optional: true
    },
    height: {
        type: Number,
        label: "Height",
        optional: true
    }
});
Images.attachSchema(Schema);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"patterns.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/schemas/patterns.js                                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Schema = new SimpleSchema({
	'auto_preview': {
		'type': String,
		'label': 'Auto preview',
		'optional': true
	},
	'auto_turn_sequence': {
		'type': [String],
		'label': 'Auto turn sequence',
		'optional': true
	},
	'auto_turn_threads': {
		'type': [[Number]],
		'label': 'Auto turn threads',
		'optional': true
	},
	'created_at': {
		'type': Number,
		'label': 'Created at'
	},
	'created_by': {
		'type': String,
		'label': 'Created by'
	},
	'created_by_username': {
		'type': String,
		'label': 'Created by username'
	},
	'description': {
		'type': String,
		'label': 'Description',
		'optional': true
	},
	'hole_handedness': {
		'type': String,
		'label': 'Hole handedness',
		'max': 50,
		'optional': true
	},
	'edit_mode': {
		'type': String,
		'label': 'Edit mode',
		'max': 50,
		'optional': true
	},
	'long_floats_chart': {
		'type': String,
		'label': 'Long floats grid',
		'max': 10000,
		'optional': true
	},
	'name': {
		'type': String,
		'label': 'Name',
		'max': 200
	},
	'manual_weaving_threads': {
		'type': [[Number]],
		'label': 'Manual weaving turns',
		'optional': true
	},
	'manual_weaving_turns': {
		'type': String,
		'label': 'Manual weaving turns',
		'optional': true
	},
	'name_sort': {
		'type': String,
		'optional': true,
		'autoValue': function () {
			var name = this.field('name');

			if (name.isSet) {
				return name.value.toLowerCase();
			} else {
				this.unset();
			}
		}
	},
	'number_of_rows': {
		'type': Number,
		'label': 'Number of rows',
		'max': 1000,
		'optional': true
	},
	'number_of_tablets': {
		'type': Number,
		'label': 'Number of rows',
		'max': 1000,
		'optional': true
	},
	'orientation': {
		'type': String,
		'label': 'Orientation',
		'max': 10000,
		'optional': true
	},
	'pattern_edited_at': {
		'type': Number,
		'label': 'Edited at',
		'optional': true
	},
	'position_of_A': {
		'type': String,
		'label': 'Position of A',
		'optional': true
	},
	'preview_rotation': {
		'type': String,
		'label': 'Preview rotation',
		'optional': true
	},
	'private': {
		'type': Boolean,
		'label': 'Private',
		'optional': true
	},
	'simulation_mode': {
		'type': String,
		'label': 'Simulation mode',
		'optional': true
	},
	'special_styles': {
		'type': String,
		'label': 'Styles',
		'max': 10000,
		'optional': true
	},
	'styles': {
		'type': String,
		'label': 'Styles',
		'max': 10000,
		'optional': true
	},
	'tags': {
		'type': String,
		'label': 'Tags',
		'max': 10000,
		'optional': true
	},
	'text_edited_at': {
		'type': Number,
		'label': 'Edited at',
		'optional': true
	},
	'threading': {
		'type': String,
		'label': 'Threading',
		'max': 10000,
		'optional': true
	},
	'threading_notes': {
		'type': String,
		'label': 'Threading notes',
		'optional': true
	},
	'twill_change_chart': {
		'type': String,
		'label': 'Twill direction change chart',
		'max': 10000,
		'optional': true
	},
	'twill_direction': {
		'type': String,
		'label': 'Twill direction',
		'optional': true
	},
	'twill_pattern_chart': {
		'type': String,
		'label': 'Twill pattern chart',
		'max': 10000,
		'optional': true
	},
	'weaving_start_row': {
		'type': Number,
		'label': 'Weaving start row',
		'optional': true
	},
	'weaving': {
		'type': String,
		'label': 'Weaving',
		'max': 20000,
		'optional': true
	},
	'weaving_notes': {
		'type': String,
		'label': 'Weaving notes',
		'optional': true
	},
	'weft_color': {
		'type': String,
		'label': 'Weft color',
		'optional': true
	}
});
Patterns = new Meteor.Collection('patterns');

if (Meteor.isServer) {
	// ensure there is are indexes to speed up queries
	// Patterns (patterns by owner, by private)
	Patterns.rawCollection().createIndex({
		'created_by': 1
	});
	Patterns.rawCollection().createIndex({
		'private': 1
	}); // New Patterns (patterns by creation date, newest first)

	Patterns.rawCollection().createIndex({
		'created_at': -1
	});
}

Patterns.attachSchema(Schema);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"db_setup.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/db_setup.js                                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/////////////////////////////
// Users collection
this.Users = new Meteor.Pagination(Meteor.users, {
  itemTemplate: "user_thumbnail",
  templateName: "users",
  perPage: 12,
  availableSettings: {
    filters: true,
    sort: true
  },
  auth: function (skip, sub) {
    var userSettings = this.userSettings[sub._session.id] || {};
    var userFilters = userSettings.filters || {};
    var update = {};
    update["profile.public_patterns_count"] = {
      $gt: 0
    }; // this construction is required to query a child property

    if (sub.userId) var _filters = _.extend({
      $or: [update, {
        _id: sub.userId
      }]
    }, userFilters); // Only return users with published patterns, and the user themself
    else var _filters = _.extend({
        $or: [update]
      }, userFilters); // Only return users with published patterns, and the user themself

    var _options = {
      limit: 12,
      skip: skip,
      fields: {
        username: 1 // if no fields are set, ALL user fields are published, including sensitive ones. Setting even one field seems to ensure only 'public' fields like profile are published.

      }
    };
    if (typeof userSettings.sort === "object") _options.sort = userSettings.sort;else {
      _options.sort = {
        'profile.name_sort': 1
      }; // lower-case version of username
    }
    return [_filters, _options];
  }
}); // Deny all client-side updates to user documents
// Otherwise the user can write to their profile from the client

Meteor.users.deny({
  update() {
    return true;
  }

}); /////////////////////////////
// tags on patterns

Tags.TagsMixin(Patterns); // https://atmospherejs.com/patrickleet/tags

Patterns.allowTags(function (userId) {
  return true;
}); // search patterns

patternsIndex = new EasySearch.Index({
  collection: Patterns,
  fields: ['name_sort', 'tags', 'created_by_username', 'number_of_tablets'],
  defaultSearchOptions: {
    limit: 6
  },
  engine: new EasySearch.Minimongo() // search only on the client, so only published documents are returned
  // server side searches
  /*engine: new EasySearch.MongoDB({
    selector: function (searchObject, options, aggregation) {
      let selector = this.defaultConfiguration().selector(searchObject, options, aggregation);
       selector.createdBy = options.userId;
      console.log("searchObject " + Object.keys(searchObject));
      console.log("aggregation " + Object.keys(aggregation));
      console.log("id " + options.search.userId);
       return selector;
    }
  })*/
});
usersIndex = new EasySearch.Index({
  collection: Meteor.users,
  fields: ['username', 'profile.description'],
  defaultSearchOptions: {
    limit: 6
  },
  engine: new EasySearch.Minimongo() // search only on the client, so only published documents are returned

}); ////////////////////////////
// Pagination
// https://github.com/alethes/meteor-pages
// note that requestPage(1) is called when each template is rendered
// https://github.com/alethes/meteor-pages/issues/208
// show all patterns belonging to one user

this.UserPatterns = new Meteor.Pagination(Patterns, {
  itemTemplate: "pattern_thumbnail",
  templateName: "user",
  perPage: 12,
  availableSettings: {
    filters: true,
    sort: true
  },
  auth: function (skip, sub) {
    var userSettings = this.userSettings[sub._session.id] || {};
    var userFilters = userSettings.filters || {};
    if (sub.userId) var _filters = _.extend({
      $or: [{
        private: {
          $ne: true
        }
      }, {
        created_by: sub.userId
      }]
    }, userFilters);else var _filters = _.extend({
      private: {
        $ne: true
      }
    }, userFilters);
    var _options = {
      limit: 12,
      sort: {
        name_sort: 1
      },
      skip: skip,
      fields: {
        _id: 1,
        auto_preview: 1,
        created_at: 1,
        created_by: 1,
        created_by_username: 1,
        description: 1,
        name: 1,
        name_sort: 1,
        number_of_tablets: 1,
        private: 1
      }
    };
    return [_filters, _options];
  }
});
this.MyPatterns = new Meteor.Pagination(Patterns, {
  itemTemplate: "pattern_thumbnail",
  templateName: "my_patterns",
  perPage: 12,
  availableSettings: {
    filters: true,
    sort: true
  },
  auth: function (skip, sub) {
    var userSettings = this.userSettings[sub._session.id] || {};
    var userFilters = userSettings.filters || {};

    var _filters = _.extend({
      created_by: sub.userId
    }, userFilters);

    var _options = {
      limit: 12,
      sort: {
        name_sort: 1
      },
      skip: skip,
      fields: {
        _id: 1,
        auto_preview: 1,
        created_at: 1,
        created_by: 1,
        created_by_username: 1,
        description: 1,
        name: 1,
        name_sort: 1,
        number_of_tablets: 1,
        private: 1
      }
    };
    return [_filters, _options];
  },
  filters: {}
});
this.AllPatterns = new Meteor.Pagination(Patterns, {
  itemTemplate: "pattern_thumbnail",
  templateName: "all_patterns",
  perPage: 12,
  /* required, otherwise pages do not show consistent number of documents */availableSettings: {
    filters: true,
    sort: true
  },
  auth: function (skip, sub) {
    var userSettings = this.userSettings[sub._session.id] || {};
    var userFilters = userSettings.filters || {}; /* apply client-side filters if set */
    if (sub.userId) var _filters = _.extend({
      /* whatever you allow here is allowed everywhere - including by your own publish functions */$or: [{
        private: {
          $ne: true
        }
      }, {
        created_by: sub.userId
      }]
    }, userFilters);else var _filters = _.extend( /* whatever you allow here is allowed everywhere - including by your own publish functions */{
      private: {
        $ne: true
      }
    }, userFilters);
    var _options = {
      limit: 12,
      /* replaces perPage */skip: skip,
      /* skip is required, otherwise pages > 1 show nothing */fields: {
        _id: 1,
        auto_preview: 1,
        created_at: 1,
        created_by: 1,
        created_by_username: 1,
        description: 1,
        name: 1,
        name_sort: 1,
        number_of_tablets: 1,
        private: 1
      }
    };
    if (typeof userSettings.sort === "object") /* if client-side sort */_options.sort = userSettings.sort;else _options.sort = {
      name_sort: 1
    };
    return [_filters, _options];
  },
  filters: {}
});
this.NewPatterns = new Meteor.Pagination(Patterns, {
  itemTemplate: "pattern_thumbnail",
  templateName: "new_patterns",
  perPage: 12,
  availableSettings: {
    filters: true,
    sort: true
  },
  auth: function (skip, sub) {
    var userSettings = this.userSettings[sub._session.id] || {};
    var userFilters = userSettings.filters || {};
    if (sub.userId) var _filters = _.extend({
      $or: [{
        private: {
          $ne: true
        }
      }, {
        created_by: sub.userId
      }]
    }, userFilters);else var _filters = _.extend({
      private: {
        $ne: true
      }
    }, userFilters);
    var _options = {
      limit: 12,
      sort: {
        created_at: -1
      },
      skip: skip,
      fields: {
        _id: 1,
        auto_preview: 1,
        created_at: 1,
        created_by: 1,
        created_by_username: 1,
        description: 1,
        name: 1,
        name_sort: 1,
        number_of_tablets: 1,
        private: 1
      }
    };
    return [_filters, _options];
  },
  filters: {}
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"default_pattern_data.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/default_pattern_data.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
// used by new_pattern_from_json
default_pattern_data = {
  "version": "2.02",
  "name": "New pattern",
  "description": "A pattern woven by forward and backward turning of the tablets.",
  "weaving_notes": "",
  "threading_notes": "",
  "tags": [],
  "styles": [{
    "background_color": "#cc0000",
    "line_color": "#ffffff",
    "warp": "none",
    "style": 1
  }, {
    "background_color": "#ffd966",
    "line_color": "#ffffff",
    "warp": "none",
    "style": 2
  }, {
    "background_color": "#ffffff",
    "line_color": "#cc0000",
    "warp": "forward",
    "style": 3
  }, {
    "background_color": "#ffffff",
    "line_color": "#cc0000",
    "warp": "backward",
    "style": 4
  }, {
    "background_color": "#ffffff",
    "line_color": "#ffd966",
    "warp": "forward",
    "style": 5
  }, {
    "background_color": "#ffffff",
    "line_color": "#ffd966",
    "warp": "backward",
    "style": 6
  }, {
    "background_color": "#ffffff",
    "line_color": "#1c4587",
    "warp": "forward",
    "style": 7
  }, {
    "background_color": "#ffffff",
    "line_color": "#1c4587",
    "warp": "backward",
    "style": 8
  }, {
    "background_color": "#1c4587",
    "line_color": "#ffffff",
    "warp": "none",
    "style": 9
  }, {
    "background_color": "#6aa84f",
    "line_color": "#ffffff",
    "warp": "none",
    "style": 10
  }, {
    "background_color": "#bbbbbb",
    "line_color": "#cc0000",
    "warp": "backward",
    "style": 11
  }, {
    "background_color": "#bbbbbb",
    "line_color": "#cc0000",
    "warp": "forward",
    "style": 12
  }, {
    "background_color": "#BBBBBB",
    "line_color": "#ffd966",
    "warp": "backward",
    "style": 13
  }, {
    "background_color": "#BBBBBB",
    "line_color": "#ffd966",
    "warp": "forward",
    "style": 14
  }, {
    "background_color": "#BBBBBB",
    "line_color": "#1c4587",
    "warp": "backward",
    "style": 15
  }, {
    "background_color": "#BBBBBB",
    "line_color": "#1c4587",
    "warp": "forward",
    "style": 16
  }, {
    "background_color": "#ffffff",
    "line_color": "#6aa84f",
    "warp": "forward",
    "style": 17
  }, {
    "background_color": "#ffffff",
    "line_color": "#6aa84f",
    "warp": "backward",
    "style": 18
  }, {
    "background_color": "#ffffff",
    "line_color": "#783f04",
    "warp": "forward",
    "style": 19,
    "special": false
  }, {
    "background_color": "#ffffff",
    "line_color": "#783f04",
    "warp": "backward",
    "style": 20,
    "special": false
  }, {
    "background_color": "#ffffff",
    "line_color": "#ffffff",
    "warp": "forward",
    "style": 21,
    "special": false
  }, {
    "background_color": "#ffffff",
    "line_color": "#ffffff",
    "warp": "backward",
    "style": 22,
    "special": false
  }, {
    "background_color": "#ffffff",
    "line_color": "#1c4587",
    "warp": "forward_empty",
    "style": 23
  }, {
    "background_color": "#ffffff",
    "line_color": "#1c4587",
    "warp": "backward_empty",
    "style": 24
  }, {
    "background_color": "#BBBBBB",
    "line_color": "#6aa84f",
    "warp": "backward",
    "style": 25
  }, {
    "background_color": "#BBBBBB",
    "line_color": "#6aa84f",
    "warp": "forward",
    "style": 26
  }, {
    "background_color": "#BBBBBB",
    "line_color": "#783f04",
    "warp": "backward",
    "style": 27
  }, {
    "background_color": "#BBBBBB",
    "line_color": "#783f04",
    "warp": "forward",
    "style": 28
  }, {
    "background_color": "#BBBBBB",
    "line_color": "#ffffff",
    "warp": "backward",
    "style": 29
  }, {
    "background_color": "#BBBBBB",
    "line_color": "#ffffff",
    "warp": "forward",
    "style": 30
  }, {
    "background_color": "#BBBBBB",
    "line_color": "#1c4587",
    "warp": "backward_empty",
    "style": 31
  }, {
    "background_color": "#BBBBBB",
    "line_color": "#1c4587",
    "warp": "forward_empty",
    "style": 32
  }],
  "special_styles": [{
    "background_color": "#FFFFFF",
    "name": "forward_2",
    "warp": "forward",
    "image": "/images/special_forward_2.svg",
    "style": "S1"
  }, {
    "background_color": "#FFFFFF",
    "name": "backward_2",
    "warp": "backward",
    "image": "/images/special_backward_2.svg",
    "style": "S2"
  }, {
    "background_color": "#FFFFFF",
    "name": "forward_3",
    "warp": "forward",
    "image": "/images/special_forward_3.svg",
    "style": "S3"
  }, {
    "background_color": "#FFFFFF",
    "name": "backward_3",
    "warp": "backward",
    "image": "/images/special_backward_3.svg",
    "style": "S4"
  }, {
    "background_color": "#FFFFFF",
    "name": "forward_4",
    "warp": "forward",
    "image": "/images/special_forward_4.svg",
    "style": "S5"
  }, {
    "background_color": "#FFFFFF",
    "name": "backward_4",
    "warp": "backward",
    "image": "/images/special_backward_4.svg",
    "style": "S6"
  }, {
    "background_color": "#FFFFFF",
    "image": "/images/special_empty.svg",
    "style": "S7"
  }, {
    "background_color": "#FFFFFF",
    "image": "",
    "style": "S8"
  }, {
    "background_color": "#BBBBBB",
    "name": "backward_2_gray",
    "warp": "backward",
    "image": "/images/special_backward_2.svg",
    "style": "S9"
  }, {
    "background_color": "#BBBBBB",
    "name": "forward_2_gray",
    "warp": "forward",
    "image": "/images/special_forward_2.svg",
    "style": "S10"
  }, {
    "background_color": "#BBBBBB",
    "name": "backward_3_gray",
    "warp": "backward",
    "image": "/images/special_backward_3.svg",
    "style": "S11"
  }, {
    "background_color": "#BBBBBB",
    "name": "forward_3_gray",
    "warp": "forward",
    "image": "/images/special_forward_3.svg",
    "style": "S12"
  }, {
    "background_color": "#BBBBBB",
    "name": "backward_4_gray",
    "warp": "backward",
    "image": "/images/special_backward_4.svg",
    "style": "S13"
  }, {
    "background_color": "#BBBBBB",
    "name": "forward_4_gray",
    "warp": "forward",
    "image": "/images/special_forward_4.svg",
    "style": "S14"
  }, {
    "background_color": "#FFFFFF",
    "name": "idle",
    "image": "/images/special_idle.svg",
    "style": "S15"
  }, {
    "background_color": "#FFFFFF",
    "image": "",
    "style": "S16"
  }],
  "simulation_styles": [{
    "background_color": "#cc0000",
    "line_color": "#ffffff",
    "warp": "none",
    "style": 1
  }, {
    "background_color": "#ffd966",
    "line_color": "#ffffff",
    "warp": "none",
    "style": 2
  }, {
    "background_color": "#1c4587",
    "line_color": "#ffffff",
    "warp": "none",
    "style": 3
  }, {
    "background_color": "#6aa84f",
    "line_color": "#ffffff",
    "warp": "none",
    "style": 4
  }, {
    "background_color": "#674ea7",
    "line_color": "#ffffff",
    "warp": "none",
    "style": 5,
    "special": false
  }, {
    "background_color": "#783f04",
    "line_color": "#ffffff",
    "warp": "none",
    "style": 6,
    "special": false
  }, {
    "background_color": "#ffffff",
    "line_color": "#ffffff",
    "warp": "none",
    "style": 7
  }, {
    "background_color": "#ffffff",
    "line_color": "#cc0000",
    "warp": "forward",
    "style": 8
  }, {
    "background_color": "#ffffff",
    "line_color": "#cc0000",
    "warp": "backward",
    "style": 9
  }, {
    "background_color": "#bbbbbb",
    "line_color": "#cc0000",
    "warp": "forward",
    "style": 10,
    "special": false
  }, {
    "background_color": "#bbbbbb",
    "line_color": "#cc0000",
    "warp": "backward",
    "style": 11,
    "special": false
  }, {
    "background_color": "#ffffff",
    "line_color": "#ffd966",
    "warp": "forward",
    "style": 12,
    "special": false
  }, {
    "background_color": "#ffffff",
    "line_color": "#ffd966",
    "warp": "backward",
    "style": 14,
    "special": false
  }, {
    "background_color": "#bbbbbb",
    "line_color": "#ffd966",
    "warp": "forward",
    "style": 14
  }, {
    "background_color": "#bbbbbb",
    "line_color": "#ffd966",
    "warp": "backward",
    "style": 15
  }, {
    "background_color": "#ffffff",
    "line_color": "#1c4587",
    "warp": "forward",
    "style": 16
  }, {
    "background_color": "#ffffff",
    "line_color": "#1c4587",
    "warp": "backward",
    "style": 17
  }, {
    "background_color": "#bbbbbb",
    "line_color": "#1c4587",
    "warp": "forward",
    "style": 18
  }, {
    "background_color": "#bbbbbb",
    "line_color": "#1c4587",
    "warp": "backward",
    "style": 19
  }, {
    "background_color": "#ffffff",
    "line_color": "#6aa84f",
    "warp": "forward",
    "style": 20
  }, {
    "background_color": "#ffffff",
    "line_color": "#6aa84f",
    "warp": "backward",
    "style": 21
  }, {
    "background_color": "#bbbbbb",
    "line_color": "#6aa84f",
    "warp": "forward",
    "style": 22
  }, {
    "background_color": "#bbbbbb",
    "line_color": "#6aa84f",
    "warp": "backward",
    "style": 23
  }, {
    "background_color": "#ffffff",
    "line_color": "#674ea7",
    "warp": "forward",
    "style": 24
  }, {
    "background_color": "#ffffff",
    "line_color": "#674ea7",
    "warp": "backward",
    "style": 25
  }, {
    "background_color": "#bbbbbb",
    "line_color": "#674ea7",
    "warp": "forward",
    "style": 26
  }, {
    "background_color": "#bbbbbb",
    "line_color": "#674ea7",
    "warp": "backward",
    "style": 27
  }, {
    "background_color": "#ffffff",
    "line_color": "#783f04",
    "warp": "forward",
    "style": 28
  }, {
    "background_color": "#ffffff",
    "line_color": "#783f04",
    "warp": "backward",
    "style": 29
  }, {
    "background_color": "#bbbbbb",
    "line_color": "#783f04",
    "warp": "forward",
    "style": 30
  }, {
    "background_color": "#bbbbbb",
    "line_color": "#783f04",
    "warp": "backward",
    "style": 31
  }, {
    "background_color": "#ffffff",
    "line_color": "#ffffff",
    "warp": "forward",
    "style": 32
  }, {
    "background_color": "#ffffff",
    "line_color": "#ffffff",
    "warp": "backward",
    "style": 33
  }, {
    "background_color": "#bbbbbb",
    "line_color": "#ffffff",
    "warp": "forward",
    "style": 34
  }, {
    "background_color": "#bbbbbb",
    "line_color": "#ffffff",
    "warp": "backward",
    "style": 35
  }, {
    "background_color": "#ffffff",
    "line_color": "#ffffff",
    "warp": "forward_empty",
    "style": 36
  }, {
    "background_color": "#ffffff",
    "line_color": "#ffffff",
    "warp": "backward_empty",
    "style": 37
  }, {
    "background_color": "#bbbbbb",
    "line_color": "#ffffff",
    "warp": "forward_empty",
    "style": 40
  }, {
    "background_color": "#bbbbbb",
    "line_color": "#ffffff",
    "warp": "backward_empty",
    "style": 41
  }],
  "orientation": ["S", "Z", "S", "Z", "S", "Z", "S", "Z", "S", "Z", "S", "Z"],
  "threading": [[5, 6, 5, 6, 5, 6, 5, 6, 5, 6, 5, 6], [5, 6, 5, 6, 5, 6, 5, 6, 5, 6, 5, 6], [5, 6, 5, 6, 5, 6, 5, 6, 5, 6, 5, 6], [5, 6, 5, 6, 5, 6, 5, 6, 5, 6, 5, 6]],
  "weaving": [[5, 6, 5, 6, 5, 6, 5, 6, 5, 6, 5, 6], [5, 6, 5, 6, 5, 6, 5, 6, 5, 6, 5, 6], [5, 6, 5, 6, 5, 6, 5, 6, 5, 6, 5, 6], [5, 6, 5, 6, 5, 6, 5, 6, 5, 6, 5, 6], [5, 6, 5, 6, 5, 6, 5, 6, 5, 6, 5, 6], [5, 6, 5, 6, 5, 6, 5, 6, 5, 6, 5, 6], [5, 6, 5, 6, 5, 6, 5, 6, 5, 6, 5, 6], [5, 6, 5, 6, 5, 6, 5, 6, 5, 6, 5, 6]],
  "weft_color": "#76a5af"
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mixins.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/mixins.js                                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
////////////////////////
// extends 'check' functionality
// check(userId, NonEmptyString);
NonEmptyString = Match.Where(function (x) {
  check(x, String);
  return x.length > 0;
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"params.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/params.js                                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
// general parameters that do not affect security
Meteor.my_params = {
  // namespace for parameters
  undo_stack_length: 10,
  special_styles_number: 16,
  // currently up to 16 special styles allowing 3 multiple turns and 4 other single styles
  pattern_thumbnail_width: 248,
  // tiled pattern thumbnails
  pattern_thumbnail_rmargin: 16,
  // right margin
  max_recents: 12,
  max_home_thumbnails: 12,
  max_auto_turns: 48,
  number_of_packs: 3,
  // packs in simulation pattern, manual mode
  default_pattern_name: "New pattern",
  default_special_styles: [{
    "background_color": "#FFFFFF",
    "name": "forward_2",
    "warp": "forward",
    "image": "/images/special_forward_2.svg",
    "style": "S1"
  }, {
    "background_color": "#FFFFFF",
    "name": "backward_2",
    "warp": "backward",
    "image": "/images/special_backward_2.svg",
    "style": "S2"
  }, {
    "background_color": "#FFFFFF",
    "name": "forward_3",
    "warp": "forward",
    "image": "/images/special_forward_3.svg",
    "style": "S3"
  }, {
    "background_color": "#FFFFFF",
    "name": "backward_3",
    "warp": "backward",
    "image": "/images/special_backward_3.svg",
    "style": "S4"
  }, {
    "background_color": "#FFFFFF",
    "name": "forward_4",
    "warp": "forward",
    "image": "/images/special_forward_4.svg",
    "style": "S5"
  }, {
    "background_color": "#FFFFFF",
    "name": "backward_4",
    "warp": "backward",
    "image": "/images/special_backward_4.svg",
    "style": "S6"
  }, {
    "background_color": "#FFFFFF",
    "image": "/images/special_empty.svg",
    "style": "S7"
  }, {
    "background_color": "#FFFFFF",
    "image": "",
    "style": "S8"
  }, {
    "background_color": "#BBBBBB",
    "name": "backward_2_gray",
    "warp": "backward",
    "image": "/images/special_backward_2.svg",
    "style": "S9"
  }, {
    "background_color": "#BBBBBB",
    "name": "forward_2_gray",
    "warp": "forward",
    "image": "/images/special_forward_2.svg",
    "style": "S10"
  }, {
    "background_color": "#BBBBBB",
    "name": "backward_3_gray",
    "warp": "backward",
    "image": "/images/special_backward_3.svg",
    "style": "S11"
  }, {
    "background_color": "#BBBBBB",
    "name": "forward_3_gray",
    "warp": "forward",
    "image": "/images/special_forward_3.svg",
    "style": "S12"
  }, {
    "background_color": "#BBBBBB",
    "name": "backward_4_gray",
    "warp": "backward",
    "image": "/images/special_backward_4.svg",
    "style": "S13"
  }, {
    "background_color": "#BBBBBB",
    "name": "forward_4_gray",
    "warp": "forward",
    "image": "/images/special_forward_4.svg",
    "style": "S14"
  }, {
    "background_color": "#FFFFFF",
    "name": "idle",
    "image": "/images/special_idle.svg",
    "style": "S15"
  }, {
    "background_color": "#FFFFFF",
    "image": "",
    "style": "S16"
  }]
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"slingshot.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/slingshot.js                                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
// slingshot image uploader
// puts files in an AWS (Amazon Web Services) bucket
if (Meteor.isClient) {
  uploader = new ReactiveVar();
  var currentUserId = Meteor.userId();
  Session.set('upload_status', 'not started');
  Template.image_uploader.events({
    'change .uploadFile': function (event, template) {
      event.preventDefault();

      var pattern_id = Router.current().params._id;

      var file = document.getElementById('uploadFile').files[0];
      Meteor.my_functions.upload_pattern_image(file, pattern_id);
    }
  });
  Meteor.subscribe('images');
}

if (Meteor.isServer) {
  Slingshot.fileRestrictions("myImageUploads", {
    allowedFileTypes: ["image/png", "image/jpeg", "image/gif"],
    maxSize: 2 * 1024 * 1024
  });
  Slingshot.createDirective("myImageUploads", Slingshot.S3Storage, {
    AWSAccessKeyId: Meteor.settings.private.AWSAccessKeyId,
    AWSSecretAccessKey: Meteor.settings.private.AWSSecretAccessKey,
    bucket: Meteor.settings.private.AWSBucket,
    acl: "public-read",
    region: Meteor.settings.public.AWSRegion,
    authorize: function (file, context) {
      // User must be logged in
      if (!this.userId) {
        var message = "You are not logged in.";
        throw new Meteor.Error("not-authorized", message);
      } // User must have verified their email address


      var user = Meteor.users.findOne({
        _id: this.userId
      }, {
        fields: {
          emails: 1
        }
      });

      if (!user.emails[0].verified) {
        var message = "Your email address is not verified.";
        throw new Meteor.Error("not-authorized", message);
      } // User must own the pattern


      var pattern = Patterns.findOne({
        _id: context.pattern_id
      }, {
        fields: {
          created_by: 1
        }
      });

      if (pattern.created_by != this.userId) {
        var message = "You did not create this pattern.";
        throw new Meteor.Error("not-authorized", message);
      } // check for too many image uploads too fast


      var document_id = Meteor.call('get_actions_log');
      var db_document = ActionsLog.findOne({
        _id: document_id
      }, {
        fields: {
          image_uploaded: 1,
          locked: 1
        }
      });
      var event_log = db_document.image_uploaded;
      if (db_document.locked) throw new Meteor.Error("account-locked", "Your account has been locked, please contact an administrator");
      var number_of_entries = event_log.length;
      var time_since_last_action = moment().valueOf() - event_log[0]; // try to detect automated image uploads
      // A human shouldn't be able to upload 10 images in 2 seconds

      var last_10_actions_in = event_log[0] - event_log[9];

      if (last_10_actions_in < 2000) {
        ActionsLog.update({
          _id: document_id
        }, {
          locked: true
        });
        throw new Meteor.Error("account-locked", "Your account has been locked, please contact an administrator");
      }

      var last_5_actions_in = event_log[0] - event_log[4];

      if (last_5_actions_in < 2000) {
        // Don't allow another attempt for 5 minutes
        if (time_since_last_action < 60 * 1000 * 5) throw new Meteor.Error("too-many-requests", "Please wait 5 mins before retrying"); // it's been at least 5 mins so consider allowing another image upload
        else {
            var previous_5_actions_in = event_log[4] - event_log[9];

            if (previous_5_actions_in < 2000) {
              // if the 5 previous actions were in 2 seconds, wait 30 minutes
              // this looks like an automatic process that has tried continually
              if (time_since_last_action < 60 * 1000 * 30 + 4000) throw new Meteor.Error("too-many-requests", "Please wait 30 mins before retrying");
            }
          }
      } // record the action in the log


      ActionsLog.update({
        _id: document_id
      }, {
        $push: {
          image_uploaded: {
            $each: [moment().valueOf()],
            $position: 0
          }
        }
      });
      ; // remove the oldest log entry if too many stored

      if (number_of_entries > Meteor.settings.private.image_uploads_num_to_log) {
        ActionsLog.update({
          _id: document_id
        }, {
          $pop: {
            image_uploaded: 1
          }
        });
      }

      return true;
    },
    key: function (file) {
      var parts = file.name.split("."); // find the file extension

      var extension = parts.pop();
      var name = parts.join(""); // find the name

      var name = name.slice(0, 30) + "-" + moment().valueOf().toString() + "." + extension; // use the first 30 chars of the name, plus timestamp, plus file extension, to make a meaningful name that is unique to this user

      return Meteor.userId() + "/" + name;
    }
  });
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"router":{"routes.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// router/routes.js                                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Router.configure({
  layoutTemplate: 'main_layout',
  fastRender: true,
  loadingTemplate: 'loading'
}); // waitOn makes initial page render very slow, maybe 15 seconds. On pages like Home that list patterns, it's better to see the page sooner and watch the patterns appear.

Router.route('/', {
  name: 'home',
  template: 'home'
});
Router.route('/about', {
  name: 'about',
  template: 'about'
});
Router.route('/recent-patterns', {
  name: 'recent_patterns',
  template: 'recent_patterns'
});
Router.route('/new-patterns', {
  name: 'new_patterns',
  template: 'new_patterns'
});
Router.route('/my-patterns', {
  name: 'my_patterns',
  template: 'my_patterns'
});
Router.route('/all-patterns', {
  name: 'all_patterns',
  template: 'all_patterns'
});
Router.route('/users', {
  name: 'users',
  template: 'users'
});
Router.route('/pattern/:_id/:mode?', {
  name: 'pattern',
  data: function () {
    var pattern_id = this.params._id;
    return Patterns.findOne({
      _id: pattern_id
    }, {
      fields: {
        weaving: 0,
        threading: 0,
        orientation: 0
      }
    });
  },
  waitOn: function () {
    var pattern_id = this.params._id;
    var params = {
      pattern_id: pattern_id
    };
    return [Meteor.subscribe('pattern', params)];
  },
  action: function () {
    var pattern_id = this.params._id;

    if (Patterns.find({
      _id: pattern_id
    }).count() == 0) {
      this.layout('main_layout');
      this.render("pattern_not_found");
      this.render(null, {
        to: 'footer'
      }); // yield regions must be manually cleared
    } else if (this.params.mode == "weaving") {
      this.render('weave_pattern');
      this.render(null, {
        to: 'footer'
      });
    } else if (this.params.mode == "print") {
      this.layout('print_layout');
      this.render('print_pattern');
      this.render(null, {
        to: 'footer'
      });
    } else {
      this.render('view_pattern');
      if (Meteor.my_functions.can_edit_pattern(pattern_id)) this.render('styles_palette', {
        to: 'footer'
      });else this.render(null, {
        to: 'footer'
      });
    }
  }
});
Router.route('/user/:_id', {
  name: 'user',
  data: function () {
    var user_id = this.params._id;
    return Meteor.users.findOne({
      _id: user_id
    });
  },
  waitOn: function () {
    var user_id = this.params._id;
    var params = {
      user_id: user_id
    };
    return [Meteor.subscribe('user', params)];
  },
  action: function () {
    var user_id = this.params._id;
    if (Meteor.users.find({
      _id: user_id
    }).count() == 0) this.render("user_not_found");else this.render("user");
  }
});
Router.route('/account-settings', {
  name: 'account_settings',
  data: function () {
    var user_id = Meteor.userId();
    return Meteor.users.findOne({
      _id: user_id
    });
  },
  waitOn: function () {
    var user_id = Meteor.userId();
    var params = {
      user_id: user_id
    };
    return [Meteor.subscribe('user', params)];
  },
  action: function () {
    // var user_id = this.params._id;
    this.render("account_settings");
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"init.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/init.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Meteor.startup(function () {
  process.env.MAIL_URL = Meteor.settings['private'].MAIL_URL;
  process.env.ROOT_URL = Meteor.settings['private'].ROOT_URL; // Accounts

  Accounts.config({
    sendVerificationEmail: true
  });
  Accounts.emailTemplates.siteName = "Twisted Threads";
  Accounts.emailTemplates.from = "Twisted Threads <no-reply@twistedthreads.org>";

  Accounts.emailTemplates.verifyEmail.subject = function (user) {
    return "Verify your email address";
  };

  Accounts.emailTemplates.verifyEmail.text = function (user, url) {
    return "Hello " + user.username + ",\n\nYou have registered a new email address on Twisted Threads, the online app for tablet weaving. To verify your email address, please click the link below:\n\n" + url;
  }; // make sure the current user has correct role based on whether their email address is verified


  Meteor.users.find().observeChanges({
    changed: function (id, fields) {
      Meteor.call('update_user_roles', id);
    }
  }); ///////////////////////////////
  // Ongoing database updates
  // run this as desired
  // make private all patterns with the default name
  /*Patterns.find().forEach( function(myDoc) {
    if (myDoc.name == Meteor.my_params.default_pattern_name)
      Patterns.update({_id: myDoc._id}, { $set: {private: true}});
  });*/ // remove all patterns because something has gone wrong
  /*Patterns.find().forEach( function(myDoc) {
    //if (myDoc.name == Meteor.my_params.default_pattern_name)
     Patterns.remove(myDoc._id);
  });*/
});
Accounts.onCreateUser(function (options, user) {
  // We still want the default hook's 'profile' behavior.
  user.profile = options.profile || {};
  user.profile.name_sort = user.username.toLowerCase();
  return user;
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/methods.js                                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Meteor.methods({
  //////////////////////
  // Pattern management
  show_pattern_tags: function () {
    // for internal use only
    console.log("All tags " + Meteor.tags.find().fetch().map(function (tag) {
      return tag.name;
    }));
  },
  can_create_pattern: function () {
    if (!Meteor.userId()) return false;
    var count = Patterns.find({
      created_by: Meteor.userId()
    }).count();

    if (Roles.userIsInRole(Meteor.userId(), 'verified', 'users')) {
      if (Roles.userIsInRole(Meteor.userId(), 'premium', 'users')) {
        if (count < Meteor.settings.public.max_patterns_per_user.premium) return true;else return false;
      } else {
        if (count < Meteor.settings.public.max_patterns_per_user.verified) return true;else return false;
      }
    } // if the user's email address is not verified, they can only create 1 pattern
    else {
        if (count < Meteor.settings.public.max_patterns_per_user.default) return true;else return false;
      }
  },
  /*
  // this is no longer used because the file read seemed to fail sometimes. The function is left in as a reference for reading a JSON file.
  read_default_pattern: function() {
  // return the default_turning_pattern.json
  if (!Meteor.userId()) {
    // Only logged in users can create patterns
    throw new Meteor.Error("not-authorized", "You must be signed in to read default pattern data");
  }
   try {
    var data = JSON.parse(Assets.getText("default_pattern_data.json"));
  return data;
    
    
  }
  catch(e)
  {
    //return -1;
    throw new Meteor.Error("file-load-failed", "File load error in read_default_pattern");
  }
  },*/new_pattern_from_json: function (options) {
    // options
    /* {
      name: "pattern name", //optional
      data: json data object,
    } */ // if number_of_tablets and number_of_rows are both specified, a blank pattern will be built with style 1 for all weaving and threading cells
    //console.log('new pattern from JSON 1');
    //console.log(`options ${JSON.stringify(options)}`);
    check(options, {
      edit_mode: Match.Optional(String),
      number_of_tablets: Match.Optional(String),
      number_of_rows: Match.Optional(String),
      name: Match.Optional(String),
      data: Object,
      twill_direction: Match.Optional(String)
    });
    if (!Meteor.isServer) // minimongo cannot simulate loading data with Assets
      return;

    if (!Meteor.userId()) {
      // Only logged in users can create patterns
      throw new Meteor.Error("not-authorized", "You must be signed in to create a new pattern");
    }

    var result = Meteor.call('can_create_pattern');
    if (!result) throw new Meteor.Error("not-authorized", "You may not create any more patterns");

    if (typeof options.data !== "undefined") {
      var data = options.data;
    } else if (typeof options.filename !== "undefined") {
      try {
        var data = JSON.parse(Assets.getText(options.filename));
      } catch (e) {
        //return -1;
        throw new Meteor.Error("file-load-failed", "File load error in new_pattern_from_json");
      }
    } else {
      //return -1;
      throw new Meteor.Error("file-load-failed", "File load error in new_pattern_from_json");
    } // check version


    var version = [0, 0];

    if (typeof data.version !== "undefined") {
      var split_version = data.version.split("."); // [main, subsidiary] e.g. 2.1

      if (typeof split_version[0] !== "undefined") {
        version[0] = parseInt(split_version[0]);

        if (typeof split_version[1] !== "undefined") {
          version[1] = parseInt(split_version[1]);
        }
      }
    } // edit_mode "freehand" (default), "simulation" or "broken_twill"


    if (options.edit_mode == "" || typeof options.edit_mode === "undefined") options.edit_mode = "freehand"; // earlier data version

    if (data.edit_mode == "" || typeof data.edit_mode === "undefined") data.edit_mode = options.edit_mode; // Numbers of rows and tablets
    // have both rows and tablets been specified as positive integers less than 100?

    var build_new = true; // whether to build a blank pattern using a specified number of tablets and rows

    if (typeof options.number_of_tablets !== "undefined" && typeof options.number_of_rows !== "undefined") {
      var tablets = parseInt(options.number_of_tablets);
      if (isNaN(tablets)) build_new = false;else if (tablets < 1 || tablets > 100) build_new = false;
      var rows = parseInt(options.number_of_rows);
      if (rows < 1 || rows > 100) if (options.edit_mode != "simulation") // simulation pattern builds its own weaving chart
        build_new = false;
    } else {
      build_new = false;
    }

    if (build_new) {
      // build pattern data
      switch (options.edit_mode) {
        case "freehand":
          data.preview_rotation = "left";
          break;

        case "simulation":
          data.preview_rotation = "up";
          break;

        case "broken_twill":
          data.preview_rotation = "up";
          break;
      } // weaving


      data.weaving = new Array();

      for (var i = 0; i < options.number_of_rows; i++) {
        data.weaving[i] = new Array();

        for (var j = 0; j < options.number_of_tablets; j++) {
          data.weaving[i][j] = j % 2 == 0 ? 5 : 6;
        }
      }

      if (options.edit_mode == "broken_twill") {
        data.weaving_start_row = 1;
      } // threading


      data.threading = new Array(options.number_of_rows); // default threading is style 1 for background, style 2 for foreground

      const broken_twill_threading = [[2, 2, 1, 2], [2, 1, 1, 1], [1, 1, 2, 1], [1, 2, 2, 2]];

      for (var i = 0; i < 4; i++) {
        data.threading[i] = new Array(options.number_of_tablets);

        for (var j = 0; j < options.number_of_tablets; j++) {
          if (data.edit_mode == "freehand") data.threading[i][j] = j % 2 == 0 ? 5 : 6; // manually set threading to show warp direction
          else if (data.edit_mode == "simulation") data.threading[i][j] = 2; // plain yellow in default pattern
            // two light, two dark, offset along tablets
            else if (data.edit_mode == "broken_twill") {
                data.threading[i][j] = broken_twill_threading[i][j % 4];
              }
        }
      } // orientation


      data.orientation = new Array(number_of_tablets);

      for (var i = 0; i < options.number_of_tablets; i++) {
        if (data.edit_mode == "broken_twill") data.orientation[i] = "S";else data.orientation[i] = i % 2 == 0 ? "S" : "Z";
      }
    } else if (typeof data.threading[0] === "undefined") // no rows of threading have been defined
      {
        throw new Meteor.Error("no-threading-data", "error creating pattern from JSON. No threading data");
      }

    var number_of_rows = data.weaving.length;
    var number_of_tablets = data.threading[0].length; // there may be no weaving rows but there must be threading
    // try to prevent huge patterns that would fill up the database

    if (number_of_rows > Meteor.settings.private.max_pattern_rows) throw new Meteor.Error("too-many-rows", "error creating pattern from JSON. Too many rows.");
    if (number_of_tablets > Meteor.settings.private.max_pattern_tablets) throw new Meteor.Error("too-many-tablets", "error creating pattern from JSON. Too many tablets.");
    if (options.name == "") options.name = Meteor.my_params.default_pattern_name;
    data.name = options.name; // tags

    if (typeof data.tags === "undefined") {
      data.tags = [];
    }

    if (data.edit_mode == "broken_twill") {
      data.tags.push('3/1 broken twill');
    }

    var description = "";
    if (typeof data.description !== "undefined") description = data.description;
    var weaving_notes = "";
    if (typeof data.weaving_notes !== "undefined") weaving_notes = data.weaving_notes;
    var weft_color = Meteor.settings.private.default_weft_color;
    if (typeof data.weft_color !== "undefined") weft_color = data.weft_color;
    if (typeof data.preview_rotation === "undefined") data.preview_rotation = "left";
    var threading_notes = "";
    if (typeof data.threading_notes !== "undefined") threading_notes = data.threading_notes;
    var pattern_id = Patterns.insert({
      name: data.name,
      edit_mode: data.edit_mode,
      description: description,
      weaving_notes: weaving_notes,
      preview_rotation: data.preview_rotation,
      weft_color: weft_color,
      threading_notes: threading_notes,
      private: true,
      // patterns are private by default so the user can edit them before revealing them to the world
      number_of_rows: number_of_rows,
      number_of_tablets: number_of_tablets,
      created_at: moment().valueOf(),
      // current time
      created_by: Meteor.userId(),
      // _id of logged in user
      created_by_username: Meteor.user().username // username of logged in user

    });

    if (data.weaving_start_row) {
      Patterns.update({
        _id: pattern_id
      }, {
        $set: {
          weaving_start_row: data.weaving_start_row
        }
      });
    } // Tags


    for (var i = 0; i < data.tags.length; i++) {
      Patterns.addTag(data.tags[i], {
        _id: pattern_id
      });
    } // Styles


    var styles_array = [];

    if (data.edit_mode == "simulation" || data.edit_mode == "broken_twill") // palette shows 7 regular styles for threading. The other 32 are used to automatically build the weaving chart: 4 per threading styles to show S/Z and turn forwards, backwards
      // in 3/1 broken twill only two thread colours may be set but it's easier to stick with the same styles
      {
        var styles;
        if (typeof data.simulation_styles !== "undefined") styles = data.simulation_styles; // new pattern
        else if (typeof data.styles !== "undefined") styles = data.styles; // copy of existing pattern JSON
          else throw new Meteor.Error("no-styles-data", "error creating pattern from JSON. No styles data.");

        for (var i = 0; i < styles.length; i++) {
          styles_array[i] = styles[i];
        }
      } else if (data.edit_mode == "freehand") // 32 visible styles for manually drawing threading and weaving charts
      {
        for (var i = 0; i < 32; i++) // create 32 styles
        {
          styles_array[i] = data.styles[i]; // version 1 has style.backward_stroke, style.forward_stroke
          // convert to 2+
          // style.stroke "forward" "backward" "none (other values possible in 2+)

          if (data.styles[i].backward_stroke) data.styles[i].warp = "backward";
          if (data.styles[i].forward_stroke) // if both defined, choose forward
            data.styles[i].warp = "forward";
          delete data.styles[i].backward_stroke;
          delete data.styles[i].forward_stroke;
          if (typeof data.styles[i].warp === "undefined") data.styles[i].warp = "none";
        }
      }

    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        styles: JSON.stringify(styles_array)
      }
    }); // Special styles

    var special_styles_array = [];
    if (typeof data.special_styles === "undefined") data.special_styles = [];

    for (var i = 0; i < Meteor.my_params.special_styles_number; i++) {
      special_styles_array[i] = data.special_styles[i];
    }

    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        special_styles: JSON.stringify(special_styles_array)
      }
    }); // Pattern

    var weaving = new Array(number_of_rows);

    for (var i = 0; i < number_of_rows; i++) {
      weaving[i] = new Array(number_of_tablets);

      for (var j = 0; j < number_of_tablets; j++) {
        weaving[i][j] = data.weaving[i][j];
      }
    }

    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        weaving: JSON.stringify(weaving)
      }
    }); //////////////////////////////

    if (data.edit_mode == "simulation") {
      // auto or manual. New patterns default to "freehand". Patterns from JSON may be either.
      if (data.simulation_mode == "" || typeof data.simulation_mode === "undefined") data.simulation_mode = "auto";
      Patterns.update({
        _id: pattern_id
      }, {
        $set: {
          simulation_mode: data.simulation_mode
        }
      }); // auto and manual turn sequences exist so the user can switch between them without losing data
      // track current rotation of each tablet

      if (typeof data.position_of_A === "undefined") {
        data.position_of_A = new Array();

        for (var i = 0; i < number_of_tablets; i++) {
          data.position_of_A.push(0);
        }
      }

      Patterns.update({
        _id: pattern_id
      }, {
        $set: {
          position_of_A: JSON.stringify(data.position_of_A)
        }
      }); // auto_turn_sequence e.g. FFFFBBBB

      if (typeof data.auto_turn_sequence === "undefined") data.auto_turn_sequence = ["F", "F", "F", "F", "B", "B", "B", "B"]; // default to 4 forward, 4 back

      Patterns.update({
        _id: pattern_id
      }, {
        $set: {
          auto_turn_sequence: data.auto_turn_sequence
        }
      }); // manual_weaving_turns, 4 packs each tablet turned individually
      // create row 0 which is never woven, it is a default and working row
      // actual weaving begins with row 1, 2...

      if (data.manual_weaving_turns == "" || typeof data.manual_weaving_turns === "undefined") data.manual_weaving_turns = [];
      var new_turn = {
        tablets: [],
        // for each tablet, the pack number
        packs: [] // turning info for each pack

      };

      for (var i = 1; i <= Meteor.my_params.number_of_packs; i++) {
        var pack = {
          pack_number: i,
          number_of_turns: 1
        };

        if (i == 2) {
          pack.direction = "B"; // suggested usage is pack 1 F, pack 2 B. Pack 3 F for borders.
        } else {
          pack.direction = "F";
        }

        new_turn.packs.push(pack);
      }

      for (var j = 0; j < number_of_tablets; j++) {
        new_turn.tablets.push(1); // all tablets start in pack 1
      }

      data.manual_weaving_turns[0] = new_turn;
      Patterns.update({
        _id: pattern_id
      }, {
        $set: {
          manual_weaving_turns: JSON.stringify(data.manual_weaving_turns)
        }
      }); /*
          4 packs, each tablet in one pack
          for each pack, each pick: turn direction, number of turns 0,1,2,3
          export JSON, import JSON
           use this to build weaving chart dynamically
          */
    } else if (data.edit_mode == "broken_twill") {
      if (typeof options.twill_direction !== "undefined") {
        // new pattern
        var twill_direction = options.twill_direction; // 3/1 twill must have an even number of rows

        if (options.number_of_rows % 2 == 1) throw new Meteor.Error("odd-twill-rows", "error creating pattern from JSON. 3/1 broken twill pattern must have even number of rows");
        var twill_pattern_chart = []; // corresponds to Data in GTT pattern. This is the chart showing the two-colour design.

        var twill_change_chart = []; // corresponds to LongFloats in GTT pattern. This is the chart showing 'backsteps' in the turning schedule to adjust for smooth diagonal edges.
        // set up a plain chart for each, this will give just background twill
        // charts have an extra row at the end
        // this extra row is not shown in preview or weaving chart but is used to determine the last even row

        for (var i = 0; i < options.number_of_rows / 2 + 1; i++) {
          twill_pattern_chart[i] = new Array();
          twill_change_chart[i] = new Array();

          for (var j = 0; j < options.number_of_tablets; j++) {
            twill_pattern_chart[i][j] = ".";
            twill_change_chart[i][j] = ".";
          }
        }
      } else if (typeof options.data.twill_direction !== "undefined") {
        // loaded from JSON file
        var twill_direction = options.data.twill_direction;
        var twill_pattern_chart = JSON.parse(options.data.twill_pattern_chart); // corresponds to Data in GTT pattern. This is the chart showing the two-colour design.

        var twill_change_chart = JSON.parse(options.data.twill_change_chart); // corresponds to LongFloats in GTT pattern. This is the chart showing 'backsteps' in the turning schedule to adjust for smooth diagonal edges.
      } else {
        throw new Meteor.Error("no-twill-direction", "error creating pattern from JSON. No twill direction for 3/1 broken twill pattern");
      }

      Patterns.update({
        _id: pattern_id
      }, {
        $set: {
          twill_direction: twill_direction
        }
      });
      Patterns.update({
        _id: pattern_id
      }, {
        $set: {
          twill_pattern_chart: JSON.stringify(twill_pattern_chart)
        }
      });
      Patterns.update({
        _id: pattern_id
      }, {
        $set: {
          twill_change_chart: JSON.stringify(twill_change_chart)
        }
      });
    } /////////////////////////////////
    // Threading


    var threading = new Array(4);

    for (var i = 0; i < 4; i++) {
      threading[i] = new Array(number_of_tablets);

      for (var j = 0; j < number_of_tablets; j++) {
        threading[i][j] = data.threading[i][j];
      }
    }

    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        threading: JSON.stringify(threading)
      }
    }); // Orientation

    var orientation = new Array(number_of_tablets);

    for (var i = 0; i < number_of_tablets; i++) {
      orientation[i] = data.orientation[i];
    } // count public patterns as a safety check (new patterns are private by default so it shouldn't make any difference).


    Meteor.call("count_public_patterns", Meteor.userId());
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        orientation: JSON.stringify(orientation)
      }
    });
    var pattern = Patterns.findOne({
      _id: pattern_id
    }); ///////////////////////////////////
    //
    ///////////////////////////////////

    return pattern_id;
  },
  /////////////////////////////////////
  // New: create collection data from an existing dynamic arrays
  /////////////////////////////////////
  create_new_data_from_arrays: function (pattern_id, weaving_data) {
    check(pattern_id, String);
    check(weaving_data, Array);
    var pattern = Patterns.findOne({
      _id: pattern_id
    }, {
      fields: {
        created_by: 1
      }
    });
    if (pattern.created_by != Meteor.userId()) throw new Meteor.Error("not-authorized", "You can only create data for patterns that you created");
  },
  xml2js: function (data) {
    // use xml2js package to convert XML to JSON
    // see https://github.com/Leonidas-from-XIV/node-xml2js for documentation of xml2js
    check(data, String);
    var convertAsyncToSync = Meteor.wrapAsync(xml2js.parseString),
        resultOfAsyncToSync = convertAsyncToSync(data, {}); // {} would be 'this' context if required

    return resultOfAsyncToSync; /*
                                package:
                                https://github.com/peerlibrary/meteor-xml2js
                                meteor add peerlibrary:xml2js
                                 usage:
                                https://github.com/Leonidas-from-XIV/node-xml2js
                                 wrapasync tutorial:
                                https://themeteorchef.com/snippets/synchronous-methods/#tmc-using-wrapasync
                                 // usage from client:
                                var data = "<root>Hello xml2js! New2</root>";
                                Meteor.call('xml2js',data, function(error, result){
                                  if (!error) {
                                  console.log("got xml " + JSON.stringify(result));
                                  }
                                  else {
                                    console.log(error);
                                  }
                                })
                                */
  },
  ///////////////////////////////
  // Modify patterns
  remove_pattern: function (pattern_id) {
    check(pattern_id, String);
    if (!Meteor.isServer) // attempt to avoid error "server sent add for existing id"
      return;
    var pattern = Patterns.findOne({
      _id: pattern_id
    }, {
      fields: {
        created_by: 1
      }
    });
    if (pattern.created_by != Meteor.userId()) throw new Meteor.Error("not-authorized", "You can only remove patterns that you created"); // remove from Patterns collection

    Patterns.remove(pattern_id); // remove from Recent Patterns list

    var recent_patterns = typeof Meteor.user().profile.recent_patterns === "undefined" ? [] : Meteor.user().profile.recent_patterns;
    var index = -1;

    for (var i = 0; i < recent_patterns.length; i++) {
      if (recent_patterns[i].pattern_id == pattern_id) {
        index = i;
        break;
      }
    }

    if (index > -1) {
      recent_patterns.splice(index, 1);
    }

    var update = {};
    update["profile.recent_patterns"] = recent_patterns;
    Meteor.users.update({
      _id: Meteor.userId()
    }, {
      $set: update
    }); // update count of public patterns

    Meteor.call("count_public_patterns", Meteor.userId()); // remove associated images from AWS

    Images.find({
      used_by: pattern_id
    }).map(function (image) {
      Meteor.call("remove_image", image._id);
    }); // update collection that lists associated images

    Images.remove({
      used_by: pattern_id
    });
  },
  set_private: function (pattern_id, set_to_private) {
    check(pattern_id, String);
    check(set_to_private, Boolean);
    var pattern = Patterns.findOne({
      _id: pattern_id
    }, {
      fields: {
        created_by: 1
      }
    });
    if (pattern.created_by != Meteor.userId()) throw new Meteor.Error("not-authorized", "You can only change the privacy on a pattern you created");
    Patterns.update(pattern_id, {
      $set: {
        private: set_to_private
      }
    });
    Meteor.call("count_public_patterns", pattern.created_by);
  },
  count_public_patterns: function (user_id) {
    // maintain a count of the user's public patterns, so we can easily see which users have public patterns
    var num = Patterns.find({
      $and: [{
        private: {
          $ne: true
        }
      }, {
        created_by: user_id
      }]
    }).count();
    var profile = Meteor.users.findOne({
      _id: user_id
    }).profile;
    if (typeof profile === "undefined") profile = {};
    profile["public_patterns_count"] = num;
    Meteor.users.update({
      _id: user_id
    }, {
      $set: {
        profile: profile
      }
    });
  },
  ///////////////////////////////
  // Stringify pattern data and save it
  save_weaving_to_db: function (pattern_id, text, number_of_rows, number_of_tablets) {
    check(pattern_id, String);
    check(text, String);
    check(number_of_rows, Number);
    check(number_of_tablets, Number);
    var pattern = Patterns.findOne({
      _id: pattern_id
    }, {
      fields: {
        created_by: 1
      }
    });
    if (pattern.created_by != Meteor.userId()) // Only the owner can edit a pattern
      throw new Meteor.Error("not-authorized", "You can only edit cells in a pattern you created"); // try to prevent huge patterns that would fill up the database

    if (number_of_rows > Meteor.settings.private.max_pattern_rows) throw new Meteor.Error("too-many-rows", "error saving pattern. Too many rows.");
    if (number_of_tablets > Meteor.settings.private.max_pattern_tablets) throw new Meteor.Error("too-many-tablets", "error saving pattern. Too many tablets."); // Save the individual cell data
    // var pattern = Patterns.findOne({_id: pattern_id}); // TODO remove

    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        weaving: text
      }
    }); // Record the number of rows

    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        number_of_rows: number_of_rows
      }
    }); // Record the number of tablets

    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        number_of_tablets: number_of_tablets
      }
    }); // Record the edit time

    Meteor.call("save_pattern_edit_time", pattern_id);
  },
  save_number_of_tablets: function (pattern_id, number_of_tablets) {
    check(pattern_id, String);
    check(number_of_tablets, Number);
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        number_of_tablets: number_of_tablets
      }
    });
  },
  save_preview_as_text: function (pattern_id, data) {
    check(pattern_id, String);
    check(data, String);
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        auto_preview: data
      }
    });
  },
  rotate_preview: function (pattern_id) {
    check(pattern_id, String);
    var pattern = Patterns.findOne({
      _id: pattern_id
    }, {
      fields: {
        created_by: 1,
        preview_rotation: 1
      }
    });

    if (typeof pattern.preview_rotation === "undefined") // old pattern, needs value setting
      {
        Patterns.update({
          _id: pattern_id
        }, {
          $set: {
            preview_rotation: "left"
          }
        });
        return;
      }

    if (pattern.created_by != Meteor.userId()) // Only the owner can edit a pattern
      throw new Meteor.Error("not-authorized", "You can only edit a pattern you created");
    if (typeof pattern.preview_rotation === "undefined") Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        preview_rotation: "left"
      }
    });

    switch (pattern.preview_rotation) {
      case "left":
        Patterns.update({
          _id: pattern_id
        }, {
          $set: {
            preview_rotation: "right"
          }
        });
        break;

      case "right":
        Patterns.update({
          _id: pattern_id
        }, {
          $set: {
            preview_rotation: "left"
          }
        });
        break;

      default:
        Patterns.update({
          _id: pattern_id
        }, {
          $set: {
            preview_rotation: "left"
          }
        });
    }
  },
  set_preview_orientation: function (pattern_id, rotation) {
    check(pattern_id, String);
    check(rotation, String);
    var pattern = Patterns.findOne({
      _id: pattern_id
    }, {
      fields: {
        created_by: 1,
        preview_rotation: 1
      }
    });
    if (pattern.created_by != Meteor.userId()) // Only the owner can edit a pattern
      throw new Meteor.Error("not-authorized", "You can only edit a pattern you created");
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        preview_rotation: rotation
      }
    });
  },
  save_threading_to_db: function (pattern_id, text) {
    check(pattern_id, String);
    check(text, String);
    var pattern = Patterns.findOne({
      _id: pattern_id
    }, {
      fields: {
        created_by: 1
      }
    });
    if (pattern.created_by != Meteor.userId()) // Only the owner can edit a pattern
      throw new Meteor.Error("not-authorized", "You can only edit cells in a pattern you created"); // Save the individual cell data

    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        threading: text
      }
    }); // Record the edit time

    Meteor.call("save_pattern_edit_time", pattern_id);
    return;
  },
  save_weft_color_to_db: function (pattern_id, text) {
    check(pattern_id, String);
    check(text, String);
    var pattern = Patterns.findOne({
      _id: pattern_id
    }, {
      fields: {
        created_by: 1
      }
    });
    if (pattern.created_by != Meteor.userId()) // Only the owner can edit a pattern
      throw new Meteor.Error("not-authorized", "You can only edit cells in a pattern you created"); // Save the individual cell data

    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        weft_color: text
      }
    }); // Record the edit time

    Meteor.call("save_pattern_edit_time", pattern_id);
  },
  save_orientation_to_db: function (pattern_id, text) {
    check(pattern_id, String);
    check(text, String);
    var pattern = Patterns.findOne({
      _id: pattern_id
    }, {
      fields: {
        created_by: 1
      }
    });
    if (pattern.created_by != Meteor.userId()) // Only the owner can edit a pattern
      throw new Meteor.Error("not-authorized", "You can only edit cells in a pattern you created"); // Save the individual cell data

    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        orientation: text
      }
    }); // Record the edit time

    Meteor.call("save_pattern_edit_time", pattern_id);
  },
  save_styles_to_db: function (pattern_id, text) {
    check(pattern_id, String);
    check(text, String);
    var pattern = Patterns.findOne({
      _id: pattern_id
    }, {
      fields: {
        created_by: 1
      }
    });
    if (pattern.created_by != Meteor.userId()) // Only the owner can edit a pattern
      throw new Meteor.Error("not-authorized", "You can only edit styles in a pattern you created"); // Save the individual cell data

    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        styles: text
      }
    }); // Record the edit time

    Meteor.call("save_pattern_edit_time", pattern_id);
  },
  save_manual_weaving_turns: function (pattern_id, text) {
    check(pattern_id, String);
    check(text, text);
    var pattern = Patterns.findOne({
      _id: pattern_id
    }, {
      fields: {
        created_by: 1
      }
    });
    if (pattern.created_by != Meteor.userId()) // Only the owner can edit a pattern
      throw new Meteor.Error("not-authorized", "You can only edit maual weaving turns in a pattern you created");
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        manual_weaving_turns: text
      }
    });
  },
  restore_pattern: function (data) {
    check(data, Object);
    var pattern = Patterns.findOne({
      _id: data._id
    }, {
      fields: {
        created_by: 1
      }
    });
    if (pattern.created_by != Meteor.userId()) // Only the owner can edit a pattern
      throw new Meteor.Error("not-authorized", "You can only restore a pattern you created"); // reconstruct the pattern according to the data, e.g. for undo

    Meteor.call('save_weaving_to_db', data._id, JSON.stringify(data.weaving), data.number_of_rows, data.number_of_tablets);
    Meteor.call('save_threading_to_db', data._id, JSON.stringify(data.threading));
    Meteor.call('save_orientation_to_db', data._id, JSON.stringify(data.orientation));
    Meteor.call('save_styles_to_db', data._id, JSON.stringify(data.styles));
    Patterns.update({
      _id: data._id
    }, {
      $unset: {
        auto_preview: ""
      }
    }); // preview must be re-read from the HTML after it has been built

    return;
  },
  update_after_tablet_change: function (data) // required to restore reactivity after tablets have been added or removed
  // it seems to be necessary to change the database
  {
    check(data, Object);
    Meteor.call('save_weaving_to_db', data._id, JSON.stringify(data.weaving), data.number_of_rows, data.number_of_tablets);
    var pattern = Patterns.findOne({
      _id: data._id
    }, {
      fields: {
        created_by: 1
      }
    });
    if (pattern.created_by != Meteor.userId()) // Only the owner can edit a pattern
      throw new Meteor.Error("not-authorized", "You can only restore a pattern you created");
    return;
  },
  save_pattern_edit_time: function (pattern_id) {
    check(pattern_id, String);
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        pattern_edited_at: moment().valueOf()
      }
    });
  },
  ///////////////////////////////
  // Edit other pattern properties
  toggle_hole_handedness: function (pattern_id) {
    check(pattern_id, String);
    var pattern = Patterns.findOne({
      _id: pattern_id
    }, {
      fields: {
        created_by: 1,
        hole_handedness: 1
      }
    });
    if (pattern.created_by != Meteor.userId()) // Only the owner can edit a pattern
      throw new Meteor.Error("not-authorized", "You can only edit hole handedness for a pattern you created"); // default is clockwise if not otherwise specified

    var new_value = "anticlockwise";
    if (pattern.hole_handedness == "anticlockwise") new_value = "clockwise";
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        hole_handedness: new_value
      }
    });
  },
  add_pattern_thumbnail: function (pattern_id, fileObj) {
    console.log("add_pattern_thumbnail");
    console.log("fileObj keys " + Object.keys(fileObj));
  },
  ///////////////////////////////
  // Edit styles
  set_pattern_cell_style: function (pattern_id, row, tablet, new_style) {
    check(pattern_id, String);
    check(row, Number);
    check(tablet, Number);
    check(new_style, Number);

    if (Meteor.isServer) {
      var pattern = Patterns.findOne({
        _id: pattern_id
      }, {
        fields: {
          created_by: 1
        }
      });
      if (pattern.created_by != Meteor.userId()) // Only the owner can edit a pattern
        throw new Meteor.Error("not-authorized", "You can only edit cells in a pattern you created"); // This construction allows variable properties of the document to be set

      var update = {};
      update["weaving." + row + "." + tablet + ".style"] = new_style;
      Patterns.update({
        _id: pattern_id
      }, {
        $set: update
      });
    }
  },
  set_threading_cell_style: function (pattern_id, hole, tablet, new_style) {
    check(pattern_id, String);
    check(hole, Number);
    check(tablet, Number);
    check(new_style, Number);

    if (Meteor.isServer) {
      var pattern = Patterns.findOne({
        _id: pattern_id
      }, {
        fields: {
          created_by: 1
        }
      });

      if (pattern.created_by != Meteor.userId()) {
        // Only the owner can edit a pattern
        throw new Meteor.Error("not-authorized", "You can only edit threading in a pattern you created");
      } // This construction allows variable properties of the document to be set


      var update = {};
      update["threading." + hole + "." + tablet + ".style"] = new_style;
      Patterns.update({
        _id: pattern_id
      }, {
        $set: update
      });
    }
  },
  //////////////////////////////////////
  // Simulation patterns
  update_simulation_mode: function (pattern_id, simulation_mode) {
    var pattern = Patterns.findOne({
      _id: pattern_id
    }, {
      fields: {
        created_by: 1,
        simulation_mode: 1
      }
    });
    if (pattern.created_by != Meteor.userId()) // Only the owner can edit a pattern
      throw new Meteor.Error("not-authorized", "You can only update simulation mode for a pattern you created");
    if (pattern.simulation_mode == simulation_mode) return;
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        simulation_mode: simulation_mode
      }
    });
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        weaving: "[]"
      }
    });
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        number_of_rows: 0
      }
    });
  },
  //////////////////////////////////
  // Manual simulation
  update_auto_weaving: function (pattern_id, data) {
    check(data, Object);
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        weaving: data.weaving
      }
    });
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        number_of_rows: data.number_of_rows
      }
    });
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        position_of_A: data.position_of_A
      }
    });
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        auto_turn_threads: data.auto_turn_threads
      }
    });
  },
  update_manual_weaving: function (pattern_id, data) {
    check(pattern_id, String);
    check(data, Object);
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        position_of_A: JSON.stringify(data.position_of_A)
      }
    });
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        weaving: JSON.stringify(data.weaving)
      }
    });
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        number_of_rows: data.weaving.length
      }
    });
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        manual_weaving_turns: JSON.stringify(data.manual_weaving_turns)
      }
    });
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        manual_weaving_threads: data.manual_weaving_threads
      }
    });
  },
  /////////////////////////////
  // auto simulation pattern UI
  set_auto_number_of_turns: function (pattern_id, auto_turn_sequence) {
    check(pattern_id, String);
    check(auto_turn_sequence, [String]);
    var num_auto_turns = auto_turn_sequence.length;
    if (num_auto_turns < 1 || num_auto_turns > Meteor.my_params.max_auto_turns) throw new Meteor.Error("not-valid", "Number of turns exceeds the allowed maximum");
    if (num_auto_turns < 1) throw new Meteor.Error("not-valid", "You cannot have 0 turns in the sequence");
    var pattern = Patterns.findOne({
      _id: pattern_id
    }, {
      fields: {
        created_by: 1,
        auto_turn_sequence: 1
      }
    });
    if (pattern.created_by != Meteor.userId()) throw new Meteor.Error("not-authorized", "You can only update number of turns for a pattern you created");
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        auto_turn_sequence: auto_turn_sequence
      }
    });
  },
  toggle_turn_direction: function (pattern_id, turn_number) {
    // toggle direction of a turn of auto turning, for simulation pattern
    check(pattern_id, String);
    check(turn_number, Number);
    var pattern = Patterns.findOne({
      _id: pattern_id
    }, {
      fields: {
        created_by: 1,
        auto_turn_sequence: 1
      }
    });
    if (pattern.created_by != Meteor.userId()) // Only the owner can edit a pattern
      throw new Meteor.Error("not-authorized", "You can only update turn direction for a pattern you created");
    var auto_turn_sequence = pattern.auto_turn_sequence;
    var direction = auto_turn_sequence[turn_number - 1];
    if (direction == "F") direction = "B";else direction = "F";
    auto_turn_sequence[turn_number - 1] = direction;
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        auto_turn_sequence: auto_turn_sequence
      }
    }); // Record the edit time

    Meteor.call("save_pattern_edit_time", pattern_id);
  },
  //////////////////////////////////////
  // Broken twill
  update_twill_pattern_chart: function (pattern_id, data) {
    check(pattern_id, String);
    check(data, Object);
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        twill_pattern_chart: JSON.stringify(data.twill_pattern_chart)
      }
    }); // Record the edit time

    Meteor.call("save_pattern_edit_time", pattern_id);
  },
  update_twill_change_chart: function (pattern_id, data) {
    check(pattern_id, String);
    check(data, Object);
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        twill_change_chart: JSON.stringify(data.twill_change_chart)
      }
    }); // Record the edit time

    Meteor.call("save_pattern_edit_time", pattern_id);
  },
  update_twill_charts: function (pattern_id, data, number_of_rows, number_of_tablets) {
    check(pattern_id, String);
    check(data, Object);
    check(number_of_rows, Number);
    check(number_of_tablets, Number);
    var pattern = Patterns.findOne({
      _id: pattern_id
    }, {
      fields: {
        created_by: 1
      }
    });
    if (pattern.created_by != Meteor.userId()) // Only the owner can edit a pattern
      throw new Meteor.Error("not-authorized", "You can only edit cells in a pattern you created"); // try to prevent huge patterns that would fill up the database

    if (number_of_rows > Meteor.settings.private.max_pattern_rows) throw new Meteor.Error("too-many-rows", "error saving pattern. Too many rows.");
    if (number_of_tablets > Meteor.settings.private.max_pattern_tablets) throw new Meteor.Error("too-many-tablets", "error saving pattern. Too many tablets.");
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        twill_pattern_chart: JSON.stringify(data.twill_pattern_chart)
      }
    });
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        twill_change_chart: JSON.stringify(data.twill_change_chart)
      }
    });

    if (data.orientation) {
      Patterns.update({
        _id: pattern_id
      }, {
        $set: {
          orientation: JSON.stringify(data.orientation)
        }
      });
    }

    if (data.threading) {
      Patterns.update({
        _id: pattern_id
      }, {
        $set: {
          threading: JSON.stringify(data.threading)
        }
      });
    } // copied from save_weaving_to_db


    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        weaving: JSON.stringify(data.weaving)
      }
    }); // Record the number of rows

    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        number_of_rows: number_of_rows
      }
    }); // Record the number of tablets

    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        number_of_tablets: number_of_tablets
      }
    }); // Record the edit time

    Meteor.call("save_pattern_edit_time", pattern_id);
  },
  set_weaving_start_row: function (pattern_id, row_number) {
    check(pattern_id, String);
    check(row_number, Number);
    var pattern = Patterns.findOne({
      _id: pattern_id
    }, {
      fields: {
        created_by: 1,
        edit_mode: 1,
        weaving_start_row: 1,
        number_of_rows: 1
      }
    });
    if (pattern.created_by != Meteor.userId()) // Only the owner can edit a pattern
      throw new Meteor.Error("not-authorized", "You can only edit twill start row in a pattern you created");
    if (pattern.edit_mode !== "broken_twill") throw new Meteor.Error("not-authorized", "You can only set twill start row in a broken twill pattern");
    row_number = Math.floor(row_number);
    if (row_number < 1) throw new Meteor.Error("not-authorized", "Broken twill start row must be at least 1");
    if (row_number > pattern.number_of_rows) throw new Meteor.Error("not-authorized", "Broken twill start row cannot be greater than number of rows"); // Record the number of tablets

    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        weaving_start_row: row_number
      }
    }); // Record the edit time

    Meteor.call("save_pattern_edit_time", pattern_id);
  },
  //////////////////////////////////////
  // Recent patterns
  add_to_recent_patterns: function (pattern_id) {
    // Add a pattern to the Recent_Patterns list in the user's profile
    // If it's already in the list, update the accessed_at time
    check(pattern_id, String);
    if (!Meteor.userId()) // user is not signed in
      return;
    if (typeof Patterns.findOne({
      _id: pattern_id
    }, {
      fields: {
        _id: 1
      }
    }, {
      limit: 1
    }) === "undefined") return; // the pattern doesn't exist
    // create an empty array if there is no existing list of recent patterns for this user

    var recent_patterns = typeof Meteor.user().profile.recent_patterns === "undefined" ? [] : Meteor.user().profile.recent_patterns;
    var recent_pattern = {
      pattern_id: pattern_id,
      accessed_at: moment().valueOf(),
      // current time
      current_weave_row: 1 // is the pattern already in the list?

    };
    var index = -1;

    for (var i = 0; i < recent_patterns.length; i++) {
      if (recent_patterns[i].pattern_id == pattern_id) {
        index = i;
        break;
      }
    } // the pattern is not in the list, so add it


    if (index === -1) {
      recent_patterns.unshift(recent_pattern); // don't store too many patterns

      if (recent_patterns.length > Meteor.my_params.max_recents) recent_patterns.pop();
    } // the pattern is in the list, so update it
    else {
        // note the current weave row
        var stored_weave_row = recent_patterns[index].current_weave_row;
        if (typeof stored_weave_row === "number") recent_pattern.current_weave_row = stored_weave_row; // remove the existing occurence of the pattern

        recent_patterns.splice(index, 1); // and add the pattern as the most recent i.e. first element

        recent_patterns.unshift(recent_pattern);
      }

    var update = {};
    update["profile.recent_patterns"] = recent_patterns;
    Meteor.users.update({
      _id: Meteor.userId()
    }, {
      $set: update
    });
  },
  maintain_recent_patterns: function () {
    // remove any patterns that no longer exist or are now hidden from the user
    var recent_patterns = typeof Meteor.user().profile.recent_patterns === "undefined" ? [] : Meteor.user().profile.recent_patterns; // don't store too many patterns

    recent_patterns = recent_patterns.slice(0, Meteor.my_params.max_recents);
    var update = {};
    update["profile.recent_patterns"] = recent_patterns;
    Meteor.users.update({
      _id: Meteor.userId()
    }, {
      $set: update
    });
  },
  set_current_weave_row: function (pattern_id, index) {
    check(pattern_id, String);
    check(index, Number);
    if (!Meteor.userId()) return;
    if (index < 1) return;
    var pattern = Patterns.findOne({
      _id: pattern_id
    }, {
      fields: {
        _id: 1
      }
    });
    if (typeof pattern === "undefined") return;
    var number_of_rows = pattern.number_of_rows;
    if (index > number_of_rows) return;
    var recent_patterns = typeof Meteor.user().profile.recent_patterns === "undefined" ? [] : Meteor.user().profile.recent_patterns;

    for (var i = 0; i < recent_patterns.length; i++) {
      if (recent_patterns[i].pattern_id == pattern_id) {
        recent_patterns[i].current_weave_row = index;
        var update = {};
        update["profile.recent_patterns"] = recent_patterns;
        Meteor.users.update({
          _id: Meteor.userId()
        }, {
          $set: update
        });
        break;
      }
    }

    return;
  },
  ///////////////////////////////
  // uploaded images
  // Is there already an image with this key?
  does_image_exist: function (key, cb) {
    // check if the image already exists in the S3 bucket
    var s3 = new AWS.S3({
      accessKeyId: Meteor.settings.private.AWSAccessKeyId,
      secretAccessKey: Meteor.settings.private.AWSSecretAccessKey //,

    });
    var params = {
      Bucket: Meteor.settings.private.AWSBucket,
      // 'mybucket'
      Key: key // 'images/myimage.jpg'

    };
    var my_fn = Meteor.wrapAsync(s3.headObject, s3);
    var results = my_fn(params, function (err, data) {
      if (err) {
        throw new Meteor.Error("object does not exist with key " + key);
      } else {
        return data;
      }
    });
    return results; // callback doesn't seem to work, results has no data and appears before callback
  },
  // Slingshot has added a new image to Amazon S3. Now log in it the Images collection.
  upload_pattern_image: function (downloadUrl, pattern_id, role, width, height) {
    check(downloadUrl, NonEmptyString);
    check(pattern_id, NonEmptyString);
    check(role, NonEmptyString);
    check(width, Number);
    check(height, Number);
    var user = Meteor.user();
    if (!Meteor.userId()) return;
    if (!user.emails[0].verified) throw new Meteor.Error("not-authorized", "You can only upload images if you have a verified email address");
    var pattern = Patterns.findOne({
      _id: pattern_id
    }, {
      fields: {
        created_by: 1
      }
    });
    if (pattern.created_by != Meteor.userId()) throw new Meteor.Error("not-authorized", "You can only upload images for patterns you created");
    var count = Images.find({
      used_by: pattern_id
    }).count();

    if (Roles.userIsInRole(Meteor.userId(), 'premium', 'users')) {
      if (count >= Meteor.settings.public.max_images_per_pattern.premium) throw new Meteor.Error("limit-reached", "You cannot upload any more images for this pattern");
    } else {
      if (count >= Meteor.settings.public.max_images_per_pattern.verified) throw new Meteor.Error("limit-reached", "You cannot upload any more images for this pattern");
    }

    var bucket = Meteor.settings.private.AWSBucket;
    var region = Meteor.settings.public.AWSRegion; // Find the key by stripping out the first part of the image url

    var key = downloadUrl.replace('https://' + bucket + ".s3-" + region + '.amazonaws.com/', ''); // used to delete the object from AWS

    if (Images.find({
      key: key
    }).count() == 0) {
      // add the new object to the Images collection
      var image_id = Images.insert({
        url: downloadUrl,
        key: key,
        created_at: moment().valueOf(),
        // current time
        created_by: Meteor.userId(),
        // _id of logged in user
        created_by_username: Meteor.user().username,
        // username of logged in user
        used_by: pattern_id,
        role: role,
        width: width,
        height: height
      });
      return image_id;
    } else {
      // uploading a new version of an existing file, just update "created_at"
      var image_id = Images.findOne({
        key: key
      }, {
        fields: {
          _id: 1
        }
      });
      Images.update({
        _id: image_id
      }, {
        $set: {
          created_at: moment().valueOf()
        }
      });
    }
  },
  make_preview: function (image_id) {
    check(image_id, NonEmptyString); // Does the user have permission to remove this image?

    var image = Images.findOne({
      '_id': image_id
    });
    if (typeof image === "undefined") throw new Meteor.Error("not-found", "Image not found: " + image_id);
    if (image.created_by != Meteor.userId()) throw new Meteor.Error("not-authorized", "You can only remove an image you uploaded");
    if (image.role == "preview") return true;else {
      var pattern_id = image.used_by;

      try {
        var current_preview_id = Images.findOne({
          used_by: pattern_id,
          role: "preview"
        })._id; // remove any existing preview image


        Images.update({
          _id: current_preview_id
        }, {
          $set: {
            role: "image"
          }
        });
      } catch (err) {// no existing preview, nothing to do here
      }

      Images.update({
        _id: image_id
      }, {
        $set: {
          role: "preview"
        }
      });
    }
  },
  set_image_dimensions: function (image_id, width, height) {
    check(image_id, NonEmptyString);
    check(width, Number);
    check(height, Number); // Does the user have permission to edit this image?

    var image = Images.findOne({
      '_id': image_id
    });
    if (typeof image === "undefined") throw new Meteor.Error("not-found", "Image not found: " + image_id);
    if (image.created_by != Meteor.userId()) throw new Meteor.Error("not-authorized", "You can only edit an image you uploaded"); // landscape or portrait
    // constrain size

    var new_width = width;
    var new_height = height;
    Images.update({
      _id: image_id
    }, {
      $set: {
        width: new_width,
        height: new_height
      }
    });
  },
  remove_image: function (image_id) {
    check(image_id, NonEmptyString); // Does the user have permission to remove this image?

    var image = Images.findOne({
      '_id': image_id
    });
    if (typeof image === "undefined") throw new Meteor.Error("not-found", "Image not found: " + image_id);
    if (image.created_by != Meteor.userId()) throw new Meteor.Error("not-authorized", "You can only remove an image you uploaded"); // check for too many image removals too fast

    var document_id = Meteor.call('get_actions_log');
    var db_document = ActionsLog.findOne({
      _id: document_id
    }, {
      fields: {
        image_removed: 1,
        locked: 1
      }
    });
    var event_log = db_document.image_removed;
    if (db_document.locked) throw new Meteor.Error("account-locked", "Your account has been locked, please contact an administrator");
    var number_of_entries = event_log.length;
    var time_since_last_action = moment().valueOf() - event_log[0]; // try to detect automated image removes
    // A human shouldn't be able to removes 10 images in 2 seconds

    var last_10_actions_in = event_log[0] - event_log[9];

    if (last_10_actions_in < 2000) {
      ActionsLog.update({
        _id: document_id
      }, {
        locked: true
      });
      throw new Meteor.Error("account-locked", "Your account has been locked, please contact an administrator");
    }

    var last_5_actions_in = event_log[0] - event_log[4];

    if (last_5_actions_in < 2000) {
      // Don't allow another attempt for 5 minutes
      if (time_since_last_action < 60 * 1000 * 5) throw new Meteor.Error("too-many-requests", "Please wait 5 mins before retrying"); // it's been at least 5 mins so consider allowing another image upload
      else {
          var previous_5_actions_in = event_log[4] - event_log[9];

          if (previous_5_actions_in < 2000) {
            // if the 5 previous actions were in 2 seconds, wait 30 minutes
            // this looks like an automatic process that has tried continually
            if (time_since_last_action < 60 * 1000 * 30 + 4000) throw new Meteor.Error("too-many-requests", "Please wait 30 mins before retrying");
          }
        }
    } // record the action in the log


    ActionsLog.update({
      _id: document_id
    }, {
      $push: {
        image_removed: {
          $each: [moment().valueOf()],
          $position: 0
        }
      }
    });
    ; // remove the oldest log entry if too many stored

    if (number_of_entries > Meteor.settings.private.image_remove_num_to_log) {
      ActionsLog.update({
        _id: document_id
      }, {
        $pop: {
          image_removed: 1
        }
      });
    }

    var s3 = new AWS.S3({
      accessKeyId: Meteor.settings.private.AWSAccessKeyId,
      secretAccessKey: Meteor.settings.private.AWSSecretAccessKey //,

    });
    var params = {
      Bucket: Meteor.settings.private.AWSBucket,
      // 'mybucket'
      Key: image.key // 'images/myimage.jpg'

    };
    s3.deleteObject(params, Meteor.bindEnvironment(function (error, data) {
      if (!error) {
        Images.remove({
          _id: image_id
        });
      }
    }));
  },
  ///////////////////////////////
  // Edit pattern properties
  update_text_property: function (collection, object_id, property, value) {
    // used by the editable_field template
    // this function updates specified text properties of specified collections. It deliberately checks for known collections and properties to avoid unexpected database changes.
    check(object_id, NonEmptyString);
    check(collection, NonEmptyString);
    check(property, NonEmptyString);
    check(value, String);
    if (value.length > 6000) throw new Meteor.Error("not-authorized", "Value is too long");

    if (collection == "patterns") {
      var pattern = Patterns.findOne({
        _id: object_id
      }, {
        fields: {
          created_by: 1
        }
      });
      if (pattern.created_by != Meteor.userId()) throw new Meteor.Error("not-authorized", "You can only update patterns you created");

      switch (property) {
        case "name":
        case "description":
        case "weaving_notes":
        case "threading_notes":
          if (property == "name" && value == "") return; // pattern must have a name

          var update = {};
          update[property] = value; // this construction is necessary to handle a variable property name

          Patterns.update({
            _id: object_id
          }, {
            $set: update
          }); // Record the edit time

          Meteor.call("save_text_edit_time", object_id);
          return;

        default:
          throw new Meteor.Error("not-authorized", "Unknown property");
      }
    }

    if (collection == "images") {
      var image = Images.findOne({
        _id: object_id
      });
      var pattern = Patterns.findOne({
        _id: image.used_by
      });
      if (pattern.created_by != Meteor.userId()) throw new Meteor.Error("not-authorized", "You can only update patterns you created"); // *** TODO check user can edit pattern

      switch (property) {
        case "caption":
          var update = {};
          update[property] = value; // this construction is necessary to handle a variable property name

          Images.update({
            _id: object_id
          }, {
            $set: update
          });
          return;

        default:
          throw new Meteor.Error("not-authorized", "Unknown property");
      }
    }

    if (collection == "users") {
      // only the user can update their own profile
      if (object_id != Meteor.userId()) throw new Meteor.Error("not-authorized", "You can only change your own user details");

      switch (property) {
        case "description":
          // correct for me having messed up profiles by setting them as a text string not knowing it already existed
          // profile is an object to which editable properties may be added
          var profile = Meteor.users.findOne({
            _id: object_id
          }).profile;
          if (typeof profile === "undefined") profile = {};
          profile[property] = value;
          Meteor.users.update({
            _id: object_id
          }, {
            $set: {
              profile: profile
            }
          });
          return;

        case "email_address":
          if (value == "") return;
          var old_emails = Meteor.users.findOne({
            _id: object_id
          }).emails;
          if (old_emails) // user may have no emails
            var start_number = old_emails.length;else var start_number = 0;
          Accounts.addEmail(object_id, value); // I believe this runs synchronously because it is being called on the server
          // If addEmail doesn't throw an error, we can assume that either the new email was added, or it replaced one that was identical apart from case - in the latter case, verification status is unchanged. So the user should have an email address.

          var new_emails = Meteor.users.findOne({
            _id: object_id
          }).emails;
          if (new_emails) var end_number = new_emails.length;else var end_number = 0;

          if (end_number > start_number) // email was successfully added
            {
              // remove any other email addresses - user should only have one.
              for (var i = 0; i < new_emails.length; i++) {
                if (new_emails[i].address != value) Accounts.removeEmail(object_id, new_emails[i].address);
              } //Accounts.sendVerificationEmail(object_id);


              Meteor.call('sendVerificationEmail', object_id);
            }

          return;

        default:
          throw new Meteor.Error("not-authorized", "Unknown property");
      }
    }
  },
  save_text_edit_time: function (pattern_id) {
    check(pattern_id, String);
    Patterns.update({
      _id: pattern_id
    }, {
      $set: {
        text_edited_at: moment().valueOf()
      }
    });
  },

  ///////////////////////////////
  // user account management
  sendVerificationEmail(userId, email) {
    check(userId, NonEmptyString);
    check(email, Match.Optional(String));
    if (userId != Meteor.userId()) // Only the owner can request a verification email
      throw new Meteor.Error("not-authorized", "You can only request verification emails for your own email addresses"); // check for the user having requested too many emails in too short a time

    var document_id = Meteor.call('get_actions_log');
    var db_document = ActionsLog.findOne({
      _id: document_id
    }, {
      fields: {
        verification_email_sent: 1,
        locked: 1
      }
    });
    var event_log = db_document.verification_email_sent;
    if (db_document.locked) throw new Meteor.Error("account-locked", "Your account has been locked, please contact an administrator");
    var number_of_entries = event_log.length;
    var time_since_last_action = moment().valueOf() - event_log[0]; // try to detect automated email send
    // If the last 5 actions in a space of 1 second

    var last_5_actions_in = event_log[0] - event_log[4];

    if (last_5_actions_in < 2000) {
      // Don't allow another attempt for 5 minutes
      if (time_since_last_action < 60 * 1000 * 5) throw new Meteor.Error("too-many-requests", "Please wait 5 mins before retrying"); // it's been at least 5 mins so consider allowing another email
      else {
          var last_10_actions_in = event_log[0] - event_log[9];

          if (last_10_actions_in < 60 * 1000 * 5) {
            // if the last 10 actions in 5 minutes 4 seconds, wait 30 minutes
            // this looks like an automatic process that has tried continually
            if (time_since_last_action < 60 * 1000 * 30 + 4000) throw new Meteor.Error("too-many-requests", "Please wait 30 mins before retrying");
          }
        }
    } // try to prevent sending too many emails if the user hits the button repeatedly
    // If the last 3 actions in a space of 1 minute, wait 5 minutes


    var last_3_actions_in = event_log[0] - event_log[2];

    if (last_3_actions_in < 60000) {
      // Don't allow another attempt for 5 minutes
      if (time_since_last_action < 60 * 1000 * 5) throw new Meteor.Error("too-many-requests", "Please wait 5 mins before retrying");
    } // Lock the user's account if 20 emails requested in 30 minutes


    var last_20_actions_in = event_log[0] - event_log[29];

    if (last_20_actions_in < 60 * 1000 * 30) {
      ActionsLog.update({
        _id: document_id
      }, {
        locked: true
      });
      throw new Meteor.Error("account-locked", "Your account has been locked, please contact an administrator");
    } // send the email
    // record the action in the log


    ActionsLog.update({
      _id: document_id
    }, {
      $push: {
        verification_email_sent: {
          $each: [moment().valueOf()],
          $position: 0
        }
      }
    }); // remove the oldest log entry if too many stored

    if (number_of_entries > Meteor.settings.private.verification_emails_num_to_log) ActionsLog.update({
      _id: document_id
    }, {
      $pop: {
        verification_email_sent: 1
      }
    });
    if (typeof email !== "string") Accounts.sendVerificationEmail(Meteor.userId(), email);else Accounts.sendVerificationEmail(Meteor.userId());
  },

  // make sure the user has the correct role depending on whether their email address is verified
  update_user_roles(id) {
    check(id, String);
    if (Meteor.users.find({
      _id: id
    }).count() == 0) throw new Meteor.Error("not-found", "User width id " + id + "not found");
    var user = Meteor.users.findOne({
      _id: id
    });

    try {
      if (user.emails[0].verified) {
        Roles.addUsersToRoles(id, ['verified'], 'users');
      } else {
        Roles.removeUsersFromRoles(id, ['verified'], 'users');
      }
    } catch (err) {}
  },

  // return the action log for the current user
  // add a blank if none exists
  get_actions_log() {
    if (ActionsLog.find({
      user_id: Meteor.userId()
    }).count() == 0) return ActionsLog.insert({
      user_id: Meteor.userId(),
      username: Meteor.user().username,
      verification_email_sent: [],
      image_uploaded: [],
      image_removed: []
    });else return ActionsLog.findOne({
      user_id: Meteor.userId()
    })._id;
  },

  ///////////////////////////////
  // IMPORTANT!! Only works if "debug"
  // Meteor.call("debug_validate_email", Meteor.userId(), true)
  debug_validate_email(user_id, validated) {
    if (!Meteor.settings.private.debug) return;
    var emails = Meteor.users.findOne({
      _id: user_id
    }).emails;
    emails[0]["verified"] = validated;
    var update = {};
    update["emails"] = emails;
    Meteor.users.update({
      _id: user_id
    }, {
      $set: update
    });
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publish.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/publish.js                                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
// with fastrender, params are passed in as an object.
// there is a subscription that passes in [] as params and I can't find where it is called. The current version of Match avoids error when this empty array is passed in, and everything seems to work. The issue occurs at first load or page refresh, not on navigating routes.
// if (typeof params !== "undefined") console.log(`i ${params.i}`); // test rate limit DO NOT SHIP THIS
// fastrender causes the production server to show "incomplete response from application" error. A workaround is to modify the core package minifier.js to reserve keywords
// https://github.com/abecks/meteor-fast-render/issues/2
// update: meteor --production --settings settings.json should simulate the minification locally where the server output can be viewed. However the app does not crash, it just generates the same Match failure in publish.js.
// Data for search
Meteor.publish('search_patterns', function () {
  fields = {
    _id: 1,
    created_by_username: 1,
    name: 1,
    name_sort: 1,
    number_of_tablets: 1,
    tags: 1
  };
  if (this.userId) return Patterns.find({
    $or: [{
      private: {
        $ne: true
      }
    }, {
      created_by: this.userId
    }]
  }, {
    fields: fields
  });else return Patterns.find({
    private: {
      $ne: true
    }
  }, {
    fields: fields
  });
});
Meteor.publish('search_users', function () {
  var update = {};
  update["profile.public_patterns_count"] = {
    $gt: 0
  }; // this construction is required to query a child property

  if (this.userId) return Meteor.users.find({
    $or: [update, {
      _id: this.userId
    }]
  }, {
    fields: {
      _id: 1,
      profile: 1,
      username: 1
    }
  });else return Meteor.users.find({
    $or: [update]
  }, {
    fields: {
      _id: 1,
      profile: 1,
      username: 1
    }
  });
}); // Single pattern

Meteor.publish('pattern', function (params) {
  check(params, Object);
  check(params.pattern_id, String);
  if (this.userId) return Patterns.find({
    $and: [{
      _id: params.pattern_id
    }, {
      $or: [{
        private: {
          $ne: true
        }
      }, {
        created_by: this.userId
      }]
    }]
  }, {
    limit: 1
  });else return Patterns.find({
    $and: [{
      _id: params.pattern_id
    }, {
      private: {
        $ne: true
      }
    }]
  }, {
    limit: 1
  });
}); // Recent Patterns for Home page

Meteor.publish('recent_patterns', function (params) {
  check(params, Object);
  var pattern_ids = typeof params.pattern_ids === "undefined" ? [] : params.pattern_ids;
  var fields = {
    _id: 1,
    auto_preview: 1,
    created_at: 1,
    created_by: 1,
    created_by_username: 1,
    description: 1,
    name: 1,
    name_sort: 1,
    number_of_tablets: 1,
    private: 1
  };
  if (this.userId) return Patterns.find({
    $and: [{
      _id: {
        $in: params.pattern_ids
      }
    }, {
      $or: [{
        private: {
          $ne: true
        }
      }, {
        created_by: this.userId
      }]
    }]
  }, {
    limit: Meteor.my_params.max_recents,
    fields: fields
  });else return Patterns.find({
    $and: [{
      _id: {
        $in: params.pattern_ids
      }
    }, {
      private: {
        $ne: true
      }
    }]
  }, {
    limit: Meteor.my_params.max_recents,
    fields: fields
  });
}); // New Patterns for Home page

Meteor.publish('new_patterns', function () {
  var fields = {
    _id: 1,
    auto_preview: 1,
    created_at: 1,
    created_by: 1,
    created_by_username: 1,
    description: 1,
    name: 1,
    name_sort: 1,
    number_of_tablets: 1,
    private: 1
  };
  if (this.userId) return Patterns.find({
    $or: [{
      private: {
        $ne: true
      }
    }, {
      created_by: this.userId
    }]
  }, {
    limit: Meteor.my_params.max_home_thumbnails,
    sort: {
      created_at: -1
    },
    fields: fields
  });else return Patterns.find({
    private: {
      $ne: true
    }
  }, {
    limit: Meteor.my_params.max_home_thumbnails,
    sort: {
      created_at: -1
    },
    fields: fields
  });
}); // My Patterns for Home page

Meteor.publish('my_patterns', function () {
  var fields = {
    _id: 1,
    auto_preview: 1,
    created_at: 1,
    created_by: 1,
    created_by_username: 1,
    description: 1,
    name: 1,
    name_sort: 1,
    number_of_tablets: 1,
    private: 1
  };
  if (this.userId) return Patterns.find({
    created_by: this.userId
  }, {
    limit: Meteor.my_params.max_home_thumbnails,
    sort: {
      name_sort: 1
    },
    fields: fields
  });else return [];
}); // All Patterns for Home page

Meteor.publish('all_patterns', function () {
  var fields = {
    _id: 1,
    auto_preview: 1,
    created_at: 1,
    created_by: 1,
    created_by_username: 1,
    description: 1,
    name: 1,
    name_sort: 1,
    number_of_tablets: 1,
    private: 1
  };
  if (this.userId) return Patterns.find({
    $or: [{
      private: {
        $ne: true
      }
    }, {
      created_by: this.userId
    }]
  }, {
    limit: Meteor.my_params.max_home_thumbnails,
    sort: {
      name_sort: 1
    },
    fields: fields
  });else return Patterns.find({
    private: {
      $ne: true
    }
  }, {
    limit: Meteor.my_params.max_home_thumbnails,
    sort: {
      name_sort: 1
    },
    fields: fields
  });
}); // Single user

Meteor.publish('user', function (params) {
  check(params, Object);
  check(params.user_id, String); // the user's emails will be returned but for other users, only public information should be shown.

  var update = {};
  update["profile.public_patterns_count"] = {
    $gt: 0
  }; // this construction is required to query a child property

  update["id"] = params.user_id;
  return Meteor.users.find({
    $or: [update, {
      _id: this.userId
    }]
  }, {
    limit: 1,
    sort: {
      "profile.name_sort": 1
    },
    fields: {
      _id: 1,
      username: 1,
      profile: 1
    }
  });
}); // Users for Home page

Meteor.publish('users_home', function (trigger) {
  // show the current user and any users who have public patterns
  check(trigger, Match.Optional(Number)); // the user's emails will be returned but for other users, only public information should be shown.

  var update = {};
  update["profile.public_patterns_count"] = {
    $gt: 0
  }; // this construction is required to query a child property

  if (this.userId) return Meteor.users.find({
    $or: [update, {
      _id: this.userId
    }]
  }, {
    limit: Meteor.my_params.max_home_thumbnails,
    sort: {
      "profile.name_sort": 1
    },
    fields: {
      _id: 1,
      username: 1,
      profile: 1
    }
  });else return Meteor.users.find({
    $or: [update]
  }, {
    limit: Meteor.my_params.max_home_thumbnails,
    sort: {
      "profile.name_sort": 1
    },
    fields: {
      _id: 1,
      username: 1,
      profile: 1
    }
  });
}); // Publish images uploaded by the user

Meteor.publish('images', function (params) {
  return Images.find();
});
Meteor.publish('tags', function () {
  // The collection is readonly and all tags should be public
  return Meteor.tags.find();
}); // Debug only - show log of user actions
// to access this, subscribe in the client with:
// Meteor.subscribe('actions_log')

Meteor.publish('actions_log', function () {
  if (!Meteor.settings.private.debug) return;
  return ActionsLog.find();
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"main.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// main.js                                                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
if (Meteor.isClient) {
  // configure the default accounts-ui package
  Accounts.ui.config({
    passwordSignupFields: "USERNAME_AND_EMAIL"
  });
  Session.set('window_width', $(window).width());
  Session.set('window_height', $(window).height());
  Meteor.startup(function () {
    Session.set('click_latch', false); // used to prevent double click on buttons

    Session.set("loading", false);
    window.addEventListener('resize', function () {
      Session.set('window_width', $(window).width());
      Session.set('window_height', $(window).height());
      Session.set('thumbnails_in_row', Meteor.my_functions.thumbnails_in_row());
    });
    Session.set('display_min_tablets', 1);
  }); //////////////////////////////
  // enable search

  Template.header.created = function () {
    this.subscribe('search_patterns');
    this.subscribe('search_users');
  }; //////////////////////////////
  // Helpers for templates that may be used on multiple pages
  /* *** Loading template *** */

  Template.loading.rendered = function () {
    $('body').attr("class", "loading");
    Meteor.my_functions.initialize_route();
  };

  Template.main_layout.rendered = function () {
    // main template contains the header and width divs
    $(window).on('resize orientationchange', function (e) {
      Meteor.my_functions.resize_page();
    });
    $("#width").on('scroll', function (e) {
      Meteor.my_functions.resize_page();
    });
  };

  Template.main_layout.helpers({
    loading: function () {
      if (Session.equals('loading', true)) return "loading";
    }
  }); /* *** Helper functions that may be used by more than one template *** */ // Allows a template to check whether a helper value equals a string

  UI.registerHelper('equals', function (a, b) {
    return a === b;
  });
  UI.registerHelper('multiply', function (a, b) {
    return a * b;
  }); // allows a template to check whether a session variable equals a value

  UI.registerHelper('session_equals', function (session_var, test_value) {
    if (Session.get(session_var) == test_value) return true;else return false;
  });
  UI.registerHelper('is_cordova', function () {
    if (Meteor.isCordova) return true;
  });
  UI.registerHelper('show_editable_field', function (field_value, _id) {
    // editable field such as pattern description is shown if:
    // the user can edit the pattern, or
    // a string value exists and is not empty
    if (Meteor.my_functions.can_edit_pattern(_id)) return true;
    return Meteor.my_functions.string_exists(field_value);
  });
  UI.registerHelper('string_exists', function (value) {
    return Meteor.my_functions.string_exists(value);
  }); // used by connection_status template and also to apply class to div#width

  UI.registerHelper('connection_status', function () {
    /* meteor.status().status can have these values:
      connected
      connecting (disconnnected, trying to connect)
      failed (permainently failed e.g. incompatible)
      waiting (will try to reconnect)
      offline (user disconnected the connection)
    */ // there is a 3 second delay before reporting connection lost, partly to avoid a false 'connection lost' message when the page is first loaded.
    switch (Meteor.status().status) {
      case "connecting": // Fallthrough

      case "waiting":
        if (typeof connection_timeout === "undefined") connection_timeout = setTimeout(function () {
          Session.set("connection_status", "trying_to_connect");
        }, 3000);
        break;

      case "failed": // Fallthrough

      case "offline":
        if (typeof disconnected_timeout === "undefined") disconnected_timeout = setTimeout(function () {
          Session.set("connection_status", "disconnected");
        }, 3000);
        Session.set("connection_status", "disconnected");
        break;

      case "connected":
        Session.set("connected", true);
        if (typeof connection_timeout !== "undefined") clearTimeout(connection_timeout);
        if (typeof disconnected_timeout !== "undefined") clearTimeout(disconnected_timeout);
        Session.set("connection_status", "connected");
        break;

      default:
        Session.set("connection_status", "disconnected");
        break;
    }

    return Session.get("connection_status");
  });
  UI.registerHelper('no_weaving_rows', function () {
    // cannot remove a row from pattern, and
    // cannot view interactive weaving chart because no rows woven
    // can only happen in manual simulation pattern
    // avoids error when pattern is private and user doesn't have permission to see it
    var pattern_id = Router.current().params._id;

    if (!Meteor.my_functions.pattern_exists(pattern_id)) return "disabled";
    var pattern = Patterns.findOne({
      _id: pattern_id
    }, {
      fields: {
        number_of_rows: 1
      }
    });
    if (pattern.number_of_rows < 1) return "disabled";
  });
  UI.registerHelper('includes_idle', function () {
    // does the pattern contain any idle tablets? Used in key
    var pattern_id = Router.current().params._id;

    if (!Meteor.my_functions.pattern_exists(pattern_id)) return;
    var pattern = Patterns.findOne({
      _id: pattern_id
    }, {
      fields: {
        weaving: 1
      }
    });
    if (pattern.weaving.indexOf("S15") != -1) // idle tablet special style
      return true;else return false;
  }); //////////////////////////////////
  // Used in header to display correct buttons and title depending on route and params
  // Used in menu to determine menu entries

  UI.registerHelper('route_name', function () {
    return Router.current().route.getName();
  }); //////////////////////////////////
  // turn off / show manually activated 'Loading...' indicator

  UI.registerHelper('rendered_manual', function () {
    // call this in the template to hide "loading..."
    Session.set("loading", false);
    return true;
  }); //////////////////////////////////
  // Simulation patterns

  UI.registerHelper('edit_mode', function () {
    if (Router.current().route.getName() == "pattern") {
      return Session.get("edit_mode");
    }
  });
  UI.registerHelper('simulation_mode', function () {
    if (Router.current().route.getName() == "pattern") return Session.get("simulation_mode");
  });
  UI.registerHelper('does_pattern_repeat', function () {
    var pattern_id = Router.current().params._id;

    return Meteor.my_functions.does_pattern_repeat(pattern_id);
  }); //////////////////////////////////
  // provide lists of patterns in different categories
  // requestPage(1) works around a bug in alethes-pages introduced with the Meteor 1.3 upgrade, in which if you have more than 2 or 3 paginated objects, only the first few that were defined will work.
  // https://github.com/alethes/meteor-pages/issues/208

  Template.new_patterns.onRendered(function () {
    NewPatterns.requestPage(1);
  });
  Template.my_patterns.onRendered(function () {
    MyPatterns.requestPage(1);
  });
  Template.all_patterns.onRendered(function () {
    AllPatterns.requestPage(1);
  });
  Template.user.onRendered(function () {
    UserPatterns.requestPage(1);
  }); ////////////////////
  // used to check page is sufficiently rendered for number of thumbnails to have been calculated

  UI.registerHelper('thumbnails_in_row', function () {
    return Session.get('thumbnails_in_row');
  });
  UI.registerHelper('auto_preview_svg', function () {
    var data = this.auto_preview; //console.log("data " + data);

    var src = 'data:image/svg+xml;base64,' + window.btoa(data);
    return src;
  });
  UI.registerHelper('my_patterns', function () {
    if (!Meteor.userId()) return;
    var obj = {
      'sort': {
        'name': 1
      },
      'limit': Session.get('thumbnails_in_row')
    };
    return Patterns.find({
      created_by: Meteor.userId()
    }, obj);
  });
  UI.registerHelper('new_patterns', function () {
    var obj = {
      'sort': {
        'created_at': -1
      },
      'limit': Session.get('thumbnails_in_row')
    };
    return Patterns.find({}, obj);
  });
  UI.registerHelper('all_patterns', function () {
    var obj = {
      'sort': {
        'name': 1
      },
      'limit': Session.get('thumbnails_in_row')
    };
    return Patterns.find({}, obj);
  });
  UI.registerHelper('users', function () {
    var obj = {
      'sort': {
        'profile.name_sort': 1
      },
      'limit': Session.get('thumbnails_in_row')
    };
    return Meteor.users.find({}, obj);
  }); // *** has the user permission to create a new pattern? *** //

  UI.registerHelper('can_create_pattern', function () {
    return Meteor.my_functions.can_create_pattern();
  });
  UI.registerHelper('view_pattern_mode', function () {
    return Session.get('view_pattern_mode');
  });
  Template.left_column.helpers({
    selected: function (item) {
      var route = Router.current().route.getName();

      switch (item) {
        case "home":
        case "recent_patterns":
        case "new_patterns":
        case "my_patterns":
        case "all_patterns":
        case "users":
          if (route == item) return "selected";
          break;
      }
    }
  }); ////////////////////////////////////

  Template.search.helpers({
    indexes: function () {
      return [patternsIndex, usersIndex];
    },
    patternsIndex: function () {
      return patternsIndex;
    },
    usersIndex: function () {
      return usersIndex;
    },
    attributes: function () {
      if (Session.get('window_width') > 650) return {
        'class': 'easy-search-input',
        'placeholder': 'Search...'
      };else if (Session.get('window_width') < 460) return {
        'class': 'easy-search-input',
        'placeholder': ''
      };else return {
        'class': 'easy-search-input',
        'placeholder': 'Search...'
      };
    },
    search_term: function () {
      return patternsIndex.getComponentDict().get('searchDefinition');
    },
    pattern_results_count: function () {
      return patternsIndex.getComponentDict().get('count');
    },
    users_results_count: function () {
      return usersIndex.getComponentDict().get('count');
    },
    css_class: function () {
      if (Session.get('window_width') > 650) return "wide";else if (Session.get('window_width') < 460) return "narrow";
    },
    more_patterns: function () {
      if (patternsIndex.getComponentMethods().hasMoreDocuments()) return true;
    },
    more_users: function () {
      if (usersIndex.getComponentMethods().hasMoreDocuments()) return true;
    }
  });
  Template.search.onRendered(function () {
    // do not remove these handlers with $('body').off("click") or $(window).off("keyup"), as it prevents these being registered on any elements directly attached to body such as the "email just verified" dialog in accounts-ui-unstyled
    $('body').on("click", function (event) {
      // close the results list if the user clicks outside it
      // if the results list is shown
      if ($('#search .results-wrapper').length != 0) {
        // did the user click outside the results list
        var results_list = $('.results-wrapper');

        if (!results_list.is(event.target) // if the target of the click isn't the container...
        && results_list.has(event.target).length === 0) // ... nor a descendant of the container
          {
            // but not in the search input?
            var input = $('#search .input-wrapper input.easy-search-input');

            if (!input.is(event.target) && input.has(event.target).length === 0) {
              Meteor.my_functions.hide_search_results();
            }
          }
      }
    });
    $(window).on("keyup", function (event) {
      // close the results list if the user presses 'Esc'
      // if the results list is shown
      if ($('#search .results-wrapper').length != 0) {
        if (event.which == 27) // user pressed 'Esc'
          Meteor.my_functions.hide_search_results();
      }
    });
  });
  Template.search.events({
    'click li': function () {
      // clear the search when you select a result
      $('input.easy-search-input').val("");
      Meteor.my_functions.hide_search_results();
    },
    'click #load_more_patterns': function (event) {
      if (patternsIndex.getComponentMethods().hasMoreDocuments()) patternsIndex.getComponentMethods().loadMore(8);
    },
    'click #load_more_users': function (event) {
      if (usersIndex.getComponentMethods().hasMoreDocuments()) usersIndex.getComponentMethods().loadMore(8);
    },
    'click #search .pattern_results': function (event) {
      event.preventDefault(); // to make router work from Home, not sure why but this is necessary when not already in pattern route

      Meteor.my_functions.search_result_clicked(this._id);
    }
  });
  UI.registerHelper('is_weaving', function () {
    if (Router.current().params.mode == "weaving") return true;
  }); // this checks not only whether user_id is null but also whether the user curently has permission to see this user

  UI.registerHelper('user_exists', function (user_id) {
    return Meteor.users.find({
      _id: user_id
    }).count() != 0;
  });
  UI.registerHelper('pattern_exists', function (pattern_id) {
    if (Patterns.find({
      _id: pattern_id
    }, {
      fields: {
        _id: 1
      }
    }, {
      limit: 1
    }).count() != 0) return true;
  });
  UI.registerHelper('app_name_in_header', function (pattern_id) {
    switch (Router.current().route.getName()) {
      case "home":
      case "recent_patterns":
      case "new_patterns":
      case "my_patterns":
      case "all_patterns":
      case "users":
        return true;
        break;
    }
  }); ///////////////////////////////
  // menu

  UI.registerHelper('menu_open', function () {
    if (Session.equals('menu_open', true)) return "open";
  });
  UI.registerHelper('can_edit_pattern', function (pattern_id) {
    return Meteor.my_functions.can_edit_pattern(pattern_id);
  }); ///////////////////////////////////
  // Menu - options for selected pattern

  Template.menu.helpers({
    show_menu: function (subscriptionsReady, route_name, pattern_id) {
      return true; // there is now always at least one menu option
      /*if (Meteor.userId()) // account settings is available to any signed in user
        return true;
       if (subscriptionsReady && (route_name == "pattern") && (Patterns.find({ _id: pattern_id}).count() != 0)) // printer friendly view is available
        return true;
       else
        return false;*/ /* show the menu if:
                        * the user is signed in (Account settings)
                        // file loading is supported by the browser and the user is signed in,
                        // OR the user is viewing a specific pattern
                        // if the user is not signed in, the only available menu option is to view the printer-friendly pattern
                        // import, copy and export pattern are only available to users who can create patterns
                        */ /*if ((Meteor.my_functions.is_file_loading_supported() && Meteor.my_functions.can_create_pattern()) || (subscriptionsReady && (route_name == "pattern") && (Patterns.find({ _id: pattern_id}).count() != 0)))
                             return true;*/
    },
    is_file_loading_supported: function () {
      if (Meteor.my_functions.is_file_loading_supported() && Meteor.my_functions.can_create_pattern()) return true;else return false;
    }
  });
  Template.menu.events({
    'click #menu_button': function () {
      if (Session.equals('menu_open', true)) Session.set('menu_open', false);else Session.set('menu_open', true);
    },
    'click #menu .menu_list ul li a': function () {
      Session.set('menu_open', false);
    },
    // import a pattern from a JSON file
    'click #import_pattern': function () {
      Session.set('show_import_pattern', true);
    },
    // copy this pattern to a new pattern
    // if route="pattern", the template _id is a pattern_id
    'click #copy_pattern': function (event, template) {
      if (Router.current().route.getName() == "pattern") {
        Meteor.my_functions.copy_pattern(template.data._id);
      }
    },
    // display this pattern as JSON
    'click #export_pattern': function () {
      Session.set('show_pattern_as_text', true);
    }
  }); // Import pattern from file
  // Dialog to choose which type of file to import

  Template.import_pattern_dialog.helpers({
    'show_import_pattern': function () {
      if (Session.equals('show_import_pattern', true)) return "visible";
    },
    'checked': function (name) {
      if (Session.equals('import_file_type', name)) return "true";
    },
    'disabled': function () {
      if (typeof Session.get('import_file_type') === "undefined") return "disabled";
    }
  });
  Template.import_pattern_dialog.events({
    'click #import_pattern_dialog .close': function (event) {
      Session.set('show_import_pattern', false);
    },
    'click #import_pattern_dialog .continue': function (event) {
      $('#file_picker').trigger('click');
      Session.set('show_import_pattern', false);
    },
    'change [name="file_type"]': function () {
      var file_types = document.getElementsByName('file_type');
      var selected_type;

      for (var i = 0; i < file_types.length; i++) {
        if (file_types[i].checked) {
          selected_type = file_types[i].value;
        }
      }

      Session.set('import_file_type', selected_type);
    }
  }); // Import a file

  Template.import_file_picker.events({
    'change input#file_picker': function (event) {
      // Check for the various File API support.
      if (Meteor.my_functions.is_file_loading_supported()) {
        var files = event.target.files; // FileList object

        f = files[0];
        var reader = new FileReader(); // Closure to capture the file information.

        reader.onload = function (theFile) {
          return function (e) {
            // find the filename so it can be used as a fallback pattern name
            // e.g. GTT files don't always have a name
            var filename = Meteor.my_functions.trim_file_extension(theFile.name); // be cautious about uploading large files

            if (theFile.size > 1000000) alert("Unable to load a file larger than 1MB");

            switch (Session.get('import_file_type')) {
              case "JSON":
                JsonObj = JSON.parse(e.target.result);
                Meteor.my_functions.import_pattern_from_json(JsonObj);
                break;

              case "GTT":
                Meteor.my_functions.import_pattern_from_gtt(e.target.result, filename);
                break;

              default:
                alert("Unrecognised file type, cannot import pattern");
                break;
            }
          };
        }(f); // Read in the image file as a data URL.


        reader.readAsText(f); // reset the form so that the same file can be loaded twice in succession

        $(event.target).wrap('<form>').closest('form').get(0).reset();
        $(event.target).unwrap(); // Prevent form submission

        event.stopPropagation();
        event.preventDefault();
      }
    }
  }); ///////////////////////////////////
  // 'view pattern as text' (e.g. JSON) dialog

  Template.pattern_as_text.helpers({
    'show_pattern_as_text': function () {
      if (Session.equals('show_pattern_as_text', true)) return "visible";
    },
    'pattern_as_json': function () {
      if (Session.equals('show_pattern_as_text', false)) return;
      var pattern_id = this._id;
      var pattern_as_text = JSON.stringify(Meteor.my_functions.export_pattern_to_json(pattern_id), null, '\t'); // prettify JSON with tabs
      // make arrays more readable by removing new lines, spaces and tabs within them. But don't alter arrays of objects (styles).

      var original_arrays = [];
      var new_arrays = [];
      var re = /\[[^\][^\}]*?\]/g; // find text between [], may contain new lines http://stackoverflow.com/questions/6108555/replace-text-inside-of-square-brackets
      // ignore text containing [] or {}, i.e. nested brackets and objects in arrays

      for (m = re.exec(pattern_as_text); m; m = re.exec(pattern_as_text)) {
        original_arrays.push(m[0]);
        var this_array = m[0]; //this_array = this_array.replace(/ /g,'');// original, works but strips spaces from inside strings such as tags
        /*this_array.replace(/([^"]+)|("(?:[^"\\]|\\.)+")/, function($0, $1, $2) {
            if ($1) {
                return $1.replace(/\s/g, '');
            } else {
                return $2; 
            } 
        });*/ // works but long, from same source as below
        // remove spaces except for those between double quotes
        // http://stackoverflow.com/questions/14540094/javascript-regular-expression-for-removing-all-spaces-except-for-what-between-do

        var regex = /"[^"]+"|( )/g;
        this_array.replace(regex, function (m, group1) {
          if (group1 == "") return m;else return "";
        });
        this_array = this_array.replace(/\t/g, ''); //remove tabs

        this_array = this_array.replace(/(\r\n|\n|\r)/gm, ""); // line break removal http://www.textfixer.com/tutorials/javascript-line-breaks.php

        new_arrays.push(this_array);
      }

      for (var i = 0; i < original_arrays.length; i++) {
        pattern_as_text = pattern_as_text.split(original_arrays[i]).join(new_arrays[i]); // replace text http://stackoverflow.com/questions/5334380/replacing-text-inside-of-curley-braces-javascript
      }

      return pattern_as_text;
    }
  });
  Template.pattern_as_text.events({
    'click #pattern_as_text .close': function () {
      Session.set('show_pattern_as_text', false);
    },
    'click #pattern_as_text .select': function () {
      $('#pattern_as_text textarea').select();
    }
  }); ///////////////////////////////
  // row being edited in simulation pattern

  UI.registerHelper('row_to_edit', function () {
    return Session.get("row_to_edit");
  }); ///////////////////////////////////
  // reacting to database changes

  Tracker.autorun(function (computation) {
    // detect login / logout
    var currentUser = Meteor.user();

    if (currentUser) {
      if (!Session.equals('was_signed_in', true)) {
        Session.set('was_signed_in', true);
        setTimeout(function () {
          Meteor.my_functions.resize_page();
        }, 20);
      }
    } else if (!computation.firstRun) {
      // avoid useless logout detection on app startup
      if (Session.equals('was_signed_in', true)) {
        Session.set('was_signed_in', false);
        setTimeout(function () {
          Meteor.my_functions.resize_page();
        }, 20);
      }
    }
  });
  Tracker.autorun(function (computation) {
    // Filters
    var max = Session.get('display_max_tablets');
    var min = Session.get('display_min_tablets');

    if (min || max) {
      // All Patterns
      var filter = jQuery.extend({}, AllPatterns.filters);
      AllPatterns.set({
        filters: Meteor.my_functions.set_tablets_filter(filter, min, max)
      }); // New Patterns

      var filter = jQuery.extend({}, NewPatterns.filters);
      NewPatterns.set({
        filters: Meteor.my_functions.set_tablets_filter(filter, min, max)
      }); // My Patterns

      var filter = jQuery.extend({}, MyPatterns.filters);
      MyPatterns.set({
        filters: Meteor.my_functions.set_tablets_filter(filter, min, max)
      }); // User Patterns

      var filter = jQuery.extend({}, UserPatterns.filters);
      UserPatterns.set({
        filters: Meteor.my_functions.set_tablets_filter(filter, min, max)
      });
    }
  });
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./lib/schemas/actions-log.js");
require("./lib/schemas/images.js");
require("./lib/schemas/patterns.js");
require("./lib/db_setup.js");
require("./lib/default_pattern_data.js");
require("./lib/mixins.js");
require("./lib/params.js");
require("./lib/slingshot.js");
require("./router/routes.js");
require("./server/init.js");
require("./server/methods.js");
require("./server/publish.js");
require("./main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvbGliL3NjaGVtYXMvYWN0aW9ucy1sb2cuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2xpYi9zY2hlbWFzL2ltYWdlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvbGliL3NjaGVtYXMvcGF0dGVybnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2xpYi9kYl9zZXR1cC5qcyIsIm1ldGVvcjovL/CfkrthcHAvbGliL2RlZmF1bHRfcGF0dGVybl9kYXRhLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvbWl4aW5zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvcGFyYW1zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvc2xpbmdzaG90LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9yb3V0ZXIvcm91dGVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvaW5pdC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9wdWJsaXNoLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9tYWluLmpzIl0sIm5hbWVzIjpbIkFjdGlvbnNMb2ciLCJNZXRlb3IiLCJDb2xsZWN0aW9uIiwiU2NoZW1hIiwiU2ltcGxlU2NoZW1hIiwidXNlcl9pZCIsInR5cGUiLCJTdHJpbmciLCJsYWJlbCIsInVzZXJuYW1lIiwibG9ja2VkIiwiQm9vbGVhbiIsIm9wdGlvbmFsIiwidmVyaWZpY2F0aW9uX2VtYWlsX3NlbnQiLCJOdW1iZXIiLCJpbWFnZV91cGxvYWRlZCIsImltYWdlX3JlbW92ZWQiLCJhdHRhY2hTY2hlbWEiLCJJbWFnZXMiLCJ1cmwiLCJrZXkiLCJjYXB0aW9uIiwiY3JlYXRlZF9hdCIsImNyZWF0ZWRfYnkiLCJjcmVhdGVkX2J5X3VzZXJuYW1lIiwidXNlZF9ieSIsInJvbGUiLCJ3aWR0aCIsImhlaWdodCIsIm5hbWUiLCJmaWVsZCIsImlzU2V0IiwidmFsdWUiLCJ0b0xvd2VyQ2FzZSIsInVuc2V0IiwiUGF0dGVybnMiLCJpc1NlcnZlciIsInJhd0NvbGxlY3Rpb24iLCJjcmVhdGVJbmRleCIsIlVzZXJzIiwiUGFnaW5hdGlvbiIsInVzZXJzIiwiaXRlbVRlbXBsYXRlIiwidGVtcGxhdGVOYW1lIiwicGVyUGFnZSIsImF2YWlsYWJsZVNldHRpbmdzIiwiZmlsdGVycyIsInNvcnQiLCJhdXRoIiwic2tpcCIsInN1YiIsInVzZXJTZXR0aW5ncyIsIl9zZXNzaW9uIiwiaWQiLCJ1c2VyRmlsdGVycyIsInVwZGF0ZSIsIiRndCIsInVzZXJJZCIsIl9maWx0ZXJzIiwiXyIsImV4dGVuZCIsIiRvciIsIl9pZCIsIl9vcHRpb25zIiwibGltaXQiLCJmaWVsZHMiLCJkZW55IiwiVGFncyIsIlRhZ3NNaXhpbiIsImFsbG93VGFncyIsInBhdHRlcm5zSW5kZXgiLCJFYXN5U2VhcmNoIiwiSW5kZXgiLCJjb2xsZWN0aW9uIiwiZGVmYXVsdFNlYXJjaE9wdGlvbnMiLCJlbmdpbmUiLCJNaW5pbW9uZ28iLCJ1c2Vyc0luZGV4IiwiVXNlclBhdHRlcm5zIiwicHJpdmF0ZSIsIiRuZSIsIm5hbWVfc29ydCIsImF1dG9fcHJldmlldyIsImRlc2NyaXB0aW9uIiwibnVtYmVyX29mX3RhYmxldHMiLCJNeVBhdHRlcm5zIiwiQWxsUGF0dGVybnMiLCJOZXdQYXR0ZXJucyIsImRlZmF1bHRfcGF0dGVybl9kYXRhIiwiTm9uRW1wdHlTdHJpbmciLCJNYXRjaCIsIldoZXJlIiwieCIsImNoZWNrIiwibGVuZ3RoIiwibXlfcGFyYW1zIiwidW5kb19zdGFja19sZW5ndGgiLCJzcGVjaWFsX3N0eWxlc19udW1iZXIiLCJwYXR0ZXJuX3RodW1ibmFpbF93aWR0aCIsInBhdHRlcm5fdGh1bWJuYWlsX3JtYXJnaW4iLCJtYXhfcmVjZW50cyIsIm1heF9ob21lX3RodW1ibmFpbHMiLCJtYXhfYXV0b190dXJucyIsIm51bWJlcl9vZl9wYWNrcyIsImRlZmF1bHRfcGF0dGVybl9uYW1lIiwiZGVmYXVsdF9zcGVjaWFsX3N0eWxlcyIsImlzQ2xpZW50IiwidXBsb2FkZXIiLCJSZWFjdGl2ZVZhciIsImN1cnJlbnRVc2VySWQiLCJTZXNzaW9uIiwic2V0IiwiVGVtcGxhdGUiLCJpbWFnZV91cGxvYWRlciIsImV2ZW50cyIsImV2ZW50IiwidGVtcGxhdGUiLCJwcmV2ZW50RGVmYXVsdCIsInBhdHRlcm5faWQiLCJSb3V0ZXIiLCJjdXJyZW50IiwicGFyYW1zIiwiZmlsZSIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJmaWxlcyIsIm15X2Z1bmN0aW9ucyIsInVwbG9hZF9wYXR0ZXJuX2ltYWdlIiwic3Vic2NyaWJlIiwiU2xpbmdzaG90IiwiZmlsZVJlc3RyaWN0aW9ucyIsImFsbG93ZWRGaWxlVHlwZXMiLCJtYXhTaXplIiwiY3JlYXRlRGlyZWN0aXZlIiwiUzNTdG9yYWdlIiwiQVdTQWNjZXNzS2V5SWQiLCJzZXR0aW5ncyIsIkFXU1NlY3JldEFjY2Vzc0tleSIsImJ1Y2tldCIsIkFXU0J1Y2tldCIsImFjbCIsInJlZ2lvbiIsInB1YmxpYyIsIkFXU1JlZ2lvbiIsImF1dGhvcml6ZSIsImNvbnRleHQiLCJtZXNzYWdlIiwiRXJyb3IiLCJ1c2VyIiwiZmluZE9uZSIsImVtYWlscyIsInZlcmlmaWVkIiwicGF0dGVybiIsImRvY3VtZW50X2lkIiwiY2FsbCIsImRiX2RvY3VtZW50IiwiZXZlbnRfbG9nIiwibnVtYmVyX29mX2VudHJpZXMiLCJ0aW1lX3NpbmNlX2xhc3RfYWN0aW9uIiwibW9tZW50IiwidmFsdWVPZiIsImxhc3RfMTBfYWN0aW9uc19pbiIsImxhc3RfNV9hY3Rpb25zX2luIiwicHJldmlvdXNfNV9hY3Rpb25zX2luIiwiJHB1c2giLCIkZWFjaCIsIiRwb3NpdGlvbiIsImltYWdlX3VwbG9hZHNfbnVtX3RvX2xvZyIsIiRwb3AiLCJwYXJ0cyIsInNwbGl0IiwiZXh0ZW5zaW9uIiwicG9wIiwiam9pbiIsInNsaWNlIiwidG9TdHJpbmciLCJjb25maWd1cmUiLCJsYXlvdXRUZW1wbGF0ZSIsImZhc3RSZW5kZXIiLCJsb2FkaW5nVGVtcGxhdGUiLCJyb3V0ZSIsImRhdGEiLCJ3ZWF2aW5nIiwidGhyZWFkaW5nIiwib3JpZW50YXRpb24iLCJ3YWl0T24iLCJhY3Rpb24iLCJmaW5kIiwiY291bnQiLCJsYXlvdXQiLCJyZW5kZXIiLCJ0byIsIm1vZGUiLCJjYW5fZWRpdF9wYXR0ZXJuIiwic3RhcnR1cCIsInByb2Nlc3MiLCJlbnYiLCJNQUlMX1VSTCIsIlJPT1RfVVJMIiwiQWNjb3VudHMiLCJjb25maWciLCJzZW5kVmVyaWZpY2F0aW9uRW1haWwiLCJlbWFpbFRlbXBsYXRlcyIsInNpdGVOYW1lIiwiZnJvbSIsInZlcmlmeUVtYWlsIiwic3ViamVjdCIsInRleHQiLCJvYnNlcnZlQ2hhbmdlcyIsImNoYW5nZWQiLCJvbkNyZWF0ZVVzZXIiLCJvcHRpb25zIiwicHJvZmlsZSIsIm1ldGhvZHMiLCJzaG93X3BhdHRlcm5fdGFncyIsImNvbnNvbGUiLCJsb2ciLCJ0YWdzIiwiZmV0Y2giLCJtYXAiLCJ0YWciLCJjYW5fY3JlYXRlX3BhdHRlcm4iLCJSb2xlcyIsInVzZXJJc0luUm9sZSIsIm1heF9wYXR0ZXJuc19wZXJfdXNlciIsInByZW1pdW0iLCJkZWZhdWx0IiwibmV3X3BhdHRlcm5fZnJvbV9qc29uIiwiZWRpdF9tb2RlIiwiT3B0aW9uYWwiLCJudW1iZXJfb2Zfcm93cyIsIk9iamVjdCIsInR3aWxsX2RpcmVjdGlvbiIsInJlc3VsdCIsImZpbGVuYW1lIiwiSlNPTiIsInBhcnNlIiwiQXNzZXRzIiwiZ2V0VGV4dCIsImUiLCJ2ZXJzaW9uIiwic3BsaXRfdmVyc2lvbiIsInBhcnNlSW50IiwiYnVpbGRfbmV3IiwidGFibGV0cyIsImlzTmFOIiwicm93cyIsInByZXZpZXdfcm90YXRpb24iLCJBcnJheSIsImkiLCJqIiwid2VhdmluZ19zdGFydF9yb3ciLCJicm9rZW5fdHdpbGxfdGhyZWFkaW5nIiwibWF4X3BhdHRlcm5fcm93cyIsIm1heF9wYXR0ZXJuX3RhYmxldHMiLCJwdXNoIiwid2VhdmluZ19ub3RlcyIsIndlZnRfY29sb3IiLCJkZWZhdWx0X3dlZnRfY29sb3IiLCJ0aHJlYWRpbmdfbm90ZXMiLCJpbnNlcnQiLCIkc2V0IiwiYWRkVGFnIiwic3R5bGVzX2FycmF5Iiwic3R5bGVzIiwic2ltdWxhdGlvbl9zdHlsZXMiLCJiYWNrd2FyZF9zdHJva2UiLCJ3YXJwIiwiZm9yd2FyZF9zdHJva2UiLCJzdHJpbmdpZnkiLCJzcGVjaWFsX3N0eWxlc19hcnJheSIsInNwZWNpYWxfc3R5bGVzIiwic2ltdWxhdGlvbl9tb2RlIiwicG9zaXRpb25fb2ZfQSIsImF1dG9fdHVybl9zZXF1ZW5jZSIsIm1hbnVhbF93ZWF2aW5nX3R1cm5zIiwibmV3X3R1cm4iLCJwYWNrcyIsInBhY2siLCJwYWNrX251bWJlciIsIm51bWJlcl9vZl90dXJucyIsImRpcmVjdGlvbiIsInR3aWxsX3BhdHRlcm5fY2hhcnQiLCJ0d2lsbF9jaGFuZ2VfY2hhcnQiLCJjcmVhdGVfbmV3X2RhdGFfZnJvbV9hcnJheXMiLCJ3ZWF2aW5nX2RhdGEiLCJ4bWwyanMiLCJjb252ZXJ0QXN5bmNUb1N5bmMiLCJ3cmFwQXN5bmMiLCJwYXJzZVN0cmluZyIsInJlc3VsdE9mQXN5bmNUb1N5bmMiLCJyZW1vdmVfcGF0dGVybiIsInJlbW92ZSIsInJlY2VudF9wYXR0ZXJucyIsImluZGV4Iiwic3BsaWNlIiwiaW1hZ2UiLCJzZXRfcHJpdmF0ZSIsInNldF90b19wcml2YXRlIiwiY291bnRfcHVibGljX3BhdHRlcm5zIiwibnVtIiwiJGFuZCIsInNhdmVfd2VhdmluZ190b19kYiIsInNhdmVfbnVtYmVyX29mX3RhYmxldHMiLCJzYXZlX3ByZXZpZXdfYXNfdGV4dCIsInJvdGF0ZV9wcmV2aWV3Iiwic2V0X3ByZXZpZXdfb3JpZW50YXRpb24iLCJyb3RhdGlvbiIsInNhdmVfdGhyZWFkaW5nX3RvX2RiIiwic2F2ZV93ZWZ0X2NvbG9yX3RvX2RiIiwic2F2ZV9vcmllbnRhdGlvbl90b19kYiIsInNhdmVfc3R5bGVzX3RvX2RiIiwic2F2ZV9tYW51YWxfd2VhdmluZ190dXJucyIsInJlc3RvcmVfcGF0dGVybiIsIiR1bnNldCIsInVwZGF0ZV9hZnRlcl90YWJsZXRfY2hhbmdlIiwic2F2ZV9wYXR0ZXJuX2VkaXRfdGltZSIsInBhdHRlcm5fZWRpdGVkX2F0IiwidG9nZ2xlX2hvbGVfaGFuZGVkbmVzcyIsImhvbGVfaGFuZGVkbmVzcyIsIm5ld192YWx1ZSIsImFkZF9wYXR0ZXJuX3RodW1ibmFpbCIsImZpbGVPYmoiLCJrZXlzIiwic2V0X3BhdHRlcm5fY2VsbF9zdHlsZSIsInJvdyIsInRhYmxldCIsIm5ld19zdHlsZSIsInNldF90aHJlYWRpbmdfY2VsbF9zdHlsZSIsImhvbGUiLCJ1cGRhdGVfc2ltdWxhdGlvbl9tb2RlIiwidXBkYXRlX2F1dG9fd2VhdmluZyIsImF1dG9fdHVybl90aHJlYWRzIiwidXBkYXRlX21hbnVhbF93ZWF2aW5nIiwibWFudWFsX3dlYXZpbmdfdGhyZWFkcyIsInNldF9hdXRvX251bWJlcl9vZl90dXJucyIsIm51bV9hdXRvX3R1cm5zIiwidG9nZ2xlX3R1cm5fZGlyZWN0aW9uIiwidHVybl9udW1iZXIiLCJ1cGRhdGVfdHdpbGxfcGF0dGVybl9jaGFydCIsInVwZGF0ZV90d2lsbF9jaGFuZ2VfY2hhcnQiLCJ1cGRhdGVfdHdpbGxfY2hhcnRzIiwic2V0X3dlYXZpbmdfc3RhcnRfcm93Iiwicm93X251bWJlciIsIk1hdGgiLCJmbG9vciIsImFkZF90b19yZWNlbnRfcGF0dGVybnMiLCJyZWNlbnRfcGF0dGVybiIsImFjY2Vzc2VkX2F0IiwiY3VycmVudF93ZWF2ZV9yb3ciLCJ1bnNoaWZ0Iiwic3RvcmVkX3dlYXZlX3JvdyIsIm1haW50YWluX3JlY2VudF9wYXR0ZXJucyIsInNldF9jdXJyZW50X3dlYXZlX3JvdyIsImRvZXNfaW1hZ2VfZXhpc3QiLCJjYiIsInMzIiwiQVdTIiwiUzMiLCJhY2Nlc3NLZXlJZCIsInNlY3JldEFjY2Vzc0tleSIsIkJ1Y2tldCIsIktleSIsIm15X2ZuIiwiaGVhZE9iamVjdCIsInJlc3VsdHMiLCJlcnIiLCJkb3dubG9hZFVybCIsIm1heF9pbWFnZXNfcGVyX3BhdHRlcm4iLCJyZXBsYWNlIiwiaW1hZ2VfaWQiLCJtYWtlX3ByZXZpZXciLCJjdXJyZW50X3ByZXZpZXdfaWQiLCJzZXRfaW1hZ2VfZGltZW5zaW9ucyIsIm5ld193aWR0aCIsIm5ld19oZWlnaHQiLCJyZW1vdmVfaW1hZ2UiLCJpbWFnZV9yZW1vdmVfbnVtX3RvX2xvZyIsImRlbGV0ZU9iamVjdCIsImJpbmRFbnZpcm9ubWVudCIsImVycm9yIiwidXBkYXRlX3RleHRfcHJvcGVydHkiLCJvYmplY3RfaWQiLCJwcm9wZXJ0eSIsIm9sZF9lbWFpbHMiLCJzdGFydF9udW1iZXIiLCJhZGRFbWFpbCIsIm5ld19lbWFpbHMiLCJlbmRfbnVtYmVyIiwiYWRkcmVzcyIsInJlbW92ZUVtYWlsIiwic2F2ZV90ZXh0X2VkaXRfdGltZSIsInRleHRfZWRpdGVkX2F0IiwiZW1haWwiLCJsYXN0XzNfYWN0aW9uc19pbiIsImxhc3RfMjBfYWN0aW9uc19pbiIsInZlcmlmaWNhdGlvbl9lbWFpbHNfbnVtX3RvX2xvZyIsInVwZGF0ZV91c2VyX3JvbGVzIiwiYWRkVXNlcnNUb1JvbGVzIiwicmVtb3ZlVXNlcnNGcm9tUm9sZXMiLCJnZXRfYWN0aW9uc19sb2ciLCJkZWJ1Z192YWxpZGF0ZV9lbWFpbCIsInZhbGlkYXRlZCIsImRlYnVnIiwicHVibGlzaCIsInBhdHRlcm5faWRzIiwiJGluIiwidHJpZ2dlciIsInVpIiwicGFzc3dvcmRTaWdudXBGaWVsZHMiLCIkIiwid2luZG93IiwiYWRkRXZlbnRMaXN0ZW5lciIsInRodW1ibmFpbHNfaW5fcm93IiwiaGVhZGVyIiwiY3JlYXRlZCIsImxvYWRpbmciLCJyZW5kZXJlZCIsImF0dHIiLCJpbml0aWFsaXplX3JvdXRlIiwibWFpbl9sYXlvdXQiLCJvbiIsInJlc2l6ZV9wYWdlIiwiaGVscGVycyIsImVxdWFscyIsIlVJIiwicmVnaXN0ZXJIZWxwZXIiLCJhIiwiYiIsInNlc3Npb25fdmFyIiwidGVzdF92YWx1ZSIsImdldCIsImlzQ29yZG92YSIsImZpZWxkX3ZhbHVlIiwic3RyaW5nX2V4aXN0cyIsInN0YXR1cyIsImNvbm5lY3Rpb25fdGltZW91dCIsInNldFRpbWVvdXQiLCJkaXNjb25uZWN0ZWRfdGltZW91dCIsImNsZWFyVGltZW91dCIsInBhdHRlcm5fZXhpc3RzIiwiaW5kZXhPZiIsImdldE5hbWUiLCJkb2VzX3BhdHRlcm5fcmVwZWF0IiwibmV3X3BhdHRlcm5zIiwib25SZW5kZXJlZCIsInJlcXVlc3RQYWdlIiwibXlfcGF0dGVybnMiLCJhbGxfcGF0dGVybnMiLCJzcmMiLCJidG9hIiwib2JqIiwibGVmdF9jb2x1bW4iLCJzZWxlY3RlZCIsIml0ZW0iLCJzZWFyY2giLCJpbmRleGVzIiwiYXR0cmlidXRlcyIsInNlYXJjaF90ZXJtIiwiZ2V0Q29tcG9uZW50RGljdCIsInBhdHRlcm5fcmVzdWx0c19jb3VudCIsInVzZXJzX3Jlc3VsdHNfY291bnQiLCJjc3NfY2xhc3MiLCJtb3JlX3BhdHRlcm5zIiwiZ2V0Q29tcG9uZW50TWV0aG9kcyIsImhhc01vcmVEb2N1bWVudHMiLCJtb3JlX3VzZXJzIiwicmVzdWx0c19saXN0IiwiaXMiLCJ0YXJnZXQiLCJoYXMiLCJpbnB1dCIsImhpZGVfc2VhcmNoX3Jlc3VsdHMiLCJ3aGljaCIsInZhbCIsImxvYWRNb3JlIiwic2VhcmNoX3Jlc3VsdF9jbGlja2VkIiwibWVudSIsInNob3dfbWVudSIsInN1YnNjcmlwdGlvbnNSZWFkeSIsInJvdXRlX25hbWUiLCJpc19maWxlX2xvYWRpbmdfc3VwcG9ydGVkIiwiY29weV9wYXR0ZXJuIiwiaW1wb3J0X3BhdHRlcm5fZGlhbG9nIiwiZmlsZV90eXBlcyIsImdldEVsZW1lbnRzQnlOYW1lIiwic2VsZWN0ZWRfdHlwZSIsImNoZWNrZWQiLCJpbXBvcnRfZmlsZV9waWNrZXIiLCJmIiwicmVhZGVyIiwiRmlsZVJlYWRlciIsIm9ubG9hZCIsInRoZUZpbGUiLCJ0cmltX2ZpbGVfZXh0ZW5zaW9uIiwic2l6ZSIsImFsZXJ0IiwiSnNvbk9iaiIsImltcG9ydF9wYXR0ZXJuX2Zyb21fanNvbiIsImltcG9ydF9wYXR0ZXJuX2Zyb21fZ3R0IiwicmVhZEFzVGV4dCIsIndyYXAiLCJjbG9zZXN0IiwicmVzZXQiLCJ1bndyYXAiLCJzdG9wUHJvcGFnYXRpb24iLCJwYXR0ZXJuX2FzX3RleHQiLCJleHBvcnRfcGF0dGVybl90b19qc29uIiwib3JpZ2luYWxfYXJyYXlzIiwibmV3X2FycmF5cyIsInJlIiwibSIsImV4ZWMiLCJ0aGlzX2FycmF5IiwicmVnZXgiLCJncm91cDEiLCJzZWxlY3QiLCJUcmFja2VyIiwiYXV0b3J1biIsImNvbXB1dGF0aW9uIiwiY3VycmVudFVzZXIiLCJmaXJzdFJ1biIsIm1heCIsIm1pbiIsImZpbHRlciIsImpRdWVyeSIsInNldF90YWJsZXRzX2ZpbHRlciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFFQUEsYUFBYSxJQUFJQyxPQUFPQyxVQUFYLENBQXNCLGFBQXRCLENBQWI7QUFFQSxJQUFJQyxTQUFTLElBQUlDLFlBQUosQ0FBaUI7QUFDNUJDLGFBQVM7QUFDTEMsY0FBTUMsTUFERDtBQUVMQyxlQUFPO0FBRkYsS0FEbUI7QUFLNUJDLGNBQVU7QUFDTkgsY0FBTUMsTUFEQTtBQUVOQyxlQUFPO0FBRkQsS0FMa0I7QUFTNUJFLFlBQVE7QUFDTkosY0FBTUssT0FEQTtBQUVOSCxlQUFPLFFBRkQ7QUFHTkksa0JBQVU7QUFISixLQVRvQjtBQWM1QkMsNkJBQXlCO0FBQ3JCUCxjQUFNLENBQUNRLE1BQUQsQ0FEZTtBQUVyQk4sZUFBTztBQUZjLEtBZEc7QUFrQjVCTyxvQkFBZ0I7QUFDWlQsY0FBTSxDQUFDUSxNQUFELENBRE07QUFFWk4sZUFBTztBQUZLLEtBbEJZO0FBc0I1QlEsbUJBQWU7QUFDWFYsY0FBTSxDQUFDUSxNQUFELENBREs7QUFFWE4sZUFBTztBQUZJO0FBdEJhLENBQWpCLENBQWI7QUE2QkFSLFdBQVdpQixZQUFYLENBQXdCZCxNQUF4QixFOzs7Ozs7Ozs7OztBQ25DQWUsU0FBUyxJQUFJakIsT0FBT0MsVUFBWCxDQUF1QixRQUF2QixDQUFUO0FBRUEsSUFBSUMsU0FBUyxJQUFJQyxZQUFKLENBQWlCO0FBQzVCZSxTQUFLO0FBQ0hiLGNBQU1DLE1BREg7QUFFSEMsZUFBTztBQUZKLEtBRHVCO0FBSzVCWSxTQUFLO0FBQ0hkLGNBQU1DLE1BREg7QUFFSEMsZUFBTztBQUZKLEtBTHVCO0FBUzVCYSxhQUFTO0FBQ0xmLGNBQU1DLE1BREQ7QUFFTEMsZUFBTyxTQUZGO0FBR0xJLGtCQUFVO0FBSEwsS0FUbUI7QUFjNUJVLGdCQUFZO0FBQ1JoQixjQUFNUSxNQURFO0FBRVJOLGVBQU87QUFGQyxLQWRnQjtBQWtCNUJlLGdCQUFZO0FBQ1JqQixjQUFNQyxNQURFO0FBRVJDLGVBQU87QUFGQyxLQWxCZ0I7QUFzQjVCZ0IseUJBQXFCO0FBQ2pCbEIsY0FBTUMsTUFEVztBQUVqQkMsZUFBTztBQUZVLEtBdEJPO0FBMEI1QmlCLGFBQVM7QUFDUG5CLGNBQU1DLE1BREM7QUFDTztBQUNkQyxlQUFPO0FBRkEsS0ExQm1CO0FBOEI1QmtCLFVBQU07QUFDSnBCLGNBQU1DLE1BREY7QUFDVTtBQUNkQyxlQUFPO0FBRkgsS0E5QnNCO0FBa0M1Qm1CLFdBQU87QUFDSHJCLGNBQU1RLE1BREg7QUFFSE4sZUFBTyxPQUZKO0FBR0hJLGtCQUFVO0FBSFAsS0FsQ3FCO0FBdUM1QmdCLFlBQVE7QUFDSnRCLGNBQU1RLE1BREY7QUFFSk4sZUFBTyxRQUZIO0FBR0pJLGtCQUFVO0FBSE47QUF2Q29CLENBQWpCLENBQWI7QUE4Q0FNLE9BQU9ELFlBQVAsQ0FBb0JkLE1BQXBCLEU7Ozs7Ozs7Ozs7O0FDaERBLElBQUlBLFNBQVMsSUFBSUMsWUFBSixDQUFpQjtBQUM3QixpQkFBZ0I7QUFDZixVQUFRRyxNQURPO0FBRWYsV0FBUyxjQUZNO0FBR2YsY0FBWTtBQUhHLEVBRGE7QUFNN0IsdUJBQXNCO0FBQ3JCLFVBQVEsQ0FBQ0EsTUFBRCxDQURhO0FBRXJCLFdBQVMsb0JBRlk7QUFHckIsY0FBWTtBQUhTLEVBTk87QUFXN0Isc0JBQXFCO0FBQ3BCLFVBQVEsQ0FBQyxDQUFDTyxNQUFELENBQUQsQ0FEWTtBQUVwQixXQUFTLG1CQUZXO0FBR3BCLGNBQVk7QUFIUSxFQVhRO0FBZ0I3QixlQUFjO0FBQ2IsVUFBUUEsTUFESztBQUViLFdBQVM7QUFGSSxFQWhCZTtBQW9CN0IsZUFBYztBQUNiLFVBQVFQLE1BREs7QUFFYixXQUFTO0FBRkksRUFwQmU7QUF3QjdCLHdCQUF1QjtBQUN0QixVQUFRQSxNQURjO0FBRXRCLFdBQVM7QUFGYSxFQXhCTTtBQTRCN0IsZ0JBQWU7QUFDZCxVQUFRQSxNQURNO0FBRWQsV0FBUyxhQUZLO0FBR2QsY0FBWTtBQUhFLEVBNUJjO0FBaUM3QixvQkFBbUI7QUFDbEIsVUFBUUEsTUFEVTtBQUVsQixXQUFTLGlCQUZTO0FBR2xCLFNBQU8sRUFIVztBQUlsQixjQUFZO0FBSk0sRUFqQ1U7QUF1QzdCLGNBQWE7QUFDWixVQUFRQSxNQURJO0FBRVosV0FBUyxXQUZHO0FBR1osU0FBTyxFQUhLO0FBSVosY0FBWTtBQUpBLEVBdkNnQjtBQTZDN0Isc0JBQXFCO0FBQ3BCLFVBQVFBLE1BRFk7QUFFcEIsV0FBUyxrQkFGVztBQUdwQixTQUFPLEtBSGE7QUFJcEIsY0FBWTtBQUpRLEVBN0NRO0FBbUQ3QixTQUFRO0FBQ1AsVUFBUUEsTUFERDtBQUVQLFdBQVMsTUFGRjtBQUdQLFNBQU87QUFIQSxFQW5EcUI7QUF3RDdCLDJCQUEwQjtBQUN6QixVQUFRLENBQUMsQ0FBQ08sTUFBRCxDQUFELENBRGlCO0FBRXpCLFdBQVMsc0JBRmdCO0FBR3pCLGNBQVk7QUFIYSxFQXhERztBQTZEN0IseUJBQXdCO0FBQ3ZCLFVBQVFQLE1BRGU7QUFFdkIsV0FBUyxzQkFGYztBQUd2QixjQUFZO0FBSFcsRUE3REs7QUFrRTdCLGNBQWE7QUFDWixVQUFRQSxNQURJO0FBRVosY0FBWSxJQUZBO0FBR1osZUFBYSxZQUFXO0FBQ3ZCLE9BQUlzQixPQUFPLEtBQUtDLEtBQUwsQ0FBVyxNQUFYLENBQVg7O0FBRUEsT0FBSUQsS0FBS0UsS0FBVCxFQUFnQjtBQUNkLFdBQU9GLEtBQUtHLEtBQUwsQ0FBV0MsV0FBWCxFQUFQO0FBQ0QsSUFGRCxNQUVPO0FBQ0wsU0FBS0MsS0FBTDtBQUNEO0FBQ0Q7QUFYVyxFQWxFZ0I7QUErRTdCLG1CQUFrQjtBQUNqQixVQUFRcEIsTUFEUztBQUVqQixXQUFTLGdCQUZRO0FBR2pCLFNBQU8sSUFIVTtBQUlqQixjQUFZO0FBSkssRUEvRVc7QUFxRjdCLHNCQUFxQjtBQUNwQixVQUFRQSxNQURZO0FBRXBCLFdBQVMsZ0JBRlc7QUFHcEIsU0FBTyxJQUhhO0FBSXBCLGNBQVk7QUFKUSxFQXJGUTtBQTJGN0IsZ0JBQWU7QUFDZCxVQUFRUCxNQURNO0FBRWQsV0FBUyxhQUZLO0FBR2QsU0FBTyxLQUhPO0FBSWQsY0FBWTtBQUpFLEVBM0ZjO0FBaUc3QixzQkFBcUI7QUFDcEIsVUFBUU8sTUFEWTtBQUVwQixXQUFTLFdBRlc7QUFHcEIsY0FBWTtBQUhRLEVBakdRO0FBc0c3QixrQkFBaUI7QUFDaEIsVUFBUVAsTUFEUTtBQUVoQixXQUFTLGVBRk87QUFHaEIsY0FBWTtBQUhJLEVBdEdZO0FBMkc3QixxQkFBb0I7QUFDbkIsVUFBUUEsTUFEVztBQUVuQixXQUFTLGtCQUZVO0FBR25CLGNBQVk7QUFITyxFQTNHUztBQWdIN0IsWUFBVztBQUNWLFVBQVFJLE9BREU7QUFFVixXQUFTLFNBRkM7QUFHVixjQUFZO0FBSEYsRUFoSGtCO0FBcUg3QixvQkFBbUI7QUFDbEIsVUFBUUosTUFEVTtBQUVsQixXQUFTLGlCQUZTO0FBR2xCLGNBQVk7QUFITSxFQXJIVTtBQTBIN0IsbUJBQWtCO0FBQ2pCLFVBQVFBLE1BRFM7QUFFakIsV0FBUyxRQUZRO0FBR2pCLFNBQU8sS0FIVTtBQUlqQixjQUFZO0FBSkssRUExSFc7QUFnSTdCLFdBQVU7QUFDVCxVQUFRQSxNQURDO0FBRVQsV0FBUyxRQUZBO0FBR1QsU0FBTyxLQUhFO0FBSVQsY0FBWTtBQUpILEVBaEltQjtBQXNJN0IsU0FBUTtBQUNQLFVBQVFBLE1BREQ7QUFFUCxXQUFTLE1BRkY7QUFHUCxTQUFPLEtBSEE7QUFJUCxjQUFZO0FBSkwsRUF0SXFCO0FBNEk3QixtQkFBa0I7QUFDakIsVUFBUU8sTUFEUztBQUVqQixXQUFTLFdBRlE7QUFHakIsY0FBWTtBQUhLLEVBNUlXO0FBaUo3QixjQUFhO0FBQ1osVUFBUVAsTUFESTtBQUVaLFdBQVMsV0FGRztBQUdaLFNBQU8sS0FISztBQUlaLGNBQVk7QUFKQSxFQWpKZ0I7QUF1SjdCLG9CQUFtQjtBQUNsQixVQUFRQSxNQURVO0FBRWxCLFdBQVMsaUJBRlM7QUFHbEIsY0FBWTtBQUhNLEVBdkpVO0FBNEo3Qix1QkFBc0I7QUFDckIsVUFBUUEsTUFEYTtBQUVyQixXQUFTLDhCQUZZO0FBR3JCLFNBQU8sS0FIYztBQUlyQixjQUFZO0FBSlMsRUE1Sk87QUFrSzdCLG9CQUFtQjtBQUNsQixVQUFRQSxNQURVO0FBRWxCLFdBQVMsaUJBRlM7QUFHbEIsY0FBWTtBQUhNLEVBbEtVO0FBdUs3Qix3QkFBdUI7QUFDdEIsVUFBUUEsTUFEYztBQUV0QixXQUFTLHFCQUZhO0FBR3RCLFNBQU8sS0FIZTtBQUl0QixjQUFZO0FBSlUsRUF2S007QUE2SzdCLHNCQUFxQjtBQUNwQixVQUFRTyxNQURZO0FBRXBCLFdBQVMsbUJBRlc7QUFHcEIsY0FBWTtBQUhRLEVBN0tRO0FBa0w3QixZQUFXO0FBQ1YsVUFBUVAsTUFERTtBQUVWLFdBQVMsU0FGQztBQUdWLFNBQU8sS0FIRztBQUlWLGNBQVk7QUFKRixFQWxMa0I7QUF3TDdCLGtCQUFpQjtBQUNoQixVQUFRQSxNQURRO0FBRWhCLFdBQVMsZUFGTztBQUdoQixjQUFZO0FBSEksRUF4TFk7QUE2TDdCLGVBQWM7QUFDYixVQUFRQSxNQURLO0FBRWIsV0FBUyxZQUZJO0FBR2IsY0FBWTtBQUhDO0FBN0xlLENBQWpCLENBQWI7QUFvTUE0QixXQUFXLElBQUlsQyxPQUFPQyxVQUFYLENBQXNCLFVBQXRCLENBQVg7O0FBRUEsSUFBSUQsT0FBT21DLFFBQVgsRUFBcUI7QUFDcEI7QUFDQTtBQUNBRCxVQUFTRSxhQUFULEdBQXlCQyxXQUF6QixDQUFzQztBQUFDLGdCQUFjO0FBQWYsRUFBdEM7QUFDQUgsVUFBU0UsYUFBVCxHQUF5QkMsV0FBekIsQ0FBc0M7QUFBQyxhQUFXO0FBQVosRUFBdEMsRUFKb0IsQ0FNcEI7O0FBQ0FILFVBQVNFLGFBQVQsR0FBeUJDLFdBQXpCLENBQXNDO0FBQUMsZ0JBQWMsQ0FBQztBQUFoQixFQUF0QztBQUNBOztBQUVESCxTQUFTbEIsWUFBVCxDQUFzQmQsTUFBdEIsRTs7Ozs7Ozs7Ozs7QUNoTkE7QUFDQTtBQUVBLEtBQUtvQyxLQUFMLEdBQWEsSUFBSXRDLE9BQU91QyxVQUFYLENBQXNCdkMsT0FBT3dDLEtBQTdCLEVBQW9DO0FBQy9DQyxnQkFBYyxnQkFEaUM7QUFFL0NDLGdCQUFjLE9BRmlDO0FBRy9DQyxXQUFTLEVBSHNDO0FBSS9DQyxxQkFBbUI7QUFDakJDLGFBQVMsSUFEUTtBQUVqQkMsVUFBTTtBQUZXLEdBSjRCO0FBUS9DQyxRQUFNLFVBQVNDLElBQVQsRUFBZUMsR0FBZixFQUFtQjtBQUN2QixRQUFJQyxlQUFlLEtBQUtBLFlBQUwsQ0FBa0JELElBQUlFLFFBQUosQ0FBYUMsRUFBL0IsS0FBc0MsRUFBekQ7QUFDQSxRQUFJQyxjQUFjSCxhQUFhTCxPQUFiLElBQXdCLEVBQTFDO0FBRUEsUUFBSVMsU0FBUyxFQUFiO0FBQ0FBLFdBQU8sK0JBQVAsSUFBMEM7QUFBQ0MsV0FBSztBQUFOLEtBQTFDLENBTHVCLENBSzZCOztBQUVwRCxRQUFJTixJQUFJTyxNQUFSLEVBQ0UsSUFBSUMsV0FBV0MsRUFBRUMsTUFBRixDQUNiO0FBQUVDLFdBQUssQ0FBQ04sTUFBRCxFQUFTO0FBQUNPLGFBQUtaLElBQUlPO0FBQVYsT0FBVDtBQUFQLEtBRGEsRUFDd0JILFdBRHhCLENBQWYsQ0FERixDQUV1RDtBQUZ2RCxTQUlFLElBQUlJLFdBQVdDLEVBQUVDLE1BQUYsQ0FDYjtBQUFFQyxhQUFLLENBQUNOLE1BQUQ7QUFBUCxPQURhLEVBQ0tELFdBREwsQ0FBZixDQVhxQixDQVlhOztBQUVwQyxRQUFJUyxXQUFXO0FBQ2JDLGFBQU8sRUFETTtBQUViZixZQUFNQSxJQUZPO0FBR2JnQixjQUFRO0FBQUV4RCxrQkFBVSxDQUFaLENBQWdCOztBQUFoQjtBQUhLLEtBQWY7QUFLQSxRQUFJLE9BQU8wQyxhQUFhSixJQUFwQixLQUE2QixRQUFqQyxFQUNFZ0IsU0FBU2hCLElBQVQsR0FBZ0JJLGFBQWFKLElBQTdCLENBREYsS0FHQTtBQUNFZ0IsZUFBU2hCLElBQVQsR0FBZ0I7QUFBRSw2QkFBcUI7QUFBdkIsT0FBaEIsQ0FERixDQUM2QztBQUM1QztBQUVELFdBQU8sQ0FBQ1csUUFBRCxFQUFXSyxRQUFYLENBQVA7QUFDRDtBQW5DOEMsQ0FBcEMsQ0FBYixDLENBc0NBO0FBQ0E7O0FBQ0E5RCxPQUFPd0MsS0FBUCxDQUFheUIsSUFBYixDQUFrQjtBQUNoQlgsV0FBUztBQUFFLFdBQU8sSUFBUDtBQUFjOztBQURULENBQWxCLEUsQ0FJQTtBQUNBOztBQUNBWSxLQUFLQyxTQUFMLENBQWVqQyxRQUFmLEUsQ0FBMEI7O0FBQzFCQSxTQUFTa0MsU0FBVCxDQUFtQixVQUFVWixNQUFWLEVBQWtCO0FBQUUsU0FBTyxJQUFQO0FBQWMsQ0FBckQsRSxDQUVBOztBQUNBYSxnQkFBZ0IsSUFBSUMsV0FBV0MsS0FBZixDQUFxQjtBQUNuQ0MsY0FBWXRDLFFBRHVCO0FBRW5DOEIsVUFBUSxDQUFDLFdBQUQsRUFBYyxNQUFkLEVBQXNCLHFCQUF0QixFQUE2QyxtQkFBN0MsQ0FGMkI7QUFHbkNTLHdCQUFzQjtBQUNwQlYsV0FBTztBQURhLEdBSGE7QUFNbkNXLFVBQVEsSUFBSUosV0FBV0ssU0FBZixFQU4yQixDQU1BO0FBRW5DO0FBQ0E7Ozs7Ozs7Ozs7QUFUbUMsQ0FBckIsQ0FBaEI7QUF1QkFDLGFBQWEsSUFBSU4sV0FBV0MsS0FBZixDQUFxQjtBQUNoQ0MsY0FBWXhFLE9BQU93QyxLQURhO0FBRWhDd0IsVUFBUSxDQUFDLFVBQUQsRUFBYSxxQkFBYixDQUZ3QjtBQUdoQ1Msd0JBQXNCO0FBQ3BCVixXQUFPO0FBRGEsR0FIVTtBQU1oQ1csVUFBUSxJQUFJSixXQUFXSyxTQUFmLEVBTndCLENBTUc7O0FBTkgsQ0FBckIsQ0FBYixDLENBU0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBOztBQUNBLEtBQUtFLFlBQUwsR0FBb0IsSUFBSTdFLE9BQU91QyxVQUFYLENBQXNCTCxRQUF0QixFQUFnQztBQUNsRE8sZ0JBQWMsbUJBRG9DO0FBRWxEQyxnQkFBYyxNQUZvQztBQUdsREMsV0FBUyxFQUh5QztBQUlsREMscUJBQW1CO0FBQ2pCQyxhQUFTLElBRFE7QUFFakJDLFVBQU07QUFGVyxHQUorQjtBQVFsREMsUUFBTSxVQUFTQyxJQUFULEVBQWVDLEdBQWYsRUFBbUI7QUFDdkIsUUFBSUMsZUFBZSxLQUFLQSxZQUFMLENBQWtCRCxJQUFJRSxRQUFKLENBQWFDLEVBQS9CLEtBQXNDLEVBQXpEO0FBQ0EsUUFBSUMsY0FBY0gsYUFBYUwsT0FBYixJQUF3QixFQUExQztBQUVBLFFBQUlJLElBQUlPLE1BQVIsRUFDRSxJQUFJQyxXQUFXQyxFQUFFQyxNQUFGLENBQVM7QUFDdEJDLFdBQUssQ0FDSDtBQUFFa0IsaUJBQVM7QUFBQ0MsZUFBSztBQUFOO0FBQVgsT0FERyxFQUVIO0FBQUV6RCxvQkFBWTJCLElBQUlPO0FBQWxCLE9BRkc7QUFEaUIsS0FBVCxFQUtaSCxXQUxZLENBQWYsQ0FERixLQVFFLElBQUlJLFdBQVdDLEVBQUVDLE1BQUYsQ0FDYjtBQUFFbUIsZUFBUztBQUFDQyxhQUFLO0FBQU47QUFBWCxLQURhLEVBRWIxQixXQUZhLENBQWY7QUFJRixRQUFJUyxXQUFXO0FBQ2JDLGFBQU8sRUFETTtBQUViakIsWUFBTTtBQUFFa0MsbUJBQVc7QUFBYixPQUZPO0FBR2JoQyxZQUFNQSxJQUhPO0FBSWJnQixjQUFRO0FBQ05ILGFBQUssQ0FEQztBQUVOb0Isc0JBQWMsQ0FGUjtBQUdONUQsb0JBQVksQ0FITjtBQUlOQyxvQkFBWSxDQUpOO0FBS05DLDZCQUFxQixDQUxmO0FBTU4yRCxxQkFBYSxDQU5QO0FBT050RCxjQUFNLENBUEE7QUFRTm9ELG1CQUFXLENBUkw7QUFTTkcsMkJBQW1CLENBVGI7QUFVTkwsaUJBQVM7QUFWSDtBQUpLLEtBQWY7QUFrQkEsV0FBTyxDQUFDckIsUUFBRCxFQUFXSyxRQUFYLENBQVA7QUFDRDtBQTNDaUQsQ0FBaEMsQ0FBcEI7QUE4Q0EsS0FBS3NCLFVBQUwsR0FBa0IsSUFBSXBGLE9BQU91QyxVQUFYLENBQXNCTCxRQUF0QixFQUFnQztBQUNoRE8sZ0JBQWMsbUJBRGtDO0FBRWhEQyxnQkFBYyxhQUZrQztBQUdoREMsV0FBUyxFQUh1QztBQUloREMscUJBQW1CO0FBQ2pCQyxhQUFTLElBRFE7QUFFakJDLFVBQU07QUFGVyxHQUo2QjtBQVFoREMsUUFBTSxVQUFTQyxJQUFULEVBQWVDLEdBQWYsRUFBbUI7QUFDdkIsUUFBSUMsZUFBZSxLQUFLQSxZQUFMLENBQWtCRCxJQUFJRSxRQUFKLENBQWFDLEVBQS9CLEtBQXNDLEVBQXpEO0FBQ0EsUUFBSUMsY0FBY0gsYUFBYUwsT0FBYixJQUF3QixFQUExQzs7QUFDQSxRQUFJWSxXQUFXQyxFQUFFQyxNQUFGLENBQVM7QUFBQ3JDLGtCQUFZMkIsSUFBSU87QUFBakIsS0FBVCxFQUFtQ0gsV0FBbkMsQ0FBZjs7QUFFQSxRQUFJUyxXQUFXO0FBQ2JDLGFBQU8sRUFETTtBQUViakIsWUFBTTtBQUFFa0MsbUJBQVc7QUFBYixPQUZPO0FBR2JoQyxZQUFNQSxJQUhPO0FBSWJnQixjQUFRO0FBQ05ILGFBQUssQ0FEQztBQUVOb0Isc0JBQWMsQ0FGUjtBQUdONUQsb0JBQVksQ0FITjtBQUlOQyxvQkFBWSxDQUpOO0FBS05DLDZCQUFxQixDQUxmO0FBTU4yRCxxQkFBYSxDQU5QO0FBT050RCxjQUFNLENBUEE7QUFRTm9ELG1CQUFXLENBUkw7QUFTTkcsMkJBQW1CLENBVGI7QUFVTkwsaUJBQVM7QUFWSDtBQUpLLEtBQWY7QUFrQkEsV0FBTyxDQUFDckIsUUFBRCxFQUFXSyxRQUFYLENBQVA7QUFDRCxHQWhDK0M7QUFpQ2hEakIsV0FBUztBQWpDdUMsQ0FBaEMsQ0FBbEI7QUFvQ0EsS0FBS3dDLFdBQUwsR0FBbUIsSUFBSXJGLE9BQU91QyxVQUFYLENBQXNCTCxRQUF0QixFQUFnQztBQUNqRE8sZ0JBQWMsbUJBRG1DO0FBRWpEQyxnQkFBYyxjQUZtQztBQUdqREMsV0FBUyxFQUh3QztBQUdwQyw0RUFDYkMsbUJBQW1CO0FBQ2pCQyxhQUFTLElBRFE7QUFFakJDLFVBQU07QUFGVyxHQUo4QjtBQVFqREMsUUFBTSxVQUFTQyxJQUFULEVBQWVDLEdBQWYsRUFBbUI7QUFDdkIsUUFBSUMsZUFBZSxLQUFLQSxZQUFMLENBQWtCRCxJQUFJRSxRQUFKLENBQWFDLEVBQS9CLEtBQXNDLEVBQXpEO0FBQ0EsUUFBSUMsY0FBY0gsYUFBYUwsT0FBYixJQUF3QixFQUExQyxDQUZ1QixDQUV1QjtBQUU5QyxRQUFJSSxJQUFJTyxNQUFSLEVBQ0UsSUFBSUMsV0FBV0MsRUFBRUMsTUFBRixDQUFTO0FBQUUsbUdBQ3hCQyxLQUFLLENBQ0g7QUFBRWtCLGlCQUFTO0FBQUNDLGVBQUs7QUFBTjtBQUFYLE9BREcsRUFFSDtBQUFFekQsb0JBQVkyQixJQUFJTztBQUFsQixPQUZHO0FBRGlCLEtBQVQsRUFLWkgsV0FMWSxDQUFmLENBREYsS0FRRSxJQUFJSSxXQUFXQyxFQUFFQyxNQUFGLEVBQVUsNkZBQ3ZCO0FBQUVtQixlQUFTO0FBQUNDLGFBQUs7QUFBTjtBQUFYLEtBRGEsRUFFYjFCLFdBRmEsQ0FBZjtBQUlGLFFBQUlTLFdBQVc7QUFDYkMsYUFBTyxFQURNO0FBQ0YsNEJBQ1hmLE1BQU1BLElBRk87QUFFRCw4REFDWmdCLFFBQVE7QUFDTkgsYUFBSyxDQURDO0FBRU5vQixzQkFBYyxDQUZSO0FBR041RCxvQkFBWSxDQUhOO0FBSU5DLG9CQUFZLENBSk47QUFLTkMsNkJBQXFCLENBTGY7QUFNTjJELHFCQUFhLENBTlA7QUFPTnRELGNBQU0sQ0FQQTtBQVFOb0QsbUJBQVcsQ0FSTDtBQVNORywyQkFBbUIsQ0FUYjtBQVVOTCxpQkFBUztBQVZIO0FBSEssS0FBZjtBQWdCQSxRQUFJLE9BQU81QixhQUFhSixJQUFwQixLQUE2QixRQUFqQyxFQUEyQyx5QkFDekNnQixTQUFTaEIsSUFBVCxHQUFnQkksYUFBYUosSUFBN0IsQ0FERixLQUdFZ0IsU0FBU2hCLElBQVQsR0FBZ0I7QUFBRWtDLGlCQUFXO0FBQWIsS0FBaEI7QUFFRixXQUFPLENBQUN2QixRQUFELEVBQVdLLFFBQVgsQ0FBUDtBQUNELEdBOUNnRDtBQStDakRqQixXQUFTO0FBL0N3QyxDQUFoQyxDQUFuQjtBQWtEQSxLQUFLeUMsV0FBTCxHQUFtQixJQUFJdEYsT0FBT3VDLFVBQVgsQ0FBc0JMLFFBQXRCLEVBQWdDO0FBQ2pETyxnQkFBYyxtQkFEbUM7QUFFakRDLGdCQUFjLGNBRm1DO0FBR2pEQyxXQUFTLEVBSHdDO0FBSWpEQyxxQkFBbUI7QUFDakJDLGFBQVMsSUFEUTtBQUVqQkMsVUFBTTtBQUZXLEdBSjhCO0FBUWpEQyxRQUFNLFVBQVNDLElBQVQsRUFBZUMsR0FBZixFQUFtQjtBQUN2QixRQUFJQyxlQUFlLEtBQUtBLFlBQUwsQ0FBa0JELElBQUlFLFFBQUosQ0FBYUMsRUFBL0IsS0FBc0MsRUFBekQ7QUFDQSxRQUFJQyxjQUFjSCxhQUFhTCxPQUFiLElBQXdCLEVBQTFDO0FBRUEsUUFBSUksSUFBSU8sTUFBUixFQUNFLElBQUlDLFdBQVdDLEVBQUVDLE1BQUYsQ0FBUztBQUN0QkMsV0FBSyxDQUNIO0FBQUVrQixpQkFBUztBQUFDQyxlQUFLO0FBQU47QUFBWCxPQURHLEVBRUg7QUFBRXpELG9CQUFZMkIsSUFBSU87QUFBbEIsT0FGRztBQURpQixLQUFULEVBS1pILFdBTFksQ0FBZixDQURGLEtBUUUsSUFBSUksV0FBV0MsRUFBRUMsTUFBRixDQUNmO0FBQUVtQixlQUFTO0FBQUNDLGFBQUs7QUFBTjtBQUFYLEtBRGUsRUFFZjFCLFdBRmUsQ0FBZjtBQUlGLFFBQUlTLFdBQVc7QUFDYkMsYUFBTyxFQURNO0FBRWJqQixZQUFNO0FBQUV6QixvQkFBWSxDQUFDO0FBQWYsT0FGTztBQUdiMkIsWUFBTUEsSUFITztBQUliZ0IsY0FBUTtBQUNOSCxhQUFLLENBREM7QUFFTm9CLHNCQUFjLENBRlI7QUFHTjVELG9CQUFZLENBSE47QUFJTkMsb0JBQVksQ0FKTjtBQUtOQyw2QkFBcUIsQ0FMZjtBQU1OMkQscUJBQWEsQ0FOUDtBQU9OdEQsY0FBTSxDQVBBO0FBUU5vRCxtQkFBVyxDQVJMO0FBU05HLDJCQUFtQixDQVRiO0FBVU5MLGlCQUFTO0FBVkg7QUFKSyxLQUFmO0FBa0JBLFdBQU8sQ0FBQ3JCLFFBQUQsRUFBV0ssUUFBWCxDQUFQO0FBQ0QsR0EzQ2dEO0FBNENqRGpCLFdBQVM7QUE1Q3dDLENBQWhDLENBQW5CLEM7Ozs7Ozs7Ozs7O0FDaE9BO0FBQ0EwQyx1QkFBdUI7QUFDckIsYUFBVyxNQURVO0FBRXJCLFVBQVEsYUFGYTtBQUdyQixpQkFBZSxpRUFITTtBQUlyQixtQkFBaUIsRUFKSTtBQUtyQixxQkFBbUIsRUFMRTtBQU1yQixVQUFRLEVBTmE7QUFPbkIsWUFBVSxDQUNWO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLE1BSFY7QUFJRSxhQUFTO0FBSlgsR0FEVSxFQU9WO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLE1BSFY7QUFJRSxhQUFTO0FBSlgsR0FQVSxFQWFWO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLFNBSFY7QUFJRSxhQUFTO0FBSlgsR0FiVSxFQW1CVjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLGtCQUFjLFNBRmhCO0FBR0UsWUFBUSxVQUhWO0FBSUUsYUFBUztBQUpYLEdBbkJVLEVBeUJWO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLFNBSFY7QUFJRSxhQUFTO0FBSlgsR0F6QlUsRUErQlY7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxrQkFBYyxTQUZoQjtBQUdFLFlBQVEsVUFIVjtBQUlFLGFBQVM7QUFKWCxHQS9CVSxFQXFDVjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLGtCQUFjLFNBRmhCO0FBR0UsWUFBUSxTQUhWO0FBSUUsYUFBUztBQUpYLEdBckNVLEVBMkNWO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLFVBSFY7QUFJRSxhQUFTO0FBSlgsR0EzQ1UsRUFpRFY7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxrQkFBYyxTQUZoQjtBQUdFLFlBQVEsTUFIVjtBQUlFLGFBQVM7QUFKWCxHQWpEVSxFQXVEVjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLGtCQUFjLFNBRmhCO0FBR0UsWUFBUSxNQUhWO0FBSUUsYUFBUztBQUpYLEdBdkRVLEVBNkRWO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLFVBSFY7QUFJRSxhQUFTO0FBSlgsR0E3RFUsRUFtRVY7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxrQkFBYyxTQUZoQjtBQUdFLFlBQVEsU0FIVjtBQUlFLGFBQVM7QUFKWCxHQW5FVSxFQXlFVjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLGtCQUFjLFNBRmhCO0FBR0UsWUFBUSxVQUhWO0FBSUUsYUFBUztBQUpYLEdBekVVLEVBK0VWO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLFNBSFY7QUFJRSxhQUFTO0FBSlgsR0EvRVUsRUFxRlY7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxrQkFBYyxTQUZoQjtBQUdFLFlBQVEsVUFIVjtBQUlFLGFBQVM7QUFKWCxHQXJGVSxFQTJGVjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLGtCQUFjLFNBRmhCO0FBR0UsWUFBUSxTQUhWO0FBSUUsYUFBUztBQUpYLEdBM0ZVLEVBaUdWO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLFNBSFY7QUFJRSxhQUFTO0FBSlgsR0FqR1UsRUF1R1Y7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxrQkFBYyxTQUZoQjtBQUdFLFlBQVEsVUFIVjtBQUlFLGFBQVM7QUFKWCxHQXZHVSxFQTZHVjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLGtCQUFjLFNBRmhCO0FBR0UsWUFBUSxTQUhWO0FBSUUsYUFBUyxFQUpYO0FBS0UsZUFBVztBQUxiLEdBN0dVLEVBb0hWO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLFVBSFY7QUFJRSxhQUFTLEVBSlg7QUFLRSxlQUFXO0FBTGIsR0FwSFUsRUEySFY7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxrQkFBYyxTQUZoQjtBQUdFLFlBQVEsU0FIVjtBQUlFLGFBQVMsRUFKWDtBQUtFLGVBQVc7QUFMYixHQTNIVSxFQWtJVjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLGtCQUFjLFNBRmhCO0FBR0UsWUFBUSxVQUhWO0FBSUUsYUFBUyxFQUpYO0FBS0UsZUFBVztBQUxiLEdBbElVLEVBeUlWO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLGVBSFY7QUFJRSxhQUFTO0FBSlgsR0F6SVUsRUErSVY7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxrQkFBYyxTQUZoQjtBQUdFLFlBQVEsZ0JBSFY7QUFJRSxhQUFTO0FBSlgsR0EvSVUsRUFxSlY7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxrQkFBYyxTQUZoQjtBQUdFLFlBQVEsVUFIVjtBQUlFLGFBQVM7QUFKWCxHQXJKVSxFQTJKVjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLGtCQUFjLFNBRmhCO0FBR0UsWUFBUSxTQUhWO0FBSUUsYUFBUztBQUpYLEdBM0pVLEVBaUtWO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLFVBSFY7QUFJRSxhQUFTO0FBSlgsR0FqS1UsRUF1S1Y7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxrQkFBYyxTQUZoQjtBQUdFLFlBQVEsU0FIVjtBQUlFLGFBQVM7QUFKWCxHQXZLVSxFQTZLVjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLGtCQUFjLFNBRmhCO0FBR0UsWUFBUSxVQUhWO0FBSUUsYUFBUztBQUpYLEdBN0tVLEVBbUxWO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLFNBSFY7QUFJRSxhQUFTO0FBSlgsR0FuTFUsRUF5TFY7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxrQkFBYyxTQUZoQjtBQUdFLFlBQVEsZ0JBSFY7QUFJRSxhQUFTO0FBSlgsR0F6TFUsRUErTFY7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxrQkFBYyxTQUZoQjtBQUdFLFlBQVEsZUFIVjtBQUlFLGFBQVM7QUFKWCxHQS9MVSxDQVBTO0FBNk1yQixvQkFBa0IsQ0FDaEI7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxZQUFRLFdBRlY7QUFHRSxZQUFRLFNBSFY7QUFJRSxhQUFTLCtCQUpYO0FBS0UsYUFBUztBQUxYLEdBRGdCLEVBUWhCO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsWUFBUSxZQUZWO0FBR0UsWUFBUSxVQUhWO0FBSUUsYUFBUyxnQ0FKWDtBQUtFLGFBQVM7QUFMWCxHQVJnQixFQWVoQjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLFlBQVEsV0FGVjtBQUdFLFlBQVEsU0FIVjtBQUlFLGFBQVMsK0JBSlg7QUFLRSxhQUFTO0FBTFgsR0FmZ0IsRUFzQmhCO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsWUFBUSxZQUZWO0FBR0UsWUFBUSxVQUhWO0FBSUUsYUFBUyxnQ0FKWDtBQUtFLGFBQVM7QUFMWCxHQXRCZ0IsRUE2QmhCO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsWUFBUSxXQUZWO0FBR0UsWUFBUSxTQUhWO0FBSUUsYUFBUywrQkFKWDtBQUtFLGFBQVM7QUFMWCxHQTdCZ0IsRUFvQ2hCO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsWUFBUSxZQUZWO0FBR0UsWUFBUSxVQUhWO0FBSUUsYUFBUyxnQ0FKWDtBQUtFLGFBQVM7QUFMWCxHQXBDZ0IsRUEyQ2hCO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsYUFBUywyQkFGWDtBQUdFLGFBQVM7QUFIWCxHQTNDZ0IsRUFnRGhCO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsYUFBUyxFQUZYO0FBR0UsYUFBUztBQUhYLEdBaERnQixFQXFEaEI7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxZQUFRLGlCQUZWO0FBR0UsWUFBUSxVQUhWO0FBSUUsYUFBUyxnQ0FKWDtBQUtFLGFBQVM7QUFMWCxHQXJEZ0IsRUE0RGhCO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsWUFBUSxnQkFGVjtBQUdFLFlBQVEsU0FIVjtBQUlFLGFBQVMsK0JBSlg7QUFLRSxhQUFTO0FBTFgsR0E1RGdCLEVBbUVoQjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLFlBQVEsaUJBRlY7QUFHRSxZQUFRLFVBSFY7QUFJRSxhQUFTLGdDQUpYO0FBS0UsYUFBUztBQUxYLEdBbkVnQixFQTBFaEI7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxZQUFRLGdCQUZWO0FBR0UsWUFBUSxTQUhWO0FBSUUsYUFBUywrQkFKWDtBQUtFLGFBQVM7QUFMWCxHQTFFZ0IsRUFpRmhCO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsWUFBUSxpQkFGVjtBQUdFLFlBQVEsVUFIVjtBQUlFLGFBQVMsZ0NBSlg7QUFLRSxhQUFTO0FBTFgsR0FqRmdCLEVBd0ZoQjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLFlBQVEsZ0JBRlY7QUFHRSxZQUFRLFNBSFY7QUFJRSxhQUFTLCtCQUpYO0FBS0UsYUFBUztBQUxYLEdBeEZnQixFQStGaEI7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxZQUFRLE1BRlY7QUFHRSxhQUFTLDBCQUhYO0FBSUUsYUFBUztBQUpYLEdBL0ZnQixFQXFHaEI7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxhQUFTLEVBRlg7QUFHRSxhQUFTO0FBSFgsR0FyR2dCLENBN01HO0FBd1RyQix1QkFBcUIsQ0FDbkI7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxrQkFBYyxTQUZoQjtBQUdFLFlBQVEsTUFIVjtBQUlFLGFBQVM7QUFKWCxHQURtQixFQU9uQjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLGtCQUFjLFNBRmhCO0FBR0UsWUFBUSxNQUhWO0FBSUUsYUFBUztBQUpYLEdBUG1CLEVBYW5CO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLE1BSFY7QUFJRSxhQUFTO0FBSlgsR0FibUIsRUFtQm5CO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLE1BSFY7QUFJRSxhQUFTO0FBSlgsR0FuQm1CLEVBeUJuQjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLGtCQUFjLFNBRmhCO0FBR0UsWUFBUSxNQUhWO0FBSUUsYUFBUyxDQUpYO0FBS0UsZUFBVztBQUxiLEdBekJtQixFQWdDbkI7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxrQkFBYyxTQUZoQjtBQUdFLFlBQVEsTUFIVjtBQUlFLGFBQVMsQ0FKWDtBQUtFLGVBQVc7QUFMYixHQWhDbUIsRUF1Q25CO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLE1BSFY7QUFJRSxhQUFTO0FBSlgsR0F2Q21CLEVBNkNmO0FBQ0Ysd0JBQW9CLFNBRGxCO0FBRUYsa0JBQWMsU0FGWjtBQUdGLFlBQVEsU0FITjtBQUlGLGFBQVM7QUFKUCxHQTdDZSxFQW1EbkI7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxrQkFBYyxTQUZoQjtBQUdFLFlBQVEsVUFIVjtBQUlFLGFBQVM7QUFKWCxHQW5EbUIsRUF5RG5CO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLFNBSFY7QUFJRSxhQUFTLEVBSlg7QUFLRSxlQUFXO0FBTGIsR0F6RG1CLEVBZ0VuQjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLGtCQUFjLFNBRmhCO0FBR0UsWUFBUSxVQUhWO0FBSUUsYUFBUyxFQUpYO0FBS0UsZUFBVztBQUxiLEdBaEVtQixFQXVFbkI7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxrQkFBYyxTQUZoQjtBQUdFLFlBQVEsU0FIVjtBQUlFLGFBQVMsRUFKWDtBQUtFLGVBQVc7QUFMYixHQXZFbUIsRUE4RW5CO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLFVBSFY7QUFJRSxhQUFTLEVBSlg7QUFLRSxlQUFXO0FBTGIsR0E5RW1CLEVBcUZuQjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLGtCQUFjLFNBRmhCO0FBR0UsWUFBUSxTQUhWO0FBSUUsYUFBUztBQUpYLEdBckZtQixFQTJGbkI7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxrQkFBYyxTQUZoQjtBQUdFLFlBQVEsVUFIVjtBQUlFLGFBQVM7QUFKWCxHQTNGbUIsRUFpR25CO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLFNBSFY7QUFJRSxhQUFTO0FBSlgsR0FqR21CLEVBdUduQjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLGtCQUFjLFNBRmhCO0FBR0UsWUFBUSxVQUhWO0FBSUUsYUFBUztBQUpYLEdBdkdtQixFQTZHbkI7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxrQkFBYyxTQUZoQjtBQUdFLFlBQVEsU0FIVjtBQUlFLGFBQVM7QUFKWCxHQTdHbUIsRUFtSG5CO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLFVBSFY7QUFJRSxhQUFTO0FBSlgsR0FuSG1CLEVBeUhuQjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLGtCQUFjLFNBRmhCO0FBR0UsWUFBUSxTQUhWO0FBSUUsYUFBUztBQUpYLEdBekhtQixFQStIbkI7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxrQkFBYyxTQUZoQjtBQUdFLFlBQVEsVUFIVjtBQUlFLGFBQVM7QUFKWCxHQS9IbUIsRUFxSW5CO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLFNBSFY7QUFJRSxhQUFTO0FBSlgsR0FySW1CLEVBMkluQjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLGtCQUFjLFNBRmhCO0FBR0UsWUFBUSxVQUhWO0FBSUUsYUFBUztBQUpYLEdBM0ltQixFQWtKbkI7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxrQkFBYyxTQUZoQjtBQUdFLFlBQVEsU0FIVjtBQUlFLGFBQVM7QUFKWCxHQWxKbUIsRUF3Sm5CO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLFVBSFY7QUFJRSxhQUFTO0FBSlgsR0F4Sm1CLEVBOEpuQjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLGtCQUFjLFNBRmhCO0FBR0UsWUFBUSxTQUhWO0FBSUUsYUFBUztBQUpYLEdBOUptQixFQW9LbkI7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxrQkFBYyxTQUZoQjtBQUdFLFlBQVEsVUFIVjtBQUlFLGFBQVM7QUFKWCxHQXBLbUIsRUEwS25CO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLFNBSFY7QUFJRSxhQUFTO0FBSlgsR0ExS21CLEVBZ0xuQjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLGtCQUFjLFNBRmhCO0FBR0UsWUFBUSxVQUhWO0FBSUUsYUFBUztBQUpYLEdBaExtQixFQXNMbkI7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxrQkFBYyxTQUZoQjtBQUdFLFlBQVEsU0FIVjtBQUlFLGFBQVM7QUFKWCxHQXRMbUIsRUE0TG5CO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLFVBSFY7QUFJRSxhQUFTO0FBSlgsR0E1TG1CLEVBa01uQjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLGtCQUFjLFNBRmhCO0FBR0UsWUFBUSxTQUhWO0FBSUUsYUFBUztBQUpYLEdBbE1tQixFQXdNbkI7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxrQkFBYyxTQUZoQjtBQUdFLFlBQVEsVUFIVjtBQUlFLGFBQVM7QUFKWCxHQXhNbUIsRUE4TW5CO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLFNBSFY7QUFJRSxhQUFTO0FBSlgsR0E5TW1CLEVBb05uQjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLGtCQUFjLFNBRmhCO0FBR0UsWUFBUSxVQUhWO0FBSUUsYUFBUztBQUpYLEdBcE5tQixFQTBObkI7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxrQkFBYyxTQUZoQjtBQUdFLFlBQVEsZUFIVjtBQUlFLGFBQVM7QUFKWCxHQTFObUIsRUFnT25CO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLGdCQUhWO0FBSUUsYUFBUztBQUpYLEdBaE9tQixFQXNPbkI7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxrQkFBYyxTQUZoQjtBQUdFLFlBQVEsZUFIVjtBQUlFLGFBQVM7QUFKWCxHQXRPbUIsRUE0T25CO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsa0JBQWMsU0FGaEI7QUFHRSxZQUFRLGdCQUhWO0FBSUUsYUFBUztBQUpYLEdBNU9tQixDQXhUQTtBQTJpQnJCLGlCQUFlLENBQUMsR0FBRCxFQUFLLEdBQUwsRUFBUyxHQUFULEVBQWEsR0FBYixFQUFpQixHQUFqQixFQUFxQixHQUFyQixFQUF5QixHQUF6QixFQUE2QixHQUE3QixFQUFpQyxHQUFqQyxFQUFxQyxHQUFyQyxFQUF5QyxHQUF6QyxFQUE2QyxHQUE3QyxDQTNpQk07QUE0aUJyQixlQUFhLENBQ1gsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLEVBQWUsQ0FBZixFQUFpQixDQUFqQixFQUFtQixDQUFuQixFQUFxQixDQUFyQixFQUF1QixDQUF2QixDQURXLEVBRVgsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLEVBQWUsQ0FBZixFQUFpQixDQUFqQixFQUFtQixDQUFuQixFQUFxQixDQUFyQixFQUF1QixDQUF2QixDQUZXLEVBR1gsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLEVBQWUsQ0FBZixFQUFpQixDQUFqQixFQUFtQixDQUFuQixFQUFxQixDQUFyQixFQUF1QixDQUF2QixDQUhXLEVBSVgsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLEVBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLEVBQWUsQ0FBZixFQUFpQixDQUFqQixFQUFtQixDQUFuQixFQUFxQixDQUFyQixFQUF1QixDQUF2QixDQUpXLENBNWlCUTtBQWtqQnJCLGFBQVcsQ0FDVCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsRUFBZSxDQUFmLEVBQWlCLENBQWpCLEVBQW1CLENBQW5CLEVBQXFCLENBQXJCLEVBQXVCLENBQXZCLENBRFMsRUFFVCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsRUFBZSxDQUFmLEVBQWlCLENBQWpCLEVBQW1CLENBQW5CLEVBQXFCLENBQXJCLEVBQXVCLENBQXZCLENBRlMsRUFHVCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsRUFBZSxDQUFmLEVBQWlCLENBQWpCLEVBQW1CLENBQW5CLEVBQXFCLENBQXJCLEVBQXVCLENBQXZCLENBSFMsRUFJVCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsRUFBZSxDQUFmLEVBQWlCLENBQWpCLEVBQW1CLENBQW5CLEVBQXFCLENBQXJCLEVBQXVCLENBQXZCLENBSlMsRUFLVCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsRUFBZSxDQUFmLEVBQWlCLENBQWpCLEVBQW1CLENBQW5CLEVBQXFCLENBQXJCLEVBQXVCLENBQXZCLENBTFMsRUFNVCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsRUFBZSxDQUFmLEVBQWlCLENBQWpCLEVBQW1CLENBQW5CLEVBQXFCLENBQXJCLEVBQXVCLENBQXZCLENBTlMsRUFPVCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsRUFBZSxDQUFmLEVBQWlCLENBQWpCLEVBQW1CLENBQW5CLEVBQXFCLENBQXJCLEVBQXVCLENBQXZCLENBUFMsRUFRVCxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsRUFBUyxDQUFULEVBQVcsQ0FBWCxFQUFhLENBQWIsRUFBZSxDQUFmLEVBQWlCLENBQWpCLEVBQW1CLENBQW5CLEVBQXFCLENBQXJCLEVBQXVCLENBQXZCLENBUlMsQ0FsakJVO0FBNGpCckIsZ0JBQWM7QUE1akJPLENBQXZCLEM7Ozs7Ozs7Ozs7O0FDREE7QUFDQTtBQUNBO0FBQ0FDLGlCQUFpQkMsTUFBTUMsS0FBTixDQUFZLFVBQVVDLENBQVYsRUFBYTtBQUN4Q0MsUUFBTUQsQ0FBTixFQUFTckYsTUFBVDtBQUNBLFNBQU9xRixFQUFFRSxNQUFGLEdBQVcsQ0FBbEI7QUFDRCxDQUhnQixDQUFqQixDOzs7Ozs7Ozs7OztBQ0hBO0FBQ0E3RixPQUFPOEYsU0FBUCxHQUFtQjtBQUFFO0FBQ25CQyxxQkFBbUIsRUFERjtBQUVqQkMseUJBQXVCLEVBRk47QUFFVTtBQUMzQkMsMkJBQXlCLEdBSFI7QUFHYTtBQUM5QkMsNkJBQTBCLEVBSlQ7QUFJYTtBQUM5QkMsZUFBYSxFQUxJO0FBTWpCQyx1QkFBcUIsRUFOSjtBQU9qQkMsa0JBQWdCLEVBUEM7QUFRakJDLG1CQUFpQixDQVJBO0FBUUc7QUFDcEJDLHdCQUFzQixhQVRMO0FBVWpCQywwQkFBd0IsQ0FDdEI7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxZQUFRLFdBRlY7QUFHRSxZQUFRLFNBSFY7QUFJRSxhQUFTLCtCQUpYO0FBS0UsYUFBUztBQUxYLEdBRHNCLEVBUXRCO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsWUFBUSxZQUZWO0FBR0UsWUFBUSxVQUhWO0FBSUUsYUFBUyxnQ0FKWDtBQUtFLGFBQVM7QUFMWCxHQVJzQixFQWV0QjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLFlBQVEsV0FGVjtBQUdFLFlBQVEsU0FIVjtBQUlFLGFBQVMsK0JBSlg7QUFLRSxhQUFTO0FBTFgsR0Fmc0IsRUFzQnRCO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsWUFBUSxZQUZWO0FBR0UsWUFBUSxVQUhWO0FBSUUsYUFBUyxnQ0FKWDtBQUtFLGFBQVM7QUFMWCxHQXRCc0IsRUE2QnRCO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsWUFBUSxXQUZWO0FBR0UsWUFBUSxTQUhWO0FBSUUsYUFBUywrQkFKWDtBQUtFLGFBQVM7QUFMWCxHQTdCc0IsRUFvQ3RCO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsWUFBUSxZQUZWO0FBR0UsWUFBUSxVQUhWO0FBSUUsYUFBUyxnQ0FKWDtBQUtFLGFBQVM7QUFMWCxHQXBDc0IsRUEyQ3RCO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsYUFBUywyQkFGWDtBQUdFLGFBQVM7QUFIWCxHQTNDc0IsRUFnRHRCO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsYUFBUyxFQUZYO0FBR0UsYUFBUztBQUhYLEdBaERzQixFQXFEdEI7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxZQUFRLGlCQUZWO0FBR0UsWUFBUSxVQUhWO0FBSUUsYUFBUyxnQ0FKWDtBQUtFLGFBQVM7QUFMWCxHQXJEc0IsRUE0RHRCO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsWUFBUSxnQkFGVjtBQUdFLFlBQVEsU0FIVjtBQUlFLGFBQVMsK0JBSlg7QUFLRSxhQUFTO0FBTFgsR0E1RHNCLEVBbUV0QjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLFlBQVEsaUJBRlY7QUFHRSxZQUFRLFVBSFY7QUFJRSxhQUFTLGdDQUpYO0FBS0UsYUFBUztBQUxYLEdBbkVzQixFQTBFdEI7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxZQUFRLGdCQUZWO0FBR0UsWUFBUSxTQUhWO0FBSUUsYUFBUywrQkFKWDtBQUtFLGFBQVM7QUFMWCxHQTFFc0IsRUFpRnRCO0FBQ0Usd0JBQW9CLFNBRHRCO0FBRUUsWUFBUSxpQkFGVjtBQUdFLFlBQVEsVUFIVjtBQUlFLGFBQVMsZ0NBSlg7QUFLRSxhQUFTO0FBTFgsR0FqRnNCLEVBd0Z0QjtBQUNFLHdCQUFvQixTQUR0QjtBQUVFLFlBQVEsZ0JBRlY7QUFHRSxZQUFRLFNBSFY7QUFJRSxhQUFTLCtCQUpYO0FBS0UsYUFBUztBQUxYLEdBeEZzQixFQStGdEI7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxZQUFRLE1BRlY7QUFHRSxhQUFTLDBCQUhYO0FBSUUsYUFBUztBQUpYLEdBL0ZzQixFQXFHdEI7QUFDRSx3QkFBb0IsU0FEdEI7QUFFRSxhQUFTLEVBRlg7QUFHRSxhQUFTO0FBSFgsR0FyR3NCO0FBVlAsQ0FBbkIsQzs7Ozs7Ozs7Ozs7QUNEQTtBQUNBO0FBRUEsSUFBSXhHLE9BQU95RyxRQUFYLEVBQXFCO0FBQ25CQyxhQUFXLElBQUlDLFdBQUosRUFBWDtBQUVBLE1BQUlDLGdCQUFnQjVHLE9BQU93RCxNQUFQLEVBQXBCO0FBQ0FxRCxVQUFRQyxHQUFSLENBQVksZUFBWixFQUE2QixhQUE3QjtBQUVBQyxXQUFTQyxjQUFULENBQXdCQyxNQUF4QixDQUErQjtBQUFDLDBCQUFzQixVQUFTQyxLQUFULEVBQWdCQyxRQUFoQixFQUF5QjtBQUMzRUQsWUFBTUUsY0FBTjs7QUFDQSxVQUFJQyxhQUFhQyxPQUFPQyxPQUFQLEdBQWlCQyxNQUFqQixDQUF3QjNELEdBQXpDOztBQUNBLFVBQUk0RCxPQUFPQyxTQUFTQyxjQUFULENBQXdCLFlBQXhCLEVBQXNDQyxLQUF0QyxDQUE0QyxDQUE1QyxDQUFYO0FBRUE1SCxhQUFPNkgsWUFBUCxDQUFvQkMsb0JBQXBCLENBQXlDTCxJQUF6QyxFQUErQ0osVUFBL0M7QUFDRDtBQU40QixHQUEvQjtBQVNBckgsU0FBTytILFNBQVAsQ0FBaUIsUUFBakI7QUFDRDs7QUFFRCxJQUFJL0gsT0FBT21DLFFBQVgsRUFBcUI7QUFDbkI2RixZQUFVQyxnQkFBVixDQUEyQixnQkFBM0IsRUFBNkM7QUFDM0NDLHNCQUFrQixDQUFDLFdBQUQsRUFBYyxZQUFkLEVBQTRCLFdBQTVCLENBRHlCO0FBRTNDQyxhQUFTLElBQUksSUFBSixHQUFXO0FBRnVCLEdBQTdDO0FBS0FILFlBQVVJLGVBQVYsQ0FBMEIsZ0JBQTFCLEVBQTRDSixVQUFVSyxTQUF0RCxFQUFpRTtBQUMvREMsb0JBQWdCdEksT0FBT3VJLFFBQVAsQ0FBZ0J6RCxPQUFoQixDQUF3QndELGNBRHVCO0FBRS9ERSx3QkFBb0J4SSxPQUFPdUksUUFBUCxDQUFnQnpELE9BQWhCLENBQXdCMEQsa0JBRm1CO0FBRy9EQyxZQUFRekksT0FBT3VJLFFBQVAsQ0FBZ0J6RCxPQUFoQixDQUF3QjRELFNBSCtCO0FBSS9EQyxTQUFLLGFBSjBEO0FBSy9EQyxZQUFRNUksT0FBT3VJLFFBQVAsQ0FBZ0JNLE1BQWhCLENBQXVCQyxTQUxnQztBQU8vREMsZUFBVyxVQUFVdEIsSUFBVixFQUFnQnVCLE9BQWhCLEVBQXlCO0FBRWxDO0FBQ0EsVUFBSSxDQUFDLEtBQUt4RixNQUFWLEVBQWtCO0FBQ2hCLFlBQUl5RixVQUFVLHdCQUFkO0FBQ0EsY0FBTSxJQUFJakosT0FBT2tKLEtBQVgsQ0FBaUIsZ0JBQWpCLEVBQW1DRCxPQUFuQyxDQUFOO0FBQ0QsT0FOaUMsQ0FRbEM7OztBQUNBLFVBQUlFLE9BQU9uSixPQUFPd0MsS0FBUCxDQUFhNEcsT0FBYixDQUFxQjtBQUFDdkYsYUFBSyxLQUFLTDtBQUFYLE9BQXJCLEVBQXlDO0FBQUVRLGdCQUFRO0FBQUNxRixrQkFBUTtBQUFUO0FBQVYsT0FBekMsQ0FBWDs7QUFDQSxVQUFJLENBQUNGLEtBQUtFLE1BQUwsQ0FBWSxDQUFaLEVBQWVDLFFBQXBCLEVBQThCO0FBQzVCLFlBQUlMLFVBQVUscUNBQWQ7QUFDQSxjQUFNLElBQUlqSixPQUFPa0osS0FBWCxDQUFpQixnQkFBakIsRUFBbUNELE9BQW5DLENBQU47QUFDRCxPQWJpQyxDQWVsQzs7O0FBQ0EsVUFBSU0sVUFBVXJILFNBQVNrSCxPQUFULENBQWlCO0FBQUN2RixhQUFLbUYsUUFBUTNCO0FBQWQsT0FBakIsRUFBNEM7QUFBRXJELGdCQUFRO0FBQUMxQyxzQkFBWTtBQUFiO0FBQVYsT0FBNUMsQ0FBZDs7QUFDQSxVQUFJaUksUUFBUWpJLFVBQVIsSUFBc0IsS0FBS2tDLE1BQS9CLEVBQ0E7QUFDRSxZQUFJeUYsVUFBVSxrQ0FBZDtBQUNBLGNBQU0sSUFBSWpKLE9BQU9rSixLQUFYLENBQWlCLGdCQUFqQixFQUFtQ0QsT0FBbkMsQ0FBTjtBQUNELE9BckJpQyxDQXVCbEM7OztBQUNBLFVBQUlPLGNBQWN4SixPQUFPeUosSUFBUCxDQUFZLGlCQUFaLENBQWxCO0FBRUEsVUFBSUMsY0FBYzNKLFdBQVdxSixPQUFYLENBQW1CO0FBQUN2RixhQUFLMkY7QUFBTixPQUFuQixFQUF1QztBQUFDeEYsZ0JBQVE7QUFBRWxELDBCQUFnQixDQUFsQjtBQUFxQkwsa0JBQVE7QUFBN0I7QUFBVCxPQUF2QyxDQUFsQjtBQUVBLFVBQUlrSixZQUFZRCxZQUFZNUksY0FBNUI7QUFFQSxVQUFJNEksWUFBWWpKLE1BQWhCLEVBQ0EsTUFBTSxJQUFJVCxPQUFPa0osS0FBWCxDQUFpQixnQkFBakIsRUFBbUMsK0RBQW5DLENBQU47QUFFQSxVQUFJVSxvQkFBb0JELFVBQVU5RCxNQUFsQztBQUNBLFVBQUlnRSx5QkFBeUJDLFNBQVNDLE9BQVQsS0FBcUJKLFVBQVUsQ0FBVixDQUFsRCxDQWxDa0MsQ0FvQ2xDO0FBQ0E7O0FBQ0EsVUFBSUsscUJBQXFCTCxVQUFVLENBQVYsSUFBZUEsVUFBVSxDQUFWLENBQXhDOztBQUNBLFVBQUlLLHFCQUFxQixJQUF6QixFQUNBO0FBQ0VqSyxtQkFBV3VELE1BQVgsQ0FBbUI7QUFBQ08sZUFBSzJGO0FBQU4sU0FBbkIsRUFBdUM7QUFBRS9JLGtCQUFRO0FBQVYsU0FBdkM7QUFDQSxjQUFNLElBQUlULE9BQU9rSixLQUFYLENBQWlCLGdCQUFqQixFQUFtQywrREFBbkMsQ0FBTjtBQUNEOztBQUVELFVBQUllLG9CQUFvQk4sVUFBVSxDQUFWLElBQWVBLFVBQVUsQ0FBVixDQUF2Qzs7QUFDQSxVQUFJTSxvQkFBb0IsSUFBeEIsRUFDQTtBQUNFO0FBQ0EsWUFBSUoseUJBQTBCLEtBQUssSUFBTCxHQUFZLENBQTFDLEVBQ0UsTUFBTSxJQUFJN0osT0FBT2tKLEtBQVgsQ0FBaUIsbUJBQWpCLEVBQXNDLG9DQUF0QyxDQUFOLENBREYsQ0FHQTtBQUhBLGFBS0E7QUFDRSxnQkFBSWdCLHdCQUF3QlAsVUFBVSxDQUFWLElBQWVBLFVBQVUsQ0FBVixDQUEzQzs7QUFDQSxnQkFBSU8sd0JBQXdCLElBQTVCLEVBQ0E7QUFDRTtBQUNBO0FBQ0Esa0JBQUlMLHlCQUEwQixLQUFLLElBQUwsR0FBWSxFQUFaLEdBQWlCLElBQS9DLEVBQ0UsTUFBTSxJQUFJN0osT0FBT2tKLEtBQVgsQ0FBaUIsbUJBQWpCLEVBQXNDLHFDQUF0QyxDQUFOO0FBQ0g7QUFDRjtBQUNGLE9BaEVpQyxDQWtFbEM7OztBQUNBbkosaUJBQVd1RCxNQUFYLENBQW1CO0FBQUNPLGFBQUsyRjtBQUFOLE9BQW5CLEVBQXVDO0FBQUVXLGVBQU87QUFBRXJKLDBCQUFnQjtBQUNoRXNKLG1CQUFPLENBQUNOLFNBQVNDLE9BQVQsRUFBRCxDQUR5RDtBQUVoRU0sdUJBQVc7QUFGcUQ7QUFBbEI7QUFBVCxPQUF2QztBQUlKLE9BdkVzQyxDQXdFbEM7O0FBQ0EsVUFBSVQsb0JBQW9CNUosT0FBT3VJLFFBQVAsQ0FBZ0J6RCxPQUFoQixDQUF3QndGLHdCQUFoRCxFQUNBO0FBQ0V2SyxtQkFBV3VELE1BQVgsQ0FBbUI7QUFBQ08sZUFBSzJGO0FBQU4sU0FBbkIsRUFBdUM7QUFBRWUsZ0JBQU07QUFBRXpKLDRCQUFnQjtBQUFsQjtBQUFSLFNBQXZDO0FBQ0Q7O0FBRUQsYUFBTyxJQUFQO0FBQ0QsS0F0RjhEO0FBd0YvREssU0FBSyxVQUFVc0csSUFBVixFQUFnQjtBQUNuQixVQUFJK0MsUUFBUS9DLEtBQUs3RixJQUFMLENBQVU2SSxLQUFWLENBQWdCLEdBQWhCLENBQVosQ0FEbUIsQ0FDZTs7QUFDbEMsVUFBSUMsWUFBWUYsTUFBTUcsR0FBTixFQUFoQjtBQUNBLFVBQUkvSSxPQUFPNEksTUFBTUksSUFBTixDQUFXLEVBQVgsQ0FBWCxDQUhtQixDQUdROztBQUMzQixVQUFJaEosT0FBT0EsS0FBS2lKLEtBQUwsQ0FBVyxDQUFYLEVBQWEsRUFBYixJQUFtQixHQUFuQixHQUF5QmYsU0FBU0MsT0FBVCxHQUFtQmUsUUFBbkIsRUFBekIsR0FBeUQsR0FBekQsR0FBK0RKLFNBQTFFLENBSm1CLENBSWtFOztBQUNyRixhQUFPMUssT0FBT3dELE1BQVAsS0FBa0IsR0FBbEIsR0FBd0I1QixJQUEvQjtBQUNEO0FBOUY4RCxHQUFqRTtBQWdHRCxDOzs7Ozs7Ozs7OztBQzNIRDBGLE9BQU95RCxTQUFQLENBQWlCO0FBQ2ZDLGtCQUFnQixhQUREO0FBRWZDLGNBQVksSUFGRztBQUdmQyxtQkFBaUI7QUFIRixDQUFqQixFLENBTUE7O0FBRUE1RCxPQUFPNkQsS0FBUCxDQUFhLEdBQWIsRUFBa0I7QUFDaEJ2SixRQUFNLE1BRFU7QUFFaEJ1RixZQUFVO0FBRk0sQ0FBbEI7QUFLQUcsT0FBTzZELEtBQVAsQ0FBYSxRQUFiLEVBQXVCO0FBQ3JCdkosUUFBTSxPQURlO0FBRXJCdUYsWUFBVTtBQUZXLENBQXZCO0FBS0FHLE9BQU82RCxLQUFQLENBQWEsa0JBQWIsRUFBaUM7QUFDL0J2SixRQUFNLGlCQUR5QjtBQUUvQnVGLFlBQVU7QUFGcUIsQ0FBakM7QUFLQUcsT0FBTzZELEtBQVAsQ0FBYSxlQUFiLEVBQThCO0FBQzVCdkosUUFBTSxjQURzQjtBQUU1QnVGLFlBQVU7QUFGa0IsQ0FBOUI7QUFLQUcsT0FBTzZELEtBQVAsQ0FBYSxjQUFiLEVBQTZCO0FBQzNCdkosUUFBTSxhQURxQjtBQUUzQnVGLFlBQVU7QUFGaUIsQ0FBN0I7QUFLQUcsT0FBTzZELEtBQVAsQ0FBYSxlQUFiLEVBQThCO0FBQzVCdkosUUFBTSxjQURzQjtBQUU1QnVGLFlBQVU7QUFGa0IsQ0FBOUI7QUFNQUcsT0FBTzZELEtBQVAsQ0FBYSxRQUFiLEVBQXVCO0FBQ3JCdkosUUFBTSxPQURlO0FBRXJCdUYsWUFBVTtBQUZXLENBQXZCO0FBS0FHLE9BQU82RCxLQUFQLENBQWEsc0JBQWIsRUFBcUM7QUFDbkN2SixRQUFNLFNBRDZCO0FBRW5Dd0osUUFBTSxZQUFVO0FBQ2QsUUFBSS9ELGFBQWEsS0FBS0csTUFBTCxDQUFZM0QsR0FBN0I7QUFFQSxXQUFPM0IsU0FBU2tILE9BQVQsQ0FBaUI7QUFBRXZGLFdBQUt3RDtBQUFQLEtBQWpCLEVBQXNDO0FBQUNyRCxjQUFRO0FBQUNxSCxpQkFBUyxDQUFWO0FBQWFDLG1CQUFXLENBQXhCO0FBQTJCQyxxQkFBYTtBQUF4QztBQUFULEtBQXRDLENBQVA7QUFDRCxHQU5rQztBQU9uQ0MsVUFBUSxZQUFVO0FBQ2hCLFFBQUluRSxhQUFhLEtBQUtHLE1BQUwsQ0FBWTNELEdBQTdCO0FBQ0EsUUFBSTJELFNBQVM7QUFDWEgsa0JBQVlBO0FBREQsS0FBYjtBQUlBLFdBQU8sQ0FDTHJILE9BQU8rSCxTQUFQLENBQWlCLFNBQWpCLEVBQTRCUCxNQUE1QixDQURLLENBQVA7QUFHRCxHQWhCa0M7QUFpQm5DaUUsVUFBUSxZQUFXO0FBQ2pCLFFBQUlwRSxhQUFhLEtBQUtHLE1BQUwsQ0FBWTNELEdBQTdCOztBQUVBLFFBQUkzQixTQUFTd0osSUFBVCxDQUFjO0FBQUU3SCxXQUFLd0Q7QUFBUCxLQUFkLEVBQWtDc0UsS0FBbEMsTUFBNkMsQ0FBakQsRUFDQTtBQUNFLFdBQUtDLE1BQUwsQ0FBWSxhQUFaO0FBQ0EsV0FBS0MsTUFBTCxDQUFZLG1CQUFaO0FBQ0EsV0FBS0EsTUFBTCxDQUFZLElBQVosRUFBa0I7QUFBQ0MsWUFBSTtBQUFMLE9BQWxCLEVBSEYsQ0FHcUM7QUFDcEMsS0FMRCxNQU9LLElBQUksS0FBS3RFLE1BQUwsQ0FBWXVFLElBQVosSUFBb0IsU0FBeEIsRUFDTDtBQUNFLFdBQUtGLE1BQUwsQ0FBWSxlQUFaO0FBQ0EsV0FBS0EsTUFBTCxDQUFZLElBQVosRUFBa0I7QUFBQ0MsWUFBSTtBQUFMLE9BQWxCO0FBQ0QsS0FKSSxNQU1BLElBQUksS0FBS3RFLE1BQUwsQ0FBWXVFLElBQVosSUFBb0IsT0FBeEIsRUFDTDtBQUNFLFdBQUtILE1BQUwsQ0FBWSxjQUFaO0FBQ0EsV0FBS0MsTUFBTCxDQUFZLGVBQVo7QUFDQSxXQUFLQSxNQUFMLENBQVksSUFBWixFQUFrQjtBQUFDQyxZQUFJO0FBQUwsT0FBbEI7QUFDRCxLQUxJLE1BUUw7QUFDRSxXQUFLRCxNQUFMLENBQVksY0FBWjtBQUVBLFVBQUk3TCxPQUFPNkgsWUFBUCxDQUFvQm1FLGdCQUFwQixDQUFxQzNFLFVBQXJDLENBQUosRUFDRSxLQUFLd0UsTUFBTCxDQUFZLGdCQUFaLEVBQThCO0FBQUNDLFlBQUk7QUFBTCxPQUE5QixFQURGLEtBSUUsS0FBS0QsTUFBTCxDQUFZLElBQVosRUFBa0I7QUFBQ0MsWUFBSTtBQUFMLE9BQWxCO0FBQ0g7QUFFRjtBQW5Ea0MsQ0FBckM7QUFzREF4RSxPQUFPNkQsS0FBUCxDQUFhLFlBQWIsRUFBMkI7QUFDekJ2SixRQUFNLE1BRG1CO0FBRXpCd0osUUFBTSxZQUFVO0FBQ2QsUUFBSWhMLFVBQVUsS0FBS29ILE1BQUwsQ0FBWTNELEdBQTFCO0FBRUEsV0FBTzdELE9BQU93QyxLQUFQLENBQWE0RyxPQUFiLENBQXFCO0FBQUV2RixXQUFLekQ7QUFBUCxLQUFyQixDQUFQO0FBQ0QsR0FOd0I7QUFPekJvTCxVQUFRLFlBQVU7QUFDaEIsUUFBSXBMLFVBQVUsS0FBS29ILE1BQUwsQ0FBWTNELEdBQTFCO0FBQ0EsUUFBSTJELFNBQVM7QUFDWHBILGVBQVNBO0FBREUsS0FBYjtBQUlBLFdBQU8sQ0FDTEosT0FBTytILFNBQVAsQ0FBaUIsTUFBakIsRUFBeUJQLE1BQXpCLENBREssQ0FBUDtBQUdELEdBaEJ3QjtBQWlCekJpRSxVQUFRLFlBQVc7QUFDakIsUUFBSXJMLFVBQVUsS0FBS29ILE1BQUwsQ0FBWTNELEdBQTFCO0FBRUEsUUFBSTdELE9BQU93QyxLQUFQLENBQWFrSixJQUFiLENBQWtCO0FBQUU3SCxXQUFLekQ7QUFBUCxLQUFsQixFQUFtQ3VMLEtBQW5DLE1BQThDLENBQWxELEVBQ0UsS0FBS0UsTUFBTCxDQUFZLGdCQUFaLEVBREYsS0FJRSxLQUFLQSxNQUFMLENBQVksTUFBWjtBQUNIO0FBekJ3QixDQUEzQjtBQTRCQXZFLE9BQU82RCxLQUFQLENBQWEsbUJBQWIsRUFBa0M7QUFDaEN2SixRQUFNLGtCQUQwQjtBQUVoQ3dKLFFBQU0sWUFBVztBQUNmLFFBQUloTCxVQUFVSixPQUFPd0QsTUFBUCxFQUFkO0FBRUEsV0FBT3hELE9BQU93QyxLQUFQLENBQWE0RyxPQUFiLENBQXFCO0FBQUV2RixXQUFLekQ7QUFBUCxLQUFyQixDQUFQO0FBQ0QsR0FOK0I7QUFPaENvTCxVQUFRLFlBQVU7QUFDaEIsUUFBSXBMLFVBQVVKLE9BQU93RCxNQUFQLEVBQWQ7QUFFQSxRQUFJZ0UsU0FBUztBQUNYcEgsZUFBU0E7QUFERSxLQUFiO0FBSUEsV0FBTyxDQUNMSixPQUFPK0gsU0FBUCxDQUFpQixNQUFqQixFQUF5QlAsTUFBekIsQ0FESyxDQUFQO0FBR0QsR0FqQitCO0FBa0JoQ2lFLFVBQVEsWUFBVztBQUNqQjtBQUNBLFNBQUtJLE1BQUwsQ0FBWSxrQkFBWjtBQUNEO0FBckIrQixDQUFsQyxFOzs7Ozs7Ozs7OztBQzlIQTdMLE9BQU9pTSxPQUFQLENBQWUsWUFBWTtBQUN6QkMsVUFBUUMsR0FBUixDQUFZQyxRQUFaLEdBQXVCcE0sT0FBT3VJLFFBQVAsQ0FBZ0IsU0FBaEIsRUFBMkI2RCxRQUFsRDtBQUNBRixVQUFRQyxHQUFSLENBQVlFLFFBQVosR0FBdUJyTSxPQUFPdUksUUFBUCxDQUFnQixTQUFoQixFQUEyQjhELFFBQWxELENBRnlCLENBSXpCOztBQUNBQyxXQUFTQyxNQUFULENBQWdCO0FBQ2RDLDJCQUF1QjtBQURULEdBQWhCO0FBSUFGLFdBQVNHLGNBQVQsQ0FBd0JDLFFBQXhCLEdBQW1DLGlCQUFuQztBQUNBSixXQUFTRyxjQUFULENBQXdCRSxJQUF4QixHQUErQiwrQ0FBL0I7O0FBQ0FMLFdBQVNHLGNBQVQsQ0FBd0JHLFdBQXhCLENBQW9DQyxPQUFwQyxHQUE4QyxVQUFVMUQsSUFBVixFQUFnQjtBQUMxRCxXQUFPLDJCQUFQO0FBQ0gsR0FGRDs7QUFHQW1ELFdBQVNHLGNBQVQsQ0FBd0JHLFdBQXhCLENBQW9DRSxJQUFwQyxHQUEyQyxVQUFVM0QsSUFBVixFQUFnQmpJLEdBQWhCLEVBQXFCO0FBQzdELFdBQU8sV0FBV2lJLEtBQUszSSxRQUFoQixHQUNILG9LQURHLEdBRUhVLEdBRko7QUFHRixHQUpELENBZHlCLENBb0J6Qjs7O0FBQ0FsQixTQUFPd0MsS0FBUCxDQUFha0osSUFBYixHQUFvQnFCLGNBQXBCLENBQW1DO0FBQ2pDQyxhQUFTLFVBQVM1SixFQUFULEVBQWFZLE1BQWIsRUFBcUI7QUFDNUJoRSxhQUFPeUosSUFBUCxDQUFZLG1CQUFaLEVBQWlDckcsRUFBakM7QUFDRDtBQUhnQyxHQUFuQyxFQXJCeUIsQ0EyQnpCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztPQS9CeUIsQ0FvQ3pCO0FBQ0E7Ozs7QUFLRCxDQTFDRDtBQTRDQWtKLFNBQVNXLFlBQVQsQ0FBc0IsVUFBU0MsT0FBVCxFQUFrQi9ELElBQWxCLEVBQXdCO0FBQzVDO0FBQ0FBLE9BQUtnRSxPQUFMLEdBQWVELFFBQVFDLE9BQVIsSUFBbUIsRUFBbEM7QUFDQWhFLE9BQUtnRSxPQUFMLENBQWFuSSxTQUFiLEdBQXlCbUUsS0FBSzNJLFFBQUwsQ0FBY3dCLFdBQWQsRUFBekI7QUFDQSxTQUFPbUgsSUFBUDtBQUNELENBTEQsRTs7Ozs7Ozs7Ozs7QUM1Q0FuSixPQUFPb04sT0FBUCxDQUFlO0FBQ2I7QUFDQTtBQUNBQyxxQkFBbUIsWUFBVztBQUM1QjtBQUNBQyxZQUFRQyxHQUFSLENBQVksY0FBY3ZOLE9BQU93TixJQUFQLENBQVk5QixJQUFaLEdBQW1CK0IsS0FBbkIsR0FBMkJDLEdBQTNCLENBQStCLFVBQVNDLEdBQVQsRUFBYztBQUFDLGFBQU9BLElBQUkvTCxJQUFYO0FBQWdCLEtBQTlELENBQTFCO0FBQ0QsR0FOWTtBQU9iZ00sc0JBQW9CLFlBQVc7QUFDN0IsUUFBSSxDQUFDNU4sT0FBT3dELE1BQVAsRUFBTCxFQUNFLE9BQU8sS0FBUDtBQUVGLFFBQUltSSxRQUFRekosU0FBU3dKLElBQVQsQ0FBYztBQUFDcEssa0JBQVl0QixPQUFPd0QsTUFBUDtBQUFiLEtBQWQsRUFBNkNtSSxLQUE3QyxFQUFaOztBQUVBLFFBQUlrQyxNQUFNQyxZQUFOLENBQW9COU4sT0FBT3dELE1BQVAsRUFBcEIsRUFBcUMsVUFBckMsRUFBaUQsT0FBakQsQ0FBSixFQUNBO0FBQ0UsVUFBSXFLLE1BQU1DLFlBQU4sQ0FBb0I5TixPQUFPd0QsTUFBUCxFQUFwQixFQUFxQyxTQUFyQyxFQUFnRCxPQUFoRCxDQUFKLEVBQ0E7QUFDRSxZQUFJbUksUUFBUTNMLE9BQU91SSxRQUFQLENBQWdCTSxNQUFoQixDQUF1QmtGLHFCQUF2QixDQUE2Q0MsT0FBekQsRUFDRSxPQUFPLElBQVAsQ0FERixLQUlFLE9BQU8sS0FBUDtBQUNILE9BUEQsTUFTQTtBQUNFLFlBQUlyQyxRQUFRM0wsT0FBT3VJLFFBQVAsQ0FBZ0JNLE1BQWhCLENBQXVCa0YscUJBQXZCLENBQTZDekUsUUFBekQsRUFDRSxPQUFPLElBQVAsQ0FERixLQUlFLE9BQU8sS0FBUDtBQUNIO0FBQ0YsS0FsQkQsQ0FtQkE7QUFuQkEsU0FxQkE7QUFDRSxZQUFJcUMsUUFBUTNMLE9BQU91SSxRQUFQLENBQWdCTSxNQUFoQixDQUF1QmtGLHFCQUF2QixDQUE2Q0UsT0FBekQsRUFDRSxPQUFPLElBQVAsQ0FERixLQUlFLE9BQU8sS0FBUDtBQUNIO0FBQ0YsR0F6Q1k7QUF5Q1g7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7TUFxQkZDLHVCQUF1QixVQUFTaEIsT0FBVCxFQUFrQjtBQUN2QztBQUNBOzs7UUFGdUMsQ0FPdkM7QUFDQTtBQUNBO0FBQ0F0SCxVQUFNc0gsT0FBTixFQUFlO0FBQ2JpQixpQkFBVzFJLE1BQU0ySSxRQUFOLENBQWU5TixNQUFmLENBREU7QUFFYjZFLHlCQUFtQk0sTUFBTTJJLFFBQU4sQ0FBZTlOLE1BQWYsQ0FGTjtBQUdiK04sc0JBQWdCNUksTUFBTTJJLFFBQU4sQ0FBZTlOLE1BQWYsQ0FISDtBQUlic0IsWUFBTTZELE1BQU0ySSxRQUFOLENBQWU5TixNQUFmLENBSk87QUFLYjhLLFlBQU1rRCxNQUxPO0FBTWJDLHVCQUFpQjlJLE1BQU0ySSxRQUFOLENBQWU5TixNQUFmO0FBTkosS0FBZjtBQVNBLFFBQUksQ0FBQ04sT0FBT21DLFFBQVosRUFBc0I7QUFDbEI7O0FBRUosUUFBSSxDQUFDbkMsT0FBT3dELE1BQVAsRUFBTCxFQUFzQjtBQUNwQjtBQUNBLFlBQU0sSUFBSXhELE9BQU9rSixLQUFYLENBQWlCLGdCQUFqQixFQUFtQywrQ0FBbkMsQ0FBTjtBQUNEOztBQUVELFFBQUlzRixTQUFTeE8sT0FBT3lKLElBQVAsQ0FBWSxvQkFBWixDQUFiO0FBQ0EsUUFBSSxDQUFDK0UsTUFBTCxFQUNFLE1BQU0sSUFBSXhPLE9BQU9rSixLQUFYLENBQWlCLGdCQUFqQixFQUFtQyxzQ0FBbkMsQ0FBTjs7QUFFRixRQUFJLE9BQU9nRSxRQUFROUIsSUFBZixLQUF3QixXQUE1QixFQUNBO0FBQ0UsVUFBSUEsT0FBTzhCLFFBQVE5QixJQUFuQjtBQUNELEtBSEQsTUFJSyxJQUFJLE9BQU84QixRQUFRdUIsUUFBZixLQUE0QixXQUFoQyxFQUNMO0FBQ0UsVUFBSTtBQUNGLFlBQUlyRCxPQUFPc0QsS0FBS0MsS0FBTCxDQUFXQyxPQUFPQyxPQUFQLENBQWUzQixRQUFRdUIsUUFBdkIsQ0FBWCxDQUFYO0FBQ0QsT0FGRCxDQUdBLE9BQU1LLENBQU4sRUFDQTtBQUNFO0FBQ0EsY0FBTSxJQUFJOU8sT0FBT2tKLEtBQVgsQ0FBaUIsa0JBQWpCLEVBQXFDLDBDQUFyQyxDQUFOO0FBQ0Q7QUFDRixLQVZJLE1BWUw7QUFDRTtBQUNBLFlBQU0sSUFBSWxKLE9BQU9rSixLQUFYLENBQWlCLGtCQUFqQixFQUFxQywwQ0FBckMsQ0FBTjtBQUNELEtBbERzQyxDQW9EdkM7OztBQUNBLFFBQUk2RixVQUFVLENBQUMsQ0FBRCxFQUFHLENBQUgsQ0FBZDs7QUFDQSxRQUFJLE9BQU8zRCxLQUFLMkQsT0FBWixLQUF3QixXQUE1QixFQUNBO0FBQ0UsVUFBSUMsZ0JBQWdCNUQsS0FBSzJELE9BQUwsQ0FBYXRFLEtBQWIsQ0FBbUIsR0FBbkIsQ0FBcEIsQ0FERixDQUMrQzs7QUFDN0MsVUFBSSxPQUFPdUUsY0FBYyxDQUFkLENBQVAsS0FBNEIsV0FBaEMsRUFDQTtBQUNFRCxnQkFBUSxDQUFSLElBQWFFLFNBQVNELGNBQWMsQ0FBZCxDQUFULENBQWI7O0FBRUEsWUFBSSxPQUFPQSxjQUFjLENBQWQsQ0FBUCxLQUE0QixXQUFoQyxFQUNBO0FBQ0VELGtCQUFRLENBQVIsSUFBYUUsU0FBU0QsY0FBYyxDQUFkLENBQVQsQ0FBYjtBQUNEO0FBQ0Y7QUFDRixLQWxFc0MsQ0FvRXZDOzs7QUFDQSxRQUFJOUIsUUFBUWlCLFNBQVIsSUFBcUIsRUFBdEIsSUFBOEIsT0FBT2pCLFFBQVFpQixTQUFmLEtBQTZCLFdBQTlELEVBQ0VqQixRQUFRaUIsU0FBUixHQUFvQixVQUFwQixDQXRFcUMsQ0FzRUw7O0FBRWxDLFFBQUkvQyxLQUFLK0MsU0FBTCxJQUFrQixFQUFuQixJQUEyQixPQUFPL0MsS0FBSytDLFNBQVosS0FBMEIsV0FBeEQsRUFDRS9DLEtBQUsrQyxTQUFMLEdBQWlCakIsUUFBUWlCLFNBQXpCLENBekVxQyxDQTJFdkM7QUFDQTs7QUFDQSxRQUFJZSxZQUFZLElBQWhCLENBN0V1QyxDQTZFakI7O0FBQ3RCLFFBQUssT0FBT2hDLFFBQVEvSCxpQkFBZixLQUFxQyxXQUF0QyxJQUF1RCxPQUFPK0gsUUFBUW1CLGNBQWYsS0FBa0MsV0FBN0YsRUFDQTtBQUNFLFVBQUljLFVBQVVGLFNBQVMvQixRQUFRL0gsaUJBQWpCLENBQWQ7QUFFQSxVQUFJaUssTUFBTUQsT0FBTixDQUFKLEVBQ0VELFlBQVksS0FBWixDQURGLEtBR0ssSUFBS0MsVUFBUyxDQUFWLElBQWlCQSxVQUFVLEdBQS9CLEVBQ0hELFlBQVksS0FBWjtBQUVGLFVBQUlHLE9BQU9KLFNBQVMvQixRQUFRbUIsY0FBakIsQ0FBWDtBQUVBLFVBQUtnQixPQUFNLENBQVAsSUFBY0EsT0FBTyxHQUF6QixFQUNFLElBQUluQyxRQUFRaUIsU0FBUixJQUFxQixZQUF6QixFQUF1QztBQUNyQ2Usb0JBQVksS0FBWjtBQUNMLEtBZkQsTUFpQkE7QUFDRUEsa0JBQVksS0FBWjtBQUNEOztBQUVELFFBQUlBLFNBQUosRUFDQTtBQUNFO0FBQ0EsY0FBT2hDLFFBQVFpQixTQUFmO0FBQ0UsYUFBSyxVQUFMO0FBQ0UvQyxlQUFLa0UsZ0JBQUwsR0FBd0IsTUFBeEI7QUFDQTs7QUFFRixhQUFLLFlBQUw7QUFDRWxFLGVBQUtrRSxnQkFBTCxHQUF3QixJQUF4QjtBQUNBOztBQUVGLGFBQUssY0FBTDtBQUNFbEUsZUFBS2tFLGdCQUFMLEdBQXdCLElBQXhCO0FBQ0E7QUFYSixPQUZGLENBZ0JFOzs7QUFDQWxFLFdBQUtDLE9BQUwsR0FBZSxJQUFJa0UsS0FBSixFQUFmOztBQUVBLFdBQUssSUFBSUMsSUFBRSxDQUFYLEVBQWNBLElBQUV0QyxRQUFRbUIsY0FBeEIsRUFBd0NtQixHQUF4QyxFQUNBO0FBQ0VwRSxhQUFLQyxPQUFMLENBQWFtRSxDQUFiLElBQWtCLElBQUlELEtBQUosRUFBbEI7O0FBQ0EsYUFBSyxJQUFJRSxJQUFFLENBQVgsRUFBY0EsSUFBRXZDLFFBQVEvSCxpQkFBeEIsRUFBMkNzSyxHQUEzQyxFQUNBO0FBQ0VyRSxlQUFLQyxPQUFMLENBQWFtRSxDQUFiLEVBQWdCQyxDQUFoQixJQUF1QkEsSUFBSSxDQUFMLElBQVcsQ0FBWixHQUFpQixDQUFqQixHQUFvQixDQUF6QztBQUNEO0FBQ0Y7O0FBRUQsVUFBSXZDLFFBQVFpQixTQUFSLElBQXFCLGNBQXpCLEVBQXlDO0FBQ3ZDL0MsYUFBS3NFLGlCQUFMLEdBQXlCLENBQXpCO0FBQ0QsT0E5QkgsQ0FnQ0U7OztBQUNBdEUsV0FBS0UsU0FBTCxHQUFpQixJQUFJaUUsS0FBSixDQUFVckMsUUFBUW1CLGNBQWxCLENBQWpCLENBakNGLENBbUNFOztBQUNBLFlBQU1zQix5QkFBeUIsQ0FDN0IsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLENBRDZCLEVBRTdCLENBQUMsQ0FBRCxFQUFHLENBQUgsRUFBSyxDQUFMLEVBQU8sQ0FBUCxDQUY2QixFQUc3QixDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLENBQVAsQ0FINkIsRUFJN0IsQ0FBQyxDQUFELEVBQUcsQ0FBSCxFQUFLLENBQUwsRUFBTyxDQUFQLENBSjZCLENBQS9COztBQU9BLFdBQUssSUFBSUgsSUFBRSxDQUFYLEVBQWNBLElBQUUsQ0FBaEIsRUFBbUJBLEdBQW5CLEVBQ0E7QUFDRXBFLGFBQUtFLFNBQUwsQ0FBZWtFLENBQWYsSUFBb0IsSUFBSUQsS0FBSixDQUFVckMsUUFBUS9ILGlCQUFsQixDQUFwQjs7QUFDQSxhQUFLLElBQUlzSyxJQUFFLENBQVgsRUFBY0EsSUFBRXZDLFFBQVEvSCxpQkFBeEIsRUFBMkNzSyxHQUEzQyxFQUNBO0FBQ0UsY0FBSXJFLEtBQUsrQyxTQUFMLElBQWtCLFVBQXRCLEVBQ0UvQyxLQUFLRSxTQUFMLENBQWVrRSxDQUFmLEVBQWtCQyxDQUFsQixJQUF5QkEsSUFBSSxDQUFMLElBQVcsQ0FBWixHQUFpQixDQUFqQixHQUFvQixDQUEzQyxDQURGLENBQ2dEO0FBRGhELGVBR0ssSUFBSXJFLEtBQUsrQyxTQUFMLElBQWtCLFlBQXRCLEVBQ0gvQyxLQUFLRSxTQUFMLENBQWVrRSxDQUFmLEVBQWtCQyxDQUFsQixJQUF1QixDQUF2QixDQURHLENBQ3VCO0FBRTVCO0FBSEssaUJBSUEsSUFBSXJFLEtBQUsrQyxTQUFMLElBQWtCLGNBQXRCLEVBQ0w7QUFDRS9DLHFCQUFLRSxTQUFMLENBQWVrRSxDQUFmLEVBQWtCQyxDQUFsQixJQUF1QkUsdUJBQXVCSCxDQUF2QixFQUEwQkMsSUFBRSxDQUE1QixDQUF2QjtBQUNEO0FBQ0Y7QUFDRixPQTVESCxDQThERTs7O0FBQ0FyRSxXQUFLRyxXQUFMLEdBQW1CLElBQUlnRSxLQUFKLENBQVVwSyxpQkFBVixDQUFuQjs7QUFDQSxXQUFLLElBQUlxSyxJQUFFLENBQVgsRUFBY0EsSUFBRXRDLFFBQVEvSCxpQkFBeEIsRUFBMkNxSyxHQUEzQyxFQUNBO0FBQ0UsWUFBSXBFLEtBQUsrQyxTQUFMLElBQWtCLGNBQXRCLEVBQ0UvQyxLQUFLRyxXQUFMLENBQWlCaUUsQ0FBakIsSUFBc0IsR0FBdEIsQ0FERixLQUdDcEUsS0FBS0csV0FBTCxDQUFpQmlFLENBQWpCLElBQXVCQSxJQUFJLENBQUosSUFBUyxDQUFWLEdBQWUsR0FBZixHQUFxQixHQUEzQztBQUNGO0FBQ0YsS0F4RUQsTUF5RUssSUFBSSxPQUFPcEUsS0FBS0UsU0FBTCxDQUFlLENBQWYsQ0FBUCxLQUE2QixXQUFqQyxFQUE4QztBQUNuRDtBQUNFLGNBQU0sSUFBSXRMLE9BQU9rSixLQUFYLENBQWlCLG1CQUFqQixFQUFzQyxxREFBdEMsQ0FBTjtBQUNEOztBQUVELFFBQUltRixpQkFBaUJqRCxLQUFLQyxPQUFMLENBQWF4RixNQUFsQztBQUNBLFFBQUlWLG9CQUFvQmlHLEtBQUtFLFNBQUwsQ0FBZSxDQUFmLEVBQWtCekYsTUFBMUMsQ0FsTHVDLENBa0xXO0FBRWxEOztBQUNBLFFBQUl3SSxpQkFBaUJyTyxPQUFPdUksUUFBUCxDQUFnQnpELE9BQWhCLENBQXdCOEssZ0JBQTdDLEVBQ0UsTUFBTSxJQUFJNVAsT0FBT2tKLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0Msa0RBQWxDLENBQU47QUFFRixRQUFJL0Qsb0JBQW9CbkYsT0FBT3VJLFFBQVAsQ0FBZ0J6RCxPQUFoQixDQUF3QitLLG1CQUFoRCxFQUNFLE1BQU0sSUFBSTdQLE9BQU9rSixLQUFYLENBQWlCLGtCQUFqQixFQUFxQyxxREFBckMsQ0FBTjtBQUVGLFFBQUdnRSxRQUFRdEwsSUFBUixJQUFnQixFQUFuQixFQUNFc0wsUUFBUXRMLElBQVIsR0FBZTVCLE9BQU84RixTQUFQLENBQWlCUyxvQkFBaEM7QUFFRjZFLFNBQUt4SixJQUFMLEdBQVlzTCxRQUFRdEwsSUFBcEIsQ0E5THVDLENBZ012Qzs7QUFDQSxRQUFJLE9BQU93SixLQUFLb0MsSUFBWixLQUFxQixXQUF6QixFQUFzQztBQUNwQ3BDLFdBQUtvQyxJQUFMLEdBQVksRUFBWjtBQUNEOztBQUVELFFBQUlwQyxLQUFLK0MsU0FBTCxJQUFrQixjQUF0QixFQUFzQztBQUNwQy9DLFdBQUtvQyxJQUFMLENBQVVzQyxJQUFWLENBQWUsa0JBQWY7QUFDRDs7QUFFRCxRQUFJNUssY0FBYSxFQUFqQjtBQUNBLFFBQUksT0FBT2tHLEtBQUtsRyxXQUFaLEtBQTRCLFdBQWhDLEVBQ0VBLGNBQWNrRyxLQUFLbEcsV0FBbkI7QUFFRixRQUFJNkssZ0JBQWdCLEVBQXBCO0FBQ0EsUUFBSSxPQUFPM0UsS0FBSzJFLGFBQVosS0FBOEIsV0FBbEMsRUFDRUEsZ0JBQWdCM0UsS0FBSzJFLGFBQXJCO0FBRUYsUUFBSUMsYUFBYWhRLE9BQU91SSxRQUFQLENBQWdCekQsT0FBaEIsQ0FBd0JtTCxrQkFBekM7QUFDQSxRQUFJLE9BQU83RSxLQUFLNEUsVUFBWixLQUEyQixXQUEvQixFQUNFQSxhQUFhNUUsS0FBSzRFLFVBQWxCO0FBRUYsUUFBSSxPQUFPNUUsS0FBS2tFLGdCQUFaLEtBQWlDLFdBQXJDLEVBQ0VsRSxLQUFLa0UsZ0JBQUwsR0FBd0IsTUFBeEI7QUFFRixRQUFJWSxrQkFBa0IsRUFBdEI7QUFDQSxRQUFJLE9BQU85RSxLQUFLOEUsZUFBWixLQUFnQyxXQUFwQyxFQUNFQSxrQkFBa0I5RSxLQUFLOEUsZUFBdkI7QUFFRixRQUFJN0ksYUFBYW5GLFNBQVNpTyxNQUFULENBQWdCO0FBQy9Cdk8sWUFBTXdKLEtBQUt4SixJQURvQjtBQUUvQnVNLGlCQUFXL0MsS0FBSytDLFNBRmU7QUFHL0JqSixtQkFBYUEsV0FIa0I7QUFJL0I2SyxxQkFBZUEsYUFKZ0I7QUFLL0JULHdCQUFrQmxFLEtBQUtrRSxnQkFMUTtBQU0vQlUsa0JBQVlBLFVBTm1CO0FBTy9CRSx1QkFBaUJBLGVBUGM7QUFRL0JwTCxlQUFTLElBUnNCO0FBUWhCO0FBQ2Z1SixzQkFBZ0JBLGNBVGU7QUFVL0JsSix5QkFBbUJBLGlCQVZZO0FBVy9COUQsa0JBQVl5SSxTQUFTQyxPQUFULEVBWG1CO0FBV1k7QUFDM0N6SSxrQkFBWXRCLE9BQU93RCxNQUFQLEVBWm1CO0FBWVE7QUFDdkNqQywyQkFBcUJ2QixPQUFPbUosSUFBUCxHQUFjM0ksUUFiSixDQWFjOztBQWJkLEtBQWhCLENBQWpCOztBQWdCQSxRQUFJNEssS0FBS3NFLGlCQUFULEVBQTRCO0FBQzVCeE4sZUFBU29CLE1BQVQsQ0FBZ0I7QUFBQ08sYUFBS3dEO0FBQU4sT0FBaEIsRUFBbUM7QUFBQytJLGNBQU07QUFBQ1YsNkJBQW1CdEUsS0FBS3NFO0FBQXpCO0FBQVAsT0FBbkM7QUFDQyxLQTlPc0MsQ0FnUHZDOzs7QUFDQSxTQUFLLElBQUlGLElBQUUsQ0FBWCxFQUFjQSxJQUFFcEUsS0FBS29DLElBQUwsQ0FBVTNILE1BQTFCLEVBQWtDMkosR0FBbEMsRUFDQTtBQUNFdE4sZUFBU21PLE1BQVQsQ0FBZ0JqRixLQUFLb0MsSUFBTCxDQUFVZ0MsQ0FBVixDQUFoQixFQUE4QjtBQUFFM0wsYUFBS3dEO0FBQVAsT0FBOUI7QUFDRCxLQXBQc0MsQ0FzUHZDOzs7QUFDQSxRQUFJaUosZUFBZSxFQUFuQjs7QUFFQSxRQUFJbEYsS0FBSytDLFNBQUwsSUFBa0IsWUFBbEIsSUFBa0MvQyxLQUFLK0MsU0FBTCxJQUFrQixjQUF4RCxFQUF3RTtBQUN4RTtBQUNBO0FBQ0UsWUFBSW9DLE1BQUo7QUFFQSxZQUFJLE9BQU9uRixLQUFLb0YsaUJBQVosS0FBa0MsV0FBdEMsRUFDRUQsU0FBU25GLEtBQUtvRixpQkFBZCxDQURGLENBQ21DO0FBRG5DLGFBRUssSUFBSSxPQUFPcEYsS0FBS21GLE1BQVosS0FBdUIsV0FBM0IsRUFDSEEsU0FBU25GLEtBQUttRixNQUFkLENBREcsQ0FDbUI7QUFEbkIsZUFHSCxNQUFNLElBQUl2USxPQUFPa0osS0FBWCxDQUFpQixnQkFBakIsRUFBbUMsbURBQW5DLENBQU47O0FBRUYsYUFBSyxJQUFJc0csSUFBRSxDQUFYLEVBQWNBLElBQUVlLE9BQU8xSyxNQUF2QixFQUErQjJKLEdBQS9CLEVBQ0E7QUFDRWMsdUJBQWFkLENBQWIsSUFBa0JlLE9BQU9mLENBQVAsQ0FBbEI7QUFDRDtBQUNGLE9BaEJELE1BaUJLLElBQUlwRSxLQUFLK0MsU0FBTCxJQUFrQixVQUF0QixFQUFrQztBQUN2QztBQUNFLGFBQUssSUFBSXFCLElBQUUsQ0FBWCxFQUFjQSxJQUFFLEVBQWhCLEVBQW9CQSxHQUFwQixFQUF5QjtBQUN6QjtBQUNFYyx1QkFBYWQsQ0FBYixJQUFrQnBFLEtBQUttRixNQUFMLENBQVlmLENBQVosQ0FBbEIsQ0FERixDQUdFO0FBQ0E7QUFDQTs7QUFFQSxjQUFJcEUsS0FBS21GLE1BQUwsQ0FBWWYsQ0FBWixFQUFlaUIsZUFBbkIsRUFDRXJGLEtBQUttRixNQUFMLENBQVlmLENBQVosRUFBZWtCLElBQWYsR0FBc0IsVUFBdEI7QUFFRixjQUFJdEYsS0FBS21GLE1BQUwsQ0FBWWYsQ0FBWixFQUFlbUIsY0FBbkIsRUFBbUM7QUFDakN2RixpQkFBS21GLE1BQUwsQ0FBWWYsQ0FBWixFQUFla0IsSUFBZixHQUFzQixTQUF0QjtBQUVGLGlCQUFPdEYsS0FBS21GLE1BQUwsQ0FBWWYsQ0FBWixFQUFlaUIsZUFBdEI7QUFDQSxpQkFBT3JGLEtBQUttRixNQUFMLENBQVlmLENBQVosRUFBZW1CLGNBQXRCO0FBRUEsY0FBSSxPQUFPdkYsS0FBS21GLE1BQUwsQ0FBWWYsQ0FBWixFQUFla0IsSUFBdEIsS0FBK0IsV0FBbkMsRUFDRXRGLEtBQUttRixNQUFMLENBQVlmLENBQVosRUFBZWtCLElBQWYsR0FBc0IsTUFBdEI7QUFDSDtBQUNGOztBQUdEeE8sYUFBU29CLE1BQVQsQ0FBZ0I7QUFBQ08sV0FBS3dEO0FBQU4sS0FBaEIsRUFBbUM7QUFBQytJLFlBQU07QUFBQ0csZ0JBQVE3QixLQUFLa0MsU0FBTCxDQUFlTixZQUFmO0FBQVQ7QUFBUCxLQUFuQyxFQW5TdUMsQ0FxU3ZDOztBQUNBLFFBQUlPLHVCQUF1QixFQUEzQjtBQUNBLFFBQUksT0FBT3pGLEtBQUswRixjQUFaLEtBQStCLFdBQW5DLEVBQ0UxRixLQUFLMEYsY0FBTCxHQUFzQixFQUF0Qjs7QUFFRixTQUFLLElBQUl0QixJQUFFLENBQVgsRUFBY0EsSUFBRXhQLE9BQU84RixTQUFQLENBQWlCRSxxQkFBakMsRUFBd0R3SixHQUF4RCxFQUNBO0FBQ0VxQiwyQkFBcUJyQixDQUFyQixJQUEwQnBFLEtBQUswRixjQUFMLENBQW9CdEIsQ0FBcEIsQ0FBMUI7QUFDRDs7QUFDRHROLGFBQVNvQixNQUFULENBQWdCO0FBQUNPLFdBQUt3RDtBQUFOLEtBQWhCLEVBQW1DO0FBQUMrSSxZQUFNO0FBQUNVLHdCQUFnQnBDLEtBQUtrQyxTQUFMLENBQWVDLG9CQUFmO0FBQWpCO0FBQVAsS0FBbkMsRUE5U3VDLENBZ1R2Qzs7QUFDQSxRQUFJeEYsVUFBVSxJQUFJa0UsS0FBSixDQUFVbEIsY0FBVixDQUFkOztBQUNBLFNBQUssSUFBSW1CLElBQUUsQ0FBWCxFQUFjQSxJQUFFbkIsY0FBaEIsRUFBZ0NtQixHQUFoQyxFQUNBO0FBQ0VuRSxjQUFRbUUsQ0FBUixJQUFhLElBQUlELEtBQUosQ0FBVXBLLGlCQUFWLENBQWI7O0FBRUEsV0FBSyxJQUFJc0ssSUFBRSxDQUFYLEVBQWNBLElBQUV0SyxpQkFBaEIsRUFBbUNzSyxHQUFuQyxFQUNBO0FBQ0VwRSxnQkFBUW1FLENBQVIsRUFBV0MsQ0FBWCxJQUFnQnJFLEtBQUtDLE9BQUwsQ0FBYW1FLENBQWIsRUFBZ0JDLENBQWhCLENBQWhCO0FBQ0Q7QUFDRjs7QUFFRHZOLGFBQVNvQixNQUFULENBQWdCO0FBQUNPLFdBQUt3RDtBQUFOLEtBQWhCLEVBQW1DO0FBQUMrSSxZQUFNO0FBQUMvRSxpQkFBU3FELEtBQUtrQyxTQUFMLENBQWV2RixPQUFmO0FBQVY7QUFBUCxLQUFuQyxFQTVUdUMsQ0E4VHZDOztBQUNBLFFBQUlELEtBQUsrQyxTQUFMLElBQWtCLFlBQXRCLEVBQ0E7QUFDRTtBQUNBLFVBQUkvQyxLQUFLMkYsZUFBTCxJQUF3QixFQUF6QixJQUFpQyxPQUFPM0YsS0FBSzJGLGVBQVosS0FBZ0MsV0FBcEUsRUFDRTNGLEtBQUsyRixlQUFMLEdBQXVCLE1BQXZCO0FBRUY3TyxlQUFTb0IsTUFBVCxDQUFnQjtBQUFDTyxhQUFLd0Q7QUFBTixPQUFoQixFQUFtQztBQUFDK0ksY0FBTTtBQUFDVywyQkFBaUIzRixLQUFLMkY7QUFBdkI7QUFBUCxPQUFuQyxFQUxGLENBT0U7QUFDQTs7QUFDQSxVQUFHLE9BQU8zRixLQUFLNEYsYUFBWixLQUE4QixXQUFqQyxFQUNBO0FBQ0U1RixhQUFLNEYsYUFBTCxHQUFxQixJQUFJekIsS0FBSixFQUFyQjs7QUFDQSxhQUFLLElBQUlDLElBQUUsQ0FBWCxFQUFjQSxJQUFFckssaUJBQWhCLEVBQW1DcUssR0FBbkMsRUFDQTtBQUNFcEUsZUFBSzRGLGFBQUwsQ0FBbUJsQixJQUFuQixDQUF3QixDQUF4QjtBQUNEO0FBQ0Y7O0FBRUQ1TixlQUFTb0IsTUFBVCxDQUFnQjtBQUFDTyxhQUFLd0Q7QUFBTixPQUFoQixFQUFtQztBQUFDK0ksY0FBTTtBQUFDWSx5QkFBZXRDLEtBQUtrQyxTQUFMLENBQWV4RixLQUFLNEYsYUFBcEI7QUFBaEI7QUFBUCxPQUFuQyxFQWxCRixDQW9CRTs7QUFDQSxVQUFHLE9BQU81RixLQUFLNkYsa0JBQVosS0FBbUMsV0FBdEMsRUFDRTdGLEtBQUs2RixrQkFBTCxHQUEwQixDQUFDLEdBQUQsRUFBSyxHQUFMLEVBQVMsR0FBVCxFQUFhLEdBQWIsRUFBaUIsR0FBakIsRUFBcUIsR0FBckIsRUFBeUIsR0FBekIsRUFBNkIsR0FBN0IsQ0FBMUIsQ0F0QkosQ0FzQmlFOztBQUUvRC9PLGVBQVNvQixNQUFULENBQWdCO0FBQUNPLGFBQUt3RDtBQUFOLE9BQWhCLEVBQW1DO0FBQUMrSSxjQUFNO0FBQUNhLDhCQUFvQjdGLEtBQUs2RjtBQUExQjtBQUFQLE9BQW5DLEVBeEJGLENBMEJFO0FBQ0E7QUFDQTs7QUFDQSxVQUFJN0YsS0FBSzhGLG9CQUFMLElBQTZCLEVBQTlCLElBQXNDLE9BQU85RixLQUFLOEYsb0JBQVosS0FBcUMsV0FBOUUsRUFDRTlGLEtBQUs4RixvQkFBTCxHQUE0QixFQUE1QjtBQUVBLFVBQUlDLFdBQVc7QUFDYmhDLGlCQUFTLEVBREk7QUFDQTtBQUNiaUMsZUFBTyxFQUZNLENBRUg7O0FBRkcsT0FBZjs7QUFLQSxXQUFLLElBQUk1QixJQUFFLENBQVgsRUFBY0EsS0FBR3hQLE9BQU84RixTQUFQLENBQWlCUSxlQUFsQyxFQUFtRGtKLEdBQW5ELEVBQ0E7QUFDRSxZQUFJNkIsT0FBTztBQUNUQyx1QkFBYTlCLENBREo7QUFFVCtCLDJCQUFpQjtBQUZSLFNBQVg7O0FBSUEsWUFBSS9CLEtBQUssQ0FBVCxFQUFZO0FBQ1Y2QixlQUFLRyxTQUFMLEdBQWlCLEdBQWpCLENBRFUsQ0FDWTtBQUN2QixTQUZELE1BRU87QUFDTEgsZUFBS0csU0FBTCxHQUFpQixHQUFqQjtBQUNEOztBQUNETCxpQkFBU0MsS0FBVCxDQUFldEIsSUFBZixDQUFvQnVCLElBQXBCO0FBQ0Q7O0FBRUQsV0FBSyxJQUFJNUIsSUFBRSxDQUFYLEVBQWNBLElBQUV0SyxpQkFBaEIsRUFBbUNzSyxHQUFuQyxFQUNBO0FBQ0UwQixpQkFBU2hDLE9BQVQsQ0FBaUJXLElBQWpCLENBQXNCLENBQXRCLEVBREYsQ0FDNEI7QUFDM0I7O0FBRUQxRSxXQUFLOEYsb0JBQUwsQ0FBMEIsQ0FBMUIsSUFBK0JDLFFBQS9CO0FBQ0FqUCxlQUFTb0IsTUFBVCxDQUFnQjtBQUFDTyxhQUFLd0Q7QUFBTixPQUFoQixFQUFtQztBQUFDK0ksY0FBTTtBQUFDYyxnQ0FBc0J4QyxLQUFLa0MsU0FBTCxDQUFleEYsS0FBSzhGLG9CQUFwQjtBQUF2QjtBQUFQLE9BQW5DLEVBekRKLENBMkRFOzs7Ozs7QUFPRCxLQW5FRCxNQW1FTyxJQUFJOUYsS0FBSytDLFNBQUwsSUFBa0IsY0FBdEIsRUFBc0M7QUFFM0MsVUFBSSxPQUFPakIsUUFBUXFCLGVBQWYsS0FBbUMsV0FBdkMsRUFDQTtBQUNFO0FBQ0EsWUFBSUEsa0JBQWtCckIsUUFBUXFCLGVBQTlCLENBRkYsQ0FJRTs7QUFDQSxZQUFJckIsUUFBUW1CLGNBQVIsR0FBeUIsQ0FBekIsSUFBOEIsQ0FBbEMsRUFDRSxNQUFNLElBQUlyTyxPQUFPa0osS0FBWCxDQUFpQixnQkFBakIsRUFBbUMsMEZBQW5DLENBQU47QUFFRixZQUFJdUksc0JBQXNCLEVBQTFCLENBUkYsQ0FTRTs7QUFFQSxZQUFJQyxxQkFBcUIsRUFBekIsQ0FYRixDQVlFO0FBRUE7QUFDQTtBQUNBOztBQUNBLGFBQUssSUFBSWxDLElBQUUsQ0FBWCxFQUFjQSxJQUFHdEMsUUFBUW1CLGNBQVIsR0FBeUIsQ0FBMUIsR0FBK0IsQ0FBL0MsRUFBa0RtQixHQUFsRCxFQUNBO0FBQ0VpQyw4QkFBb0JqQyxDQUFwQixJQUF5QixJQUFJRCxLQUFKLEVBQXpCO0FBQ0FtQyw2QkFBbUJsQyxDQUFuQixJQUF3QixJQUFJRCxLQUFKLEVBQXhCOztBQUVBLGVBQUssSUFBSUUsSUFBRSxDQUFYLEVBQWNBLElBQUV2QyxRQUFRL0gsaUJBQXhCLEVBQTJDc0ssR0FBM0MsRUFDQTtBQUNFZ0MsZ0NBQW9CakMsQ0FBcEIsRUFBdUJDLENBQXZCLElBQTRCLEdBQTVCO0FBQ0FpQywrQkFBbUJsQyxDQUFuQixFQUFzQkMsQ0FBdEIsSUFBMkIsR0FBM0I7QUFDRDtBQUNGO0FBQ0YsT0E3QkQsTUE4QkssSUFBSSxPQUFPdkMsUUFBUTlCLElBQVIsQ0FBYW1ELGVBQXBCLEtBQXdDLFdBQTVDLEVBQ0w7QUFDRTtBQUNBLFlBQUlBLGtCQUFrQnJCLFFBQVE5QixJQUFSLENBQWFtRCxlQUFuQztBQUVBLFlBQUlrRCxzQkFBc0IvQyxLQUFLQyxLQUFMLENBQVd6QixRQUFROUIsSUFBUixDQUFhcUcsbUJBQXhCLENBQTFCLENBSkYsQ0FLRTs7QUFFQSxZQUFJQyxxQkFBcUJoRCxLQUFLQyxLQUFMLENBQVd6QixRQUFROUIsSUFBUixDQUFhc0csa0JBQXhCLENBQXpCLENBUEYsQ0FRRTtBQUNELE9BVkksTUFZTDtBQUNFLGNBQU0sSUFBSTFSLE9BQU9rSixLQUFYLENBQWlCLG9CQUFqQixFQUF1QyxtRkFBdkMsQ0FBTjtBQUNEOztBQUVEaEgsZUFBU29CLE1BQVQsQ0FBZ0I7QUFBQ08sYUFBS3dEO0FBQU4sT0FBaEIsRUFBbUM7QUFBQytJLGNBQU07QUFBQzdCLDJCQUFpQkE7QUFBbEI7QUFBUCxPQUFuQztBQUNBck0sZUFBU29CLE1BQVQsQ0FBZ0I7QUFBQ08sYUFBS3dEO0FBQU4sT0FBaEIsRUFBbUM7QUFBQytJLGNBQU07QUFBQ3FCLCtCQUFxQi9DLEtBQUtrQyxTQUFMLENBQWVhLG1CQUFmO0FBQXRCO0FBQVAsT0FBbkM7QUFDQXZQLGVBQVNvQixNQUFULENBQWdCO0FBQUNPLGFBQUt3RDtBQUFOLE9BQWhCLEVBQW1DO0FBQUMrSSxjQUFNO0FBQUNzQiw4QkFBb0JoRCxLQUFLa0MsU0FBTCxDQUFlYyxrQkFBZjtBQUFyQjtBQUFQLE9BQW5DO0FBQ0QsS0FyYnNDLENBc2J2QztBQUVBOzs7QUFDQSxRQUFJcEcsWUFBWSxJQUFJaUUsS0FBSixDQUFVLENBQVYsQ0FBaEI7O0FBQ0EsU0FBSyxJQUFJQyxJQUFFLENBQVgsRUFBY0EsSUFBRyxDQUFqQixFQUFvQkEsR0FBcEIsRUFDQTtBQUNFbEUsZ0JBQVVrRSxDQUFWLElBQWUsSUFBSUQsS0FBSixDQUFVcEssaUJBQVYsQ0FBZjs7QUFFQSxXQUFLLElBQUlzSyxJQUFFLENBQVgsRUFBY0EsSUFBRXRLLGlCQUFoQixFQUFtQ3NLLEdBQW5DLEVBQ0E7QUFDRW5FLGtCQUFVa0UsQ0FBVixFQUFhQyxDQUFiLElBQWtCckUsS0FBS0UsU0FBTCxDQUFla0UsQ0FBZixFQUFrQkMsQ0FBbEIsQ0FBbEI7QUFDRDtBQUNGOztBQUVEdk4sYUFBU29CLE1BQVQsQ0FBZ0I7QUFBQ08sV0FBS3dEO0FBQU4sS0FBaEIsRUFBbUM7QUFBQytJLFlBQU07QUFBQzlFLG1CQUFXb0QsS0FBS2tDLFNBQUwsQ0FBZXRGLFNBQWY7QUFBWjtBQUFQLEtBQW5DLEVBcGN1QyxDQXNjdkM7O0FBQ0EsUUFBSUMsY0FBYyxJQUFJZ0UsS0FBSixDQUFVcEssaUJBQVYsQ0FBbEI7O0FBQ0EsU0FBSyxJQUFJcUssSUFBRSxDQUFYLEVBQWNBLElBQUVySyxpQkFBaEIsRUFBbUNxSyxHQUFuQyxFQUNBO0FBQ0VqRSxrQkFBWWlFLENBQVosSUFBaUJwRSxLQUFLRyxXQUFMLENBQWlCaUUsQ0FBakIsQ0FBakI7QUFDRCxLQTNjc0MsQ0E2Y3ZDOzs7QUFDQXhQLFdBQU95SixJQUFQLENBQVksdUJBQVosRUFBcUN6SixPQUFPd0QsTUFBUCxFQUFyQztBQUVBdEIsYUFBU29CLE1BQVQsQ0FBZ0I7QUFBQ08sV0FBS3dEO0FBQU4sS0FBaEIsRUFBbUM7QUFBQytJLFlBQU07QUFBQzdFLHFCQUFhbUQsS0FBS2tDLFNBQUwsQ0FBZXJGLFdBQWY7QUFBZDtBQUFQLEtBQW5DO0FBQ0EsUUFBSWhDLFVBQVVySCxTQUFTa0gsT0FBVCxDQUFpQjtBQUFDdkYsV0FBS3dEO0FBQU4sS0FBakIsQ0FBZCxDQWpkdUMsQ0FtZHZDO0FBQ0E7QUFDQTs7QUFFQSxXQUFPQSxVQUFQO0FBQ0QsR0F0aEJZO0FBdWhCYjtBQUNBO0FBQ0E7QUFDQXNLLCtCQUE2QixVQUFTdEssVUFBVCxFQUFxQnVLLFlBQXJCLEVBQW1DO0FBQzlEaE0sVUFBTXlCLFVBQU4sRUFBa0IvRyxNQUFsQjtBQUNBc0YsVUFBTWdNLFlBQU4sRUFBb0JyQyxLQUFwQjtBQUVBLFFBQUloRyxVQUFVckgsU0FBU2tILE9BQVQsQ0FBaUI7QUFBQ3ZGLFdBQUt3RDtBQUFOLEtBQWpCLEVBQW9DO0FBQUNyRCxjQUFRO0FBQUMxQyxvQkFBWTtBQUFiO0FBQVQsS0FBcEMsQ0FBZDtBQUVBLFFBQUlpSSxRQUFRakksVUFBUixJQUFzQnRCLE9BQU93RCxNQUFQLEVBQTFCLEVBQ0UsTUFBTSxJQUFJeEQsT0FBT2tKLEtBQVgsQ0FBaUIsZ0JBQWpCLEVBQW1DLHdEQUFuQyxDQUFOO0FBQ0gsR0FsaUJZO0FBbWlCYjJJLFVBQVEsVUFBU3pHLElBQVQsRUFBZTtBQUNyQjtBQUNBO0FBQ0F4RixVQUFNd0YsSUFBTixFQUFZOUssTUFBWjtBQUVBLFFBQUl3UixxQkFBc0I5UixPQUFPK1IsU0FBUCxDQUFrQkYsT0FBT0csV0FBekIsQ0FBMUI7QUFBQSxRQUNFQyxzQkFBc0JILG1CQUFvQjFHLElBQXBCLEVBQTBCLEVBQTFCLENBRHhCLENBTHFCLENBTW1DOztBQUN4RCxXQUFPNkcsbUJBQVAsQ0FQcUIsQ0FTckI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFzQkQsR0Fsa0JZO0FBbWtCYjtBQUNBO0FBQ0FDLGtCQUFnQixVQUFTN0ssVUFBVCxFQUFxQjtBQUNuQ3pCLFVBQU15QixVQUFOLEVBQWtCL0csTUFBbEI7QUFFQSxRQUFJLENBQUNOLE9BQU9tQyxRQUFaLEVBQXNCO0FBQ2xCO0FBRUosUUFBSW9ILFVBQVVySCxTQUFTa0gsT0FBVCxDQUFpQjtBQUFDdkYsV0FBS3dEO0FBQU4sS0FBakIsRUFBb0M7QUFBQ3JELGNBQVE7QUFBQzFDLG9CQUFZO0FBQWI7QUFBVCxLQUFwQyxDQUFkO0FBRUEsUUFBSWlJLFFBQVFqSSxVQUFSLElBQXNCdEIsT0FBT3dELE1BQVAsRUFBMUIsRUFDRSxNQUFNLElBQUl4RCxPQUFPa0osS0FBWCxDQUFpQixnQkFBakIsRUFBbUMsK0NBQW5DLENBQU4sQ0FUaUMsQ0FXbkM7O0FBQ0FoSCxhQUFTaVEsTUFBVCxDQUFnQjlLLFVBQWhCLEVBWm1DLENBY25DOztBQUNBLFFBQUkrSyxrQkFBbUIsT0FBT3BTLE9BQU9tSixJQUFQLEdBQWNnRSxPQUFkLENBQXNCaUYsZUFBN0IsS0FBaUQsV0FBbEQsR0FBaUUsRUFBakUsR0FBc0VwUyxPQUFPbUosSUFBUCxHQUFjZ0UsT0FBZCxDQUFzQmlGLGVBQWxIO0FBRUEsUUFBSUMsUUFBUSxDQUFDLENBQWI7O0FBQ0EsU0FBSyxJQUFJN0MsSUFBRSxDQUFYLEVBQWNBLElBQUk0QyxnQkFBZ0J2TSxNQUFsQyxFQUEwQzJKLEdBQTFDLEVBQ0E7QUFDRSxVQUFJNEMsZ0JBQWdCNUMsQ0FBaEIsRUFBbUJuSSxVQUFuQixJQUFpQ0EsVUFBckMsRUFDQTtBQUNFZ0wsZ0JBQVE3QyxDQUFSO0FBQ0E7QUFDRDtBQUNGOztBQUVELFFBQUk2QyxRQUFRLENBQUMsQ0FBYixFQUFnQjtBQUNkRCxzQkFBZ0JFLE1BQWhCLENBQXVCRCxLQUF2QixFQUE4QixDQUE5QjtBQUNEOztBQUVELFFBQUkvTyxTQUFTLEVBQWI7QUFDQUEsV0FBTyx5QkFBUCxJQUFvQzhPLGVBQXBDO0FBRUFwUyxXQUFPd0MsS0FBUCxDQUFhYyxNQUFiLENBQW9CO0FBQUNPLFdBQUs3RCxPQUFPd0QsTUFBUDtBQUFOLEtBQXBCLEVBQTRDO0FBQUM0TSxZQUFNOU07QUFBUCxLQUE1QyxFQWxDbUMsQ0FvQ25DOztBQUNBdEQsV0FBT3lKLElBQVAsQ0FBWSx1QkFBWixFQUFxQ3pKLE9BQU93RCxNQUFQLEVBQXJDLEVBckNtQyxDQXVDbkM7O0FBQ0F2QyxXQUFPeUssSUFBUCxDQUFZO0FBQUNsSyxlQUFTNkY7QUFBVixLQUFaLEVBQW1DcUcsR0FBbkMsQ0FBdUMsVUFBUzZFLEtBQVQsRUFBZ0I7QUFDckR2UyxhQUFPeUosSUFBUCxDQUFZLGNBQVosRUFBNEI4SSxNQUFNMU8sR0FBbEM7QUFDRCxLQUZELEVBeENtQyxDQTRDbkM7O0FBQ0E1QyxXQUFPa1IsTUFBUCxDQUFjO0FBQUMzUSxlQUFTNkY7QUFBVixLQUFkO0FBQ0QsR0FubkJZO0FBb25CYm1MLGVBQWEsVUFBVW5MLFVBQVYsRUFBc0JvTCxjQUF0QixFQUFzQztBQUNqRDdNLFVBQU15QixVQUFOLEVBQWtCL0csTUFBbEI7QUFDQXNGLFVBQU02TSxjQUFOLEVBQXNCL1IsT0FBdEI7QUFFQSxRQUFJNkksVUFBVXJILFNBQVNrSCxPQUFULENBQWlCO0FBQUN2RixXQUFLd0Q7QUFBTixLQUFqQixFQUFvQztBQUFDckQsY0FBUTtBQUFDMUMsb0JBQVk7QUFBYjtBQUFULEtBQXBDLENBQWQ7QUFFQSxRQUFJaUksUUFBUWpJLFVBQVIsSUFBc0J0QixPQUFPd0QsTUFBUCxFQUExQixFQUNFLE1BQU0sSUFBSXhELE9BQU9rSixLQUFYLENBQWlCLGdCQUFqQixFQUFtQywwREFBbkMsQ0FBTjtBQUVGaEgsYUFBU29CLE1BQVQsQ0FBZ0IrRCxVQUFoQixFQUE0QjtBQUFFK0ksWUFBTTtBQUFFdEwsaUJBQVMyTjtBQUFYO0FBQVIsS0FBNUI7QUFDQXpTLFdBQU95SixJQUFQLENBQVksdUJBQVosRUFBcUNGLFFBQVFqSSxVQUE3QztBQUNELEdBL25CWTtBQWdvQmJvUix5QkFBdUIsVUFBVXRTLE9BQVYsRUFBbUI7QUFDeEM7QUFDQSxRQUFJdVMsTUFBTXpRLFNBQVN3SixJQUFULENBQWM7QUFDeEJrSCxZQUFNLENBQ0o7QUFBRTlOLGlCQUFTO0FBQUNDLGVBQUs7QUFBTjtBQUFYLE9BREksRUFFSjtBQUFFekQsb0JBQVlsQjtBQUFkLE9BRkk7QUFEa0IsS0FBZCxFQUlOdUwsS0FKTSxFQUFWO0FBTUEsUUFBSXdCLFVBQVVuTixPQUFPd0MsS0FBUCxDQUFhNEcsT0FBYixDQUFxQjtBQUFFdkYsV0FBS3pEO0FBQVAsS0FBckIsRUFBc0MrTSxPQUFwRDtBQUNBLFFBQUksT0FBT0EsT0FBUCxLQUFtQixXQUF2QixFQUNFQSxVQUFVLEVBQVY7QUFFRkEsWUFBUSx1QkFBUixJQUFtQ3dGLEdBQW5DO0FBRUEzUyxXQUFPd0MsS0FBUCxDQUFhYyxNQUFiLENBQW9CO0FBQUNPLFdBQUt6RDtBQUFOLEtBQXBCLEVBQW9DO0FBQUNnUSxZQUFNO0FBQUNqRCxpQkFBU0E7QUFBVjtBQUFQLEtBQXBDO0FBQ0QsR0Evb0JZO0FBZ3BCYjtBQUNBO0FBQ0EwRixzQkFBb0IsVUFBU3hMLFVBQVQsRUFBcUJ5RixJQUFyQixFQUEyQnVCLGNBQTNCLEVBQTJDbEosaUJBQTNDLEVBQ3BCO0FBQ0VTLFVBQU15QixVQUFOLEVBQWtCL0csTUFBbEI7QUFDQXNGLFVBQU1rSCxJQUFOLEVBQVl4TSxNQUFaO0FBQ0FzRixVQUFNeUksY0FBTixFQUFzQnhOLE1BQXRCO0FBQ0ErRSxVQUFNVCxpQkFBTixFQUF5QnRFLE1BQXpCO0FBRUEsUUFBSTBJLFVBQVVySCxTQUFTa0gsT0FBVCxDQUFpQjtBQUFDdkYsV0FBS3dEO0FBQU4sS0FBakIsRUFBb0M7QUFBQ3JELGNBQVE7QUFBQzFDLG9CQUFZO0FBQWI7QUFBVCxLQUFwQyxDQUFkO0FBRUEsUUFBSWlJLFFBQVFqSSxVQUFSLElBQXNCdEIsT0FBT3dELE1BQVAsRUFBMUIsRUFDSTtBQUNBLFlBQU0sSUFBSXhELE9BQU9rSixLQUFYLENBQWlCLGdCQUFqQixFQUFtQyxrREFBbkMsQ0FBTixDQVZOLENBWUU7O0FBQ0EsUUFBSW1GLGlCQUFpQnJPLE9BQU91SSxRQUFQLENBQWdCekQsT0FBaEIsQ0FBd0I4SyxnQkFBN0MsRUFDRSxNQUFNLElBQUk1UCxPQUFPa0osS0FBWCxDQUFpQixlQUFqQixFQUFrQyxzQ0FBbEMsQ0FBTjtBQUVGLFFBQUkvRCxvQkFBb0JuRixPQUFPdUksUUFBUCxDQUFnQnpELE9BQWhCLENBQXdCK0ssbUJBQWhELEVBQ0UsTUFBTSxJQUFJN1AsT0FBT2tKLEtBQVgsQ0FBaUIsa0JBQWpCLEVBQXFDLHlDQUFyQyxDQUFOLENBakJKLENBbUJFO0FBQ0E7O0FBRUFoSCxhQUFTb0IsTUFBVCxDQUFnQjtBQUFDTyxXQUFLd0Q7QUFBTixLQUFoQixFQUFtQztBQUFDK0ksWUFBTTtBQUFFL0UsaUJBQVN5QjtBQUFYO0FBQVAsS0FBbkMsRUF0QkYsQ0F3QkU7O0FBQ0E1SyxhQUFTb0IsTUFBVCxDQUFnQjtBQUFDTyxXQUFLd0Q7QUFBTixLQUFoQixFQUFtQztBQUFDK0ksWUFBTTtBQUFDL0Isd0JBQWdCQTtBQUFqQjtBQUFQLEtBQW5DLEVBekJGLENBMkJFOztBQUNBbk0sYUFBU29CLE1BQVQsQ0FBZ0I7QUFBQ08sV0FBS3dEO0FBQU4sS0FBaEIsRUFBbUM7QUFBQytJLFlBQU07QUFBQ2pMLDJCQUFtQkE7QUFBcEI7QUFBUCxLQUFuQyxFQTVCRixDQThCRTs7QUFDQW5GLFdBQU95SixJQUFQLENBQVksd0JBQVosRUFBc0NwQyxVQUF0QztBQUNELEdBbnJCWTtBQW9yQmJ5TCwwQkFBd0IsVUFBU3pMLFVBQVQsRUFBcUJsQyxpQkFBckIsRUFDeEI7QUFDRVMsVUFBTXlCLFVBQU4sRUFBa0IvRyxNQUFsQjtBQUNBc0YsVUFBTVQsaUJBQU4sRUFBeUJ0RSxNQUF6QjtBQUVBcUIsYUFBU29CLE1BQVQsQ0FBZ0I7QUFBQ08sV0FBS3dEO0FBQU4sS0FBaEIsRUFBbUM7QUFBQytJLFlBQU07QUFBQ2pMLDJCQUFtQkE7QUFBcEI7QUFBUCxLQUFuQztBQUNELEdBMXJCWTtBQTJyQmI0Tix3QkFBc0IsVUFBUzFMLFVBQVQsRUFBcUIrRCxJQUFyQixFQUN0QjtBQUNFeEYsVUFBTXlCLFVBQU4sRUFBa0IvRyxNQUFsQjtBQUNBc0YsVUFBTXdGLElBQU4sRUFBWTlLLE1BQVo7QUFFQTRCLGFBQVNvQixNQUFULENBQWdCO0FBQUNPLFdBQUt3RDtBQUFOLEtBQWhCLEVBQW1DO0FBQUMrSSxZQUFNO0FBQUNuTCxzQkFBY21HO0FBQWY7QUFBUCxLQUFuQztBQUNELEdBanNCWTtBQWtzQmI0SCxrQkFBZ0IsVUFBUzNMLFVBQVQsRUFDaEI7QUFDRXpCLFVBQU15QixVQUFOLEVBQWtCL0csTUFBbEI7QUFFQSxRQUFJaUosVUFBVXJILFNBQVNrSCxPQUFULENBQWlCO0FBQUN2RixXQUFLd0Q7QUFBTixLQUFqQixFQUFvQztBQUFDckQsY0FBUTtBQUFDMUMsb0JBQVksQ0FBYjtBQUFnQmdPLDBCQUFrQjtBQUFsQztBQUFULEtBQXBDLENBQWQ7O0FBRUEsUUFBSSxPQUFPL0YsUUFBUStGLGdCQUFmLEtBQW9DLFdBQXhDLEVBQXFEO0FBQ3JEO0FBQ0VwTixpQkFBU29CLE1BQVQsQ0FBZ0I7QUFBQ08sZUFBS3dEO0FBQU4sU0FBaEIsRUFBbUM7QUFBQytJLGdCQUFNO0FBQUNkLDhCQUFrQjtBQUFuQjtBQUFQLFNBQW5DO0FBQ0E7QUFDRDs7QUFFRCxRQUFJL0YsUUFBUWpJLFVBQVIsSUFBc0J0QixPQUFPd0QsTUFBUCxFQUExQixFQUNJO0FBQ0EsWUFBTSxJQUFJeEQsT0FBT2tKLEtBQVgsQ0FBaUIsZ0JBQWpCLEVBQW1DLHlDQUFuQyxDQUFOO0FBRUosUUFBSSxPQUFPSyxRQUFRK0YsZ0JBQWYsS0FBb0MsV0FBeEMsRUFDRXBOLFNBQVNvQixNQUFULENBQWdCO0FBQUNPLFdBQUt3RDtBQUFOLEtBQWhCLEVBQW1DO0FBQUMrSSxZQUFNO0FBQUNkLDBCQUFrQjtBQUFuQjtBQUFQLEtBQW5DOztBQUVGLFlBQU8vRixRQUFRK0YsZ0JBQWY7QUFFRSxXQUFLLE1BQUw7QUFDRXBOLGlCQUFTb0IsTUFBVCxDQUFnQjtBQUFDTyxlQUFLd0Q7QUFBTixTQUFoQixFQUFtQztBQUFDK0ksZ0JBQU07QUFBQ2QsOEJBQWtCO0FBQW5CO0FBQVAsU0FBbkM7QUFDQTs7QUFFRixXQUFLLE9BQUw7QUFDRXBOLGlCQUFTb0IsTUFBVCxDQUFnQjtBQUFDTyxlQUFLd0Q7QUFBTixTQUFoQixFQUFtQztBQUFDK0ksZ0JBQU07QUFBQ2QsOEJBQWtCO0FBQW5CO0FBQVAsU0FBbkM7QUFDQTs7QUFFRjtBQUNFcE4saUJBQVNvQixNQUFULENBQWdCO0FBQUNPLGVBQUt3RDtBQUFOLFNBQWhCLEVBQW1DO0FBQUMrSSxnQkFBTTtBQUFDZCw4QkFBa0I7QUFBbkI7QUFBUCxTQUFuQztBQVhKO0FBYUQsR0FsdUJZO0FBbXVCYjJELDJCQUF5QixVQUFTNUwsVUFBVCxFQUFxQjZMLFFBQXJCLEVBQStCO0FBQ3REdE4sVUFBTXlCLFVBQU4sRUFBa0IvRyxNQUFsQjtBQUNBc0YsVUFBTXNOLFFBQU4sRUFBZ0I1UyxNQUFoQjtBQUVBLFFBQUlpSixVQUFVckgsU0FBU2tILE9BQVQsQ0FBaUI7QUFBQ3ZGLFdBQUt3RDtBQUFOLEtBQWpCLEVBQW9DO0FBQUNyRCxjQUFRO0FBQUMxQyxvQkFBWSxDQUFiO0FBQWdCZ08sMEJBQWtCO0FBQWxDO0FBQVQsS0FBcEMsQ0FBZDtBQUVBLFFBQUkvRixRQUFRakksVUFBUixJQUFzQnRCLE9BQU93RCxNQUFQLEVBQTFCLEVBQ0k7QUFDQSxZQUFNLElBQUl4RCxPQUFPa0osS0FBWCxDQUFpQixnQkFBakIsRUFBbUMseUNBQW5DLENBQU47QUFFSmhILGFBQVNvQixNQUFULENBQWdCO0FBQUNPLFdBQUt3RDtBQUFOLEtBQWhCLEVBQW1DO0FBQUMrSSxZQUFNO0FBQUNkLDBCQUFrQjREO0FBQW5CO0FBQVAsS0FBbkM7QUFFRCxHQS91Qlk7QUFndkJiQyx3QkFBc0IsVUFBUzlMLFVBQVQsRUFBcUJ5RixJQUFyQixFQUN0QjtBQUNFbEgsVUFBTXlCLFVBQU4sRUFBa0IvRyxNQUFsQjtBQUNBc0YsVUFBTWtILElBQU4sRUFBWXhNLE1BQVo7QUFFQSxRQUFJaUosVUFBVXJILFNBQVNrSCxPQUFULENBQWlCO0FBQUN2RixXQUFLd0Q7QUFBTixLQUFqQixFQUFvQztBQUFDckQsY0FBUTtBQUFDMUMsb0JBQVk7QUFBYjtBQUFULEtBQXBDLENBQWQ7QUFFQSxRQUFJaUksUUFBUWpJLFVBQVIsSUFBc0J0QixPQUFPd0QsTUFBUCxFQUExQixFQUNJO0FBQ0EsWUFBTSxJQUFJeEQsT0FBT2tKLEtBQVgsQ0FBaUIsZ0JBQWpCLEVBQW1DLGtEQUFuQyxDQUFOLENBUk4sQ0FVRTs7QUFDQWhILGFBQVNvQixNQUFULENBQWdCO0FBQUNPLFdBQUt3RDtBQUFOLEtBQWhCLEVBQW1DO0FBQUMrSSxZQUFNO0FBQUU5RSxtQkFBV3dCO0FBQWI7QUFBUCxLQUFuQyxFQVhGLENBYUU7O0FBQ0E5TSxXQUFPeUosSUFBUCxDQUFZLHdCQUFaLEVBQXNDcEMsVUFBdEM7QUFFQTtBQUNELEdBbHdCWTtBQW13QmIrTCx5QkFBdUIsVUFBUy9MLFVBQVQsRUFBcUJ5RixJQUFyQixFQUN2QjtBQUNFbEgsVUFBTXlCLFVBQU4sRUFBa0IvRyxNQUFsQjtBQUNBc0YsVUFBTWtILElBQU4sRUFBWXhNLE1BQVo7QUFFQSxRQUFJaUosVUFBVXJILFNBQVNrSCxPQUFULENBQWlCO0FBQUN2RixXQUFLd0Q7QUFBTixLQUFqQixFQUFvQztBQUFDckQsY0FBUTtBQUFDMUMsb0JBQVk7QUFBYjtBQUFULEtBQXBDLENBQWQ7QUFFQSxRQUFJaUksUUFBUWpJLFVBQVIsSUFBc0J0QixPQUFPd0QsTUFBUCxFQUExQixFQUNJO0FBQ0EsWUFBTSxJQUFJeEQsT0FBT2tKLEtBQVgsQ0FBaUIsZ0JBQWpCLEVBQW1DLGtEQUFuQyxDQUFOLENBUk4sQ0FVRTs7QUFDQWhILGFBQVNvQixNQUFULENBQWdCO0FBQUNPLFdBQUt3RDtBQUFOLEtBQWhCLEVBQW1DO0FBQUMrSSxZQUFNO0FBQUVKLG9CQUFZbEQ7QUFBZDtBQUFQLEtBQW5DLEVBWEYsQ0FhRTs7QUFDQTlNLFdBQU95SixJQUFQLENBQVksd0JBQVosRUFBc0NwQyxVQUF0QztBQUNELEdBbnhCWTtBQW94QmJnTSwwQkFBd0IsVUFBU2hNLFVBQVQsRUFBcUJ5RixJQUFyQixFQUN4QjtBQUNFbEgsVUFBTXlCLFVBQU4sRUFBa0IvRyxNQUFsQjtBQUNBc0YsVUFBTWtILElBQU4sRUFBWXhNLE1BQVo7QUFFQSxRQUFJaUosVUFBVXJILFNBQVNrSCxPQUFULENBQWlCO0FBQUN2RixXQUFLd0Q7QUFBTixLQUFqQixFQUFvQztBQUFDckQsY0FBUTtBQUFDMUMsb0JBQVk7QUFBYjtBQUFULEtBQXBDLENBQWQ7QUFFQSxRQUFJaUksUUFBUWpJLFVBQVIsSUFBc0J0QixPQUFPd0QsTUFBUCxFQUExQixFQUNJO0FBQ0EsWUFBTSxJQUFJeEQsT0FBT2tKLEtBQVgsQ0FBaUIsZ0JBQWpCLEVBQW1DLGtEQUFuQyxDQUFOLENBUk4sQ0FVRTs7QUFDQWhILGFBQVNvQixNQUFULENBQWdCO0FBQUNPLFdBQUt3RDtBQUFOLEtBQWhCLEVBQW1DO0FBQUMrSSxZQUFNO0FBQUU3RSxxQkFBYXVCO0FBQWY7QUFBUCxLQUFuQyxFQVhGLENBYUU7O0FBQ0E5TSxXQUFPeUosSUFBUCxDQUFZLHdCQUFaLEVBQXNDcEMsVUFBdEM7QUFDRCxHQXB5Qlk7QUFxeUJiaU0scUJBQW1CLFVBQVNqTSxVQUFULEVBQXFCeUYsSUFBckIsRUFDbkI7QUFDRWxILFVBQU15QixVQUFOLEVBQWtCL0csTUFBbEI7QUFDQXNGLFVBQU1rSCxJQUFOLEVBQVl4TSxNQUFaO0FBRUEsUUFBSWlKLFVBQVVySCxTQUFTa0gsT0FBVCxDQUFpQjtBQUFDdkYsV0FBS3dEO0FBQU4sS0FBakIsRUFBb0M7QUFBQ3JELGNBQVE7QUFBQzFDLG9CQUFZO0FBQWI7QUFBVCxLQUFwQyxDQUFkO0FBRUEsUUFBSWlJLFFBQVFqSSxVQUFSLElBQXNCdEIsT0FBT3dELE1BQVAsRUFBMUIsRUFDSTtBQUNBLFlBQU0sSUFBSXhELE9BQU9rSixLQUFYLENBQWlCLGdCQUFqQixFQUFtQyxtREFBbkMsQ0FBTixDQVJOLENBVUU7O0FBQ0FoSCxhQUFTb0IsTUFBVCxDQUFnQjtBQUFDTyxXQUFLd0Q7QUFBTixLQUFoQixFQUFtQztBQUFDK0ksWUFBTTtBQUFFRyxnQkFBUXpEO0FBQVY7QUFBUCxLQUFuQyxFQVhGLENBYUU7O0FBQ0E5TSxXQUFPeUosSUFBUCxDQUFZLHdCQUFaLEVBQXNDcEMsVUFBdEM7QUFDRCxHQXJ6Qlk7QUFzekJia00sNkJBQTJCLFVBQVNsTSxVQUFULEVBQXFCeUYsSUFBckIsRUFDM0I7QUFDRWxILFVBQU15QixVQUFOLEVBQWtCL0csTUFBbEI7QUFDQXNGLFVBQU1rSCxJQUFOLEVBQVlBLElBQVo7QUFFQSxRQUFJdkQsVUFBVXJILFNBQVNrSCxPQUFULENBQWlCO0FBQUN2RixXQUFLd0Q7QUFBTixLQUFqQixFQUFvQztBQUFDckQsY0FBUTtBQUFDMUMsb0JBQVk7QUFBYjtBQUFULEtBQXBDLENBQWQ7QUFFQSxRQUFJaUksUUFBUWpJLFVBQVIsSUFBc0J0QixPQUFPd0QsTUFBUCxFQUExQixFQUNJO0FBQ0EsWUFBTSxJQUFJeEQsT0FBT2tKLEtBQVgsQ0FBaUIsZ0JBQWpCLEVBQW1DLGdFQUFuQyxDQUFOO0FBRUhoSCxhQUFTb0IsTUFBVCxDQUFnQjtBQUFDTyxXQUFLd0Q7QUFBTixLQUFoQixFQUFtQztBQUFDK0ksWUFBTTtBQUFDYyw4QkFBc0JwRTtBQUF2QjtBQUFQLEtBQW5DO0FBQ0YsR0FsMEJZO0FBbTBCYjBHLG1CQUFpQixVQUFTcEksSUFBVCxFQUNqQjtBQUNFeEYsVUFBTXdGLElBQU4sRUFBWWtELE1BQVo7QUFFQSxRQUFJL0UsVUFBVXJILFNBQVNrSCxPQUFULENBQWlCO0FBQUN2RixXQUFLdUgsS0FBS3ZIO0FBQVgsS0FBakIsRUFBa0M7QUFBQ0csY0FBUTtBQUFDMUMsb0JBQVk7QUFBYjtBQUFULEtBQWxDLENBQWQ7QUFFQSxRQUFJaUksUUFBUWpJLFVBQVIsSUFBc0J0QixPQUFPd0QsTUFBUCxFQUExQixFQUNJO0FBQ0EsWUFBTSxJQUFJeEQsT0FBT2tKLEtBQVgsQ0FBaUIsZ0JBQWpCLEVBQW1DLDRDQUFuQyxDQUFOLENBUE4sQ0FTRTs7QUFDQWxKLFdBQU95SixJQUFQLENBQVksb0JBQVosRUFBa0MyQixLQUFLdkgsR0FBdkMsRUFBNEM2SyxLQUFLa0MsU0FBTCxDQUFleEYsS0FBS0MsT0FBcEIsQ0FBNUMsRUFBMEVELEtBQUtpRCxjQUEvRSxFQUErRmpELEtBQUtqRyxpQkFBcEc7QUFDQW5GLFdBQU95SixJQUFQLENBQVksc0JBQVosRUFBb0MyQixLQUFLdkgsR0FBekMsRUFBOEM2SyxLQUFLa0MsU0FBTCxDQUFleEYsS0FBS0UsU0FBcEIsQ0FBOUM7QUFDQXRMLFdBQU95SixJQUFQLENBQVksd0JBQVosRUFBc0MyQixLQUFLdkgsR0FBM0MsRUFBZ0Q2SyxLQUFLa0MsU0FBTCxDQUFleEYsS0FBS0csV0FBcEIsQ0FBaEQ7QUFDQXZMLFdBQU95SixJQUFQLENBQVksbUJBQVosRUFBaUMyQixLQUFLdkgsR0FBdEMsRUFBMkM2SyxLQUFLa0MsU0FBTCxDQUFleEYsS0FBS21GLE1BQXBCLENBQTNDO0FBQ0FyTyxhQUFTb0IsTUFBVCxDQUFnQjtBQUFDTyxXQUFLdUgsS0FBS3ZIO0FBQVgsS0FBaEIsRUFBaUM7QUFBQzRQLGNBQVE7QUFBQ3hPLHNCQUFjO0FBQWY7QUFBVCxLQUFqQyxFQWRGLENBY2tFOztBQUNoRTtBQUNELEdBcDFCWTtBQXExQmJ5Tyw4QkFBNEIsVUFBU3RJLElBQVQsRUFBZTtBQUMzQztBQUNBO0FBQ0V4RixVQUFNd0YsSUFBTixFQUFZa0QsTUFBWjtBQUVBdE8sV0FBT3lKLElBQVAsQ0FBWSxvQkFBWixFQUFrQzJCLEtBQUt2SCxHQUF2QyxFQUE0QzZLLEtBQUtrQyxTQUFMLENBQWV4RixLQUFLQyxPQUFwQixDQUE1QyxFQUEwRUQsS0FBS2lELGNBQS9FLEVBQStGakQsS0FBS2pHLGlCQUFwRztBQUVBLFFBQUlvRSxVQUFVckgsU0FBU2tILE9BQVQsQ0FBaUI7QUFBQ3ZGLFdBQUt1SCxLQUFLdkg7QUFBWCxLQUFqQixFQUFrQztBQUFDRyxjQUFRO0FBQUMxQyxvQkFBWTtBQUFiO0FBQVQsS0FBbEMsQ0FBZDtBQUVBLFFBQUlpSSxRQUFRakksVUFBUixJQUFzQnRCLE9BQU93RCxNQUFQLEVBQTFCLEVBQ0k7QUFDQSxZQUFNLElBQUl4RCxPQUFPa0osS0FBWCxDQUFpQixnQkFBakIsRUFBbUMsNENBQW5DLENBQU47QUFFSjtBQUNELEdBbjJCWTtBQW8yQmJ5SywwQkFBd0IsVUFBU3RNLFVBQVQsRUFDeEI7QUFDRXpCLFVBQU15QixVQUFOLEVBQWtCL0csTUFBbEI7QUFFQTRCLGFBQVNvQixNQUFULENBQWdCO0FBQUNPLFdBQUt3RDtBQUFOLEtBQWhCLEVBQW1DO0FBQUMrSSxZQUFNO0FBQUN3RCwyQkFBbUI5SixTQUFTQyxPQUFUO0FBQXBCO0FBQVAsS0FBbkM7QUFDRCxHQXoyQlk7QUEwMkJiO0FBQ0E7QUFDQThKLDBCQUF3QixVQUFTeE0sVUFBVCxFQUN4QjtBQUNFekIsVUFBTXlCLFVBQU4sRUFBa0IvRyxNQUFsQjtBQUVBLFFBQUlpSixVQUFVckgsU0FBU2tILE9BQVQsQ0FBaUI7QUFBQ3ZGLFdBQUt3RDtBQUFOLEtBQWpCLEVBQW9DO0FBQUNyRCxjQUFRO0FBQUMxQyxvQkFBWSxDQUFiO0FBQWdCd1MseUJBQWlCO0FBQWpDO0FBQVQsS0FBcEMsQ0FBZDtBQUVBLFFBQUl2SyxRQUFRakksVUFBUixJQUFzQnRCLE9BQU93RCxNQUFQLEVBQTFCLEVBQ0U7QUFDQSxZQUFNLElBQUl4RCxPQUFPa0osS0FBWCxDQUFpQixnQkFBakIsRUFBbUMsNkRBQW5DLENBQU4sQ0FQSixDQVNFOztBQUNBLFFBQUk2SyxZQUFZLGVBQWhCO0FBQ0EsUUFBSXhLLFFBQVF1SyxlQUFSLElBQTJCLGVBQS9CLEVBQ0VDLFlBQVksV0FBWjtBQUVGN1IsYUFBU29CLE1BQVQsQ0FBZ0I7QUFBQ08sV0FBS3dEO0FBQU4sS0FBaEIsRUFBbUM7QUFBQytJLFlBQU07QUFBQzBELHlCQUFpQkM7QUFBbEI7QUFBUCxLQUFuQztBQUNELEdBNTNCWTtBQTYzQmJDLHlCQUF1QixVQUFTM00sVUFBVCxFQUFxQjRNLE9BQXJCLEVBQ3ZCO0FBQ0UzRyxZQUFRQyxHQUFSLENBQVksdUJBQVo7QUFDQUQsWUFBUUMsR0FBUixDQUFZLGtCQUFrQmUsT0FBTzRGLElBQVAsQ0FBWUQsT0FBWixDQUE5QjtBQUNELEdBajRCWTtBQWs0QmI7QUFDQTtBQUNBRSwwQkFBd0IsVUFBUzlNLFVBQVQsRUFBcUIrTSxHQUFyQixFQUEwQkMsTUFBMUIsRUFBa0NDLFNBQWxDLEVBQ3hCO0FBQ0UxTyxVQUFNeUIsVUFBTixFQUFrQi9HLE1BQWxCO0FBQ0FzRixVQUFNd08sR0FBTixFQUFXdlQsTUFBWDtBQUNBK0UsVUFBTXlPLE1BQU4sRUFBY3hULE1BQWQ7QUFDQStFLFVBQU0wTyxTQUFOLEVBQWlCelQsTUFBakI7O0FBRUEsUUFBSWIsT0FBT21DLFFBQVgsRUFDQTtBQUNFLFVBQUlvSCxVQUFVckgsU0FBU2tILE9BQVQsQ0FBaUI7QUFBQ3ZGLGFBQUt3RDtBQUFOLE9BQWpCLEVBQW9DO0FBQUNyRCxnQkFBUTtBQUFDMUMsc0JBQVk7QUFBYjtBQUFULE9BQXBDLENBQWQ7QUFFQSxVQUFJaUksUUFBUWpJLFVBQVIsSUFBc0J0QixPQUFPd0QsTUFBUCxFQUExQixFQUNFO0FBQ0EsY0FBTSxJQUFJeEQsT0FBT2tKLEtBQVgsQ0FBaUIsZ0JBQWpCLEVBQW1DLGtEQUFuQyxDQUFOLENBTEosQ0FPRTs7QUFDQSxVQUFJNUYsU0FBUyxFQUFiO0FBQ0FBLGFBQU8sYUFBYThRLEdBQWIsR0FBbUIsR0FBbkIsR0FBeUJDLE1BQXpCLEdBQWtDLFFBQXpDLElBQXFEQyxTQUFyRDtBQUNBcFMsZUFBU29CLE1BQVQsQ0FBZ0I7QUFBQ08sYUFBS3dEO0FBQU4sT0FBaEIsRUFBbUM7QUFBQytJLGNBQU05TTtBQUFQLE9BQW5DO0FBQ0Q7QUFDRixHQXg1Qlk7QUF5NUJiaVIsNEJBQTBCLFVBQVNsTixVQUFULEVBQXFCbU4sSUFBckIsRUFBMkJILE1BQTNCLEVBQW1DQyxTQUFuQyxFQUMxQjtBQUNFMU8sVUFBTXlCLFVBQU4sRUFBa0IvRyxNQUFsQjtBQUNBc0YsVUFBTTRPLElBQU4sRUFBWTNULE1BQVo7QUFDQStFLFVBQU15TyxNQUFOLEVBQWN4VCxNQUFkO0FBQ0ErRSxVQUFNME8sU0FBTixFQUFpQnpULE1BQWpCOztBQUVBLFFBQUliLE9BQU9tQyxRQUFYLEVBQ0E7QUFDRSxVQUFJb0gsVUFBVXJILFNBQVNrSCxPQUFULENBQWlCO0FBQUN2RixhQUFLd0Q7QUFBTixPQUFqQixFQUFvQztBQUFDckQsZ0JBQVE7QUFBQzFDLHNCQUFZO0FBQWI7QUFBVCxPQUFwQyxDQUFkOztBQUVBLFVBQUlpSSxRQUFRakksVUFBUixJQUFzQnRCLE9BQU93RCxNQUFQLEVBQTFCLEVBQTJDO0FBQ3pDO0FBQ0EsY0FBTSxJQUFJeEQsT0FBT2tKLEtBQVgsQ0FBaUIsZ0JBQWpCLEVBQW1DLHNEQUFuQyxDQUFOO0FBQ0QsT0FOSCxDQVFFOzs7QUFDQSxVQUFJNUYsU0FBUyxFQUFiO0FBQ0FBLGFBQU8sZUFBZWtSLElBQWYsR0FBc0IsR0FBdEIsR0FBNEJILE1BQTVCLEdBQXFDLFFBQTVDLElBQXdEQyxTQUF4RDtBQUNBcFMsZUFBU29CLE1BQVQsQ0FBZ0I7QUFBQ08sYUFBS3dEO0FBQU4sT0FBaEIsRUFBbUM7QUFBQytJLGNBQU05TTtBQUFQLE9BQW5DO0FBQ0Q7QUFDRixHQTk2Qlk7QUFnN0JiO0FBQ0E7QUFDQW1SLDBCQUF3QixVQUFTcE4sVUFBVCxFQUFxQjBKLGVBQXJCLEVBQXNDO0FBQzVELFFBQUl4SCxVQUFVckgsU0FBU2tILE9BQVQsQ0FBaUI7QUFBQ3ZGLFdBQUt3RDtBQUFOLEtBQWpCLEVBQW9DO0FBQUNyRCxjQUFRO0FBQUMxQyxvQkFBWSxDQUFiO0FBQWdCeVAseUJBQWlCO0FBQWpDO0FBQVQsS0FBcEMsQ0FBZDtBQUVBLFFBQUl4SCxRQUFRakksVUFBUixJQUFzQnRCLE9BQU93RCxNQUFQLEVBQTFCLEVBQ0U7QUFDQSxZQUFNLElBQUl4RCxPQUFPa0osS0FBWCxDQUFpQixnQkFBakIsRUFBbUMsK0RBQW5DLENBQU47QUFFRixRQUFJSyxRQUFRd0gsZUFBUixJQUEyQkEsZUFBL0IsRUFDRTtBQUVGN08sYUFBU29CLE1BQVQsQ0FBZ0I7QUFBQ08sV0FBS3dEO0FBQU4sS0FBaEIsRUFBbUM7QUFBQytJLFlBQU07QUFBQ1cseUJBQWlCQTtBQUFsQjtBQUFQLEtBQW5DO0FBRUE3TyxhQUFTb0IsTUFBVCxDQUFnQjtBQUFDTyxXQUFLd0Q7QUFBTixLQUFoQixFQUFtQztBQUFDK0ksWUFBTTtBQUFDL0UsaUJBQVM7QUFBVjtBQUFQLEtBQW5DO0FBQ0FuSixhQUFTb0IsTUFBVCxDQUFnQjtBQUFDTyxXQUFLd0Q7QUFBTixLQUFoQixFQUFtQztBQUFDK0ksWUFBTTtBQUFDL0Isd0JBQWdCO0FBQWpCO0FBQVAsS0FBbkM7QUFFRCxHQWo4Qlk7QUFrOEJiO0FBQ0E7QUFDQXFHLHVCQUFxQixVQUFTck4sVUFBVCxFQUFxQitELElBQXJCLEVBQ3JCO0FBQ0V4RixVQUFNd0YsSUFBTixFQUFZa0QsTUFBWjtBQUVBcE0sYUFBU29CLE1BQVQsQ0FBZ0I7QUFBQ08sV0FBS3dEO0FBQU4sS0FBaEIsRUFBbUM7QUFBQytJLFlBQU07QUFBQy9FLGlCQUFTRCxLQUFLQztBQUFmO0FBQVAsS0FBbkM7QUFDRW5KLGFBQVNvQixNQUFULENBQWdCO0FBQUNPLFdBQUt3RDtBQUFOLEtBQWhCLEVBQW1DO0FBQUMrSSxZQUFNO0FBQUMvQix3QkFBZ0JqRCxLQUFLaUQ7QUFBdEI7QUFBUCxLQUFuQztBQUNBbk0sYUFBU29CLE1BQVQsQ0FBZ0I7QUFBQ08sV0FBS3dEO0FBQU4sS0FBaEIsRUFBbUM7QUFBQytJLFlBQU07QUFBQ1ksdUJBQWU1RixLQUFLNEY7QUFBckI7QUFBUCxLQUFuQztBQUNBOU8sYUFBU29CLE1BQVQsQ0FBZ0I7QUFBQ08sV0FBS3dEO0FBQU4sS0FBaEIsRUFBbUM7QUFBQytJLFlBQU07QUFBQ3VFLDJCQUFtQnZKLEtBQUt1SjtBQUF6QjtBQUFQLEtBQW5DO0FBQ0gsR0E1OEJZO0FBNjhCYkMseUJBQXVCLFVBQVN2TixVQUFULEVBQXFCK0QsSUFBckIsRUFDdkI7QUFDRXhGLFVBQU15QixVQUFOLEVBQWtCL0csTUFBbEI7QUFDQXNGLFVBQU13RixJQUFOLEVBQVlrRCxNQUFaO0FBRUFwTSxhQUFTb0IsTUFBVCxDQUFnQjtBQUFDTyxXQUFLd0Q7QUFBTixLQUFoQixFQUFtQztBQUFDK0ksWUFBTTtBQUFDWSx1QkFBZXRDLEtBQUtrQyxTQUFMLENBQWV4RixLQUFLNEYsYUFBcEI7QUFBaEI7QUFBUCxLQUFuQztBQUNBOU8sYUFBU29CLE1BQVQsQ0FBZ0I7QUFBQ08sV0FBS3dEO0FBQU4sS0FBaEIsRUFBbUM7QUFBQytJLFlBQU07QUFBQy9FLGlCQUFTcUQsS0FBS2tDLFNBQUwsQ0FBZXhGLEtBQUtDLE9BQXBCO0FBQVY7QUFBUCxLQUFuQztBQUNBbkosYUFBU29CLE1BQVQsQ0FBZ0I7QUFBQ08sV0FBS3dEO0FBQU4sS0FBaEIsRUFBbUM7QUFBQytJLFlBQU07QUFBQy9CLHdCQUFnQmpELEtBQUtDLE9BQUwsQ0FBYXhGO0FBQTlCO0FBQVAsS0FBbkM7QUFDQTNELGFBQVNvQixNQUFULENBQWdCO0FBQUNPLFdBQUt3RDtBQUFOLEtBQWhCLEVBQW1DO0FBQUMrSSxZQUFNO0FBQUNjLDhCQUFzQnhDLEtBQUtrQyxTQUFMLENBQWV4RixLQUFLOEYsb0JBQXBCO0FBQXZCO0FBQVAsS0FBbkM7QUFDQWhQLGFBQVNvQixNQUFULENBQWdCO0FBQUNPLFdBQUt3RDtBQUFOLEtBQWhCLEVBQW1DO0FBQUMrSSxZQUFNO0FBQUN5RSxnQ0FBd0J6SixLQUFLeUo7QUFBOUI7QUFBUCxLQUFuQztBQUNELEdBdjlCWTtBQXc5QmI7QUFDQTtBQUNBQyw0QkFBMEIsVUFBU3pOLFVBQVQsRUFBcUI0SixrQkFBckIsRUFDMUI7QUFDRXJMLFVBQU15QixVQUFOLEVBQWtCL0csTUFBbEI7QUFDQXNGLFVBQU1xTCxrQkFBTixFQUEwQixDQUFDM1EsTUFBRCxDQUExQjtBQUVBLFFBQUl5VSxpQkFBaUI5RCxtQkFBbUJwTCxNQUF4QztBQUVBLFFBQUtrUCxpQkFBaUIsQ0FBbEIsSUFBeUJBLGlCQUFpQi9VLE9BQU84RixTQUFQLENBQWlCTyxjQUEvRCxFQUNFLE1BQU0sSUFBSXJHLE9BQU9rSixLQUFYLENBQWlCLFdBQWpCLEVBQThCLDZDQUE5QixDQUFOO0FBRUYsUUFBSTZMLGlCQUFpQixDQUFyQixFQUNJLE1BQU0sSUFBSS9VLE9BQU9rSixLQUFYLENBQWlCLFdBQWpCLEVBQThCLHlDQUE5QixDQUFOO0FBRUosUUFBSUssVUFBVXJILFNBQVNrSCxPQUFULENBQWlCO0FBQUN2RixXQUFLd0Q7QUFBTixLQUFqQixFQUFvQztBQUFDckQsY0FBUTtBQUFDMUMsb0JBQVksQ0FBYjtBQUFnQjJQLDRCQUFvQjtBQUFwQztBQUFULEtBQXBDLENBQWQ7QUFFQSxRQUFJMUgsUUFBUWpJLFVBQVIsSUFBc0J0QixPQUFPd0QsTUFBUCxFQUExQixFQUNFLE1BQU0sSUFBSXhELE9BQU9rSixLQUFYLENBQWlCLGdCQUFqQixFQUFtQywrREFBbkMsQ0FBTjtBQUVBaEgsYUFBU29CLE1BQVQsQ0FBZ0I7QUFBQ08sV0FBS3dEO0FBQU4sS0FBaEIsRUFBbUM7QUFBQytJLFlBQU07QUFBQ2EsNEJBQW9CQTtBQUFyQjtBQUFQLEtBQW5DO0FBQ0gsR0E3K0JZO0FBOCtCYitELHlCQUF1QixVQUFTM04sVUFBVCxFQUFxQjROLFdBQXJCLEVBQWtDO0FBQ3ZEO0FBQ0FyUCxVQUFNeUIsVUFBTixFQUFrQi9HLE1BQWxCO0FBQ0FzRixVQUFNcVAsV0FBTixFQUFtQnBVLE1BQW5CO0FBRUEsUUFBSTBJLFVBQVVySCxTQUFTa0gsT0FBVCxDQUFpQjtBQUFDdkYsV0FBS3dEO0FBQU4sS0FBakIsRUFBb0M7QUFBQ3JELGNBQVE7QUFBQzFDLG9CQUFZLENBQWI7QUFBZ0IyUCw0QkFBb0I7QUFBcEM7QUFBVCxLQUFwQyxDQUFkO0FBRUEsUUFBSTFILFFBQVFqSSxVQUFSLElBQXNCdEIsT0FBT3dELE1BQVAsRUFBMUIsRUFDRTtBQUNBLFlBQU0sSUFBSXhELE9BQU9rSixLQUFYLENBQWlCLGdCQUFqQixFQUFtQyw4REFBbkMsQ0FBTjtBQUVGLFFBQUkrSCxxQkFBcUIxSCxRQUFRMEgsa0JBQWpDO0FBQ0EsUUFBSU8sWUFBWVAsbUJBQW1CZ0UsY0FBYyxDQUFqQyxDQUFoQjtBQUVBLFFBQUl6RCxhQUFhLEdBQWpCLEVBQ0VBLFlBQVksR0FBWixDQURGLEtBSUVBLFlBQVksR0FBWjtBQUVGUCx1QkFBbUJnRSxjQUFjLENBQWpDLElBQXNDekQsU0FBdEM7QUFFQXRQLGFBQVNvQixNQUFULENBQWdCO0FBQUNPLFdBQUt3RDtBQUFOLEtBQWhCLEVBQW1DO0FBQUMrSSxZQUFNO0FBQUNhLDRCQUFvQkE7QUFBckI7QUFBUCxLQUFuQyxFQXRCdUQsQ0F3QnZEOztBQUNBalIsV0FBT3lKLElBQVAsQ0FBWSx3QkFBWixFQUFzQ3BDLFVBQXRDO0FBQ0QsR0F4Z0NZO0FBeWdDYjtBQUNBO0FBQ0E2Tiw4QkFBNEIsVUFBUzdOLFVBQVQsRUFBcUIrRCxJQUFyQixFQUM1QjtBQUNFeEYsVUFBTXlCLFVBQU4sRUFBa0IvRyxNQUFsQjtBQUNBc0YsVUFBTXdGLElBQU4sRUFBWWtELE1BQVo7QUFFQXBNLGFBQVNvQixNQUFULENBQWdCO0FBQUNPLFdBQUt3RDtBQUFOLEtBQWhCLEVBQW1DO0FBQUMrSSxZQUFNO0FBQUNxQiw2QkFBcUIvQyxLQUFLa0MsU0FBTCxDQUFleEYsS0FBS3FHLG1CQUFwQjtBQUF0QjtBQUFQLEtBQW5DLEVBSkYsQ0FNRTs7QUFDQXpSLFdBQU95SixJQUFQLENBQVksd0JBQVosRUFBc0NwQyxVQUF0QztBQUNELEdBcGhDWTtBQXFoQ2I4Tiw2QkFBMkIsVUFBUzlOLFVBQVQsRUFBcUIrRCxJQUFyQixFQUMzQjtBQUNFeEYsVUFBTXlCLFVBQU4sRUFBa0IvRyxNQUFsQjtBQUNBc0YsVUFBTXdGLElBQU4sRUFBWWtELE1BQVo7QUFFQXBNLGFBQVNvQixNQUFULENBQWdCO0FBQUNPLFdBQUt3RDtBQUFOLEtBQWhCLEVBQW1DO0FBQUMrSSxZQUFNO0FBQUNzQiw0QkFBb0JoRCxLQUFLa0MsU0FBTCxDQUFleEYsS0FBS3NHLGtCQUFwQjtBQUFyQjtBQUFQLEtBQW5DLEVBSkYsQ0FNRTs7QUFDQTFSLFdBQU95SixJQUFQLENBQVksd0JBQVosRUFBc0NwQyxVQUF0QztBQUNELEdBOWhDWTtBQStoQ2IrTix1QkFBcUIsVUFBUy9OLFVBQVQsRUFBcUIrRCxJQUFyQixFQUEyQmlELGNBQTNCLEVBQTJDbEosaUJBQTNDLEVBQThEO0FBQ2pGUyxVQUFNeUIsVUFBTixFQUFrQi9HLE1BQWxCO0FBQ0FzRixVQUFNd0YsSUFBTixFQUFZa0QsTUFBWjtBQUNBMUksVUFBTXlJLGNBQU4sRUFBc0J4TixNQUF0QjtBQUNBK0UsVUFBTVQsaUJBQU4sRUFBeUJ0RSxNQUF6QjtBQUVBLFFBQUkwSSxVQUFVckgsU0FBU2tILE9BQVQsQ0FBaUI7QUFBQ3ZGLFdBQUt3RDtBQUFOLEtBQWpCLEVBQW9DO0FBQUNyRCxjQUFRO0FBQUMxQyxvQkFBWTtBQUFiO0FBQVQsS0FBcEMsQ0FBZDtBQUVBLFFBQUlpSSxRQUFRakksVUFBUixJQUFzQnRCLE9BQU93RCxNQUFQLEVBQTFCLEVBQ0k7QUFDQSxZQUFNLElBQUl4RCxPQUFPa0osS0FBWCxDQUFpQixnQkFBakIsRUFBbUMsa0RBQW5DLENBQU4sQ0FWNkUsQ0FZakY7O0FBQ0EsUUFBSW1GLGlCQUFpQnJPLE9BQU91SSxRQUFQLENBQWdCekQsT0FBaEIsQ0FBd0I4SyxnQkFBN0MsRUFDRSxNQUFNLElBQUk1UCxPQUFPa0osS0FBWCxDQUFpQixlQUFqQixFQUFrQyxzQ0FBbEMsQ0FBTjtBQUVGLFFBQUkvRCxvQkFBb0JuRixPQUFPdUksUUFBUCxDQUFnQnpELE9BQWhCLENBQXdCK0ssbUJBQWhELEVBQ0UsTUFBTSxJQUFJN1AsT0FBT2tKLEtBQVgsQ0FBaUIsa0JBQWpCLEVBQXFDLHlDQUFyQyxDQUFOO0FBRUZoSCxhQUFTb0IsTUFBVCxDQUFnQjtBQUFDTyxXQUFLd0Q7QUFBTixLQUFoQixFQUFtQztBQUFDK0ksWUFBTTtBQUFDcUIsNkJBQXFCL0MsS0FBS2tDLFNBQUwsQ0FBZXhGLEtBQUtxRyxtQkFBcEI7QUFBdEI7QUFBUCxLQUFuQztBQUNBdlAsYUFBU29CLE1BQVQsQ0FBZ0I7QUFBQ08sV0FBS3dEO0FBQU4sS0FBaEIsRUFBbUM7QUFBQytJLFlBQU07QUFBQ3NCLDRCQUFvQmhELEtBQUtrQyxTQUFMLENBQWV4RixLQUFLc0csa0JBQXBCO0FBQXJCO0FBQVAsS0FBbkM7O0FBRUEsUUFBSXRHLEtBQUtHLFdBQVQsRUFBc0I7QUFDcEJySixlQUFTb0IsTUFBVCxDQUFnQjtBQUFDTyxhQUFLd0Q7QUFBTixPQUFoQixFQUFtQztBQUFDK0ksY0FBTTtBQUFDN0UsdUJBQWFtRCxLQUFLa0MsU0FBTCxDQUFleEYsS0FBS0csV0FBcEI7QUFBZDtBQUFQLE9BQW5DO0FBQ0Q7O0FBRUQsUUFBSUgsS0FBS0UsU0FBVCxFQUFvQjtBQUNsQnBKLGVBQVNvQixNQUFULENBQWdCO0FBQUNPLGFBQUt3RDtBQUFOLE9BQWhCLEVBQW1DO0FBQUMrSSxjQUFNO0FBQUM5RSxxQkFBV29ELEtBQUtrQyxTQUFMLENBQWV4RixLQUFLRSxTQUFwQjtBQUFaO0FBQVAsT0FBbkM7QUFDRCxLQTVCZ0YsQ0E4QmpGOzs7QUFDQXBKLGFBQVNvQixNQUFULENBQWdCO0FBQUNPLFdBQUt3RDtBQUFOLEtBQWhCLEVBQW1DO0FBQUMrSSxZQUFNO0FBQUUvRSxpQkFBU3FELEtBQUtrQyxTQUFMLENBQWV4RixLQUFLQyxPQUFwQjtBQUFYO0FBQVAsS0FBbkMsRUEvQmlGLENBaUNqRjs7QUFDQW5KLGFBQVNvQixNQUFULENBQWdCO0FBQUNPLFdBQUt3RDtBQUFOLEtBQWhCLEVBQW1DO0FBQUMrSSxZQUFNO0FBQUMvQix3QkFBZ0JBO0FBQWpCO0FBQVAsS0FBbkMsRUFsQ2lGLENBb0NqRjs7QUFDQW5NLGFBQVNvQixNQUFULENBQWdCO0FBQUNPLFdBQUt3RDtBQUFOLEtBQWhCLEVBQW1DO0FBQUMrSSxZQUFNO0FBQUNqTCwyQkFBbUJBO0FBQXBCO0FBQVAsS0FBbkMsRUFyQ2lGLENBdUNqRjs7QUFDQW5GLFdBQU95SixJQUFQLENBQVksd0JBQVosRUFBc0NwQyxVQUF0QztBQUVELEdBemtDWTtBQTBrQ2JnTyx5QkFBdUIsVUFBU2hPLFVBQVQsRUFBcUJpTyxVQUFyQixFQUFpQztBQUN0RDFQLFVBQU15QixVQUFOLEVBQWtCL0csTUFBbEI7QUFDQXNGLFVBQU0wUCxVQUFOLEVBQWtCelUsTUFBbEI7QUFFQSxRQUFJMEksVUFBVXJILFNBQVNrSCxPQUFULENBQWlCO0FBQUN2RixXQUFLd0Q7QUFBTixLQUFqQixFQUFvQztBQUFDckQsY0FBUTtBQUFDMUMsb0JBQVksQ0FBYjtBQUFnQjZNLG1CQUFXLENBQTNCO0FBQThCdUIsMkJBQW1CLENBQWpEO0FBQW9EckIsd0JBQWdCO0FBQXBFO0FBQVQsS0FBcEMsQ0FBZDtBQUVBLFFBQUk5RSxRQUFRakksVUFBUixJQUFzQnRCLE9BQU93RCxNQUFQLEVBQTFCLEVBQ0k7QUFDQSxZQUFNLElBQUl4RCxPQUFPa0osS0FBWCxDQUFpQixnQkFBakIsRUFBbUMsNERBQW5DLENBQU47QUFFSixRQUFJSyxRQUFRNEUsU0FBUixLQUFzQixjQUExQixFQUNFLE1BQU0sSUFBSW5PLE9BQU9rSixLQUFYLENBQWlCLGdCQUFqQixFQUFtQyw0REFBbkMsQ0FBTjtBQUVGb00saUJBQWFDLEtBQUtDLEtBQUwsQ0FBV0YsVUFBWCxDQUFiO0FBRUEsUUFBSUEsYUFBYSxDQUFqQixFQUNFLE1BQU0sSUFBSXRWLE9BQU9rSixLQUFYLENBQWlCLGdCQUFqQixFQUFtQywyQ0FBbkMsQ0FBTjtBQUVGLFFBQUlvTSxhQUFhL0wsUUFBUThFLGNBQXpCLEVBQ0UsTUFBTSxJQUFJck8sT0FBT2tKLEtBQVgsQ0FBaUIsZ0JBQWpCLEVBQW1DLDhEQUFuQyxDQUFOLENBbkJvRCxDQXFCdEQ7O0FBQ0FoSCxhQUFTb0IsTUFBVCxDQUFnQjtBQUFDTyxXQUFLd0Q7QUFBTixLQUFoQixFQUFtQztBQUFDK0ksWUFBTTtBQUFDViwyQkFBbUI0RjtBQUFwQjtBQUFQLEtBQW5DLEVBdEJzRCxDQXdCdEQ7O0FBQ0F0VixXQUFPeUosSUFBUCxDQUFZLHdCQUFaLEVBQXNDcEMsVUFBdEM7QUFDRCxHQXBtQ1k7QUFxbUNiO0FBQ0E7QUFDQW9PLDBCQUF3QixVQUFTcE8sVUFBVCxFQUFxQjtBQUMzQztBQUNBO0FBQ0F6QixVQUFNeUIsVUFBTixFQUFrQi9HLE1BQWxCO0FBRUEsUUFBSSxDQUFDTixPQUFPd0QsTUFBUCxFQUFMLEVBQXNCO0FBQ3BCO0FBRUYsUUFBSSxPQUFPdEIsU0FBU2tILE9BQVQsQ0FBaUI7QUFBQ3ZGLFdBQUt3RDtBQUFOLEtBQWpCLEVBQW9DO0FBQUNyRCxjQUFRO0FBQUNILGFBQUs7QUFBTjtBQUFULEtBQXBDLEVBQXdEO0FBQUNFLGFBQU87QUFBUixLQUF4RCxDQUFQLEtBQStFLFdBQW5GLEVBQ0UsT0FUeUMsQ0FTakM7QUFFVjs7QUFDQSxRQUFJcU8sa0JBQW1CLE9BQU9wUyxPQUFPbUosSUFBUCxHQUFjZ0UsT0FBZCxDQUFzQmlGLGVBQTdCLEtBQWlELFdBQWxELEdBQWlFLEVBQWpFLEdBQXNFcFMsT0FBT21KLElBQVAsR0FBY2dFLE9BQWQsQ0FBc0JpRixlQUFsSDtBQUVBLFFBQUlzRCxpQkFBaUI7QUFDbkJyTyxrQkFBWUEsVUFETztBQUVuQnNPLG1CQUFhN0wsU0FBU0MsT0FBVCxFQUZNO0FBRXlCO0FBQzVDNkwseUJBQW1CLENBSEEsQ0FNckI7O0FBTnFCLEtBQXJCO0FBT0EsUUFBSXZELFFBQVEsQ0FBQyxDQUFiOztBQUNBLFNBQUssSUFBSTdDLElBQUUsQ0FBWCxFQUFjQSxJQUFJNEMsZ0JBQWdCdk0sTUFBbEMsRUFBMEMySixHQUExQyxFQUNBO0FBQ0UsVUFBSTRDLGdCQUFnQjVDLENBQWhCLEVBQW1CbkksVUFBbkIsSUFBaUNBLFVBQXJDLEVBQ0E7QUFDRWdMLGdCQUFRN0MsQ0FBUjtBQUNBO0FBQ0Q7QUFDRixLQTdCMEMsQ0ErQjNDOzs7QUFDQSxRQUFJNkMsVUFBVSxDQUFDLENBQWYsRUFDQTtBQUNFRCxzQkFBZ0J5RCxPQUFoQixDQUF3QkgsY0FBeEIsRUFERixDQUdFOztBQUNBLFVBQUl0RCxnQkFBZ0J2TSxNQUFoQixHQUF5QjdGLE9BQU84RixTQUFQLENBQWlCSyxXQUE5QyxFQUNFaU0sZ0JBQWdCekgsR0FBaEI7QUFDSCxLQVBELENBUUE7QUFSQSxTQVNLO0FBQ0g7QUFDQSxZQUFJbUwsbUJBQW1CMUQsZ0JBQWdCQyxLQUFoQixFQUF1QnVELGlCQUE5QztBQUNBLFlBQUksT0FBT0UsZ0JBQVAsS0FBNEIsUUFBaEMsRUFDRUosZUFBZUUsaUJBQWYsR0FBbUNFLGdCQUFuQyxDQUpDLENBTUg7O0FBQ0ExRCx3QkFBZ0JFLE1BQWhCLENBQXVCRCxLQUF2QixFQUE4QixDQUE5QixFQVBHLENBU0g7O0FBQ0FELHdCQUFnQnlELE9BQWhCLENBQXdCSCxjQUF4QjtBQUNEOztBQUVELFFBQUlwUyxTQUFTLEVBQWI7QUFDQUEsV0FBTyx5QkFBUCxJQUFvQzhPLGVBQXBDO0FBRUFwUyxXQUFPd0MsS0FBUCxDQUFhYyxNQUFiLENBQW9CO0FBQUNPLFdBQUs3RCxPQUFPd0QsTUFBUDtBQUFOLEtBQXBCLEVBQTRDO0FBQUM0TSxZQUFNOU07QUFBUCxLQUE1QztBQUNELEdBanFDWTtBQWtxQ2J5Uyw0QkFBMEIsWUFBVztBQUNuQztBQUNBLFFBQUkzRCxrQkFBbUIsT0FBT3BTLE9BQU9tSixJQUFQLEdBQWNnRSxPQUFkLENBQXNCaUYsZUFBN0IsS0FBaUQsV0FBbEQsR0FBaUUsRUFBakUsR0FBc0VwUyxPQUFPbUosSUFBUCxHQUFjZ0UsT0FBZCxDQUFzQmlGLGVBQWxILENBRm1DLENBSW5DOztBQUNBQSxzQkFBa0JBLGdCQUFnQnZILEtBQWhCLENBQXNCLENBQXRCLEVBQXlCN0ssT0FBTzhGLFNBQVAsQ0FBaUJLLFdBQTFDLENBQWxCO0FBRUEsUUFBSTdDLFNBQVMsRUFBYjtBQUNBQSxXQUFPLHlCQUFQLElBQW9DOE8sZUFBcEM7QUFFQXBTLFdBQU93QyxLQUFQLENBQWFjLE1BQWIsQ0FBb0I7QUFBQ08sV0FBSzdELE9BQU93RCxNQUFQO0FBQU4sS0FBcEIsRUFBNEM7QUFBQzRNLFlBQU05TTtBQUFQLEtBQTVDO0FBQ0QsR0E3cUNZO0FBOHFDYjBTLHlCQUF1QixVQUFTM08sVUFBVCxFQUFxQmdMLEtBQXJCLEVBQTRCO0FBQ2pEek0sVUFBTXlCLFVBQU4sRUFBa0IvRyxNQUFsQjtBQUNBc0YsVUFBTXlNLEtBQU4sRUFBYXhSLE1BQWI7QUFFQSxRQUFJLENBQUNiLE9BQU93RCxNQUFQLEVBQUwsRUFDRTtBQUVGLFFBQUk2TyxRQUFRLENBQVosRUFDRTtBQUVGLFFBQUk5SSxVQUFVckgsU0FBU2tILE9BQVQsQ0FBaUI7QUFBQ3ZGLFdBQUt3RDtBQUFOLEtBQWpCLEVBQW9DO0FBQUVyRCxjQUFRO0FBQUVILGFBQU07QUFBUjtBQUFWLEtBQXBDLENBQWQ7QUFFQSxRQUFJLE9BQU8wRixPQUFQLEtBQW1CLFdBQXZCLEVBQ0U7QUFFRixRQUFJOEUsaUJBQWlCOUUsUUFBUThFLGNBQTdCO0FBRUEsUUFBSWdFLFFBQVFoRSxjQUFaLEVBQ0U7QUFHRixRQUFJK0Qsa0JBQW1CLE9BQU9wUyxPQUFPbUosSUFBUCxHQUFjZ0UsT0FBZCxDQUFzQmlGLGVBQTdCLEtBQWlELFdBQWxELEdBQWlFLEVBQWpFLEdBQXNFcFMsT0FBT21KLElBQVAsR0FBY2dFLE9BQWQsQ0FBc0JpRixlQUFsSDs7QUFFQSxTQUFLLElBQUk1QyxJQUFFLENBQVgsRUFBY0EsSUFBSTRDLGdCQUFnQnZNLE1BQWxDLEVBQTBDMkosR0FBMUMsRUFDQTtBQUNFLFVBQUk0QyxnQkFBZ0I1QyxDQUFoQixFQUFtQm5JLFVBQW5CLElBQWlDQSxVQUFyQyxFQUNBO0FBQ0UrSyx3QkFBZ0I1QyxDQUFoQixFQUFtQm9HLGlCQUFuQixHQUF1Q3ZELEtBQXZDO0FBQ0EsWUFBSS9PLFNBQVMsRUFBYjtBQUNBQSxlQUFPLHlCQUFQLElBQW9DOE8sZUFBcEM7QUFDQXBTLGVBQU93QyxLQUFQLENBQWFjLE1BQWIsQ0FBb0I7QUFBQ08sZUFBSzdELE9BQU93RCxNQUFQO0FBQU4sU0FBcEIsRUFBNEM7QUFBQzRNLGdCQUFNOU07QUFBUCxTQUE1QztBQUNBO0FBQ0Q7QUFDRjs7QUFFRDtBQUNELEdBbHRDWTtBQW10Q2I7QUFDQTtBQUNBO0FBQ0EyUyxvQkFBa0IsVUFBUzlVLEdBQVQsRUFBYytVLEVBQWQsRUFBa0I7QUFFakM7QUFDRCxRQUFJQyxLQUFLLElBQUlDLElBQUlDLEVBQVIsQ0FBVztBQUNsQkMsbUJBQWF0VyxPQUFPdUksUUFBUCxDQUFnQnpELE9BQWhCLENBQXdCd0QsY0FEbkI7QUFFbEJpTyx1QkFBaUJ2VyxPQUFPdUksUUFBUCxDQUFnQnpELE9BQWhCLENBQXdCMEQsa0JBRnZCLENBRXlDOztBQUZ6QyxLQUFYLENBQVQ7QUFLQSxRQUFJaEIsU0FBUztBQUNYZ1AsY0FBUXhXLE9BQU91SSxRQUFQLENBQWdCekQsT0FBaEIsQ0FBd0I0RCxTQURyQjtBQUNnQztBQUMzQytOLFdBQUt0VixHQUZNLENBRUY7O0FBRkUsS0FBYjtBQUtBLFFBQUl1VixRQUFRMVcsT0FBTytSLFNBQVAsQ0FBaUJvRSxHQUFHUSxVQUFwQixFQUFnQ1IsRUFBaEMsQ0FBWjtBQUNBLFFBQUlTLFVBQVVGLE1BQU1sUCxNQUFOLEVBQWMsVUFBU3FQLEdBQVQsRUFBY3pMLElBQWQsRUFBb0I7QUFFOUMsVUFBSXlMLEdBQUosRUFDQTtBQUNDLGNBQU0sSUFBSTdXLE9BQU9rSixLQUFYLENBQWlCLG9DQUFvQy9ILEdBQXJELENBQU47QUFFQSxPQUpELE1BS0E7QUFDRSxlQUFPaUssSUFBUDtBQUNEO0FBQ0YsS0FWYSxDQUFkO0FBWUEsV0FBT3dMLE9BQVAsQ0ExQmtDLENBMkJsQztBQUNELEdBbHZDWTtBQW12Q2I7QUFDQTlPLHdCQUFzQixVQUFTZ1AsV0FBVCxFQUFzQnpQLFVBQXRCLEVBQWtDNUYsSUFBbEMsRUFBd0NDLEtBQXhDLEVBQStDQyxNQUEvQyxFQUFzRDtBQUMxRWlFLFVBQU1rUixXQUFOLEVBQW1CdFIsY0FBbkI7QUFDQUksVUFBTXlCLFVBQU4sRUFBa0I3QixjQUFsQjtBQUNBSSxVQUFNbkUsSUFBTixFQUFZK0QsY0FBWjtBQUNBSSxVQUFNbEUsS0FBTixFQUFhYixNQUFiO0FBQ0ErRSxVQUFNakUsTUFBTixFQUFjZCxNQUFkO0FBRUEsUUFBSXNJLE9BQU9uSixPQUFPbUosSUFBUCxFQUFYO0FBQ0EsUUFBSSxDQUFDbkosT0FBT3dELE1BQVAsRUFBTCxFQUNFO0FBRUYsUUFBSSxDQUFDMkYsS0FBS0UsTUFBTCxDQUFZLENBQVosRUFBZUMsUUFBcEIsRUFDRSxNQUFNLElBQUl0SixPQUFPa0osS0FBWCxDQUFpQixnQkFBakIsRUFBbUMsaUVBQW5DLENBQU47QUFFRixRQUFJSyxVQUFVckgsU0FBU2tILE9BQVQsQ0FBaUI7QUFBQ3ZGLFdBQUt3RDtBQUFOLEtBQWpCLEVBQW9DO0FBQUVyRCxjQUFRO0FBQUMxQyxvQkFBWTtBQUFiO0FBQVYsS0FBcEMsQ0FBZDtBQUVBLFFBQUlpSSxRQUFRakksVUFBUixJQUFzQnRCLE9BQU93RCxNQUFQLEVBQTFCLEVBQ0UsTUFBTSxJQUFJeEQsT0FBT2tKLEtBQVgsQ0FBaUIsZ0JBQWpCLEVBQW1DLHFEQUFuQyxDQUFOO0FBRUYsUUFBSXlDLFFBQVExSyxPQUFPeUssSUFBUCxDQUFZO0FBQUVsSyxlQUFTNkY7QUFBWCxLQUFaLEVBQXFDc0UsS0FBckMsRUFBWjs7QUFFQSxRQUFJa0MsTUFBTUMsWUFBTixDQUFvQjlOLE9BQU93RCxNQUFQLEVBQXBCLEVBQXFDLFNBQXJDLEVBQWdELE9BQWhELENBQUosRUFDQTtBQUNFLFVBQUltSSxTQUFTM0wsT0FBT3VJLFFBQVAsQ0FBZ0JNLE1BQWhCLENBQXVCa08sc0JBQXZCLENBQThDL0ksT0FBM0QsRUFDRSxNQUFNLElBQUloTyxPQUFPa0osS0FBWCxDQUFpQixlQUFqQixFQUFrQyxvREFBbEMsQ0FBTjtBQUNILEtBSkQsTUFNQTtBQUNFLFVBQUl5QyxTQUFTM0wsT0FBT3VJLFFBQVAsQ0FBZ0JNLE1BQWhCLENBQXVCa08sc0JBQXZCLENBQThDek4sUUFBM0QsRUFDRSxNQUFNLElBQUl0SixPQUFPa0osS0FBWCxDQUFpQixlQUFqQixFQUFrQyxvREFBbEMsQ0FBTjtBQUNIOztBQUVELFFBQUlULFNBQVN6SSxPQUFPdUksUUFBUCxDQUFnQnpELE9BQWhCLENBQXdCNEQsU0FBckM7QUFDQSxRQUFJRSxTQUFTNUksT0FBT3VJLFFBQVAsQ0FBZ0JNLE1BQWhCLENBQXVCQyxTQUFwQyxDQWpDMEUsQ0FtQzFFOztBQUNBLFFBQUkzSCxNQUFNMlYsWUFBWUUsT0FBWixDQUFvQixhQUFhdk8sTUFBYixHQUFzQixNQUF0QixHQUErQkcsTUFBL0IsR0FBd0MsaUJBQTVELEVBQStFLEVBQS9FLENBQVYsQ0FwQzBFLENBb0NvQjs7QUFFOUYsUUFBSTNILE9BQU95SyxJQUFQLENBQVk7QUFBQ3ZLLFdBQUlBO0FBQUwsS0FBWixFQUF1QndLLEtBQXZCLE1BQWtDLENBQXRDLEVBQ0E7QUFDRTtBQUNBLFVBQUlzTCxXQUFXaFcsT0FBT2tQLE1BQVAsQ0FBYztBQUN6QmpQLGFBQUs0VixXQURvQjtBQUV6QjNWLGFBQUtBLEdBRm9CO0FBR3pCRSxvQkFBWXlJLFNBQVNDLE9BQVQsRUFIYTtBQUdrQjtBQUMzQ3pJLG9CQUFZdEIsT0FBT3dELE1BQVAsRUFKYTtBQUljO0FBQ3ZDakMsNkJBQXFCdkIsT0FBT21KLElBQVAsR0FBYzNJLFFBTFY7QUFLcUI7QUFDOUNnQixpQkFBUzZGLFVBTmdCO0FBT3pCNUYsY0FBTUEsSUFQbUI7QUFRekJDLGVBQU9BLEtBUmtCO0FBU3pCQyxnQkFBUUE7QUFUaUIsT0FBZCxDQUFmO0FBV0EsYUFBT3NWLFFBQVA7QUFDRCxLQWZELE1BaUJBO0FBQ0U7QUFDQSxVQUFJQSxXQUFXaFcsT0FBT21JLE9BQVAsQ0FBZTtBQUFDakksYUFBSUE7QUFBTCxPQUFmLEVBQTBCO0FBQUM2QyxnQkFBUTtBQUFDSCxlQUFJO0FBQUw7QUFBVCxPQUExQixDQUFmO0FBQ0E1QyxhQUFPcUMsTUFBUCxDQUFjO0FBQUNPLGFBQUtvVDtBQUFOLE9BQWQsRUFBK0I7QUFBQzdHLGNBQzlCO0FBQ0UvTyxzQkFBWXlJLFNBQVNDLE9BQVQ7QUFEZDtBQUQ2QixPQUEvQjtBQUlEO0FBQ0YsR0FuekNZO0FBb3pDYm1OLGdCQUFjLFVBQVNELFFBQVQsRUFBbUI7QUFDL0JyUixVQUFNcVIsUUFBTixFQUFnQnpSLGNBQWhCLEVBRCtCLENBRy9COztBQUNBLFFBQUkrTSxRQUFRdFIsT0FBT21JLE9BQVAsQ0FBZTtBQUFFLGFBQU82TjtBQUFULEtBQWYsQ0FBWjtBQUVBLFFBQUksT0FBTzFFLEtBQVAsS0FBaUIsV0FBckIsRUFDRSxNQUFNLElBQUl2UyxPQUFPa0osS0FBWCxDQUFpQixXQUFqQixFQUE4QixzQkFBc0IrTixRQUFwRCxDQUFOO0FBRUYsUUFBSTFFLE1BQU1qUixVQUFOLElBQW9CdEIsT0FBT3dELE1BQVAsRUFBeEIsRUFDRSxNQUFNLElBQUl4RCxPQUFPa0osS0FBWCxDQUFpQixnQkFBakIsRUFBbUMsMkNBQW5DLENBQU47QUFFRixRQUFJcUosTUFBTTlRLElBQU4sSUFBYyxTQUFsQixFQUNFLE9BQU8sSUFBUCxDQURGLEtBSUE7QUFDRSxVQUFJNEYsYUFBYWtMLE1BQU0vUSxPQUF2Qjs7QUFDQSxVQUFJO0FBQ0YsWUFBSTJWLHFCQUFxQmxXLE9BQU9tSSxPQUFQLENBQWU7QUFBQzVILG1CQUFRNkYsVUFBVDtBQUFxQjVGLGdCQUFLO0FBQTFCLFNBQWYsRUFBcURvQyxHQUE5RSxDQURFLENBQ2lGOzs7QUFDbkY1QyxlQUFPcUMsTUFBUCxDQUFjO0FBQUNPLGVBQUlzVDtBQUFMLFNBQWQsRUFBd0M7QUFBQy9HLGdCQUFNO0FBQUMzTyxrQkFBSztBQUFOO0FBQVAsU0FBeEM7QUFDRCxPQUhELENBSUEsT0FBTW9WLEdBQU4sRUFBVyxDQUNUO0FBQ0Q7O0FBRUQ1VixhQUFPcUMsTUFBUCxDQUFjO0FBQUNPLGFBQUlvVDtBQUFMLE9BQWQsRUFBOEI7QUFBQzdHLGNBQU07QUFBQzNPLGdCQUFLO0FBQU47QUFBUCxPQUE5QjtBQUNEO0FBQ0YsR0FoMUNZO0FBaTFDYjJWLHdCQUFzQixVQUFTSCxRQUFULEVBQW1CdlYsS0FBbkIsRUFBMEJDLE1BQTFCLEVBQWtDO0FBQ3REaUUsVUFBTXFSLFFBQU4sRUFBZ0J6UixjQUFoQjtBQUNBSSxVQUFNbEUsS0FBTixFQUFhYixNQUFiO0FBQ0ErRSxVQUFNakUsTUFBTixFQUFjZCxNQUFkLEVBSHNELENBS3REOztBQUNBLFFBQUkwUixRQUFRdFIsT0FBT21JLE9BQVAsQ0FBZTtBQUFFLGFBQU82TjtBQUFULEtBQWYsQ0FBWjtBQUVBLFFBQUksT0FBTzFFLEtBQVAsS0FBaUIsV0FBckIsRUFDRSxNQUFNLElBQUl2UyxPQUFPa0osS0FBWCxDQUFpQixXQUFqQixFQUE4QixzQkFBc0IrTixRQUFwRCxDQUFOO0FBRUYsUUFBSTFFLE1BQU1qUixVQUFOLElBQW9CdEIsT0FBT3dELE1BQVAsRUFBeEIsRUFDRSxNQUFNLElBQUl4RCxPQUFPa0osS0FBWCxDQUFpQixnQkFBakIsRUFBbUMseUNBQW5DLENBQU4sQ0Fab0QsQ0FjdEQ7QUFFQTs7QUFFQSxRQUFJbU8sWUFBWTNWLEtBQWhCO0FBQ0EsUUFBSTRWLGFBQWEzVixNQUFqQjtBQUVBVixXQUFPcUMsTUFBUCxDQUFjO0FBQUNPLFdBQUtvVDtBQUFOLEtBQWQsRUFBK0I7QUFBQzdHLFlBQU07QUFBQzFPLGVBQU8yVixTQUFSO0FBQW1CMVYsZ0JBQVEyVjtBQUEzQjtBQUFQLEtBQS9CO0FBRUQsR0F4MkNZO0FBeTJDYkMsZ0JBQWMsVUFBU04sUUFBVCxFQUFtQjtBQUMvQnJSLFVBQU1xUixRQUFOLEVBQWdCelIsY0FBaEIsRUFEK0IsQ0FHL0I7O0FBQ0EsUUFBSStNLFFBQVF0UixPQUFPbUksT0FBUCxDQUFlO0FBQUUsYUFBTzZOO0FBQVQsS0FBZixDQUFaO0FBRUEsUUFBSSxPQUFPMUUsS0FBUCxLQUFpQixXQUFyQixFQUNFLE1BQU0sSUFBSXZTLE9BQU9rSixLQUFYLENBQWlCLFdBQWpCLEVBQThCLHNCQUFzQitOLFFBQXBELENBQU47QUFFRixRQUFJMUUsTUFBTWpSLFVBQU4sSUFBb0J0QixPQUFPd0QsTUFBUCxFQUF4QixFQUNFLE1BQU0sSUFBSXhELE9BQU9rSixLQUFYLENBQWlCLGdCQUFqQixFQUFtQywyQ0FBbkMsQ0FBTixDQVY2QixDQVkvQjs7QUFDQSxRQUFJTSxjQUFjeEosT0FBT3lKLElBQVAsQ0FBWSxpQkFBWixDQUFsQjtBQUVBLFFBQUlDLGNBQWMzSixXQUFXcUosT0FBWCxDQUFtQjtBQUFDdkYsV0FBSzJGO0FBQU4sS0FBbkIsRUFBdUM7QUFBQ3hGLGNBQVE7QUFBRWpELHVCQUFlLENBQWpCO0FBQW9CTixnQkFBUTtBQUE1QjtBQUFULEtBQXZDLENBQWxCO0FBRUEsUUFBSWtKLFlBQVlELFlBQVkzSSxhQUE1QjtBQUVBLFFBQUkySSxZQUFZakosTUFBaEIsRUFDQSxNQUFNLElBQUlULE9BQU9rSixLQUFYLENBQWlCLGdCQUFqQixFQUFtQywrREFBbkMsQ0FBTjtBQUVBLFFBQUlVLG9CQUFvQkQsVUFBVTlELE1BQWxDO0FBQ0EsUUFBSWdFLHlCQUF5QkMsU0FBU0MsT0FBVCxLQUFxQkosVUFBVSxDQUFWLENBQWxELENBdkIrQixDQXlCL0I7QUFDQTs7QUFDQSxRQUFJSyxxQkFBcUJMLFVBQVUsQ0FBVixJQUFlQSxVQUFVLENBQVYsQ0FBeEM7O0FBQ0EsUUFBSUsscUJBQXFCLElBQXpCLEVBQ0E7QUFDRWpLLGlCQUFXdUQsTUFBWCxDQUFtQjtBQUFDTyxhQUFLMkY7QUFBTixPQUFuQixFQUF1QztBQUFFL0ksZ0JBQVE7QUFBVixPQUF2QztBQUNBLFlBQU0sSUFBSVQsT0FBT2tKLEtBQVgsQ0FBaUIsZ0JBQWpCLEVBQW1DLCtEQUFuQyxDQUFOO0FBQ0Q7O0FBRUQsUUFBSWUsb0JBQW9CTixVQUFVLENBQVYsSUFBZUEsVUFBVSxDQUFWLENBQXZDOztBQUNFLFFBQUlNLG9CQUFvQixJQUF4QixFQUNBO0FBQ0U7QUFDQSxVQUFJSix5QkFBMEIsS0FBSyxJQUFMLEdBQVksQ0FBMUMsRUFDRSxNQUFNLElBQUk3SixPQUFPa0osS0FBWCxDQUFpQixtQkFBakIsRUFBc0Msb0NBQXRDLENBQU4sQ0FERixDQUdBO0FBSEEsV0FLQTtBQUNFLGNBQUlnQix3QkFBd0JQLFVBQVUsQ0FBVixJQUFlQSxVQUFVLENBQVYsQ0FBM0M7O0FBQ0EsY0FBSU8sd0JBQXdCLElBQTVCLEVBQ0E7QUFDRTtBQUNBO0FBQ0EsZ0JBQUlMLHlCQUEwQixLQUFLLElBQUwsR0FBWSxFQUFaLEdBQWlCLElBQS9DLEVBQ0UsTUFBTSxJQUFJN0osT0FBT2tKLEtBQVgsQ0FBaUIsbUJBQWpCLEVBQXNDLHFDQUF0QyxDQUFOO0FBQ0g7QUFDRjtBQUNGLEtBckQ0QixDQXVEN0I7OztBQUNBbkosZUFBV3VELE1BQVgsQ0FBbUI7QUFBQ08sV0FBSzJGO0FBQU4sS0FBbkIsRUFBdUM7QUFBRVcsYUFBTztBQUFFcEosdUJBQWU7QUFDL0RxSixpQkFBTyxDQUFDTixTQUFTQyxPQUFULEVBQUQsQ0FEd0Q7QUFFL0RNLHFCQUFXO0FBRm9EO0FBQWpCO0FBQVQsS0FBdkM7QUFJSixLQTVEaUMsQ0E2RDdCOztBQUNBLFFBQUlULG9CQUFvQjVKLE9BQU91SSxRQUFQLENBQWdCekQsT0FBaEIsQ0FBd0IwUyx1QkFBaEQsRUFDQTtBQUNFelgsaUJBQVd1RCxNQUFYLENBQW1CO0FBQUNPLGFBQUsyRjtBQUFOLE9BQW5CLEVBQXVDO0FBQUVlLGNBQU07QUFBRXhKLHlCQUFlO0FBQWpCO0FBQVIsT0FBdkM7QUFDRDs7QUFFSCxRQUFJb1YsS0FBSyxJQUFJQyxJQUFJQyxFQUFSLENBQVc7QUFDbEJDLG1CQUFhdFcsT0FBT3VJLFFBQVAsQ0FBZ0J6RCxPQUFoQixDQUF3QndELGNBRG5CO0FBRWxCaU8sdUJBQWlCdlcsT0FBT3VJLFFBQVAsQ0FBZ0J6RCxPQUFoQixDQUF3QjBELGtCQUZ2QixDQUV5Qzs7QUFGekMsS0FBWCxDQUFUO0FBS0EsUUFBSWhCLFNBQVM7QUFDWGdQLGNBQVF4VyxPQUFPdUksUUFBUCxDQUFnQnpELE9BQWhCLENBQXdCNEQsU0FEckI7QUFDZ0M7QUFDM0MrTixXQUFLbEUsTUFBTXBSLEdBRkEsQ0FFSTs7QUFGSixLQUFiO0FBS0FnVixPQUFHc0IsWUFBSCxDQUFnQmpRLE1BQWhCLEVBQXdCeEgsT0FBTzBYLGVBQVAsQ0FBdUIsVUFBVUMsS0FBVixFQUFpQnZNLElBQWpCLEVBQXNCO0FBQ25FLFVBQUksQ0FBQ3VNLEtBQUwsRUFBWTtBQUNWMVcsZUFBT2tSLE1BQVAsQ0FBYztBQUFDdE8sZUFBS29UO0FBQU4sU0FBZDtBQUNEO0FBQ0YsS0FKdUIsQ0FBeEI7QUFLRCxHQTM3Q1k7QUE0N0NiO0FBQ0E7QUFDQVcsd0JBQXNCLFVBQVNwVCxVQUFULEVBQXFCcVQsU0FBckIsRUFBZ0NDLFFBQWhDLEVBQTBDL1YsS0FBMUMsRUFDdEI7QUFDRTtBQUNBO0FBQ0E2RCxVQUFNaVMsU0FBTixFQUFpQnJTLGNBQWpCO0FBQ0FJLFVBQU1wQixVQUFOLEVBQWtCZ0IsY0FBbEI7QUFDQUksVUFBTWtTLFFBQU4sRUFBZ0J0UyxjQUFoQjtBQUNBSSxVQUFNN0QsS0FBTixFQUFhekIsTUFBYjtBQUVBLFFBQUl5QixNQUFNOEQsTUFBTixHQUFlLElBQW5CLEVBQ0UsTUFBTSxJQUFJN0YsT0FBT2tKLEtBQVgsQ0FBaUIsZ0JBQWpCLEVBQW1DLG1CQUFuQyxDQUFOOztBQUVGLFFBQUkxRSxjQUFjLFVBQWxCLEVBQ0E7QUFDRSxVQUFJK0UsVUFBVXJILFNBQVNrSCxPQUFULENBQWlCO0FBQUN2RixhQUFLZ1U7QUFBTixPQUFqQixFQUFtQztBQUFFN1QsZ0JBQVE7QUFBQzFDLHNCQUFZO0FBQWI7QUFBVixPQUFuQyxDQUFkO0FBRUEsVUFBSWlJLFFBQVFqSSxVQUFSLElBQXNCdEIsT0FBT3dELE1BQVAsRUFBMUIsRUFDRSxNQUFNLElBQUl4RCxPQUFPa0osS0FBWCxDQUFpQixnQkFBakIsRUFBbUMsMENBQW5DLENBQU47O0FBRUYsY0FBUTRPLFFBQVI7QUFFRSxhQUFLLE1BQUw7QUFDQSxhQUFLLGFBQUw7QUFDQSxhQUFLLGVBQUw7QUFDQSxhQUFLLGlCQUFMO0FBQ0UsY0FBS0EsWUFBWSxNQUFiLElBQXlCL1YsU0FBUyxFQUF0QyxFQUNFLE9BRkosQ0FFWTs7QUFFVixjQUFJdUIsU0FBUyxFQUFiO0FBQ0FBLGlCQUFPd1UsUUFBUCxJQUFtQi9WLEtBQW5CLENBTEYsQ0FLNEI7O0FBQzFCRyxtQkFBU29CLE1BQVQsQ0FBZ0I7QUFBQ08saUJBQUtnVTtBQUFOLFdBQWhCLEVBQWtDO0FBQUN6SCxrQkFBTTlNO0FBQVAsV0FBbEMsRUFORixDQVFFOztBQUNBdEQsaUJBQU95SixJQUFQLENBQVkscUJBQVosRUFBbUNvTyxTQUFuQztBQUNBOztBQUVBO0FBQ0UsZ0JBQU0sSUFBSTdYLE9BQU9rSixLQUFYLENBQWlCLGdCQUFqQixFQUFtQyxrQkFBbkMsQ0FBTjtBQWxCTjtBQW9CRDs7QUFFRCxRQUFJMUUsY0FBYyxRQUFsQixFQUNBO0FBQ0UsVUFBSStOLFFBQVF0UixPQUFPbUksT0FBUCxDQUFlO0FBQUN2RixhQUFLZ1U7QUFBTixPQUFmLENBQVo7QUFDQSxVQUFJdE8sVUFBVXJILFNBQVNrSCxPQUFULENBQWlCO0FBQUN2RixhQUFLME8sTUFBTS9RO0FBQVosT0FBakIsQ0FBZDtBQUVBLFVBQUkrSCxRQUFRakksVUFBUixJQUFzQnRCLE9BQU93RCxNQUFQLEVBQTFCLEVBQ0UsTUFBTSxJQUFJeEQsT0FBT2tKLEtBQVgsQ0FBaUIsZ0JBQWpCLEVBQW1DLDBDQUFuQyxDQUFOLENBTEosQ0FNRTs7QUFDQSxjQUFRNE8sUUFBUjtBQUVFLGFBQUssU0FBTDtBQUNFLGNBQUl4VSxTQUFTLEVBQWI7QUFDQUEsaUJBQU93VSxRQUFQLElBQW1CL1YsS0FBbkIsQ0FGRixDQUU0Qjs7QUFDMUJkLGlCQUFPcUMsTUFBUCxDQUFjO0FBQUNPLGlCQUFLZ1U7QUFBTixXQUFkLEVBQWdDO0FBQUN6SCxrQkFBTTlNO0FBQVAsV0FBaEM7QUFDQTs7QUFFRjtBQUNFLGdCQUFNLElBQUl0RCxPQUFPa0osS0FBWCxDQUFpQixnQkFBakIsRUFBbUMsa0JBQW5DLENBQU47QUFUSjtBQVdEOztBQUVELFFBQUkxRSxjQUFjLE9BQWxCLEVBQ0E7QUFDRTtBQUNBLFVBQUlxVCxhQUFhN1gsT0FBT3dELE1BQVAsRUFBakIsRUFDRSxNQUFNLElBQUl4RCxPQUFPa0osS0FBWCxDQUFpQixnQkFBakIsRUFBbUMsMkNBQW5DLENBQU47O0FBRUYsY0FBUTRPLFFBQVI7QUFFRSxhQUFLLGFBQUw7QUFDRTtBQUNBO0FBQ0EsY0FBSTNLLFVBQVVuTixPQUFPd0MsS0FBUCxDQUFhNEcsT0FBYixDQUFxQjtBQUFFdkYsaUJBQUtnVTtBQUFQLFdBQXJCLEVBQXdDMUssT0FBdEQ7QUFDQSxjQUFJLE9BQU9BLE9BQVAsS0FBbUIsV0FBdkIsRUFDRUEsVUFBVSxFQUFWO0FBRUZBLGtCQUFRMkssUUFBUixJQUFvQi9WLEtBQXBCO0FBRUEvQixpQkFBT3dDLEtBQVAsQ0FBYWMsTUFBYixDQUFvQjtBQUFDTyxpQkFBS2dVO0FBQU4sV0FBcEIsRUFBc0M7QUFBQ3pILGtCQUFNO0FBQUNqRCx1QkFBU0E7QUFBVjtBQUFQLFdBQXRDO0FBQ0E7O0FBRUYsYUFBSyxlQUFMO0FBQ0UsY0FBSXBMLFNBQVMsRUFBYixFQUNFO0FBRUYsY0FBSWdXLGFBQWEvWCxPQUFPd0MsS0FBUCxDQUFhNEcsT0FBYixDQUFxQjtBQUFFdkYsaUJBQUtnVTtBQUFQLFdBQXJCLEVBQXdDeE8sTUFBekQ7QUFDQSxjQUFJME8sVUFBSixFQUFnQjtBQUNkLGdCQUFJQyxlQUFlRCxXQUFXbFMsTUFBOUIsQ0FERixLQUdFLElBQUltUyxlQUFlLENBQW5CO0FBRUYxTCxtQkFBUzJMLFFBQVQsQ0FBa0JKLFNBQWxCLEVBQTZCOVYsS0FBN0IsRUFWRixDQVV1QztBQUVyQzs7QUFDQSxjQUFJbVcsYUFBYWxZLE9BQU93QyxLQUFQLENBQWE0RyxPQUFiLENBQXFCO0FBQUV2RixpQkFBS2dVO0FBQVAsV0FBckIsRUFBd0N4TyxNQUF6RDtBQUNBLGNBQUk2TyxVQUFKLEVBQ0UsSUFBSUMsYUFBYUQsV0FBV3JTLE1BQTVCLENBREYsS0FHRSxJQUFJc1MsYUFBYSxDQUFqQjs7QUFFRixjQUFJQSxhQUFhSCxZQUFqQixFQUErQjtBQUMvQjtBQUNFO0FBQ0EsbUJBQUssSUFBSXhJLElBQUUsQ0FBWCxFQUFjQSxJQUFFMEksV0FBV3JTLE1BQTNCLEVBQW1DMkosR0FBbkMsRUFDQTtBQUNFLG9CQUFJMEksV0FBVzFJLENBQVgsRUFBYzRJLE9BQWQsSUFBeUJyVyxLQUE3QixFQUNFdUssU0FBUytMLFdBQVQsQ0FBcUJSLFNBQXJCLEVBQWdDSyxXQUFXMUksQ0FBWCxFQUFjNEksT0FBOUM7QUFDSCxlQU5ILENBT0U7OztBQUNBcFkscUJBQU95SixJQUFQLENBQVksdUJBQVosRUFBcUNvTyxTQUFyQztBQUNEOztBQUVEOztBQUVGO0FBQ0UsZ0JBQU0sSUFBSTdYLE9BQU9rSixLQUFYLENBQWlCLGdCQUFqQixFQUFtQyxrQkFBbkMsQ0FBTjtBQWhESjtBQWtERDtBQUNGLEdBcmpEWTtBQXNqRGJvUCx1QkFBcUIsVUFBU2pSLFVBQVQsRUFDckI7QUFDRXpCLFVBQU15QixVQUFOLEVBQWtCL0csTUFBbEI7QUFDQTRCLGFBQVNvQixNQUFULENBQWdCO0FBQUNPLFdBQUt3RDtBQUFOLEtBQWhCLEVBQW1DO0FBQUMrSSxZQUFNO0FBQUNtSSx3QkFBZ0J6TyxTQUFTQyxPQUFUO0FBQWpCO0FBQVAsS0FBbkM7QUFDRCxHQTFqRFk7O0FBNGpEYjtBQUNBO0FBQ0F5Qyx3QkFBc0JoSixNQUF0QixFQUE4QmdWLEtBQTlCLEVBQ0E7QUFDRTVTLFVBQU1wQyxNQUFOLEVBQWNnQyxjQUFkO0FBQ0FJLFVBQU00UyxLQUFOLEVBQWEvUyxNQUFNMkksUUFBTixDQUFlOU4sTUFBZixDQUFiO0FBRUEsUUFBSWtELFVBQVV4RCxPQUFPd0QsTUFBUCxFQUFkLEVBQ0U7QUFDQSxZQUFNLElBQUl4RCxPQUFPa0osS0FBWCxDQUFpQixnQkFBakIsRUFBbUMsdUVBQW5DLENBQU4sQ0FOSixDQVFFOztBQUNBLFFBQUlNLGNBQWN4SixPQUFPeUosSUFBUCxDQUFZLGlCQUFaLENBQWxCO0FBRUEsUUFBSUMsY0FBYzNKLFdBQVdxSixPQUFYLENBQW1CO0FBQUN2RixXQUFLMkY7QUFBTixLQUFuQixFQUF1QztBQUFDeEYsY0FBUTtBQUFFcEQsaUNBQXlCLENBQTNCO0FBQThCSCxnQkFBUTtBQUF0QztBQUFULEtBQXZDLENBQWxCO0FBRUEsUUFBSWtKLFlBQVlELFlBQVk5SSx1QkFBNUI7QUFFQSxRQUFJOEksWUFBWWpKLE1BQWhCLEVBQ0UsTUFBTSxJQUFJVCxPQUFPa0osS0FBWCxDQUFpQixnQkFBakIsRUFBbUMsK0RBQW5DLENBQU47QUFFRixRQUFJVSxvQkFBb0JELFVBQVU5RCxNQUFsQztBQUNBLFFBQUlnRSx5QkFBeUJDLFNBQVNDLE9BQVQsS0FBcUJKLFVBQVUsQ0FBVixDQUFsRCxDQW5CRixDQXFCRTtBQUNBOztBQUNBLFFBQUlNLG9CQUFvQk4sVUFBVSxDQUFWLElBQWVBLFVBQVUsQ0FBVixDQUF2Qzs7QUFDQSxRQUFJTSxvQkFBb0IsSUFBeEIsRUFDQTtBQUNFO0FBQ0EsVUFBSUoseUJBQTBCLEtBQUssSUFBTCxHQUFZLENBQTFDLEVBQ0UsTUFBTSxJQUFJN0osT0FBT2tKLEtBQVgsQ0FBaUIsbUJBQWpCLEVBQXNDLG9DQUF0QyxDQUFOLENBREYsQ0FHQTtBQUhBLFdBS0E7QUFDRSxjQUFJYyxxQkFBcUJMLFVBQVUsQ0FBVixJQUFlQSxVQUFVLENBQVYsQ0FBeEM7O0FBQ0EsY0FBSUsscUJBQXNCLEtBQUssSUFBTCxHQUFZLENBQXRDLEVBQ0E7QUFDRTtBQUNBO0FBQ0EsZ0JBQUlILHlCQUEwQixLQUFLLElBQUwsR0FBWSxFQUFaLEdBQWlCLElBQS9DLEVBQ0UsTUFBTSxJQUFJN0osT0FBT2tKLEtBQVgsQ0FBaUIsbUJBQWpCLEVBQXNDLHFDQUF0QyxDQUFOO0FBQ0g7QUFDRjtBQUNGLEtBMUNILENBNENFO0FBQ0E7OztBQUNBLFFBQUl1UCxvQkFBb0I5TyxVQUFVLENBQVYsSUFBZUEsVUFBVSxDQUFWLENBQXZDOztBQUNBLFFBQUk4TyxvQkFBb0IsS0FBeEIsRUFDQTtBQUNFO0FBQ0EsVUFBSTVPLHlCQUEwQixLQUFLLElBQUwsR0FBWSxDQUExQyxFQUNFLE1BQU0sSUFBSTdKLE9BQU9rSixLQUFYLENBQWlCLG1CQUFqQixFQUFzQyxvQ0FBdEMsQ0FBTjtBQUNILEtBcERILENBc0RFOzs7QUFDQSxRQUFJd1AscUJBQXFCL08sVUFBVSxDQUFWLElBQWVBLFVBQVUsRUFBVixDQUF4Qzs7QUFDQSxRQUFJK08scUJBQXFCLEtBQUssSUFBTCxHQUFZLEVBQXJDLEVBQ0E7QUFDRTNZLGlCQUFXdUQsTUFBWCxDQUFtQjtBQUFDTyxhQUFLMkY7QUFBTixPQUFuQixFQUF1QztBQUFFL0ksZ0JBQVE7QUFBVixPQUF2QztBQUNBLFlBQU0sSUFBSVQsT0FBT2tKLEtBQVgsQ0FBaUIsZ0JBQWpCLEVBQW1DLCtEQUFuQyxDQUFOO0FBQ0QsS0E1REgsQ0E4REU7QUFDQTs7O0FBQ0FuSixlQUFXdUQsTUFBWCxDQUFtQjtBQUFDTyxXQUFLMkY7QUFBTixLQUFuQixFQUF1QztBQUFFVyxhQUFPO0FBQUV2SixpQ0FBeUI7QUFDekV3SixpQkFBTyxDQUFDTixTQUFTQyxPQUFULEVBQUQsQ0FEa0U7QUFFekVNLHFCQUFXO0FBRjhEO0FBQTNCO0FBQVQsS0FBdkMsRUFoRUYsQ0FxRUU7O0FBQ0EsUUFBSVQsb0JBQW9CNUosT0FBT3VJLFFBQVAsQ0FBZ0J6RCxPQUFoQixDQUF3QjZULDhCQUFoRCxFQUNJNVksV0FBV3VELE1BQVgsQ0FBbUI7QUFBQ08sV0FBSzJGO0FBQU4sS0FBbkIsRUFBdUM7QUFBRWUsWUFBTTtBQUFFM0osaUNBQXlCO0FBQTNCO0FBQVIsS0FBdkM7QUFFSixRQUFJLE9BQU80WCxLQUFQLEtBQWlCLFFBQXJCLEVBQ0VsTSxTQUFTRSxxQkFBVCxDQUErQnhNLE9BQU93RCxNQUFQLEVBQS9CLEVBQWdEZ1YsS0FBaEQsRUFERixLQUlFbE0sU0FBU0UscUJBQVQsQ0FBK0J4TSxPQUFPd0QsTUFBUCxFQUEvQjtBQUNILEdBN29EWTs7QUE4b0RiO0FBQ0FvVixvQkFBa0J4VixFQUFsQixFQUNBO0FBQ0V3QyxVQUFNeEMsRUFBTixFQUFVOUMsTUFBVjtBQUVBLFFBQUlOLE9BQU93QyxLQUFQLENBQWFrSixJQUFiLENBQWtCO0FBQUM3SCxXQUFLVDtBQUFOLEtBQWxCLEVBQTZCdUksS0FBN0IsTUFBd0MsQ0FBNUMsRUFDRSxNQUFNLElBQUkzTCxPQUFPa0osS0FBWCxDQUFpQixXQUFqQixFQUE4QixtQkFBbUI5RixFQUFuQixHQUF3QixXQUF0RCxDQUFOO0FBQ0YsUUFBSStGLE9BQU9uSixPQUFPd0MsS0FBUCxDQUFhNEcsT0FBYixDQUFxQjtBQUFDdkYsV0FBS1Q7QUFBTixLQUFyQixDQUFYOztBQUVBLFFBQUk7QUFDRixVQUFJK0YsS0FBS0UsTUFBTCxDQUFZLENBQVosRUFBZUMsUUFBbkIsRUFDQTtBQUNFdUUsY0FBTWdMLGVBQU4sQ0FBc0J6VixFQUF0QixFQUEwQixDQUFDLFVBQUQsQ0FBMUIsRUFBd0MsT0FBeEM7QUFDRCxPQUhELE1BS0E7QUFDRXlLLGNBQU1pTCxvQkFBTixDQUEyQjFWLEVBQTNCLEVBQStCLENBQUMsVUFBRCxDQUEvQixFQUE2QyxPQUE3QztBQUNEO0FBQ0YsS0FURCxDQVVBLE9BQU15VCxHQUFOLEVBQVcsQ0FFVjtBQUNGLEdBcHFEWTs7QUFxcURiO0FBQ0E7QUFDQWtDLG9CQUNBO0FBQ0UsUUFBSWhaLFdBQVcyTCxJQUFYLENBQWlCO0FBQUN0TCxlQUFTSixPQUFPd0QsTUFBUDtBQUFWLEtBQWpCLEVBQThDbUksS0FBOUMsTUFBeUQsQ0FBN0QsRUFDRSxPQUFPNUwsV0FBV29RLE1BQVgsQ0FBa0I7QUFDdkIvUCxlQUFTSixPQUFPd0QsTUFBUCxFQURjO0FBRXZCaEQsZ0JBQVVSLE9BQU9tSixJQUFQLEdBQWMzSSxRQUZEO0FBR3ZCSSwrQkFBeUIsRUFIRjtBQUl2QkUsc0JBQWdCLEVBSk87QUFLdkJDLHFCQUFlO0FBTFEsS0FBbEIsQ0FBUCxDQURGLEtBVUUsT0FBT2hCLFdBQVdxSixPQUFYLENBQW9CO0FBQUNoSixlQUFTSixPQUFPd0QsTUFBUDtBQUFWLEtBQXBCLEVBQWlESyxHQUF4RDtBQUNILEdBcHJEWTs7QUFzckRiO0FBQ0E7QUFDQTtBQUNBbVYsdUJBQXFCNVksT0FBckIsRUFBOEI2WSxTQUE5QixFQUNBO0FBQ0UsUUFBSSxDQUFDalosT0FBT3VJLFFBQVAsQ0FBZ0J6RCxPQUFoQixDQUF3Qm9VLEtBQTdCLEVBQ0U7QUFFRixRQUFJN1AsU0FBU3JKLE9BQU93QyxLQUFQLENBQWE0RyxPQUFiLENBQXFCO0FBQUV2RixXQUFLekQ7QUFBUCxLQUFyQixFQUFzQ2lKLE1BQW5EO0FBQ0FBLFdBQU8sQ0FBUCxFQUFVLFVBQVYsSUFBd0I0UCxTQUF4QjtBQUNBLFFBQUkzVixTQUFTLEVBQWI7QUFDQUEsV0FBTyxRQUFQLElBQW1CK0YsTUFBbkI7QUFDQXJKLFdBQU93QyxLQUFQLENBQWFjLE1BQWIsQ0FBb0I7QUFBQ08sV0FBS3pEO0FBQU4sS0FBcEIsRUFBb0M7QUFBQ2dRLFlBQU05TTtBQUFQLEtBQXBDO0FBQ0Q7O0FBbnNEWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDQUU7QUFFQTtBQUVBO0FBRUE7QUFDQTtBQUVBO0FBRUY7QUFDQXRELE9BQU9tWixPQUFQLENBQWUsaUJBQWYsRUFBa0MsWUFBVTtBQUUxQ25WLFdBQVM7QUFDUEgsU0FBSyxDQURFO0FBRVB0Qyx5QkFBcUIsQ0FGZDtBQUdQSyxVQUFNLENBSEM7QUFJUG9ELGVBQVcsQ0FKSjtBQUtQRyx1QkFBbUIsQ0FMWjtBQU1QcUksVUFBTTtBQU5DLEdBQVQ7QUFTQSxNQUFJLEtBQUtoSyxNQUFULEVBQ0UsT0FBT3RCLFNBQVN3SixJQUFULENBQ0w7QUFDRTlILFNBQUssQ0FDSDtBQUFFa0IsZUFBUztBQUFDQyxhQUFLO0FBQU47QUFBWCxLQURHLEVBRUg7QUFBRXpELGtCQUFZLEtBQUtrQztBQUFuQixLQUZHO0FBRFAsR0FESyxFQU9MO0FBQ0VRLFlBQVFBO0FBRFYsR0FQSyxDQUFQLENBREYsS0FhRSxPQUFPOUIsU0FBU3dKLElBQVQsQ0FDTDtBQUFFNUcsYUFBUztBQUFDQyxXQUFLO0FBQU47QUFBWCxHQURLLEVBRUw7QUFDRWYsWUFBUUE7QUFEVixHQUZLLENBQVA7QUFNSCxDQTlCRDtBQWdDQWhFLE9BQU9tWixPQUFQLENBQWUsY0FBZixFQUErQixZQUFVO0FBRXZDLE1BQUk3VixTQUFTLEVBQWI7QUFDQUEsU0FBTywrQkFBUCxJQUEwQztBQUFDQyxTQUFLO0FBQU4sR0FBMUMsQ0FIdUMsQ0FHYTs7QUFFcEQsTUFBSSxLQUFLQyxNQUFULEVBQ0UsT0FBT3hELE9BQU93QyxLQUFQLENBQWFrSixJQUFiLENBQ0w7QUFBQzlILFNBQUssQ0FBQ04sTUFBRCxFQUFTO0FBQUNPLFdBQUssS0FBS0w7QUFBWCxLQUFUO0FBQU4sR0FESyxFQUVMO0FBQUNRLFlBQVE7QUFDUEgsV0FBSyxDQURFO0FBRVBzSixlQUFTLENBRkY7QUFHUDNNLGdCQUFVO0FBSEg7QUFBVCxHQUZLLENBQVAsQ0FERixLQVVFLE9BQU9SLE9BQU93QyxLQUFQLENBQWFrSixJQUFiLENBQ0w7QUFBQzlILFNBQUssQ0FBQ04sTUFBRDtBQUFOLEdBREssRUFFTDtBQUFDVSxZQUFRO0FBQ1BILFdBQUssQ0FERTtBQUVQc0osZUFBUyxDQUZGO0FBR1AzTSxnQkFBVTtBQUhIO0FBQVQsR0FGSyxDQUFQO0FBUUgsQ0F2QkQsRSxDQXlCQTs7QUFDQVIsT0FBT21aLE9BQVAsQ0FBZSxTQUFmLEVBQTBCLFVBQVMzUixNQUFULEVBQWdCO0FBQ3hDNUIsUUFBTTRCLE1BQU4sRUFBYzhHLE1BQWQ7QUFDQTFJLFFBQU00QixPQUFPSCxVQUFiLEVBQXlCL0csTUFBekI7QUFFQSxNQUFJLEtBQUtrRCxNQUFULEVBQ0UsT0FBT3RCLFNBQVN3SixJQUFULENBQ0w7QUFBRWtILFVBQ0EsQ0FDRTtBQUFFL08sV0FBSzJELE9BQU9IO0FBQWQsS0FERixFQUVFO0FBQUV6RCxXQUFLLENBQ0w7QUFBRWtCLGlCQUFTO0FBQUNDLGVBQUs7QUFBTjtBQUFYLE9BREssRUFFTDtBQUFFekQsb0JBQVksS0FBS2tDO0FBQW5CLE9BRks7QUFBUCxLQUZGO0FBREYsR0FESyxFQVVMO0FBQ0VPLFdBQU87QUFEVCxHQVZLLENBQVAsQ0FERixLQWdCRSxPQUFPN0IsU0FBU3dKLElBQVQsQ0FDTDtBQUFFa0gsVUFDQSxDQUNFO0FBQUUvTyxXQUFLMkQsT0FBT0g7QUFBZCxLQURGLEVBRUU7QUFBRXZDLGVBQVM7QUFBQ0MsYUFBSztBQUFOO0FBQVgsS0FGRjtBQURGLEdBREssRUFPTDtBQUNFaEIsV0FBTztBQURULEdBUEssQ0FBUDtBQVdILENBL0JELEUsQ0FpQ0E7O0FBQ0EvRCxPQUFPbVosT0FBUCxDQUFlLGlCQUFmLEVBQWtDLFVBQVMzUixNQUFULEVBQWdCO0FBQ2hENUIsUUFBTTRCLE1BQU4sRUFBYzhHLE1BQWQ7QUFFQSxNQUFJOEssY0FBYyxPQUFPNVIsT0FBTzRSLFdBQWQsS0FBOEIsV0FBOUIsR0FBNEMsRUFBNUMsR0FBaUQ1UixPQUFPNFIsV0FBMUU7QUFFQSxNQUFJcFYsU0FBUztBQUNYSCxTQUFLLENBRE07QUFFWG9CLGtCQUFjLENBRkg7QUFHWDVELGdCQUFZLENBSEQ7QUFJWEMsZ0JBQVksQ0FKRDtBQUtYQyx5QkFBcUIsQ0FMVjtBQU1YMkQsaUJBQWEsQ0FORjtBQU9YdEQsVUFBTSxDQVBLO0FBUVhvRCxlQUFXLENBUkE7QUFTWEcsdUJBQW1CLENBVFI7QUFVWEwsYUFBUztBQVZFLEdBQWI7QUFhQSxNQUFJLEtBQUt0QixNQUFULEVBQ0UsT0FBT3RCLFNBQVN3SixJQUFULENBQ0w7QUFBRWtILFVBQ0EsQ0FDRTtBQUFFL08sV0FBSztBQUFDd1YsYUFBSTdSLE9BQU80UjtBQUFaO0FBQVAsS0FERixFQUVFO0FBQUV4VixXQUFLLENBQ0w7QUFBRWtCLGlCQUFTO0FBQUNDLGVBQUs7QUFBTjtBQUFYLE9BREssRUFFTDtBQUFFekQsb0JBQVksS0FBS2tDO0FBQW5CLE9BRks7QUFBUCxLQUZGO0FBREYsR0FESyxFQVVMO0FBQ0VPLFdBQU8vRCxPQUFPOEYsU0FBUCxDQUFpQkssV0FEMUI7QUFFRW5DLFlBQVFBO0FBRlYsR0FWSyxDQUFQLENBREYsS0FpQkUsT0FBTzlCLFNBQVN3SixJQUFULENBQ0w7QUFBRWtILFVBQ0EsQ0FDRTtBQUFFL08sV0FBSztBQUFDd1YsYUFBSTdSLE9BQU80UjtBQUFaO0FBQVAsS0FERixFQUVFO0FBQUV0VSxlQUFTO0FBQUNDLGFBQUs7QUFBTjtBQUFYLEtBRkY7QUFERixHQURLLEVBT0w7QUFDRWhCLFdBQU8vRCxPQUFPOEYsU0FBUCxDQUFpQkssV0FEMUI7QUFFRW5DLFlBQVFBO0FBRlYsR0FQSyxDQUFQO0FBWUgsQ0EvQ0QsRSxDQWlEQTs7QUFDQWhFLE9BQU9tWixPQUFQLENBQWUsY0FBZixFQUErQixZQUFVO0FBQ3ZDLE1BQUluVixTQUFTO0FBQ1hILFNBQUssQ0FETTtBQUVYb0Isa0JBQWMsQ0FGSDtBQUdYNUQsZ0JBQVksQ0FIRDtBQUlYQyxnQkFBWSxDQUpEO0FBS1hDLHlCQUFxQixDQUxWO0FBTVgyRCxpQkFBYSxDQU5GO0FBT1h0RCxVQUFNLENBUEs7QUFRWG9ELGVBQVcsQ0FSQTtBQVNYRyx1QkFBbUIsQ0FUUjtBQVVYTCxhQUFTO0FBVkUsR0FBYjtBQWFBLE1BQUksS0FBS3RCLE1BQVQsRUFDRSxPQUFPdEIsU0FBU3dKLElBQVQsQ0FDTDtBQUNFOUgsU0FBSyxDQUNIO0FBQUVrQixlQUFTO0FBQUNDLGFBQUs7QUFBTjtBQUFYLEtBREcsRUFFSDtBQUFFekQsa0JBQVksS0FBS2tDO0FBQW5CLEtBRkc7QUFEUCxHQURLLEVBT0w7QUFDRU8sV0FBTy9ELE9BQU84RixTQUFQLENBQWlCTSxtQkFEMUI7QUFFRXRELFVBQU07QUFBQ3pCLGtCQUFZLENBQUM7QUFBZCxLQUZSO0FBR0UyQyxZQUFRQTtBQUhWLEdBUEssQ0FBUCxDQURGLEtBZUUsT0FBTzlCLFNBQVN3SixJQUFULENBQ0w7QUFBRTVHLGFBQVM7QUFBQ0MsV0FBSztBQUFOO0FBQVgsR0FESyxFQUVMO0FBQ0VoQixXQUFPL0QsT0FBTzhGLFNBQVAsQ0FBaUJNLG1CQUQxQjtBQUVFdEQsVUFBTTtBQUFDekIsa0JBQVksQ0FBQztBQUFkLEtBRlI7QUFHRTJDLFlBQVFBO0FBSFYsR0FGSyxDQUFQO0FBUUgsQ0FyQ0QsRSxDQXVDQTs7QUFDQWhFLE9BQU9tWixPQUFQLENBQWUsYUFBZixFQUE4QixZQUFVO0FBRXRDLE1BQUluVixTQUFTO0FBQ1hILFNBQUssQ0FETTtBQUVYb0Isa0JBQWMsQ0FGSDtBQUdYNUQsZ0JBQVksQ0FIRDtBQUlYQyxnQkFBWSxDQUpEO0FBS1hDLHlCQUFxQixDQUxWO0FBTVgyRCxpQkFBYSxDQU5GO0FBT1h0RCxVQUFNLENBUEs7QUFRWG9ELGVBQVcsQ0FSQTtBQVNYRyx1QkFBbUIsQ0FUUjtBQVVYTCxhQUFTO0FBVkUsR0FBYjtBQWFBLE1BQUksS0FBS3RCLE1BQVQsRUFDRSxPQUFPdEIsU0FBU3dKLElBQVQsQ0FDTDtBQUFFcEssZ0JBQVksS0FBS2tDO0FBQW5CLEdBREssRUFFSDtBQUNFTyxXQUFPL0QsT0FBTzhGLFNBQVAsQ0FBaUJNLG1CQUQxQjtBQUVFdEQsVUFBTTtBQUFDa0MsaUJBQVc7QUFBWixLQUZSO0FBR0VoQixZQUFRQTtBQUhWLEdBRkcsQ0FBUCxDQURGLEtBVUUsT0FBTyxFQUFQO0FBRUgsQ0EzQkQsRSxDQTZCQTs7QUFDQWhFLE9BQU9tWixPQUFQLENBQWUsY0FBZixFQUErQixZQUFVO0FBRXZDLE1BQUluVixTQUFTO0FBQ1hILFNBQUssQ0FETTtBQUVYb0Isa0JBQWMsQ0FGSDtBQUdYNUQsZ0JBQVksQ0FIRDtBQUlYQyxnQkFBWSxDQUpEO0FBS1hDLHlCQUFxQixDQUxWO0FBTVgyRCxpQkFBYSxDQU5GO0FBT1h0RCxVQUFNLENBUEs7QUFRWG9ELGVBQVcsQ0FSQTtBQVNYRyx1QkFBbUIsQ0FUUjtBQVVYTCxhQUFTO0FBVkUsR0FBYjtBQWFBLE1BQUksS0FBS3RCLE1BQVQsRUFDRSxPQUFPdEIsU0FBU3dKLElBQVQsQ0FDTDtBQUNFOUgsU0FBSyxDQUNIO0FBQUVrQixlQUFTO0FBQUNDLGFBQUs7QUFBTjtBQUFYLEtBREcsRUFFSDtBQUFFekQsa0JBQVksS0FBS2tDO0FBQW5CLEtBRkc7QUFEUCxHQURLLEVBT0w7QUFDRU8sV0FBTy9ELE9BQU84RixTQUFQLENBQWlCTSxtQkFEMUI7QUFFRXRELFVBQU07QUFBQ2tDLGlCQUFXO0FBQVosS0FGUjtBQUdFaEIsWUFBUUE7QUFIVixHQVBLLENBQVAsQ0FERixLQWVFLE9BQU85QixTQUFTd0osSUFBVCxDQUNMO0FBQUU1RyxhQUFTO0FBQUNDLFdBQUs7QUFBTjtBQUFYLEdBREssRUFFTDtBQUNFaEIsV0FBTy9ELE9BQU84RixTQUFQLENBQWlCTSxtQkFEMUI7QUFFRXRELFVBQU07QUFBQ2tDLGlCQUFXO0FBQVosS0FGUjtBQUdFaEIsWUFBUUE7QUFIVixHQUZLLENBQVA7QUFRSCxDQXRDRCxFLENBd0NBOztBQUNBaEUsT0FBT21aLE9BQVAsQ0FBZSxNQUFmLEVBQXVCLFVBQVMzUixNQUFULEVBQWdCO0FBQ3JDNUIsUUFBTTRCLE1BQU4sRUFBYzhHLE1BQWQ7QUFDQTFJLFFBQU00QixPQUFPcEgsT0FBYixFQUFzQkUsTUFBdEIsRUFGcUMsQ0FJckM7O0FBQ0EsTUFBSWdELFNBQVMsRUFBYjtBQUNBQSxTQUFPLCtCQUFQLElBQTBDO0FBQUNDLFNBQUs7QUFBTixHQUExQyxDQU5xQyxDQU1lOztBQUNwREQsU0FBTyxJQUFQLElBQWVrRSxPQUFPcEgsT0FBdEI7QUFFQSxTQUFPSixPQUFPd0MsS0FBUCxDQUFha0osSUFBYixDQUNMO0FBQUM5SCxTQUFLLENBQUNOLE1BQUQsRUFBUztBQUFDTyxXQUFLLEtBQUtMO0FBQVgsS0FBVDtBQUFOLEdBREssRUFFTDtBQUNFTyxXQUFPLENBRFQ7QUFFRWpCLFVBQU07QUFBQywyQkFBcUI7QUFBdEIsS0FGUjtBQUdFa0IsWUFBUTtBQUFDSCxXQUFLLENBQU47QUFBU3JELGdCQUFVLENBQW5CO0FBQXNCMk0sZUFBUztBQUEvQjtBQUhWLEdBRkssQ0FBUDtBQVFELENBakJELEUsQ0FtQkE7O0FBQ0FuTixPQUFPbVosT0FBUCxDQUFlLFlBQWYsRUFBNkIsVUFBU0csT0FBVCxFQUFpQjtBQUU1QztBQUNBMVQsUUFBTTBULE9BQU4sRUFBZTdULE1BQU0ySSxRQUFOLENBQWV2TixNQUFmLENBQWYsRUFINEMsQ0FLNUM7O0FBQ0EsTUFBSXlDLFNBQVMsRUFBYjtBQUNBQSxTQUFPLCtCQUFQLElBQTBDO0FBQUNDLFNBQUs7QUFBTixHQUExQyxDQVA0QyxDQU9ROztBQUVwRCxNQUFJLEtBQUtDLE1BQVQsRUFDRSxPQUFPeEQsT0FBT3dDLEtBQVAsQ0FBYWtKLElBQWIsQ0FDTDtBQUFDOUgsU0FBSyxDQUFDTixNQUFELEVBQVM7QUFBQ08sV0FBSyxLQUFLTDtBQUFYLEtBQVQ7QUFBTixHQURLLEVBRUw7QUFDRU8sV0FBTy9ELE9BQU84RixTQUFQLENBQWlCTSxtQkFEMUI7QUFFRXRELFVBQU07QUFBQywyQkFBcUI7QUFBdEIsS0FGUjtBQUdFa0IsWUFBUTtBQUFDSCxXQUFLLENBQU47QUFBU3JELGdCQUFVLENBQW5CO0FBQXNCMk0sZUFBUztBQUEvQjtBQUhWLEdBRkssQ0FBUCxDQURGLEtBVUUsT0FBT25OLE9BQU93QyxLQUFQLENBQWFrSixJQUFiLENBQ0w7QUFBQzlILFNBQUssQ0FBQ04sTUFBRDtBQUFOLEdBREssRUFFTDtBQUNFUyxXQUFPL0QsT0FBTzhGLFNBQVAsQ0FBaUJNLG1CQUQxQjtBQUVFdEQsVUFBTTtBQUFDLDJCQUFxQjtBQUF0QixLQUZSO0FBR0VrQixZQUFRO0FBQUNILFdBQUssQ0FBTjtBQUFTckQsZ0JBQVUsQ0FBbkI7QUFBc0IyTSxlQUFTO0FBQS9CO0FBSFYsR0FGSyxDQUFQO0FBUUgsQ0EzQkQsRSxDQTZCQTs7QUFDQW5OLE9BQU9tWixPQUFQLENBQWUsUUFBZixFQUF5QixVQUFTM1IsTUFBVCxFQUFpQjtBQUN4QyxTQUFPdkcsT0FBT3lLLElBQVAsRUFBUDtBQUNELENBRkQ7QUFJQTFMLE9BQU9tWixPQUFQLENBQWUsTUFBZixFQUF1QixZQUFVO0FBQy9CO0FBQ0EsU0FBT25aLE9BQU93TixJQUFQLENBQVk5QixJQUFaLEVBQVA7QUFDRCxDQUhELEUsQ0FLQTtBQUNBO0FBQ0E7O0FBQ0ExTCxPQUFPbVosT0FBUCxDQUFlLGFBQWYsRUFBOEIsWUFBVztBQUN2QyxNQUFJLENBQUNuWixPQUFPdUksUUFBUCxDQUFnQnpELE9BQWhCLENBQXdCb1UsS0FBN0IsRUFDRTtBQUVGLFNBQU9uWixXQUFXMkwsSUFBWCxFQUFQO0FBQ0QsQ0FMRCxFOzs7Ozs7Ozs7OztBQ3ZVQSxJQUFJMUwsT0FBT3lHLFFBQVgsRUFBcUI7QUFDbkI7QUFFQTZGLFdBQVNpTixFQUFULENBQVloTixNQUFaLENBQW1CO0FBQ2pCaU4sMEJBQXNCO0FBREwsR0FBbkI7QUFJQTNTLFVBQVFDLEdBQVIsQ0FBWSxjQUFaLEVBQTRCMlMsRUFBRUMsTUFBRixFQUFVaFksS0FBVixFQUE1QjtBQUNBbUYsVUFBUUMsR0FBUixDQUFZLGVBQVosRUFBNkIyUyxFQUFFQyxNQUFGLEVBQVUvWCxNQUFWLEVBQTdCO0FBRUEzQixTQUFPaU0sT0FBUCxDQUFlLFlBQVk7QUFFekJwRixZQUFRQyxHQUFSLENBQVksYUFBWixFQUEyQixLQUEzQixFQUZ5QixDQUVVOztBQUVuQ0QsWUFBUUMsR0FBUixDQUFZLFNBQVosRUFBdUIsS0FBdkI7QUFFQTRTLFdBQU9DLGdCQUFQLENBQXdCLFFBQXhCLEVBQWtDLFlBQVU7QUFDMUM5UyxjQUFRQyxHQUFSLENBQVksY0FBWixFQUE0QjJTLEVBQUVDLE1BQUYsRUFBVWhZLEtBQVYsRUFBNUI7QUFDQW1GLGNBQVFDLEdBQVIsQ0FBWSxlQUFaLEVBQTZCMlMsRUFBRUMsTUFBRixFQUFVL1gsTUFBVixFQUE3QjtBQUNBa0YsY0FBUUMsR0FBUixDQUFZLG1CQUFaLEVBQWlDOUcsT0FBTzZILFlBQVAsQ0FBb0IrUixpQkFBcEIsRUFBakM7QUFDRCxLQUpEO0FBTUEvUyxZQUFRQyxHQUFSLENBQVkscUJBQVosRUFBbUMsQ0FBbkM7QUFDRCxHQWJELEVBVm1CLENBeUJuQjtBQUNBOztBQUNBQyxXQUFTOFMsTUFBVCxDQUFnQkMsT0FBaEIsR0FBMEIsWUFBVztBQUNuQyxTQUFLL1IsU0FBTCxDQUFlLGlCQUFmO0FBQ0EsU0FBS0EsU0FBTCxDQUFlLGNBQWY7QUFDRCxHQUhELENBM0JtQixDQWdDbkI7QUFDQTtBQUVBOztBQUNBaEIsV0FBU2dULE9BQVQsQ0FBaUJDLFFBQWpCLEdBQTRCLFlBQVc7QUFDckNQLE1BQUUsTUFBRixFQUFVUSxJQUFWLENBQWUsT0FBZixFQUF3QixTQUF4QjtBQUNBamEsV0FBTzZILFlBQVAsQ0FBb0JxUyxnQkFBcEI7QUFDRCxHQUhEOztBQUtBblQsV0FBU29ULFdBQVQsQ0FBcUJILFFBQXJCLEdBQWdDLFlBQVc7QUFDekM7QUFDQ1AsTUFBRUMsTUFBRixFQUFVVSxFQUFWLENBQWEsMEJBQWIsRUFBeUMsVUFBU3RMLENBQVQsRUFBWTtBQUNwRDlPLGFBQU82SCxZQUFQLENBQW9Cd1MsV0FBcEI7QUFDRCxLQUZBO0FBSUFaLE1BQUUsUUFBRixFQUFZVyxFQUFaLENBQWUsUUFBZixFQUF5QixVQUFTdEwsQ0FBVCxFQUFZO0FBQ3BDOU8sYUFBTzZILFlBQVAsQ0FBb0J3UyxXQUFwQjtBQUNELEtBRkE7QUFHRCxHQVRGOztBQVdBdFQsV0FBU29ULFdBQVQsQ0FBcUJHLE9BQXJCLENBQTZCO0FBQzNCUCxhQUFTLFlBQVU7QUFDakIsVUFBSWxULFFBQVEwVCxNQUFSLENBQWUsU0FBZixFQUEwQixJQUExQixDQUFKLEVBQ0UsT0FBTyxTQUFQO0FBQ0g7QUFKMEIsR0FBN0IsRUFwRG1CLENBMkRuQix5RUEzRG1CLENBNERuQjs7QUFDQUMsS0FBR0MsY0FBSCxDQUFrQixRQUFsQixFQUE0QixVQUFVQyxDQUFWLEVBQWFDLENBQWIsRUFBZ0I7QUFDMUMsV0FBUUQsTUFBTUMsQ0FBZDtBQUNELEdBRkQ7QUFJQUgsS0FBR0MsY0FBSCxDQUFrQixVQUFsQixFQUE4QixVQUFVQyxDQUFWLEVBQWFDLENBQWIsRUFBZ0I7QUFDNUMsV0FBT0QsSUFBRUMsQ0FBVDtBQUNELEdBRkQsRUFqRW1CLENBcUVuQjs7QUFDQUgsS0FBR0MsY0FBSCxDQUFrQixnQkFBbEIsRUFBb0MsVUFBU0csV0FBVCxFQUFzQkMsVUFBdEIsRUFBaUM7QUFDbkUsUUFBSWhVLFFBQVFpVSxHQUFSLENBQVlGLFdBQVosS0FBNEJDLFVBQWhDLEVBQ0UsT0FBTyxJQUFQLENBREYsS0FHRSxPQUFPLEtBQVA7QUFDSCxHQUxEO0FBT0FMLEtBQUdDLGNBQUgsQ0FBa0IsWUFBbEIsRUFBZ0MsWUFBWTtBQUMxQyxRQUFHemEsT0FBTythLFNBQVYsRUFDRSxPQUFPLElBQVA7QUFDSCxHQUhEO0FBS0FQLEtBQUdDLGNBQUgsQ0FBa0IscUJBQWxCLEVBQXlDLFVBQVVPLFdBQVYsRUFBdUJuWCxHQUF2QixFQUE0QjtBQUNuRTtBQUNBO0FBQ0E7QUFDQSxRQUFJN0QsT0FBTzZILFlBQVAsQ0FBb0JtRSxnQkFBcEIsQ0FBcUNuSSxHQUFyQyxDQUFKLEVBQ0UsT0FBTyxJQUFQO0FBRUYsV0FBTzdELE9BQU82SCxZQUFQLENBQW9Cb1QsYUFBcEIsQ0FBa0NELFdBQWxDLENBQVA7QUFDRCxHQVJEO0FBVUFSLEtBQUdDLGNBQUgsQ0FBa0IsZUFBbEIsRUFBbUMsVUFBVTFZLEtBQVYsRUFBaUI7QUFDaEQsV0FBTy9CLE9BQU82SCxZQUFQLENBQW9Cb1QsYUFBcEIsQ0FBa0NsWixLQUFsQyxDQUFQO0FBQ0gsR0FGRCxFQTVGbUIsQ0FnR25COztBQUNBeVksS0FBR0MsY0FBSCxDQUFrQixtQkFBbEIsRUFBdUMsWUFBWTtBQUNqRDs7Ozs7O01BRGlELENBU2pEO0FBRUEsWUFBUXphLE9BQU9rYixNQUFQLEdBQWdCQSxNQUF4QjtBQUVFLFdBQUssWUFBTCxDQUZGLENBRXNCOztBQUNwQixXQUFLLFNBQUw7QUFDRSxZQUFJLE9BQU9DLGtCQUFQLEtBQThCLFdBQWxDLEVBQ0VBLHFCQUFxQkMsV0FBVyxZQUFVO0FBQ3hDdlUsa0JBQVFDLEdBQVIsQ0FBWSxtQkFBWixFQUFpQyxtQkFBakM7QUFDRCxTQUZvQixFQUVsQixJQUZrQixDQUFyQjtBQUdGOztBQUVGLFdBQUssUUFBTCxDQVZGLENBVWtCOztBQUNoQixXQUFLLFNBQUw7QUFDRSxZQUFJLE9BQU91VSxvQkFBUCxLQUFnQyxXQUFwQyxFQUNFQSx1QkFBdUJELFdBQVcsWUFBVTtBQUMxQ3ZVLGtCQUFRQyxHQUFSLENBQVksbUJBQVosRUFBaUMsY0FBakM7QUFDRCxTQUZzQixFQUVwQixJQUZvQixDQUF2QjtBQUdGRCxnQkFBUUMsR0FBUixDQUFZLG1CQUFaLEVBQWlDLGNBQWpDO0FBQ0E7O0FBRUYsV0FBSyxXQUFMO0FBQ0VELGdCQUFRQyxHQUFSLENBQVksV0FBWixFQUF5QixJQUF6QjtBQUNBLFlBQUksT0FBT3FVLGtCQUFQLEtBQThCLFdBQWxDLEVBQ0VHLGFBQWFILGtCQUFiO0FBRUYsWUFBSSxPQUFPRSxvQkFBUCxLQUFnQyxXQUFwQyxFQUNFQyxhQUFhRCxvQkFBYjtBQUVGeFUsZ0JBQVFDLEdBQVIsQ0FBWSxtQkFBWixFQUFpQyxXQUFqQztBQUNBOztBQUVGO0FBQ0VELGdCQUFRQyxHQUFSLENBQVksbUJBQVosRUFBaUMsY0FBakM7QUFDQTtBQWhDSjs7QUFrQ0EsV0FBT0QsUUFBUWlVLEdBQVIsQ0FBWSxtQkFBWixDQUFQO0FBQ0QsR0E5Q0Q7QUFnREFOLEtBQUdDLGNBQUgsQ0FBa0IsaUJBQWxCLEVBQXFDLFlBQVc7QUFDOUM7QUFDQTtBQUNBO0FBRUE7QUFDQSxRQUFJcFQsYUFBYUMsT0FBT0MsT0FBUCxHQUFpQkMsTUFBakIsQ0FBd0IzRCxHQUF6Qzs7QUFDQSxRQUFJLENBQUM3RCxPQUFPNkgsWUFBUCxDQUFvQjBULGNBQXBCLENBQW1DbFUsVUFBbkMsQ0FBTCxFQUNJLE9BQU8sVUFBUDtBQUVKLFFBQUlrQyxVQUFVckgsU0FBU2tILE9BQVQsQ0FBaUI7QUFBQ3ZGLFdBQUt3RDtBQUFOLEtBQWpCLEVBQW9DO0FBQUNyRCxjQUFRO0FBQUVxSyx3QkFBZ0I7QUFBbEI7QUFBVCxLQUFwQyxDQUFkO0FBRUEsUUFBSTlFLFFBQVE4RSxjQUFSLEdBQXlCLENBQTdCLEVBQ0UsT0FBTyxVQUFQO0FBQ0gsR0FkRDtBQWdCQW1NLEtBQUdDLGNBQUgsQ0FBa0IsZUFBbEIsRUFBbUMsWUFBVztBQUM1QztBQUNBLFFBQUlwVCxhQUFhQyxPQUFPQyxPQUFQLEdBQWlCQyxNQUFqQixDQUF3QjNELEdBQXpDOztBQUNBLFFBQUksQ0FBQzdELE9BQU82SCxZQUFQLENBQW9CMFQsY0FBcEIsQ0FBbUNsVSxVQUFuQyxDQUFMLEVBQ0k7QUFFSixRQUFJa0MsVUFBVXJILFNBQVNrSCxPQUFULENBQWlCO0FBQUN2RixXQUFLd0Q7QUFBTixLQUFqQixFQUFvQztBQUFDckQsY0FBUTtBQUFFcUgsaUJBQVM7QUFBWDtBQUFULEtBQXBDLENBQWQ7QUFHQSxRQUFJOUIsUUFBUThCLE9BQVIsQ0FBZ0JtUSxPQUFoQixDQUF3QixLQUF4QixLQUFrQyxDQUFDLENBQXZDLEVBQTBDO0FBQ3hDLGFBQU8sSUFBUCxDQURGLEtBSUUsT0FBTyxLQUFQO0FBQ0gsR0FkRCxFQWpLbUIsQ0FpTG5CO0FBQ0E7QUFDQTs7QUFDQWhCLEtBQUdDLGNBQUgsQ0FBa0IsWUFBbEIsRUFBZ0MsWUFBVTtBQUN4QyxXQUFPblQsT0FBT0MsT0FBUCxHQUFpQjRELEtBQWpCLENBQXVCc1EsT0FBdkIsRUFBUDtBQUNELEdBRkQsRUFwTG1CLENBd0xuQjtBQUNBOztBQUNBakIsS0FBR0MsY0FBSCxDQUFrQixpQkFBbEIsRUFBcUMsWUFBVztBQUM5QztBQUNBNVQsWUFBUUMsR0FBUixDQUFZLFNBQVosRUFBdUIsS0FBdkI7QUFDQSxXQUFPLElBQVA7QUFDRCxHQUpELEVBMUxtQixDQWdNbkI7QUFDQTs7QUFDQTBULEtBQUdDLGNBQUgsQ0FBa0IsV0FBbEIsRUFBK0IsWUFBVztBQUN4QyxRQUFJblQsT0FBT0MsT0FBUCxHQUFpQjRELEtBQWpCLENBQXVCc1EsT0FBdkIsTUFBb0MsU0FBeEMsRUFDQTtBQUNFLGFBQU81VSxRQUFRaVUsR0FBUixDQUFZLFdBQVosQ0FBUDtBQUNEO0FBQ0YsR0FMRDtBQU9BTixLQUFHQyxjQUFILENBQWtCLGlCQUFsQixFQUFxQyxZQUFXO0FBQzlDLFFBQUluVCxPQUFPQyxPQUFQLEdBQWlCNEQsS0FBakIsQ0FBdUJzUSxPQUF2QixNQUFvQyxTQUF4QyxFQUNFLE9BQU81VSxRQUFRaVUsR0FBUixDQUFZLGlCQUFaLENBQVA7QUFDSCxHQUhEO0FBS0FOLEtBQUdDLGNBQUgsQ0FBa0IscUJBQWxCLEVBQXlDLFlBQVU7QUFDakQsUUFBSXBULGFBQWFDLE9BQU9DLE9BQVAsR0FBaUJDLE1BQWpCLENBQXdCM0QsR0FBekM7O0FBQ0EsV0FBTzdELE9BQU82SCxZQUFQLENBQW9CNlQsbUJBQXBCLENBQXdDclUsVUFBeEMsQ0FBUDtBQUNELEdBSEQsRUE5TW1CLENBbU5uQjtBQUNBO0FBQ0E7QUFDQTs7QUFDQU4sV0FBUzRVLFlBQVQsQ0FBc0JDLFVBQXRCLENBQWlDLFlBQVc7QUFDMUN0VyxnQkFBWXVXLFdBQVosQ0FBd0IsQ0FBeEI7QUFDRCxHQUZEO0FBSUE5VSxXQUFTK1UsV0FBVCxDQUFxQkYsVUFBckIsQ0FBZ0MsWUFBVztBQUN6Q3hXLGVBQVd5VyxXQUFYLENBQXVCLENBQXZCO0FBQ0QsR0FGRDtBQUlBOVUsV0FBU2dWLFlBQVQsQ0FBc0JILFVBQXRCLENBQWlDLFlBQVc7QUFDMUN2VyxnQkFBWXdXLFdBQVosQ0FBd0IsQ0FBeEI7QUFDRCxHQUZEO0FBSUE5VSxXQUFTb0MsSUFBVCxDQUFjeVMsVUFBZCxDQUF5QixZQUFXO0FBQ2xDL1csaUJBQWFnWCxXQUFiLENBQXlCLENBQXpCO0FBQ0QsR0FGRCxFQW5PbUIsQ0F1T25CO0FBQ0E7O0FBQ0FyQixLQUFHQyxjQUFILENBQWtCLG1CQUFsQixFQUF1QyxZQUFXO0FBQ2hELFdBQU81VCxRQUFRaVUsR0FBUixDQUFZLG1CQUFaLENBQVA7QUFDRCxHQUZEO0FBSUFOLEtBQUdDLGNBQUgsQ0FBa0Isa0JBQWxCLEVBQXNDLFlBQVc7QUFDL0MsUUFBSXJQLE9BQU8sS0FBS25HLFlBQWhCLENBRCtDLENBRS9DOztBQUNBLFFBQUkrVyxNQUFNLCtCQUErQnRDLE9BQU91QyxJQUFQLENBQVk3USxJQUFaLENBQXpDO0FBQ0EsV0FBTzRRLEdBQVA7QUFDRCxHQUxEO0FBT0F4QixLQUFHQyxjQUFILENBQWtCLGFBQWxCLEVBQWlDLFlBQVU7QUFDekMsUUFBSSxDQUFDemEsT0FBT3dELE1BQVAsRUFBTCxFQUNFO0FBRUYsUUFBSTBZLE1BQU07QUFDUixjQUFRO0FBQUUsZ0JBQVE7QUFBVixPQURBO0FBRVIsZUFBU3JWLFFBQVFpVSxHQUFSLENBQVksbUJBQVo7QUFGRCxLQUFWO0FBS0EsV0FBTzVZLFNBQVN3SixJQUFULENBQWM7QUFBQ3BLLGtCQUFZdEIsT0FBT3dELE1BQVA7QUFBYixLQUFkLEVBQTZDMFksR0FBN0MsQ0FBUDtBQUNELEdBVkQ7QUFZQTFCLEtBQUdDLGNBQUgsQ0FBa0IsY0FBbEIsRUFBa0MsWUFBVTtBQUMxQyxRQUFJeUIsTUFBTTtBQUNSLGNBQVE7QUFBRSxzQkFBYyxDQUFDO0FBQWpCLE9BREE7QUFFUixlQUFTclYsUUFBUWlVLEdBQVIsQ0FBWSxtQkFBWjtBQUZELEtBQVY7QUFLQSxXQUFPNVksU0FBU3dKLElBQVQsQ0FBYyxFQUFkLEVBQWtCd1EsR0FBbEIsQ0FBUDtBQUNELEdBUEQ7QUFTQTFCLEtBQUdDLGNBQUgsQ0FBa0IsY0FBbEIsRUFBa0MsWUFBVTtBQUMxQyxRQUFJeUIsTUFBTTtBQUNSLGNBQVE7QUFBRSxnQkFBUTtBQUFWLE9BREE7QUFFUixlQUFTclYsUUFBUWlVLEdBQVIsQ0FBWSxtQkFBWjtBQUZELEtBQVY7QUFLQSxXQUFPNVksU0FBU3dKLElBQVQsQ0FBYyxFQUFkLEVBQWtCd1EsR0FBbEIsQ0FBUDtBQUNELEdBUEQ7QUFTQTFCLEtBQUdDLGNBQUgsQ0FBa0IsT0FBbEIsRUFBMkIsWUFBVTtBQUNuQyxRQUFJeUIsTUFBTTtBQUNSLGNBQVE7QUFBRSw2QkFBcUI7QUFBdkIsT0FEQTtBQUVSLGVBQVNyVixRQUFRaVUsR0FBUixDQUFZLG1CQUFaO0FBRkQsS0FBVjtBQUtBLFdBQU85YSxPQUFPd0MsS0FBUCxDQUFha0osSUFBYixDQUFrQixFQUFsQixFQUFzQndRLEdBQXRCLENBQVA7QUFDRCxHQVBELEVBbFJtQixDQTJSbkI7O0FBQ0ExQixLQUFHQyxjQUFILENBQWtCLG9CQUFsQixFQUF3QyxZQUFVO0FBQ2hELFdBQU96YSxPQUFPNkgsWUFBUCxDQUFvQitGLGtCQUFwQixFQUFQO0FBQ0QsR0FGRDtBQUlBNE0sS0FBR0MsY0FBSCxDQUFrQixtQkFBbEIsRUFBdUMsWUFBVTtBQUMvQyxXQUFPNVQsUUFBUWlVLEdBQVIsQ0FBWSxtQkFBWixDQUFQO0FBQ0QsR0FGRDtBQUlBL1QsV0FBU29WLFdBQVQsQ0FBcUI3QixPQUFyQixDQUE2QjtBQUMzQjhCLGNBQVUsVUFBU0MsSUFBVCxFQUFlO0FBQ3ZCLFVBQUlsUixRQUFRN0QsT0FBT0MsT0FBUCxHQUFpQjRELEtBQWpCLENBQXVCc1EsT0FBdkIsRUFBWjs7QUFDQSxjQUFPWSxJQUFQO0FBRUUsYUFBSyxNQUFMO0FBQ0EsYUFBSyxpQkFBTDtBQUNBLGFBQUssY0FBTDtBQUNBLGFBQUssYUFBTDtBQUNBLGFBQUssY0FBTDtBQUNBLGFBQUssT0FBTDtBQUNFLGNBQUlsUixTQUFTa1IsSUFBYixFQUNFLE9BQU8sVUFBUDtBQUNGO0FBVko7QUFZRDtBQWYwQixHQUE3QixFQXBTbUIsQ0FzVG5COztBQUNBdFYsV0FBU3VWLE1BQVQsQ0FBZ0JoQyxPQUFoQixDQUF3QjtBQUN0QmlDLGFBQVMsWUFBWTtBQUNuQixhQUFPLENBQUNsWSxhQUFELEVBQWdCTyxVQUFoQixDQUFQO0FBQ0QsS0FIcUI7QUFJdEJQLG1CQUFlLFlBQVk7QUFDekIsYUFBT0EsYUFBUDtBQUNELEtBTnFCO0FBT3RCTyxnQkFBWSxZQUFZO0FBQ3RCLGFBQU9BLFVBQVA7QUFDRCxLQVRxQjtBQVV0QjRYLGdCQUFZLFlBQVk7QUFDdEIsVUFBSTNWLFFBQVFpVSxHQUFSLENBQVksY0FBWixJQUE4QixHQUFsQyxFQUNFLE9BQU87QUFBRSxpQkFBUyxtQkFBWDtBQUFnQyx1QkFBZTtBQUEvQyxPQUFQLENBREYsS0FHSyxJQUFJalUsUUFBUWlVLEdBQVIsQ0FBWSxjQUFaLElBQThCLEdBQWxDLEVBQ0gsT0FBTztBQUFFLGlCQUFTLG1CQUFYO0FBQWdDLHVCQUFlO0FBQS9DLE9BQVAsQ0FERyxLQUlILE9BQU87QUFBRSxpQkFBUyxtQkFBWDtBQUFnQyx1QkFBZTtBQUEvQyxPQUFQO0FBQ0gsS0FuQnFCO0FBb0J0QjJCLGlCQUFhLFlBQVc7QUFDdEIsYUFBT3BZLGNBQWNxWSxnQkFBZCxHQUFpQzVCLEdBQWpDLENBQXFDLGtCQUFyQyxDQUFQO0FBQ0QsS0F0QnFCO0FBdUJ0QjZCLDJCQUF1QixZQUFXO0FBQ2hDLGFBQU90WSxjQUFjcVksZ0JBQWQsR0FBaUM1QixHQUFqQyxDQUFxQyxPQUFyQyxDQUFQO0FBQ0QsS0F6QnFCO0FBMEJ0QjhCLHlCQUFxQixZQUFXO0FBQzlCLGFBQU9oWSxXQUFXOFgsZ0JBQVgsR0FBOEI1QixHQUE5QixDQUFrQyxPQUFsQyxDQUFQO0FBQ0QsS0E1QnFCO0FBNkJ0QitCLGVBQVcsWUFBVztBQUNwQixVQUFJaFcsUUFBUWlVLEdBQVIsQ0FBWSxjQUFaLElBQThCLEdBQWxDLEVBQ0UsT0FBTyxNQUFQLENBREYsS0FHSyxJQUFJalUsUUFBUWlVLEdBQVIsQ0FBWSxjQUFaLElBQThCLEdBQWxDLEVBQ0gsT0FBTyxRQUFQO0FBQ0gsS0FuQ3FCO0FBb0N0QmdDLG1CQUFlLFlBQVc7QUFDeEIsVUFBSXpZLGNBQWMwWSxtQkFBZCxHQUFvQ0MsZ0JBQXBDLEVBQUosRUFDRSxPQUFPLElBQVA7QUFDSCxLQXZDcUI7QUF3Q3RCQyxnQkFBWSxZQUFXO0FBQ3JCLFVBQUlyWSxXQUFXbVksbUJBQVgsR0FBaUNDLGdCQUFqQyxFQUFKLEVBQ0UsT0FBTyxJQUFQO0FBQ0g7QUEzQ3FCLEdBQXhCO0FBOENBalcsV0FBU3VWLE1BQVQsQ0FBZ0JWLFVBQWhCLENBQTJCLFlBQVk7QUFDckM7QUFDQW5DLE1BQUUsTUFBRixFQUFVVyxFQUFWLENBQWEsT0FBYixFQUFzQixVQUFTbFQsS0FBVCxFQUFlO0FBQ25DO0FBRUE7QUFDQSxVQUFJdVMsRUFBRSwwQkFBRixFQUE4QjVULE1BQTlCLElBQXdDLENBQTVDLEVBQ0E7QUFDRTtBQUNBLFlBQUlxWCxlQUFlekQsRUFBRSxrQkFBRixDQUFuQjs7QUFFQSxZQUFJLENBQUN5RCxhQUFhQyxFQUFiLENBQWdCalcsTUFBTWtXLE1BQXRCLENBQUQsQ0FBK0I7QUFBL0IsV0FDREYsYUFBYUcsR0FBYixDQUFpQm5XLE1BQU1rVyxNQUF2QixFQUErQnZYLE1BQS9CLEtBQTBDLENBRDdDLEVBQ2dEO0FBQ2hEO0FBQ0U7QUFDQSxnQkFBSXlYLFFBQVE3RCxFQUFFLGdEQUFGLENBQVo7O0FBRUUsZ0JBQUksQ0FBQzZELE1BQU1ILEVBQU4sQ0FBU2pXLE1BQU1rVyxNQUFmLENBQUQsSUFDSEUsTUFBTUQsR0FBTixDQUFVblcsTUFBTWtXLE1BQWhCLEVBQXdCdlgsTUFBeEIsS0FBbUMsQ0FEcEMsRUFFRjtBQUNFN0YscUJBQU82SCxZQUFQLENBQW9CMFYsbUJBQXBCO0FBQ0Q7QUFDRjtBQUNGO0FBQ0YsS0F0QkQ7QUF3QkE5RCxNQUFFQyxNQUFGLEVBQVVVLEVBQVYsQ0FBYSxPQUFiLEVBQXNCLFVBQVNsVCxLQUFULEVBQWdCO0FBQ3BDO0FBRUE7QUFDQSxVQUFJdVMsRUFBRSwwQkFBRixFQUE4QjVULE1BQTlCLElBQXdDLENBQTVDLEVBQ0E7QUFDRSxZQUFJcUIsTUFBTXNXLEtBQU4sSUFBZSxFQUFuQixFQUF1QjtBQUN2QnhkLGlCQUFPNkgsWUFBUCxDQUFvQjBWLG1CQUFwQjtBQUNEO0FBQ0YsS0FURDtBQVVELEdBcENEO0FBc0NBeFcsV0FBU3VWLE1BQVQsQ0FBZ0JyVixNQUFoQixDQUF1QjtBQUNyQixnQkFBWSxZQUFZO0FBQ3RCO0FBQ0F3UyxRQUFFLHlCQUFGLEVBQTZCZ0UsR0FBN0IsQ0FBaUMsRUFBakM7QUFDQXpkLGFBQU82SCxZQUFQLENBQW9CMFYsbUJBQXBCO0FBQ0QsS0FMb0I7QUFNckIsaUNBQTZCLFVBQVNyVyxLQUFULEVBQWdCO0FBQzNDLFVBQUk3QyxjQUFjMFksbUJBQWQsR0FBb0NDLGdCQUFwQyxFQUFKLEVBQ0UzWSxjQUFjMFksbUJBQWQsR0FBb0NXLFFBQXBDLENBQTZDLENBQTdDO0FBQ0gsS0FUb0I7QUFVckIsOEJBQTBCLFVBQVN4VyxLQUFULEVBQWdCO0FBQ3hDLFVBQUl0QyxXQUFXbVksbUJBQVgsR0FBaUNDLGdCQUFqQyxFQUFKLEVBQ0VwWSxXQUFXbVksbUJBQVgsR0FBaUNXLFFBQWpDLENBQTBDLENBQTFDO0FBQ0gsS0Fib0I7QUFjckIsc0NBQWtDLFVBQVN4VyxLQUFULEVBQWdCO0FBQ2hEQSxZQUFNRSxjQUFOLEdBRGdELENBQ3hCOztBQUN4QnBILGFBQU82SCxZQUFQLENBQW9COFYscUJBQXBCLENBQTBDLEtBQUs5WixHQUEvQztBQUNEO0FBakJvQixHQUF2QjtBQW9CQTJXLEtBQUdDLGNBQUgsQ0FBa0IsWUFBbEIsRUFBZ0MsWUFBVTtBQUN4QyxRQUFJblQsT0FBT0MsT0FBUCxHQUFpQkMsTUFBakIsQ0FBd0J1RSxJQUF4QixJQUE4QixTQUFsQyxFQUNFLE9BQU8sSUFBUDtBQUNILEdBSEQsRUEvWm1CLENBb2FuQjs7QUFDQXlPLEtBQUdDLGNBQUgsQ0FBa0IsYUFBbEIsRUFBaUMsVUFBU3JhLE9BQVQsRUFBaUI7QUFDaEQsV0FBUUosT0FBT3dDLEtBQVAsQ0FBYWtKLElBQWIsQ0FBa0I7QUFBRTdILFdBQUt6RDtBQUFQLEtBQWxCLEVBQW1DdUwsS0FBbkMsTUFBOEMsQ0FBdEQ7QUFDRCxHQUZEO0FBSUE2TyxLQUFHQyxjQUFILENBQWtCLGdCQUFsQixFQUFvQyxVQUFTcFQsVUFBVCxFQUFvQjtBQUN0RCxRQUFJbkYsU0FBU3dKLElBQVQsQ0FBYztBQUFDN0gsV0FBS3dEO0FBQU4sS0FBZCxFQUFpQztBQUFDckQsY0FBUTtBQUFDSCxhQUFLO0FBQU47QUFBVCxLQUFqQyxFQUFxRDtBQUFDRSxhQUFPO0FBQVIsS0FBckQsRUFBaUU0SCxLQUFqRSxNQUE0RSxDQUFoRixFQUNFLE9BQU8sSUFBUDtBQUNILEdBSEQ7QUFLQTZPLEtBQUdDLGNBQUgsQ0FBa0Isb0JBQWxCLEVBQXdDLFVBQVNwVCxVQUFULEVBQW9CO0FBQzFELFlBQVFDLE9BQU9DLE9BQVAsR0FBaUI0RCxLQUFqQixDQUF1QnNRLE9BQXZCLEVBQVI7QUFFRSxXQUFLLE1BQUw7QUFDQSxXQUFLLGlCQUFMO0FBQ0EsV0FBSyxjQUFMO0FBQ0EsV0FBSyxhQUFMO0FBQ0EsV0FBSyxjQUFMO0FBQ0EsV0FBSyxPQUFMO0FBQ0UsZUFBTyxJQUFQO0FBQ0E7QUFUSjtBQVlELEdBYkQsRUE5YW1CLENBNmJuQjtBQUNBOztBQUVBakIsS0FBR0MsY0FBSCxDQUFrQixXQUFsQixFQUErQixZQUMvQjtBQUNFLFFBQUk1VCxRQUFRMFQsTUFBUixDQUFlLFdBQWYsRUFBNEIsSUFBNUIsQ0FBSixFQUNFLE9BQU8sTUFBUDtBQUNILEdBSkQ7QUFNQUMsS0FBR0MsY0FBSCxDQUFrQixrQkFBbEIsRUFBc0MsVUFBU3BULFVBQVQsRUFBcUI7QUFDekQsV0FBT3JILE9BQU82SCxZQUFQLENBQW9CbUUsZ0JBQXBCLENBQXFDM0UsVUFBckMsQ0FBUDtBQUNELEdBRkQsRUF0Y21CLENBMGNuQjtBQUNBOztBQUNBTixXQUFTNlcsSUFBVCxDQUFjdEQsT0FBZCxDQUFzQjtBQUNwQnVELGVBQVcsVUFBU0Msa0JBQVQsRUFBNkJDLFVBQTdCLEVBQXlDMVcsVUFBekMsRUFBb0Q7QUFDN0QsYUFBTyxJQUFQLENBRDZELENBQ2hEO0FBQ2I7Ozs7O3VCQUY2RCxDQVV2RDs7Ozs7OzBCQVZ1RCxDQW1CN0Q7O0FBRUQsS0F0Qm1CO0FBdUJwQjJXLCtCQUEyQixZQUMzQjtBQUNFLFVBQUloZSxPQUFPNkgsWUFBUCxDQUFvQm1XLHlCQUFwQixNQUFtRGhlLE9BQU82SCxZQUFQLENBQW9CK0Ysa0JBQXBCLEVBQXZELEVBQ0UsT0FBTyxJQUFQLENBREYsS0FJRSxPQUFPLEtBQVA7QUFDSDtBQTlCbUIsR0FBdEI7QUFpQ0E3RyxXQUFTNlcsSUFBVCxDQUFjM1csTUFBZCxDQUFxQjtBQUNuQiwwQkFBc0IsWUFBVztBQUMvQixVQUFJSixRQUFRMFQsTUFBUixDQUFlLFdBQWYsRUFBNEIsSUFBNUIsQ0FBSixFQUNFMVQsUUFBUUMsR0FBUixDQUFZLFdBQVosRUFBeUIsS0FBekIsRUFERixLQUlFRCxRQUFRQyxHQUFSLENBQVksV0FBWixFQUF5QixJQUF6QjtBQUNILEtBUGtCO0FBUW5CLHNDQUFrQyxZQUFVO0FBQzFDRCxjQUFRQyxHQUFSLENBQVksV0FBWixFQUF5QixLQUF6QjtBQUNELEtBVmtCO0FBV25CO0FBQ0EsNkJBQXlCLFlBQVc7QUFDbENELGNBQVFDLEdBQVIsQ0FBWSxxQkFBWixFQUFtQyxJQUFuQztBQUNELEtBZGtCO0FBZW5CO0FBQ0E7QUFDQSwyQkFBdUIsVUFBU0ksS0FBVCxFQUFnQkMsUUFBaEIsRUFBMEI7QUFDL0MsVUFBSUcsT0FBT0MsT0FBUCxHQUFpQjRELEtBQWpCLENBQXVCc1EsT0FBdkIsTUFBb0MsU0FBeEMsRUFDQTtBQUNFemIsZUFBTzZILFlBQVAsQ0FBb0JvVyxZQUFwQixDQUFpQzlXLFNBQVNpRSxJQUFULENBQWN2SCxHQUEvQztBQUNEO0FBQ0YsS0F0QmtCO0FBdUJuQjtBQUNBLDZCQUF5QixZQUFXO0FBQ2xDZ0QsY0FBUUMsR0FBUixDQUFZLHNCQUFaLEVBQW9DLElBQXBDO0FBQ0Q7QUExQmtCLEdBQXJCLEVBN2VtQixDQTBnQm5CO0FBQ0E7O0FBQ0FDLFdBQVNtWCxxQkFBVCxDQUErQjVELE9BQS9CLENBQXVDO0FBQ3JDLDJCQUF1QixZQUFXO0FBQ2hDLFVBQUl6VCxRQUFRMFQsTUFBUixDQUFlLHFCQUFmLEVBQXNDLElBQXRDLENBQUosRUFDSSxPQUFPLFNBQVA7QUFDTCxLQUpvQztBQUtyQyxlQUFXLFVBQVMzWSxJQUFULEVBQWM7QUFDdkIsVUFBSWlGLFFBQVEwVCxNQUFSLENBQWUsa0JBQWYsRUFBbUMzWSxJQUFuQyxDQUFKLEVBQ0UsT0FBTyxNQUFQO0FBQ0gsS0FSb0M7QUFTckMsZ0JBQVksWUFBVTtBQUNwQixVQUFJLE9BQU9pRixRQUFRaVUsR0FBUixDQUFZLGtCQUFaLENBQVAsS0FBMkMsV0FBL0MsRUFDRSxPQUFPLFVBQVA7QUFDSDtBQVpvQyxHQUF2QztBQWVBL1QsV0FBU21YLHFCQUFULENBQStCalgsTUFBL0IsQ0FBc0M7QUFDcEMsMkNBQXVDLFVBQVNDLEtBQVQsRUFBZ0I7QUFDckRMLGNBQVFDLEdBQVIsQ0FBWSxxQkFBWixFQUFtQyxLQUFuQztBQUNELEtBSG1DO0FBSXBDLDhDQUEwQyxVQUFTSSxLQUFULEVBQWdCO0FBQ3hEdVMsUUFBRSxjQUFGLEVBQWtCSCxPQUFsQixDQUEwQixPQUExQjtBQUNBelMsY0FBUUMsR0FBUixDQUFZLHFCQUFaLEVBQW1DLEtBQW5DO0FBQ0QsS0FQbUM7QUFRcEMsaUNBQTZCLFlBQVU7QUFDckMsVUFBSXFYLGFBQWF6VyxTQUFTMFcsaUJBQVQsQ0FBMkIsV0FBM0IsQ0FBakI7QUFDQSxVQUFJQyxhQUFKOztBQUNBLFdBQUksSUFBSTdPLElBQUksQ0FBWixFQUFlQSxJQUFJMk8sV0FBV3RZLE1BQTlCLEVBQXNDMkosR0FBdEMsRUFBMEM7QUFDeEMsWUFBRzJPLFdBQVczTyxDQUFYLEVBQWM4TyxPQUFqQixFQUF5QjtBQUNyQkQsMEJBQWdCRixXQUFXM08sQ0FBWCxFQUFjek4sS0FBOUI7QUFDSDtBQUNGOztBQUNEOEUsY0FBUUMsR0FBUixDQUFZLGtCQUFaLEVBQWdDdVgsYUFBaEM7QUFDRDtBQWpCbUMsR0FBdEMsRUEzaEJtQixDQStpQm5COztBQUNBdFgsV0FBU3dYLGtCQUFULENBQTRCdFgsTUFBNUIsQ0FBbUM7QUFDbkMsZ0NBQTRCLFVBQVNDLEtBQVQsRUFBZ0I7QUFDMUM7QUFDQSxVQUFJbEgsT0FBTzZILFlBQVAsQ0FBb0JtVyx5QkFBcEIsRUFBSixFQUNBO0FBQ0UsWUFBSXBXLFFBQVFWLE1BQU1rVyxNQUFOLENBQWF4VixLQUF6QixDQURGLENBQ2tDOztBQUMvQjRXLFlBQUk1VyxNQUFNLENBQU4sQ0FBSjtBQUVDLFlBQUk2VyxTQUFTLElBQUlDLFVBQUosRUFBYixDQUpKLENBTUk7O0FBQ0FELGVBQU9FLE1BQVAsR0FBaUIsVUFBU0MsT0FBVCxFQUFrQjtBQUNqQyxpQkFBTyxVQUFTOVAsQ0FBVCxFQUFZO0FBRWpCO0FBQ0E7QUFDQSxnQkFBSUwsV0FBV3pPLE9BQU82SCxZQUFQLENBQW9CZ1gsbUJBQXBCLENBQXdDRCxRQUFRaGQsSUFBaEQsQ0FBZixDQUppQixDQU1qQjs7QUFDQSxnQkFBSWdkLFFBQVFFLElBQVIsR0FBZSxPQUFuQixFQUNFQyxNQUFNLHVDQUFOOztBQUVGLG9CQUFPbFksUUFBUWlVLEdBQVIsQ0FBWSxrQkFBWixDQUFQO0FBRUUsbUJBQUssTUFBTDtBQUNFa0UsMEJBQVV0USxLQUFLQyxLQUFMLENBQVdHLEVBQUVzTyxNQUFGLENBQVM1TyxNQUFwQixDQUFWO0FBQ0F4Tyx1QkFBTzZILFlBQVAsQ0FBb0JvWCx3QkFBcEIsQ0FBNkNELE9BQTdDO0FBQ0E7O0FBRUYsbUJBQUssS0FBTDtBQUNFaGYsdUJBQU82SCxZQUFQLENBQW9CcVgsdUJBQXBCLENBQTRDcFEsRUFBRXNPLE1BQUYsQ0FBUzVPLE1BQXJELEVBQTZEQyxRQUE3RDtBQUNBOztBQUVGO0FBQ0VzUSxzQkFBTSwrQ0FBTjtBQUNBO0FBYko7QUFlRCxXQXpCRDtBQTBCRCxTQTNCZSxDQTJCYlAsQ0EzQmEsQ0FBaEIsQ0FQSixDQW9DSTs7O0FBQ0FDLGVBQU9VLFVBQVAsQ0FBa0JYLENBQWxCLEVBckNKLENBdUNJOztBQUNBL0UsVUFBRXZTLE1BQU1rVyxNQUFSLEVBQWdCZ0MsSUFBaEIsQ0FBcUIsUUFBckIsRUFBK0JDLE9BQS9CLENBQXVDLE1BQXZDLEVBQStDdkUsR0FBL0MsQ0FBbUQsQ0FBbkQsRUFBc0R3RSxLQUF0RDtBQUNBN0YsVUFBRXZTLE1BQU1rVyxNQUFSLEVBQWdCbUMsTUFBaEIsR0F6Q0osQ0EyQ0k7O0FBQ0FyWSxjQUFNc1ksZUFBTjtBQUNBdFksY0FBTUUsY0FBTjtBQUNEO0FBQ0Y7QUFuRGdDLEdBQW5DLEVBaGpCbUIsQ0FzbUJuQjtBQUNBOztBQUNBTCxXQUFTMFksZUFBVCxDQUF5Qm5GLE9BQXpCLENBQWlDO0FBQy9CLDRCQUF3QixZQUFXO0FBQ2pDLFVBQUl6VCxRQUFRMFQsTUFBUixDQUFlLHNCQUFmLEVBQXVDLElBQXZDLENBQUosRUFDSSxPQUFPLFNBQVA7QUFDTCxLQUo4QjtBQUsvQix1QkFBbUIsWUFBVztBQUM1QixVQUFJMVQsUUFBUTBULE1BQVIsQ0FBZSxzQkFBZixFQUF1QyxLQUF2QyxDQUFKLEVBQ0k7QUFFSixVQUFJbFQsYUFBYSxLQUFLeEQsR0FBdEI7QUFDQSxVQUFJNGIsa0JBQWtCL1EsS0FBS2tDLFNBQUwsQ0FBZTVRLE9BQU82SCxZQUFQLENBQW9CNlgsc0JBQXBCLENBQTJDclksVUFBM0MsQ0FBZixFQUF1RSxJQUF2RSxFQUE2RSxJQUE3RSxDQUF0QixDQUw0QixDQUs4RTtBQUUxRzs7QUFDQSxVQUFJc1ksa0JBQWtCLEVBQXRCO0FBQ0EsVUFBSUMsYUFBYSxFQUFqQjtBQUVBLFVBQUlDLEtBQUssa0JBQVQsQ0FYNEIsQ0FZNUI7QUFDQTs7QUFDQSxXQUFJQyxJQUFJRCxHQUFHRSxJQUFILENBQVFOLGVBQVIsQ0FBUixFQUFrQ0ssQ0FBbEMsRUFBcUNBLElBQUlELEdBQUdFLElBQUgsQ0FBUU4sZUFBUixDQUF6QyxFQUFrRTtBQUNoRUUsd0JBQWdCN1AsSUFBaEIsQ0FBcUJnUSxFQUFFLENBQUYsQ0FBckI7QUFDQSxZQUFJRSxhQUFhRixFQUFFLENBQUYsQ0FBakIsQ0FGZ0UsQ0FJaEU7QUFDQTs7Ozs7O2FBTGdFLENBVzFEO0FBRU47QUFDQTs7QUFDQSxZQUFJRyxRQUFRLGNBQVo7QUFDQUQsbUJBQVdoSixPQUFYLENBQW1CaUosS0FBbkIsRUFBMEIsVUFBU0gsQ0FBVCxFQUFZSSxNQUFaLEVBQW9CO0FBQzFDLGNBQUlBLFVBQVUsRUFBZCxFQUFtQixPQUFPSixDQUFQLENBQW5CLEtBQ0ssT0FBTyxFQUFQO0FBQ1IsU0FIRDtBQUtBRSxxQkFBYUEsV0FBV2hKLE9BQVgsQ0FBbUIsS0FBbkIsRUFBeUIsRUFBekIsQ0FBYixDQXJCZ0UsQ0FxQnJCOztBQUMzQ2dKLHFCQUFhQSxXQUFXaEosT0FBWCxDQUFtQixnQkFBbkIsRUFBb0MsRUFBcEMsQ0FBYixDQXRCZ0UsQ0F1QmhFOztBQUNBNEksbUJBQVc5UCxJQUFYLENBQWdCa1EsVUFBaEI7QUFDRDs7QUFDRCxXQUFJLElBQUl4USxJQUFJLENBQVosRUFBZUEsSUFBSW1RLGdCQUFnQjlaLE1BQW5DLEVBQTJDMkosR0FBM0MsRUFBZ0Q7QUFDOUNpUSwwQkFBa0JBLGdCQUFnQmhWLEtBQWhCLENBQXNCa1YsZ0JBQWdCblEsQ0FBaEIsQ0FBdEIsRUFBMEM1RSxJQUExQyxDQUErQ2dWLFdBQVdwUSxDQUFYLENBQS9DLENBQWxCLENBRDhDLENBRTlDO0FBQ0Q7O0FBQ0QsYUFBT2lRLGVBQVA7QUFDRDtBQWxEOEIsR0FBakM7QUFxREExWSxXQUFTMFksZUFBVCxDQUF5QnhZLE1BQXpCLENBQWdDO0FBQzlCLHFDQUFpQyxZQUFXO0FBQzFDSixjQUFRQyxHQUFSLENBQVksc0JBQVosRUFBb0MsS0FBcEM7QUFDRCxLQUg2QjtBQUk5QixzQ0FBa0MsWUFBVztBQUMzQzJTLFFBQUUsMkJBQUYsRUFBK0IwRyxNQUEvQjtBQUNEO0FBTjZCLEdBQWhDLEVBN3BCbUIsQ0FzcUJuQjtBQUNBOztBQUNBM0YsS0FBR0MsY0FBSCxDQUFrQixhQUFsQixFQUFpQyxZQUFXO0FBQzFDLFdBQU81VCxRQUFRaVUsR0FBUixDQUFZLGFBQVosQ0FBUDtBQUNELEdBRkQsRUF4cUJtQixDQTRxQm5CO0FBQ0E7O0FBQ0FzRixVQUFRQyxPQUFSLENBQWdCLFVBQVVDLFdBQVYsRUFBdUI7QUFDckM7QUFDQSxRQUFJQyxjQUFjdmdCLE9BQU9tSixJQUFQLEVBQWxCOztBQUNBLFFBQUdvWCxXQUFILEVBQWU7QUFFYixVQUFJLENBQUMxWixRQUFRMFQsTUFBUixDQUFlLGVBQWYsRUFBZ0MsSUFBaEMsQ0FBTCxFQUNBO0FBQ0UxVCxnQkFBUUMsR0FBUixDQUFZLGVBQVosRUFBNkIsSUFBN0I7QUFDQXNVLG1CQUFXLFlBQVU7QUFBRXBiLGlCQUFPNkgsWUFBUCxDQUFvQndTLFdBQXBCO0FBQW1DLFNBQTFELEVBQTRELEVBQTVEO0FBQ0Q7QUFDRixLQVBELE1BUUssSUFBRyxDQUFDaUcsWUFBWUUsUUFBaEIsRUFBeUI7QUFBRTtBQUU5QixVQUFJM1osUUFBUTBULE1BQVIsQ0FBZSxlQUFmLEVBQWdDLElBQWhDLENBQUosRUFDQTtBQUNFMVQsZ0JBQVFDLEdBQVIsQ0FBWSxlQUFaLEVBQTZCLEtBQTdCO0FBQ0FzVSxtQkFBVyxZQUFVO0FBQUVwYixpQkFBTzZILFlBQVAsQ0FBb0J3UyxXQUFwQjtBQUFtQyxTQUExRCxFQUE0RCxFQUE1RDtBQUNEO0FBQ0Y7QUFDRixHQW5CRDtBQXFCQStGLFVBQVFDLE9BQVIsQ0FBZ0IsVUFBVUMsV0FBVixFQUF1QjtBQUNyQztBQUNBLFFBQUlHLE1BQU01WixRQUFRaVUsR0FBUixDQUFZLHFCQUFaLENBQVY7QUFDQSxRQUFJNEYsTUFBTTdaLFFBQVFpVSxHQUFSLENBQVkscUJBQVosQ0FBVjs7QUFFQSxRQUFJNEYsT0FBT0QsR0FBWCxFQUNBO0FBQ0U7QUFDQSxVQUFJRSxTQUFTQyxPQUFPamQsTUFBUCxDQUFjLEVBQWQsRUFBa0IwQixZQUFZeEMsT0FBOUIsQ0FBYjtBQUVBd0Msa0JBQVl5QixHQUFaLENBQWdCO0FBQ2RqRSxpQkFBUzdDLE9BQU82SCxZQUFQLENBQW9CZ1osa0JBQXBCLENBQXVDRixNQUF2QyxFQUErQ0QsR0FBL0MsRUFBb0RELEdBQXBEO0FBREssT0FBaEIsRUFKRixDQVFFOztBQUNBLFVBQUlFLFNBQVNDLE9BQU9qZCxNQUFQLENBQWMsRUFBZCxFQUFrQjJCLFlBQVl6QyxPQUE5QixDQUFiO0FBRUF5QyxrQkFBWXdCLEdBQVosQ0FBZ0I7QUFDZGpFLGlCQUFTN0MsT0FBTzZILFlBQVAsQ0FBb0JnWixrQkFBcEIsQ0FBdUNGLE1BQXZDLEVBQStDRCxHQUEvQyxFQUFvREQsR0FBcEQ7QUFESyxPQUFoQixFQVhGLENBZUU7O0FBQ0EsVUFBSUUsU0FBU0MsT0FBT2pkLE1BQVAsQ0FBYyxFQUFkLEVBQWtCeUIsV0FBV3ZDLE9BQTdCLENBQWI7QUFFQXVDLGlCQUFXMEIsR0FBWCxDQUFlO0FBQ2JqRSxpQkFBUzdDLE9BQU82SCxZQUFQLENBQW9CZ1osa0JBQXBCLENBQXVDRixNQUF2QyxFQUErQ0QsR0FBL0MsRUFBb0RELEdBQXBEO0FBREksT0FBZixFQWxCRixDQXNCRTs7QUFDQSxVQUFJRSxTQUFTQyxPQUFPamQsTUFBUCxDQUFjLEVBQWQsRUFBa0JrQixhQUFhaEMsT0FBL0IsQ0FBYjtBQUVBZ0MsbUJBQWFpQyxHQUFiLENBQWlCO0FBQ2ZqRSxpQkFBUzdDLE9BQU82SCxZQUFQLENBQW9CZ1osa0JBQXBCLENBQXVDRixNQUF2QyxFQUErQ0QsR0FBL0MsRUFBb0RELEdBQXBEO0FBRE0sT0FBakI7QUFHRDtBQUNGLEdBbkNEO0FBb0NELEMiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIGtlZXAgdHJhY2sgb2YgdXNlciBpbnRlcmFjdGlvbnMgdGhhdCBtYXkgaW5kaWNhdGUgYXR0YWNrc1xuLy8gZS5nLiByZXBlYXRlZCBhY3Rpb25zIGZhc3RlciB0aGFuIHRoZSBVSSB3b3VsZCBhbGxvdywgaW5kaWNhdGluZyBzY3JpcHRlZCBhY3Rpb25zXG4vLyB0aGVzZSBhY3Rpb25zIGFyZSByZWNvcmRlZCBwZXIgdXNlclxuXG5BY3Rpb25zTG9nID0gbmV3IE1ldGVvci5Db2xsZWN0aW9uKCdhY3Rpb25zX2xvZycpO1xuXG52YXIgU2NoZW1hID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gIHVzZXJfaWQ6IHtcbiAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgIGxhYmVsOiBcIlVzZXIgaWRcIlxuICB9LFxuICB1c2VybmFtZToge1xuICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgbGFiZWw6IFwiVXNlcm5hbWVcIlxuICB9LFxuICBsb2NrZWQ6IHtcbiAgICB0eXBlOiBCb29sZWFuLFxuICAgIGxhYmVsOiBcIkxvY2tlZFwiLFxuICAgIG9wdGlvbmFsOiB0cnVlXG4gIH0sXG4gIHZlcmlmaWNhdGlvbl9lbWFpbF9zZW50OiB7XG4gICAgICB0eXBlOiBbTnVtYmVyXSxcbiAgICAgIGxhYmVsOiBcIlZlcmlmaWNhdGlvbiBlbWFpbCBzZW50XCJcbiAgfSxcbiAgaW1hZ2VfdXBsb2FkZWQ6IHtcbiAgICAgIHR5cGU6IFtOdW1iZXJdLFxuICAgICAgbGFiZWw6IFwiSW1hZ2UgdXBsb2FkZWRcIlxuICB9LFxuICBpbWFnZV9yZW1vdmVkOiB7XG4gICAgICB0eXBlOiBbTnVtYmVyXSxcbiAgICAgIGxhYmVsOiBcIkltYWdlIHJlbW92ZWRcIlxuICB9LFxuXG59KTtcblxuQWN0aW9uc0xvZy5hdHRhY2hTY2hlbWEoU2NoZW1hKTtcbiIsIkltYWdlcyA9IG5ldyBNZXRlb3IuQ29sbGVjdGlvbiAoJ2ltYWdlcycpO1xuXG52YXIgU2NoZW1hID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gIHVybDoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogXCJVUkxcIlxuICB9LFxuICBrZXk6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6IFwiS2V5XCJcbiAgfSxcbiAgY2FwdGlvbjoge1xuICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgbGFiZWw6IFwiQ2FwdGlvblwiLFxuICAgICAgb3B0aW9uYWw6IHRydWVcbiAgfSxcbiAgY3JlYXRlZF9hdDoge1xuICAgICAgdHlwZTogTnVtYmVyLFxuICAgICAgbGFiZWw6IFwiQ3JlYXRlZCBhdFwiXG4gIH0sXG4gIGNyZWF0ZWRfYnk6IHtcbiAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgIGxhYmVsOiBcIkNyZWF0ZWQgYnlcIlxuICB9LFxuICBjcmVhdGVkX2J5X3VzZXJuYW1lOiB7XG4gICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICBsYWJlbDogXCJDcmVhdGVkIGJ5IHVzZXJuYW1lXCJcbiAgfSxcbiAgdXNlZF9ieToge1xuICAgIHR5cGU6IFN0cmluZywgLy8gZS5nLiBwYXR0ZXJuX2lkLCB1c2VyX2lkXG4gICAgbGFiZWw6IFwiVXNlZCBieVwiXG4gIH0sXG4gIHJvbGU6IHtcbiAgICB0eXBlOiBTdHJpbmcsIC8vIGUuZy4gcHJldmlldywgYXZhdGFyXG4gICAgbGFiZWw6IFwiUm9sZVwiXG4gIH0sXG4gIHdpZHRoOiB7XG4gICAgICB0eXBlOiBOdW1iZXIsXG4gICAgICBsYWJlbDogXCJXaWR0aFwiLFxuICAgICAgb3B0aW9uYWw6IHRydWVcbiAgfSxcbiAgaGVpZ2h0OiB7XG4gICAgICB0eXBlOiBOdW1iZXIsXG4gICAgICBsYWJlbDogXCJIZWlnaHRcIixcbiAgICAgIG9wdGlvbmFsOiB0cnVlXG4gIH1cbn0pO1xuXG5JbWFnZXMuYXR0YWNoU2NoZW1hKFNjaGVtYSk7XG4iLCJ2YXIgU2NoZW1hID0gbmV3IFNpbXBsZVNjaGVtYSh7XG5cdCdhdXRvX3ByZXZpZXcnOiB7XG5cdFx0J3R5cGUnOiBTdHJpbmcsXG5cdFx0J2xhYmVsJzogJ0F1dG8gcHJldmlldycsXG5cdFx0J29wdGlvbmFsJzogdHJ1ZSxcblx0fSxcblx0J2F1dG9fdHVybl9zZXF1ZW5jZSc6IHtcblx0XHQndHlwZSc6IFtTdHJpbmddLFxuXHRcdCdsYWJlbCc6ICdBdXRvIHR1cm4gc2VxdWVuY2UnLFxuXHRcdCdvcHRpb25hbCc6IHRydWUsXG5cdH0sXG5cdCdhdXRvX3R1cm5fdGhyZWFkcyc6IHtcblx0XHQndHlwZSc6IFtbTnVtYmVyXV0sXG5cdFx0J2xhYmVsJzogJ0F1dG8gdHVybiB0aHJlYWRzJyxcblx0XHQnb3B0aW9uYWwnOiB0cnVlLFxuXHR9LFxuXHQnY3JlYXRlZF9hdCc6IHtcblx0XHQndHlwZSc6IE51bWJlcixcblx0XHQnbGFiZWwnOiAnQ3JlYXRlZCBhdCcsXG5cdH0sXG5cdCdjcmVhdGVkX2J5Jzoge1xuXHRcdCd0eXBlJzogU3RyaW5nLFxuXHRcdCdsYWJlbCc6ICdDcmVhdGVkIGJ5Jyxcblx0fSxcblx0J2NyZWF0ZWRfYnlfdXNlcm5hbWUnOiB7XG5cdFx0J3R5cGUnOiBTdHJpbmcsXG5cdFx0J2xhYmVsJzogJ0NyZWF0ZWQgYnkgdXNlcm5hbWUnLFxuXHR9LFxuXHQnZGVzY3JpcHRpb24nOiB7XG5cdFx0J3R5cGUnOiBTdHJpbmcsXG5cdFx0J2xhYmVsJzogJ0Rlc2NyaXB0aW9uJyxcblx0XHQnb3B0aW9uYWwnOiB0cnVlLFxuXHR9LFxuXHQnaG9sZV9oYW5kZWRuZXNzJzoge1xuXHRcdCd0eXBlJzogU3RyaW5nLFxuXHRcdCdsYWJlbCc6ICdIb2xlIGhhbmRlZG5lc3MnLFxuXHRcdCdtYXgnOiA1MCxcblx0XHQnb3B0aW9uYWwnOiB0cnVlLFxuXHR9LFxuXHQnZWRpdF9tb2RlJzoge1xuXHRcdCd0eXBlJzogU3RyaW5nLFxuXHRcdCdsYWJlbCc6ICdFZGl0IG1vZGUnLFxuXHRcdCdtYXgnOiA1MCxcblx0XHQnb3B0aW9uYWwnOiB0cnVlLFxuXHR9LFxuXHQnbG9uZ19mbG9hdHNfY2hhcnQnOiB7XG5cdFx0J3R5cGUnOiBTdHJpbmcsXG5cdFx0J2xhYmVsJzogJ0xvbmcgZmxvYXRzIGdyaWQnLFxuXHRcdCdtYXgnOiAxMDAwMCxcblx0XHQnb3B0aW9uYWwnOiB0cnVlLFxuXHR9LFxuXHQnbmFtZSc6IHtcblx0XHQndHlwZSc6IFN0cmluZyxcblx0XHQnbGFiZWwnOiAnTmFtZScsXG5cdFx0J21heCc6IDIwMCxcblx0fSxcblx0J21hbnVhbF93ZWF2aW5nX3RocmVhZHMnOiB7XG5cdFx0J3R5cGUnOiBbW051bWJlcl1dLFxuXHRcdCdsYWJlbCc6ICdNYW51YWwgd2VhdmluZyB0dXJucycsXG5cdFx0J29wdGlvbmFsJzogdHJ1ZSxcblx0fSxcblx0J21hbnVhbF93ZWF2aW5nX3R1cm5zJzoge1xuXHRcdCd0eXBlJzogU3RyaW5nLFxuXHRcdCdsYWJlbCc6ICdNYW51YWwgd2VhdmluZyB0dXJucycsXG5cdFx0J29wdGlvbmFsJzogdHJ1ZSxcblx0fSxcblx0J25hbWVfc29ydCc6IHtcblx0XHQndHlwZSc6IFN0cmluZyxcblx0XHQnb3B0aW9uYWwnOiB0cnVlLFxuXHRcdCdhdXRvVmFsdWUnOiBmdW5jdGlvbigpIHtcblx0XHRcdHZhciBuYW1lID0gdGhpcy5maWVsZCgnbmFtZScpO1xuXG5cdFx0XHRpZiAobmFtZS5pc1NldCkge1xuXHRcdFx0XHRcdHJldHVybiBuYW1lLnZhbHVlLnRvTG93ZXJDYXNlKCk7XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdHRoaXMudW5zZXQoKTsgXG5cdFx0XHR9XG5cdFx0fVxuXHR9LFxuXHQnbnVtYmVyX29mX3Jvd3MnOiB7XG5cdFx0J3R5cGUnOiBOdW1iZXIsXG5cdFx0J2xhYmVsJzogJ051bWJlciBvZiByb3dzJyxcblx0XHQnbWF4JzogMTAwMCxcblx0XHQnb3B0aW9uYWwnOiB0cnVlLFxuXHR9LFxuXHQnbnVtYmVyX29mX3RhYmxldHMnOiB7XG5cdFx0J3R5cGUnOiBOdW1iZXIsXG5cdFx0J2xhYmVsJzogJ051bWJlciBvZiByb3dzJyxcblx0XHQnbWF4JzogMTAwMCxcblx0XHQnb3B0aW9uYWwnOiB0cnVlLFxuXHR9LFxuXHQnb3JpZW50YXRpb24nOiB7XG5cdFx0J3R5cGUnOiBTdHJpbmcsXG5cdFx0J2xhYmVsJzogJ09yaWVudGF0aW9uJyxcblx0XHQnbWF4JzogMTAwMDAsXG5cdFx0J29wdGlvbmFsJzogdHJ1ZSxcblx0fSxcblx0J3BhdHRlcm5fZWRpdGVkX2F0Jzoge1xuXHRcdCd0eXBlJzogTnVtYmVyLFxuXHRcdCdsYWJlbCc6ICdFZGl0ZWQgYXQnLFxuXHRcdCdvcHRpb25hbCc6IHRydWUsXG5cdH0sXG5cdCdwb3NpdGlvbl9vZl9BJzoge1xuXHRcdCd0eXBlJzogU3RyaW5nLFxuXHRcdCdsYWJlbCc6ICdQb3NpdGlvbiBvZiBBJyxcblx0XHQnb3B0aW9uYWwnOiB0cnVlLFxuXHR9LFxuXHQncHJldmlld19yb3RhdGlvbic6IHtcblx0XHQndHlwZSc6IFN0cmluZyxcblx0XHQnbGFiZWwnOiAnUHJldmlldyByb3RhdGlvbicsXG5cdFx0J29wdGlvbmFsJzogdHJ1ZSxcblx0fSxcblx0J3ByaXZhdGUnOiB7XG5cdFx0J3R5cGUnOiBCb29sZWFuLFxuXHRcdCdsYWJlbCc6ICdQcml2YXRlJyxcblx0XHQnb3B0aW9uYWwnOiB0cnVlLFxuXHR9LFxuXHQnc2ltdWxhdGlvbl9tb2RlJzoge1xuXHRcdCd0eXBlJzogU3RyaW5nLFxuXHRcdCdsYWJlbCc6ICdTaW11bGF0aW9uIG1vZGUnLFxuXHRcdCdvcHRpb25hbCc6IHRydWUsXG5cdH0sXG5cdCdzcGVjaWFsX3N0eWxlcyc6IHtcblx0XHQndHlwZSc6IFN0cmluZyxcblx0XHQnbGFiZWwnOiAnU3R5bGVzJyxcblx0XHQnbWF4JzogMTAwMDAsXG5cdFx0J29wdGlvbmFsJzogdHJ1ZSxcblx0fSxcblx0J3N0eWxlcyc6IHtcblx0XHQndHlwZSc6IFN0cmluZyxcblx0XHQnbGFiZWwnOiAnU3R5bGVzJyxcblx0XHQnbWF4JzogMTAwMDAsXG5cdFx0J29wdGlvbmFsJzogdHJ1ZSxcblx0fSxcblx0J3RhZ3MnOiB7XG5cdFx0J3R5cGUnOiBTdHJpbmcsXG5cdFx0J2xhYmVsJzogJ1RhZ3MnLFxuXHRcdCdtYXgnOiAxMDAwMCxcblx0XHQnb3B0aW9uYWwnOiB0cnVlLFxuXHR9LFxuXHQndGV4dF9lZGl0ZWRfYXQnOiB7XG5cdFx0J3R5cGUnOiBOdW1iZXIsXG5cdFx0J2xhYmVsJzogJ0VkaXRlZCBhdCcsXG5cdFx0J29wdGlvbmFsJzogdHJ1ZSxcblx0fSxcblx0J3RocmVhZGluZyc6IHtcblx0XHQndHlwZSc6IFN0cmluZyxcblx0XHQnbGFiZWwnOiAnVGhyZWFkaW5nJyxcblx0XHQnbWF4JzogMTAwMDAsXG5cdFx0J29wdGlvbmFsJzogdHJ1ZSxcblx0fSxcblx0J3RocmVhZGluZ19ub3Rlcyc6IHtcblx0XHQndHlwZSc6IFN0cmluZyxcblx0XHQnbGFiZWwnOiAnVGhyZWFkaW5nIG5vdGVzJyxcblx0XHQnb3B0aW9uYWwnOiB0cnVlLFxuXHR9LFxuXHQndHdpbGxfY2hhbmdlX2NoYXJ0Jzoge1xuXHRcdCd0eXBlJzogU3RyaW5nLFxuXHRcdCdsYWJlbCc6ICdUd2lsbCBkaXJlY3Rpb24gY2hhbmdlIGNoYXJ0Jyxcblx0XHQnbWF4JzogMTAwMDAsXG5cdFx0J29wdGlvbmFsJzogdHJ1ZSxcblx0fSxcblx0J3R3aWxsX2RpcmVjdGlvbic6IHtcblx0XHQndHlwZSc6IFN0cmluZyxcblx0XHQnbGFiZWwnOiAnVHdpbGwgZGlyZWN0aW9uJyxcblx0XHQnb3B0aW9uYWwnOiB0cnVlLFxuXHR9LFxuXHQndHdpbGxfcGF0dGVybl9jaGFydCc6IHtcblx0XHQndHlwZSc6IFN0cmluZyxcblx0XHQnbGFiZWwnOiAnVHdpbGwgcGF0dGVybiBjaGFydCcsXG5cdFx0J21heCc6IDEwMDAwLFxuXHRcdCdvcHRpb25hbCc6IHRydWUsXG5cdH0sXG5cdCd3ZWF2aW5nX3N0YXJ0X3Jvdyc6IHtcblx0XHQndHlwZSc6IE51bWJlcixcblx0XHQnbGFiZWwnOiAnV2VhdmluZyBzdGFydCByb3cnLFxuXHRcdCdvcHRpb25hbCc6IHRydWUsXG5cdH0sXG5cdCd3ZWF2aW5nJzoge1xuXHRcdCd0eXBlJzogU3RyaW5nLFxuXHRcdCdsYWJlbCc6ICdXZWF2aW5nJyxcblx0XHQnbWF4JzogMjAwMDAsXG5cdFx0J29wdGlvbmFsJzogdHJ1ZSxcblx0fSxcblx0J3dlYXZpbmdfbm90ZXMnOiB7XG5cdFx0J3R5cGUnOiBTdHJpbmcsXG5cdFx0J2xhYmVsJzogJ1dlYXZpbmcgbm90ZXMnLFxuXHRcdCdvcHRpb25hbCc6IHRydWUsXG5cdH0sXG5cdCd3ZWZ0X2NvbG9yJzoge1xuXHRcdCd0eXBlJzogU3RyaW5nLFxuXHRcdCdsYWJlbCc6ICdXZWZ0IGNvbG9yJyxcblx0XHQnb3B0aW9uYWwnOiB0cnVlLFxuXHR9LFxufSk7XG5cblBhdHRlcm5zID0gbmV3IE1ldGVvci5Db2xsZWN0aW9uKCdwYXR0ZXJucycpO1xuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cdC8vIGVuc3VyZSB0aGVyZSBpcyBhcmUgaW5kZXhlcyB0byBzcGVlZCB1cCBxdWVyaWVzXG5cdC8vIFBhdHRlcm5zIChwYXR0ZXJucyBieSBvd25lciwgYnkgcHJpdmF0ZSlcblx0UGF0dGVybnMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KCB7J2NyZWF0ZWRfYnknOiAxfSApO1xuXHRQYXR0ZXJucy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoIHsncHJpdmF0ZSc6IDF9ICk7XG5cblx0Ly8gTmV3IFBhdHRlcm5zIChwYXR0ZXJucyBieSBjcmVhdGlvbiBkYXRlLCBuZXdlc3QgZmlyc3QpXG5cdFBhdHRlcm5zLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCggeydjcmVhdGVkX2F0JzogLTF9ICk7XG59XG5cblBhdHRlcm5zLmF0dGFjaFNjaGVtYShTY2hlbWEpO1xuIiwiLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIFVzZXJzIGNvbGxlY3Rpb25cblxudGhpcy5Vc2VycyA9IG5ldyBNZXRlb3IuUGFnaW5hdGlvbihNZXRlb3IudXNlcnMsIHtcbiAgaXRlbVRlbXBsYXRlOiBcInVzZXJfdGh1bWJuYWlsXCIsXG4gIHRlbXBsYXRlTmFtZTogXCJ1c2Vyc1wiLFxuICBwZXJQYWdlOiAxMixcbiAgYXZhaWxhYmxlU2V0dGluZ3M6IHtcbiAgICBmaWx0ZXJzOiB0cnVlLFxuICAgIHNvcnQ6IHRydWVcbiAgfSxcbiAgYXV0aDogZnVuY3Rpb24oc2tpcCwgc3ViKXtcbiAgICB2YXIgdXNlclNldHRpbmdzID0gdGhpcy51c2VyU2V0dGluZ3Nbc3ViLl9zZXNzaW9uLmlkXSB8fCB7fTtcbiAgICB2YXIgdXNlckZpbHRlcnMgPSB1c2VyU2V0dGluZ3MuZmlsdGVycyB8fCB7fTtcblxuICAgIHZhciB1cGRhdGUgPSB7fTtcbiAgICB1cGRhdGVbXCJwcm9maWxlLnB1YmxpY19wYXR0ZXJuc19jb3VudFwiXSA9IHskZ3Q6IDB9OyAvLyB0aGlzIGNvbnN0cnVjdGlvbiBpcyByZXF1aXJlZCB0byBxdWVyeSBhIGNoaWxkIHByb3BlcnR5XG5cbiAgICBpZiAoc3ViLnVzZXJJZClcbiAgICAgIHZhciBfZmlsdGVycyA9IF8uZXh0ZW5kKFxuICAgICAgICB7ICRvcjogW3VwZGF0ZSwge19pZDogc3ViLnVzZXJJZH1dfSwgdXNlckZpbHRlcnMpOyAvLyBPbmx5IHJldHVybiB1c2VycyB3aXRoIHB1Ymxpc2hlZCBwYXR0ZXJucywgYW5kIHRoZSB1c2VyIHRoZW1zZWxmXG4gICAgZWxzZVxuICAgICAgdmFyIF9maWx0ZXJzID0gXy5leHRlbmQoXG4gICAgICAgIHsgJG9yOiBbdXBkYXRlXX0sIHVzZXJGaWx0ZXJzKTsgLy8gT25seSByZXR1cm4gdXNlcnMgd2l0aCBwdWJsaXNoZWQgcGF0dGVybnMsIGFuZCB0aGUgdXNlciB0aGVtc2VsZlxuXG4gICAgdmFyIF9vcHRpb25zID0ge1xuICAgICAgbGltaXQ6IDEyLFxuICAgICAgc2tpcDogc2tpcCxcbiAgICAgIGZpZWxkczogeyB1c2VybmFtZTogMSB9IC8vIGlmIG5vIGZpZWxkcyBhcmUgc2V0LCBBTEwgdXNlciBmaWVsZHMgYXJlIHB1Ymxpc2hlZCwgaW5jbHVkaW5nIHNlbnNpdGl2ZSBvbmVzLiBTZXR0aW5nIGV2ZW4gb25lIGZpZWxkIHNlZW1zIHRvIGVuc3VyZSBvbmx5ICdwdWJsaWMnIGZpZWxkcyBsaWtlIHByb2ZpbGUgYXJlIHB1Ymxpc2hlZC5cbiAgICB9XG4gICAgaWYgKHR5cGVvZiB1c2VyU2V0dGluZ3Muc29ydCA9PT0gXCJvYmplY3RcIikgXG4gICAgICBfb3B0aW9ucy5zb3J0ID0gdXNlclNldHRpbmdzLnNvcnQ7XG4gICAgZWxzZVxuICAgIHtcbiAgICAgIF9vcHRpb25zLnNvcnQgPSB7ICdwcm9maWxlLm5hbWVfc29ydCc6IDF9OyAvLyBsb3dlci1jYXNlIHZlcnNpb24gb2YgdXNlcm5hbWVcbiAgICB9XG4gICAgXG4gICAgcmV0dXJuIFtfZmlsdGVycywgX29wdGlvbnNdO1xuICB9XG59KTtcblxuLy8gRGVueSBhbGwgY2xpZW50LXNpZGUgdXBkYXRlcyB0byB1c2VyIGRvY3VtZW50c1xuLy8gT3RoZXJ3aXNlIHRoZSB1c2VyIGNhbiB3cml0ZSB0byB0aGVpciBwcm9maWxlIGZyb20gdGhlIGNsaWVudFxuTWV0ZW9yLnVzZXJzLmRlbnkoe1xuICB1cGRhdGUoKSB7IHJldHVybiB0cnVlOyB9XG59KTtcblxuLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIHRhZ3Mgb24gcGF0dGVybnNcblRhZ3MuVGFnc01peGluKFBhdHRlcm5zKTsgLy8gaHR0cHM6Ly9hdG1vc3BoZXJlanMuY29tL3BhdHJpY2tsZWV0L3RhZ3NcblBhdHRlcm5zLmFsbG93VGFncyhmdW5jdGlvbiAodXNlcklkKSB7IHJldHVybiB0cnVlOyB9KTtcblxuLy8gc2VhcmNoIHBhdHRlcm5zXG5wYXR0ZXJuc0luZGV4ID0gbmV3IEVhc3lTZWFyY2guSW5kZXgoe1xuICBjb2xsZWN0aW9uOiBQYXR0ZXJucyxcbiAgZmllbGRzOiBbJ25hbWVfc29ydCcsICd0YWdzJywgJ2NyZWF0ZWRfYnlfdXNlcm5hbWUnLCAnbnVtYmVyX29mX3RhYmxldHMnXSxcbiAgZGVmYXVsdFNlYXJjaE9wdGlvbnM6IHtcbiAgICBsaW1pdDogNlxuICB9LFxuICBlbmdpbmU6IG5ldyBFYXN5U2VhcmNoLk1pbmltb25nbygpIC8vIHNlYXJjaCBvbmx5IG9uIHRoZSBjbGllbnQsIHNvIG9ubHkgcHVibGlzaGVkIGRvY3VtZW50cyBhcmUgcmV0dXJuZWRcblxuICAvLyBzZXJ2ZXIgc2lkZSBzZWFyY2hlc1xuICAvKmVuZ2luZTogbmV3IEVhc3lTZWFyY2guTW9uZ29EQih7XG4gICAgc2VsZWN0b3I6IGZ1bmN0aW9uIChzZWFyY2hPYmplY3QsIG9wdGlvbnMsIGFnZ3JlZ2F0aW9uKSB7XG4gICAgICBsZXQgc2VsZWN0b3IgPSB0aGlzLmRlZmF1bHRDb25maWd1cmF0aW9uKCkuc2VsZWN0b3Ioc2VhcmNoT2JqZWN0LCBvcHRpb25zLCBhZ2dyZWdhdGlvbik7XG5cbiAgICAgIHNlbGVjdG9yLmNyZWF0ZWRCeSA9IG9wdGlvbnMudXNlcklkO1xuICAgICAgY29uc29sZS5sb2coXCJzZWFyY2hPYmplY3QgXCIgKyBPYmplY3Qua2V5cyhzZWFyY2hPYmplY3QpKTtcbiAgICAgIGNvbnNvbGUubG9nKFwiYWdncmVnYXRpb24gXCIgKyBPYmplY3Qua2V5cyhhZ2dyZWdhdGlvbikpO1xuICAgICAgY29uc29sZS5sb2coXCJpZCBcIiArIG9wdGlvbnMuc2VhcmNoLnVzZXJJZCk7XG5cbiAgICAgIHJldHVybiBzZWxlY3RvcjtcbiAgICB9XG4gIH0pKi9cbn0pO1xuXG51c2Vyc0luZGV4ID0gbmV3IEVhc3lTZWFyY2guSW5kZXgoe1xuICBjb2xsZWN0aW9uOiBNZXRlb3IudXNlcnMsXG4gIGZpZWxkczogWyd1c2VybmFtZScsICdwcm9maWxlLmRlc2NyaXB0aW9uJ10sXG4gIGRlZmF1bHRTZWFyY2hPcHRpb25zOiB7XG4gICAgbGltaXQ6IDZcbiAgfSxcbiAgZW5naW5lOiBuZXcgRWFzeVNlYXJjaC5NaW5pbW9uZ28oKSAvLyBzZWFyY2ggb25seSBvbiB0aGUgY2xpZW50LCBzbyBvbmx5IHB1Ymxpc2hlZCBkb2N1bWVudHMgYXJlIHJldHVybmVkXG59KTtcblxuLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuLy8gUGFnaW5hdGlvblxuLy8gaHR0cHM6Ly9naXRodWIuY29tL2FsZXRoZXMvbWV0ZW9yLXBhZ2VzXG4vLyBub3RlIHRoYXQgcmVxdWVzdFBhZ2UoMSkgaXMgY2FsbGVkIHdoZW4gZWFjaCB0ZW1wbGF0ZSBpcyByZW5kZXJlZFxuLy8gaHR0cHM6Ly9naXRodWIuY29tL2FsZXRoZXMvbWV0ZW9yLXBhZ2VzL2lzc3Vlcy8yMDhcblxuLy8gc2hvdyBhbGwgcGF0dGVybnMgYmVsb25naW5nIHRvIG9uZSB1c2VyXG50aGlzLlVzZXJQYXR0ZXJucyA9IG5ldyBNZXRlb3IuUGFnaW5hdGlvbihQYXR0ZXJucywge1xuICBpdGVtVGVtcGxhdGU6IFwicGF0dGVybl90aHVtYm5haWxcIixcbiAgdGVtcGxhdGVOYW1lOiBcInVzZXJcIixcbiAgcGVyUGFnZTogMTIsXG4gIGF2YWlsYWJsZVNldHRpbmdzOiB7XG4gICAgZmlsdGVyczogdHJ1ZSxcbiAgICBzb3J0OiB0cnVlXG4gIH0sXG4gIGF1dGg6IGZ1bmN0aW9uKHNraXAsIHN1Yil7XG4gICAgdmFyIHVzZXJTZXR0aW5ncyA9IHRoaXMudXNlclNldHRpbmdzW3N1Yi5fc2Vzc2lvbi5pZF0gfHwge307XG4gICAgdmFyIHVzZXJGaWx0ZXJzID0gdXNlclNldHRpbmdzLmZpbHRlcnMgfHwge307XG4gICAgXG4gICAgaWYgKHN1Yi51c2VySWQpXG4gICAgICB2YXIgX2ZpbHRlcnMgPSBfLmV4dGVuZCh7XG4gICAgICAgICRvcjogW1xuICAgICAgICAgIHsgcHJpdmF0ZTogeyRuZTogdHJ1ZX0gfSxcbiAgICAgICAgICB7IGNyZWF0ZWRfYnk6IHN1Yi51c2VySWQgfVxuICAgICAgICBdXG4gICAgICB9LCB1c2VyRmlsdGVycyk7XG4gICAgZWxzZVxuICAgICAgdmFyIF9maWx0ZXJzID0gXy5leHRlbmQoXG4gICAgICAgIHsgcHJpdmF0ZTogeyRuZTogdHJ1ZX0gfSxcbiAgICAgICAgdXNlckZpbHRlcnMpO1xuXG4gICAgdmFyIF9vcHRpb25zID0ge1xuICAgICAgbGltaXQ6IDEyLFxuICAgICAgc29ydDogeyBuYW1lX3NvcnQ6IDF9LFxuICAgICAgc2tpcDogc2tpcCxcbiAgICAgIGZpZWxkczoge1xuICAgICAgICBfaWQ6IDEsXG4gICAgICAgIGF1dG9fcHJldmlldzogMSxcbiAgICAgICAgY3JlYXRlZF9hdDogMSxcbiAgICAgICAgY3JlYXRlZF9ieTogMSxcbiAgICAgICAgY3JlYXRlZF9ieV91c2VybmFtZTogMSxcbiAgICAgICAgZGVzY3JpcHRpb246IDEsXG4gICAgICAgIG5hbWU6IDEsXG4gICAgICAgIG5hbWVfc29ydDogMSxcbiAgICAgICAgbnVtYmVyX29mX3RhYmxldHM6IDEsXG4gICAgICAgIHByaXZhdGU6IDEsXG4gICAgICB9XG4gICAgfVxuICAgIFxuICAgIHJldHVybiBbX2ZpbHRlcnMsIF9vcHRpb25zXTtcbiAgfVxufSk7XG5cbnRoaXMuTXlQYXR0ZXJucyA9IG5ldyBNZXRlb3IuUGFnaW5hdGlvbihQYXR0ZXJucywge1xuICBpdGVtVGVtcGxhdGU6IFwicGF0dGVybl90aHVtYm5haWxcIixcbiAgdGVtcGxhdGVOYW1lOiBcIm15X3BhdHRlcm5zXCIsXG4gIHBlclBhZ2U6IDEyLFxuICBhdmFpbGFibGVTZXR0aW5nczoge1xuICAgIGZpbHRlcnM6IHRydWUsXG4gICAgc29ydDogdHJ1ZVxuICB9LFxuICBhdXRoOiBmdW5jdGlvbihza2lwLCBzdWIpe1xuICAgIHZhciB1c2VyU2V0dGluZ3MgPSB0aGlzLnVzZXJTZXR0aW5nc1tzdWIuX3Nlc3Npb24uaWRdIHx8IHt9O1xuICAgIHZhciB1c2VyRmlsdGVycyA9IHVzZXJTZXR0aW5ncy5maWx0ZXJzIHx8IHt9O1xuICAgIHZhciBfZmlsdGVycyA9IF8uZXh0ZW5kKHtjcmVhdGVkX2J5OiBzdWIudXNlcklkfSwgdXNlckZpbHRlcnMpO1xuXG4gICAgdmFyIF9vcHRpb25zID0ge1xuICAgICAgbGltaXQ6IDEyLFxuICAgICAgc29ydDogeyBuYW1lX3NvcnQ6IDF9LFxuICAgICAgc2tpcDogc2tpcCxcbiAgICAgIGZpZWxkczoge1xuICAgICAgICBfaWQ6IDEsXG4gICAgICAgIGF1dG9fcHJldmlldzogMSxcbiAgICAgICAgY3JlYXRlZF9hdDogMSxcbiAgICAgICAgY3JlYXRlZF9ieTogMSxcbiAgICAgICAgY3JlYXRlZF9ieV91c2VybmFtZTogMSxcbiAgICAgICAgZGVzY3JpcHRpb246IDEsXG4gICAgICAgIG5hbWU6IDEsXG4gICAgICAgIG5hbWVfc29ydDogMSxcbiAgICAgICAgbnVtYmVyX29mX3RhYmxldHM6IDEsXG4gICAgICAgIHByaXZhdGU6IDEsXG4gICAgICB9XG4gICAgfVxuICAgIFxuICAgIHJldHVybiBbX2ZpbHRlcnMsIF9vcHRpb25zXTtcbiAgfSxcbiAgZmlsdGVyczoge31cbn0pO1xuXG50aGlzLkFsbFBhdHRlcm5zID0gbmV3IE1ldGVvci5QYWdpbmF0aW9uKFBhdHRlcm5zLCB7XG4gIGl0ZW1UZW1wbGF0ZTogXCJwYXR0ZXJuX3RodW1ibmFpbFwiLFxuICB0ZW1wbGF0ZU5hbWU6IFwiYWxsX3BhdHRlcm5zXCIsXG4gIHBlclBhZ2U6IDEyLCAvKiByZXF1aXJlZCwgb3RoZXJ3aXNlIHBhZ2VzIGRvIG5vdCBzaG93IGNvbnNpc3RlbnQgbnVtYmVyIG9mIGRvY3VtZW50cyAqL1xuICBhdmFpbGFibGVTZXR0aW5nczoge1xuICAgIGZpbHRlcnM6IHRydWUsXG4gICAgc29ydDogdHJ1ZVxuICB9LFxuICBhdXRoOiBmdW5jdGlvbihza2lwLCBzdWIpe1xuICAgIHZhciB1c2VyU2V0dGluZ3MgPSB0aGlzLnVzZXJTZXR0aW5nc1tzdWIuX3Nlc3Npb24uaWRdIHx8IHt9O1xuICAgIHZhciB1c2VyRmlsdGVycyA9IHVzZXJTZXR0aW5ncy5maWx0ZXJzIHx8IHt9OyAvKiBhcHBseSBjbGllbnQtc2lkZSBmaWx0ZXJzIGlmIHNldCAqL1xuXG4gICAgaWYgKHN1Yi51c2VySWQpXG4gICAgICB2YXIgX2ZpbHRlcnMgPSBfLmV4dGVuZCh7IC8qIHdoYXRldmVyIHlvdSBhbGxvdyBoZXJlIGlzIGFsbG93ZWQgZXZlcnl3aGVyZSAtIGluY2x1ZGluZyBieSB5b3VyIG93biBwdWJsaXNoIGZ1bmN0aW9ucyAqL1xuICAgICAgICAkb3I6IFtcbiAgICAgICAgICB7IHByaXZhdGU6IHskbmU6IHRydWV9IH0sXG4gICAgICAgICAgeyBjcmVhdGVkX2J5OiBzdWIudXNlcklkIH1cbiAgICAgICAgXVxuICAgICAgfSwgdXNlckZpbHRlcnMpO1xuICAgIGVsc2VcbiAgICAgIHZhciBfZmlsdGVycyA9IF8uZXh0ZW5kKCAvKiB3aGF0ZXZlciB5b3UgYWxsb3cgaGVyZSBpcyBhbGxvd2VkIGV2ZXJ5d2hlcmUgLSBpbmNsdWRpbmcgYnkgeW91ciBvd24gcHVibGlzaCBmdW5jdGlvbnMgKi9cbiAgICAgICAgeyBwcml2YXRlOiB7JG5lOiB0cnVlfSB9LFxuICAgICAgICB1c2VyRmlsdGVycyk7XG5cbiAgICB2YXIgX29wdGlvbnMgPSB7XG4gICAgICBsaW1pdDogMTIsIC8qIHJlcGxhY2VzIHBlclBhZ2UgKi9cbiAgICAgIHNraXA6IHNraXAsIC8qIHNraXAgaXMgcmVxdWlyZWQsIG90aGVyd2lzZSBwYWdlcyA+IDEgc2hvdyBub3RoaW5nICovXG4gICAgICBmaWVsZHM6IHtcbiAgICAgICAgX2lkOiAxLFxuICAgICAgICBhdXRvX3ByZXZpZXc6IDEsXG4gICAgICAgIGNyZWF0ZWRfYXQ6IDEsXG4gICAgICAgIGNyZWF0ZWRfYnk6IDEsXG4gICAgICAgIGNyZWF0ZWRfYnlfdXNlcm5hbWU6IDEsXG4gICAgICAgIGRlc2NyaXB0aW9uOiAxLFxuICAgICAgICBuYW1lOiAxLFxuICAgICAgICBuYW1lX3NvcnQ6IDEsXG4gICAgICAgIG51bWJlcl9vZl90YWJsZXRzOiAxLFxuICAgICAgICBwcml2YXRlOiAxLFxuICAgICAgfVxuICAgIH1cbiAgICBpZiAodHlwZW9mIHVzZXJTZXR0aW5ncy5zb3J0ID09PSBcIm9iamVjdFwiKSAvKiBpZiBjbGllbnQtc2lkZSBzb3J0ICovXG4gICAgICBfb3B0aW9ucy5zb3J0ID0gdXNlclNldHRpbmdzLnNvcnQ7XG4gICAgZWxzZVxuICAgICAgX29wdGlvbnMuc29ydCA9IHsgbmFtZV9zb3J0OiAxfTtcbiAgICBcbiAgICByZXR1cm4gW19maWx0ZXJzLCBfb3B0aW9uc107XG4gIH0sXG4gIGZpbHRlcnM6IHt9XG59KTtcblxudGhpcy5OZXdQYXR0ZXJucyA9IG5ldyBNZXRlb3IuUGFnaW5hdGlvbihQYXR0ZXJucywge1xuICBpdGVtVGVtcGxhdGU6IFwicGF0dGVybl90aHVtYm5haWxcIixcbiAgdGVtcGxhdGVOYW1lOiBcIm5ld19wYXR0ZXJuc1wiLFxuICBwZXJQYWdlOiAxMixcbiAgYXZhaWxhYmxlU2V0dGluZ3M6IHtcbiAgICBmaWx0ZXJzOiB0cnVlLFxuICAgIHNvcnQ6IHRydWVcbiAgfSxcbiAgYXV0aDogZnVuY3Rpb24oc2tpcCwgc3ViKXtcbiAgICB2YXIgdXNlclNldHRpbmdzID0gdGhpcy51c2VyU2V0dGluZ3Nbc3ViLl9zZXNzaW9uLmlkXSB8fCB7fTtcbiAgICB2YXIgdXNlckZpbHRlcnMgPSB1c2VyU2V0dGluZ3MuZmlsdGVycyB8fCB7fTtcblxuICAgIGlmIChzdWIudXNlcklkKVxuICAgICAgdmFyIF9maWx0ZXJzID0gXy5leHRlbmQoe1xuICAgICAgICAkb3I6IFtcbiAgICAgICAgICB7IHByaXZhdGU6IHskbmU6IHRydWV9IH0sXG4gICAgICAgICAgeyBjcmVhdGVkX2J5OiBzdWIudXNlcklkIH1cbiAgICAgICAgXVxuICAgICAgfSwgdXNlckZpbHRlcnMpO1xuICAgIGVsc2VcbiAgICAgIHZhciBfZmlsdGVycyA9IF8uZXh0ZW5kKFxuICAgICAgeyBwcml2YXRlOiB7JG5lOiB0cnVlfSB9LFxuICAgICAgdXNlckZpbHRlcnMpO1xuXG4gICAgdmFyIF9vcHRpb25zID0ge1xuICAgICAgbGltaXQ6IDEyLFxuICAgICAgc29ydDogeyBjcmVhdGVkX2F0OiAtMX0sXG4gICAgICBza2lwOiBza2lwLFxuICAgICAgZmllbGRzOiB7XG4gICAgICAgIF9pZDogMSxcbiAgICAgICAgYXV0b19wcmV2aWV3OiAxLFxuICAgICAgICBjcmVhdGVkX2F0OiAxLFxuICAgICAgICBjcmVhdGVkX2J5OiAxLFxuICAgICAgICBjcmVhdGVkX2J5X3VzZXJuYW1lOiAxLFxuICAgICAgICBkZXNjcmlwdGlvbjogMSxcbiAgICAgICAgbmFtZTogMSxcbiAgICAgICAgbmFtZV9zb3J0OiAxLFxuICAgICAgICBudW1iZXJfb2ZfdGFibGV0czogMSxcbiAgICAgICAgcHJpdmF0ZTogMSxcbiAgICAgIH1cbiAgICB9XG4gICAgXG4gICAgcmV0dXJuIFtfZmlsdGVycywgX29wdGlvbnNdO1xuICB9LFxuICBmaWx0ZXJzOiB7fVxufSk7XG4iLCIvLyB1c2VkIGJ5IG5ld19wYXR0ZXJuX2Zyb21fanNvblxuZGVmYXVsdF9wYXR0ZXJuX2RhdGEgPSB7XG4gIFwidmVyc2lvblwiOiBcIjIuMDJcIixcbiAgXCJuYW1lXCI6IFwiTmV3IHBhdHRlcm5cIixcbiAgXCJkZXNjcmlwdGlvblwiOiBcIkEgcGF0dGVybiB3b3ZlbiBieSBmb3J3YXJkIGFuZCBiYWNrd2FyZCB0dXJuaW5nIG9mIHRoZSB0YWJsZXRzLlwiLFxuICBcIndlYXZpbmdfbm90ZXNcIjogXCJcIixcbiAgXCJ0aHJlYWRpbmdfbm90ZXNcIjogXCJcIixcbiAgXCJ0YWdzXCI6IFtdLFxuICAgIFwic3R5bGVzXCI6IFtcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjY2MwMDAwXCIsXG4gICAgICBcImxpbmVfY29sb3JcIjogXCIjZmZmZmZmXCIsXG4gICAgICBcIndhcnBcIjogXCJub25lXCIsXG4gICAgICBcInN0eWxlXCI6IDFcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNmZmQ5NjZcIixcbiAgICAgIFwibGluZV9jb2xvclwiOiBcIiNmZmZmZmZcIixcbiAgICAgIFwid2FycFwiOiBcIm5vbmVcIixcbiAgICAgIFwic3R5bGVcIjogMlxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI2ZmZmZmZlwiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiI2NjMDAwMFwiLFxuICAgICAgXCJ3YXJwXCI6IFwiZm9yd2FyZFwiLFxuICAgICAgXCJzdHlsZVwiOiAzXG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjZmZmZmZmXCIsXG4gICAgICBcImxpbmVfY29sb3JcIjogXCIjY2MwMDAwXCIsXG4gICAgICBcIndhcnBcIjogXCJiYWNrd2FyZFwiLFxuICAgICAgXCJzdHlsZVwiOiA0XG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjZmZmZmZmXCIsXG4gICAgICBcImxpbmVfY29sb3JcIjogXCIjZmZkOTY2XCIsXG4gICAgICBcIndhcnBcIjogXCJmb3J3YXJkXCIsXG4gICAgICBcInN0eWxlXCI6IDVcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNmZmZmZmZcIixcbiAgICAgIFwibGluZV9jb2xvclwiOiBcIiNmZmQ5NjZcIixcbiAgICAgIFwid2FycFwiOiBcImJhY2t3YXJkXCIsXG4gICAgICBcInN0eWxlXCI6IDZcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNmZmZmZmZcIixcbiAgICAgIFwibGluZV9jb2xvclwiOiBcIiMxYzQ1ODdcIixcbiAgICAgIFwid2FycFwiOiBcImZvcndhcmRcIixcbiAgICAgIFwic3R5bGVcIjogN1xuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI2ZmZmZmZlwiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiIzFjNDU4N1wiLFxuICAgICAgXCJ3YXJwXCI6IFwiYmFja3dhcmRcIixcbiAgICAgIFwic3R5bGVcIjogOFxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiIzFjNDU4N1wiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiI2ZmZmZmZlwiLFxuICAgICAgXCJ3YXJwXCI6IFwibm9uZVwiLFxuICAgICAgXCJzdHlsZVwiOiA5XG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjNmFhODRmXCIsXG4gICAgICBcImxpbmVfY29sb3JcIjogXCIjZmZmZmZmXCIsXG4gICAgICBcIndhcnBcIjogXCJub25lXCIsXG4gICAgICBcInN0eWxlXCI6IDEwXG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjYmJiYmJiXCIsXG4gICAgICBcImxpbmVfY29sb3JcIjogXCIjY2MwMDAwXCIsXG4gICAgICBcIndhcnBcIjogXCJiYWNrd2FyZFwiLFxuICAgICAgXCJzdHlsZVwiOiAxMVxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI2JiYmJiYlwiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiI2NjMDAwMFwiLFxuICAgICAgXCJ3YXJwXCI6IFwiZm9yd2FyZFwiLFxuICAgICAgXCJzdHlsZVwiOiAxMlxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI0JCQkJCQlwiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiI2ZmZDk2NlwiLFxuICAgICAgXCJ3YXJwXCI6IFwiYmFja3dhcmRcIixcbiAgICAgIFwic3R5bGVcIjogMTNcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNCQkJCQkJcIixcbiAgICAgIFwibGluZV9jb2xvclwiOiBcIiNmZmQ5NjZcIixcbiAgICAgIFwid2FycFwiOiBcImZvcndhcmRcIixcbiAgICAgIFwic3R5bGVcIjogMTRcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNCQkJCQkJcIixcbiAgICAgIFwibGluZV9jb2xvclwiOiBcIiMxYzQ1ODdcIixcbiAgICAgIFwid2FycFwiOiBcImJhY2t3YXJkXCIsXG4gICAgICBcInN0eWxlXCI6IDE1XG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjQkJCQkJCXCIsXG4gICAgICBcImxpbmVfY29sb3JcIjogXCIjMWM0NTg3XCIsXG4gICAgICBcIndhcnBcIjogXCJmb3J3YXJkXCIsXG4gICAgICBcInN0eWxlXCI6IDE2XG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjZmZmZmZmXCIsXG4gICAgICBcImxpbmVfY29sb3JcIjogXCIjNmFhODRmXCIsXG4gICAgICBcIndhcnBcIjogXCJmb3J3YXJkXCIsXG4gICAgICBcInN0eWxlXCI6IDE3XG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjZmZmZmZmXCIsXG4gICAgICBcImxpbmVfY29sb3JcIjogXCIjNmFhODRmXCIsXG4gICAgICBcIndhcnBcIjogXCJiYWNrd2FyZFwiLFxuICAgICAgXCJzdHlsZVwiOiAxOFxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI2ZmZmZmZlwiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiIzc4M2YwNFwiLFxuICAgICAgXCJ3YXJwXCI6IFwiZm9yd2FyZFwiLFxuICAgICAgXCJzdHlsZVwiOiAxOSxcbiAgICAgIFwic3BlY2lhbFwiOiBmYWxzZVxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI2ZmZmZmZlwiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiIzc4M2YwNFwiLFxuICAgICAgXCJ3YXJwXCI6IFwiYmFja3dhcmRcIixcbiAgICAgIFwic3R5bGVcIjogMjAsXG4gICAgICBcInNwZWNpYWxcIjogZmFsc2VcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNmZmZmZmZcIixcbiAgICAgIFwibGluZV9jb2xvclwiOiBcIiNmZmZmZmZcIixcbiAgICAgIFwid2FycFwiOiBcImZvcndhcmRcIixcbiAgICAgIFwic3R5bGVcIjogMjEsXG4gICAgICBcInNwZWNpYWxcIjogZmFsc2VcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNmZmZmZmZcIixcbiAgICAgIFwibGluZV9jb2xvclwiOiBcIiNmZmZmZmZcIixcbiAgICAgIFwid2FycFwiOiBcImJhY2t3YXJkXCIsXG4gICAgICBcInN0eWxlXCI6IDIyLFxuICAgICAgXCJzcGVjaWFsXCI6IGZhbHNlXG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjZmZmZmZmXCIsXG4gICAgICBcImxpbmVfY29sb3JcIjogXCIjMWM0NTg3XCIsXG4gICAgICBcIndhcnBcIjogXCJmb3J3YXJkX2VtcHR5XCIsXG4gICAgICBcInN0eWxlXCI6IDIzXG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjZmZmZmZmXCIsXG4gICAgICBcImxpbmVfY29sb3JcIjogXCIjMWM0NTg3XCIsXG4gICAgICBcIndhcnBcIjogXCJiYWNrd2FyZF9lbXB0eVwiLFxuICAgICAgXCJzdHlsZVwiOiAyNFxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI0JCQkJCQlwiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiIzZhYTg0ZlwiLFxuICAgICAgXCJ3YXJwXCI6IFwiYmFja3dhcmRcIixcbiAgICAgIFwic3R5bGVcIjogMjVcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNCQkJCQkJcIixcbiAgICAgIFwibGluZV9jb2xvclwiOiBcIiM2YWE4NGZcIixcbiAgICAgIFwid2FycFwiOiBcImZvcndhcmRcIixcbiAgICAgIFwic3R5bGVcIjogMjZcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNCQkJCQkJcIixcbiAgICAgIFwibGluZV9jb2xvclwiOiBcIiM3ODNmMDRcIixcbiAgICAgIFwid2FycFwiOiBcImJhY2t3YXJkXCIsXG4gICAgICBcInN0eWxlXCI6IDI3XG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjQkJCQkJCXCIsXG4gICAgICBcImxpbmVfY29sb3JcIjogXCIjNzgzZjA0XCIsXG4gICAgICBcIndhcnBcIjogXCJmb3J3YXJkXCIsXG4gICAgICBcInN0eWxlXCI6IDI4XG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjQkJCQkJCXCIsXG4gICAgICBcImxpbmVfY29sb3JcIjogXCIjZmZmZmZmXCIsXG4gICAgICBcIndhcnBcIjogXCJiYWNrd2FyZFwiLFxuICAgICAgXCJzdHlsZVwiOiAyOVxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI0JCQkJCQlwiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiI2ZmZmZmZlwiLFxuICAgICAgXCJ3YXJwXCI6IFwiZm9yd2FyZFwiLFxuICAgICAgXCJzdHlsZVwiOiAzMFxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI0JCQkJCQlwiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiIzFjNDU4N1wiLFxuICAgICAgXCJ3YXJwXCI6IFwiYmFja3dhcmRfZW1wdHlcIixcbiAgICAgIFwic3R5bGVcIjogMzFcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNCQkJCQkJcIixcbiAgICAgIFwibGluZV9jb2xvclwiOiBcIiMxYzQ1ODdcIixcbiAgICAgIFwid2FycFwiOiBcImZvcndhcmRfZW1wdHlcIixcbiAgICAgIFwic3R5bGVcIjogMzJcbiAgICB9XG4gIF0sXG4gIFwic3BlY2lhbF9zdHlsZXNcIjogW1xuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNGRkZGRkZcIixcbiAgICAgIFwibmFtZVwiOiBcImZvcndhcmRfMlwiLFxuICAgICAgXCJ3YXJwXCI6IFwiZm9yd2FyZFwiLFxuICAgICAgXCJpbWFnZVwiOiBcIi9pbWFnZXMvc3BlY2lhbF9mb3J3YXJkXzIuc3ZnXCIsXG4gICAgICBcInN0eWxlXCI6IFwiUzFcIlxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI0ZGRkZGRlwiLFxuICAgICAgXCJuYW1lXCI6IFwiYmFja3dhcmRfMlwiLFxuICAgICAgXCJ3YXJwXCI6IFwiYmFja3dhcmRcIixcbiAgICAgIFwiaW1hZ2VcIjogXCIvaW1hZ2VzL3NwZWNpYWxfYmFja3dhcmRfMi5zdmdcIixcbiAgICAgIFwic3R5bGVcIjogXCJTMlwiXG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjRkZGRkZGXCIsXG4gICAgICBcIm5hbWVcIjogXCJmb3J3YXJkXzNcIixcbiAgICAgIFwid2FycFwiOiBcImZvcndhcmRcIixcbiAgICAgIFwiaW1hZ2VcIjogXCIvaW1hZ2VzL3NwZWNpYWxfZm9yd2FyZF8zLnN2Z1wiLFxuICAgICAgXCJzdHlsZVwiOiBcIlMzXCJcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNGRkZGRkZcIixcbiAgICAgIFwibmFtZVwiOiBcImJhY2t3YXJkXzNcIixcbiAgICAgIFwid2FycFwiOiBcImJhY2t3YXJkXCIsXG4gICAgICBcImltYWdlXCI6IFwiL2ltYWdlcy9zcGVjaWFsX2JhY2t3YXJkXzMuc3ZnXCIsXG4gICAgICBcInN0eWxlXCI6IFwiUzRcIlxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI0ZGRkZGRlwiLFxuICAgICAgXCJuYW1lXCI6IFwiZm9yd2FyZF80XCIsXG4gICAgICBcIndhcnBcIjogXCJmb3J3YXJkXCIsXG4gICAgICBcImltYWdlXCI6IFwiL2ltYWdlcy9zcGVjaWFsX2ZvcndhcmRfNC5zdmdcIixcbiAgICAgIFwic3R5bGVcIjogXCJTNVwiXG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjRkZGRkZGXCIsXG4gICAgICBcIm5hbWVcIjogXCJiYWNrd2FyZF80XCIsXG4gICAgICBcIndhcnBcIjogXCJiYWNrd2FyZFwiLFxuICAgICAgXCJpbWFnZVwiOiBcIi9pbWFnZXMvc3BlY2lhbF9iYWNrd2FyZF80LnN2Z1wiLFxuICAgICAgXCJzdHlsZVwiOiBcIlM2XCJcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNGRkZGRkZcIixcbiAgICAgIFwiaW1hZ2VcIjogXCIvaW1hZ2VzL3NwZWNpYWxfZW1wdHkuc3ZnXCIsXG4gICAgICBcInN0eWxlXCI6IFwiUzdcIlxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI0ZGRkZGRlwiLFxuICAgICAgXCJpbWFnZVwiOiBcIlwiLFxuICAgICAgXCJzdHlsZVwiOiBcIlM4XCJcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNCQkJCQkJcIixcbiAgICAgIFwibmFtZVwiOiBcImJhY2t3YXJkXzJfZ3JheVwiLFxuICAgICAgXCJ3YXJwXCI6IFwiYmFja3dhcmRcIixcbiAgICAgIFwiaW1hZ2VcIjogXCIvaW1hZ2VzL3NwZWNpYWxfYmFja3dhcmRfMi5zdmdcIixcbiAgICAgIFwic3R5bGVcIjogXCJTOVwiXG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjQkJCQkJCXCIsXG4gICAgICBcIm5hbWVcIjogXCJmb3J3YXJkXzJfZ3JheVwiLFxuICAgICAgXCJ3YXJwXCI6IFwiZm9yd2FyZFwiLFxuICAgICAgXCJpbWFnZVwiOiBcIi9pbWFnZXMvc3BlY2lhbF9mb3J3YXJkXzIuc3ZnXCIsXG4gICAgICBcInN0eWxlXCI6IFwiUzEwXCJcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNCQkJCQkJcIixcbiAgICAgIFwibmFtZVwiOiBcImJhY2t3YXJkXzNfZ3JheVwiLFxuICAgICAgXCJ3YXJwXCI6IFwiYmFja3dhcmRcIixcbiAgICAgIFwiaW1hZ2VcIjogXCIvaW1hZ2VzL3NwZWNpYWxfYmFja3dhcmRfMy5zdmdcIixcbiAgICAgIFwic3R5bGVcIjogXCJTMTFcIlxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI0JCQkJCQlwiLFxuICAgICAgXCJuYW1lXCI6IFwiZm9yd2FyZF8zX2dyYXlcIixcbiAgICAgIFwid2FycFwiOiBcImZvcndhcmRcIixcbiAgICAgIFwiaW1hZ2VcIjogXCIvaW1hZ2VzL3NwZWNpYWxfZm9yd2FyZF8zLnN2Z1wiLFxuICAgICAgXCJzdHlsZVwiOiBcIlMxMlwiXG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjQkJCQkJCXCIsXG4gICAgICBcIm5hbWVcIjogXCJiYWNrd2FyZF80X2dyYXlcIixcbiAgICAgIFwid2FycFwiOiBcImJhY2t3YXJkXCIsXG4gICAgICBcImltYWdlXCI6IFwiL2ltYWdlcy9zcGVjaWFsX2JhY2t3YXJkXzQuc3ZnXCIsXG4gICAgICBcInN0eWxlXCI6IFwiUzEzXCJcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNCQkJCQkJcIixcbiAgICAgIFwibmFtZVwiOiBcImZvcndhcmRfNF9ncmF5XCIsXG4gICAgICBcIndhcnBcIjogXCJmb3J3YXJkXCIsXG4gICAgICBcImltYWdlXCI6IFwiL2ltYWdlcy9zcGVjaWFsX2ZvcndhcmRfNC5zdmdcIixcbiAgICAgIFwic3R5bGVcIjogXCJTMTRcIlxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI0ZGRkZGRlwiLFxuICAgICAgXCJuYW1lXCI6IFwiaWRsZVwiLFxuICAgICAgXCJpbWFnZVwiOiBcIi9pbWFnZXMvc3BlY2lhbF9pZGxlLnN2Z1wiLFxuICAgICAgXCJzdHlsZVwiOiBcIlMxNVwiXG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjRkZGRkZGXCIsXG4gICAgICBcImltYWdlXCI6IFwiXCIsXG4gICAgICBcInN0eWxlXCI6IFwiUzE2XCJcbiAgICB9XG4gIF0sXG4gIFwic2ltdWxhdGlvbl9zdHlsZXNcIjogW1xuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNjYzAwMDBcIixcbiAgICAgIFwibGluZV9jb2xvclwiOiBcIiNmZmZmZmZcIixcbiAgICAgIFwid2FycFwiOiBcIm5vbmVcIixcbiAgICAgIFwic3R5bGVcIjogMVxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI2ZmZDk2NlwiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiI2ZmZmZmZlwiLFxuICAgICAgXCJ3YXJwXCI6IFwibm9uZVwiLFxuICAgICAgXCJzdHlsZVwiOiAyXG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjMWM0NTg3XCIsXG4gICAgICBcImxpbmVfY29sb3JcIjogXCIjZmZmZmZmXCIsXG4gICAgICBcIndhcnBcIjogXCJub25lXCIsXG4gICAgICBcInN0eWxlXCI6IDNcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiM2YWE4NGZcIixcbiAgICAgIFwibGluZV9jb2xvclwiOiBcIiNmZmZmZmZcIixcbiAgICAgIFwid2FycFwiOiBcIm5vbmVcIixcbiAgICAgIFwic3R5bGVcIjogNFxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiIzY3NGVhN1wiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiI2ZmZmZmZlwiLFxuICAgICAgXCJ3YXJwXCI6IFwibm9uZVwiLFxuICAgICAgXCJzdHlsZVwiOiA1LFxuICAgICAgXCJzcGVjaWFsXCI6IGZhbHNlXG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjNzgzZjA0XCIsXG4gICAgICBcImxpbmVfY29sb3JcIjogXCIjZmZmZmZmXCIsXG4gICAgICBcIndhcnBcIjogXCJub25lXCIsXG4gICAgICBcInN0eWxlXCI6IDYsXG4gICAgICBcInNwZWNpYWxcIjogZmFsc2VcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNmZmZmZmZcIixcbiAgICAgIFwibGluZV9jb2xvclwiOiBcIiNmZmZmZmZcIixcbiAgICAgIFwid2FycFwiOiBcIm5vbmVcIixcbiAgICAgIFwic3R5bGVcIjogN1xuICAgIH0sXG4gICAgICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNmZmZmZmZcIixcbiAgICAgIFwibGluZV9jb2xvclwiOiBcIiNjYzAwMDBcIixcbiAgICAgIFwid2FycFwiOiBcImZvcndhcmRcIixcbiAgICAgIFwic3R5bGVcIjogOFxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI2ZmZmZmZlwiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiI2NjMDAwMFwiLFxuICAgICAgXCJ3YXJwXCI6IFwiYmFja3dhcmRcIixcbiAgICAgIFwic3R5bGVcIjogOVxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI2JiYmJiYlwiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiI2NjMDAwMFwiLFxuICAgICAgXCJ3YXJwXCI6IFwiZm9yd2FyZFwiLFxuICAgICAgXCJzdHlsZVwiOiAxMCxcbiAgICAgIFwic3BlY2lhbFwiOiBmYWxzZVxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI2JiYmJiYlwiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiI2NjMDAwMFwiLFxuICAgICAgXCJ3YXJwXCI6IFwiYmFja3dhcmRcIixcbiAgICAgIFwic3R5bGVcIjogMTEsXG4gICAgICBcInNwZWNpYWxcIjogZmFsc2VcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNmZmZmZmZcIixcbiAgICAgIFwibGluZV9jb2xvclwiOiBcIiNmZmQ5NjZcIixcbiAgICAgIFwid2FycFwiOiBcImZvcndhcmRcIixcbiAgICAgIFwic3R5bGVcIjogMTIsXG4gICAgICBcInNwZWNpYWxcIjogZmFsc2VcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNmZmZmZmZcIixcbiAgICAgIFwibGluZV9jb2xvclwiOiBcIiNmZmQ5NjZcIixcbiAgICAgIFwid2FycFwiOiBcImJhY2t3YXJkXCIsXG4gICAgICBcInN0eWxlXCI6IDE0LFxuICAgICAgXCJzcGVjaWFsXCI6IGZhbHNlXG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjYmJiYmJiXCIsXG4gICAgICBcImxpbmVfY29sb3JcIjogXCIjZmZkOTY2XCIsXG4gICAgICBcIndhcnBcIjogXCJmb3J3YXJkXCIsXG4gICAgICBcInN0eWxlXCI6IDE0XG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjYmJiYmJiXCIsXG4gICAgICBcImxpbmVfY29sb3JcIjogXCIjZmZkOTY2XCIsXG4gICAgICBcIndhcnBcIjogXCJiYWNrd2FyZFwiLFxuICAgICAgXCJzdHlsZVwiOiAxNVxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI2ZmZmZmZlwiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiIzFjNDU4N1wiLFxuICAgICAgXCJ3YXJwXCI6IFwiZm9yd2FyZFwiLFxuICAgICAgXCJzdHlsZVwiOiAxNlxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI2ZmZmZmZlwiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiIzFjNDU4N1wiLFxuICAgICAgXCJ3YXJwXCI6IFwiYmFja3dhcmRcIixcbiAgICAgIFwic3R5bGVcIjogMTdcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNiYmJiYmJcIixcbiAgICAgIFwibGluZV9jb2xvclwiOiBcIiMxYzQ1ODdcIixcbiAgICAgIFwid2FycFwiOiBcImZvcndhcmRcIixcbiAgICAgIFwic3R5bGVcIjogMThcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNiYmJiYmJcIixcbiAgICAgIFwibGluZV9jb2xvclwiOiBcIiMxYzQ1ODdcIixcbiAgICAgIFwid2FycFwiOiBcImJhY2t3YXJkXCIsXG4gICAgICBcInN0eWxlXCI6IDE5XG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjZmZmZmZmXCIsXG4gICAgICBcImxpbmVfY29sb3JcIjogXCIjNmFhODRmXCIsXG4gICAgICBcIndhcnBcIjogXCJmb3J3YXJkXCIsXG4gICAgICBcInN0eWxlXCI6IDIwXG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjZmZmZmZmXCIsXG4gICAgICBcImxpbmVfY29sb3JcIjogXCIjNmFhODRmXCIsXG4gICAgICBcIndhcnBcIjogXCJiYWNrd2FyZFwiLFxuICAgICAgXCJzdHlsZVwiOiAyMVxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI2JiYmJiYlwiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiIzZhYTg0ZlwiLFxuICAgICAgXCJ3YXJwXCI6IFwiZm9yd2FyZFwiLFxuICAgICAgXCJzdHlsZVwiOiAyMlxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI2JiYmJiYlwiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiIzZhYTg0ZlwiLFxuICAgICAgXCJ3YXJwXCI6IFwiYmFja3dhcmRcIixcbiAgICAgIFwic3R5bGVcIjogMjNcbiAgICB9LFxuXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI2ZmZmZmZlwiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiIzY3NGVhN1wiLFxuICAgICAgXCJ3YXJwXCI6IFwiZm9yd2FyZFwiLFxuICAgICAgXCJzdHlsZVwiOiAyNFxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI2ZmZmZmZlwiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiIzY3NGVhN1wiLFxuICAgICAgXCJ3YXJwXCI6IFwiYmFja3dhcmRcIixcbiAgICAgIFwic3R5bGVcIjogMjVcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNiYmJiYmJcIixcbiAgICAgIFwibGluZV9jb2xvclwiOiBcIiM2NzRlYTdcIixcbiAgICAgIFwid2FycFwiOiBcImZvcndhcmRcIixcbiAgICAgIFwic3R5bGVcIjogMjZcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNiYmJiYmJcIixcbiAgICAgIFwibGluZV9jb2xvclwiOiBcIiM2NzRlYTdcIixcbiAgICAgIFwid2FycFwiOiBcImJhY2t3YXJkXCIsXG4gICAgICBcInN0eWxlXCI6IDI3XG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjZmZmZmZmXCIsXG4gICAgICBcImxpbmVfY29sb3JcIjogXCIjNzgzZjA0XCIsXG4gICAgICBcIndhcnBcIjogXCJmb3J3YXJkXCIsXG4gICAgICBcInN0eWxlXCI6IDI4XG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjZmZmZmZmXCIsXG4gICAgICBcImxpbmVfY29sb3JcIjogXCIjNzgzZjA0XCIsXG4gICAgICBcIndhcnBcIjogXCJiYWNrd2FyZFwiLFxuICAgICAgXCJzdHlsZVwiOiAyOVxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI2JiYmJiYlwiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiIzc4M2YwNFwiLFxuICAgICAgXCJ3YXJwXCI6IFwiZm9yd2FyZFwiLFxuICAgICAgXCJzdHlsZVwiOiAzMFxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI2JiYmJiYlwiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiIzc4M2YwNFwiLFxuICAgICAgXCJ3YXJwXCI6IFwiYmFja3dhcmRcIixcbiAgICAgIFwic3R5bGVcIjogMzFcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNmZmZmZmZcIixcbiAgICAgIFwibGluZV9jb2xvclwiOiBcIiNmZmZmZmZcIixcbiAgICAgIFwid2FycFwiOiBcImZvcndhcmRcIixcbiAgICAgIFwic3R5bGVcIjogMzJcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNmZmZmZmZcIixcbiAgICAgIFwibGluZV9jb2xvclwiOiBcIiNmZmZmZmZcIixcbiAgICAgIFwid2FycFwiOiBcImJhY2t3YXJkXCIsXG4gICAgICBcInN0eWxlXCI6IDMzXG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjYmJiYmJiXCIsXG4gICAgICBcImxpbmVfY29sb3JcIjogXCIjZmZmZmZmXCIsXG4gICAgICBcIndhcnBcIjogXCJmb3J3YXJkXCIsXG4gICAgICBcInN0eWxlXCI6IDM0XG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjYmJiYmJiXCIsXG4gICAgICBcImxpbmVfY29sb3JcIjogXCIjZmZmZmZmXCIsXG4gICAgICBcIndhcnBcIjogXCJiYWNrd2FyZFwiLFxuICAgICAgXCJzdHlsZVwiOiAzNVxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI2ZmZmZmZlwiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiI2ZmZmZmZlwiLFxuICAgICAgXCJ3YXJwXCI6IFwiZm9yd2FyZF9lbXB0eVwiLFxuICAgICAgXCJzdHlsZVwiOiAzNlxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI2ZmZmZmZlwiLFxuICAgICAgXCJsaW5lX2NvbG9yXCI6IFwiI2ZmZmZmZlwiLFxuICAgICAgXCJ3YXJwXCI6IFwiYmFja3dhcmRfZW1wdHlcIixcbiAgICAgIFwic3R5bGVcIjogMzdcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNiYmJiYmJcIixcbiAgICAgIFwibGluZV9jb2xvclwiOiBcIiNmZmZmZmZcIixcbiAgICAgIFwid2FycFwiOiBcImZvcndhcmRfZW1wdHlcIixcbiAgICAgIFwic3R5bGVcIjogNDBcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNiYmJiYmJcIixcbiAgICAgIFwibGluZV9jb2xvclwiOiBcIiNmZmZmZmZcIixcbiAgICAgIFwid2FycFwiOiBcImJhY2t3YXJkX2VtcHR5XCIsXG4gICAgICBcInN0eWxlXCI6IDQxXG4gICAgfVxuICBdLFxuICBcIm9yaWVudGF0aW9uXCI6IFtcIlNcIixcIlpcIixcIlNcIixcIlpcIixcIlNcIixcIlpcIixcIlNcIixcIlpcIixcIlNcIixcIlpcIixcIlNcIixcIlpcIl0sXG4gIFwidGhyZWFkaW5nXCI6IFtcbiAgICBbNSw2LDUsNiw1LDYsNSw2LDUsNiw1LDZdLFxuICAgIFs1LDYsNSw2LDUsNiw1LDYsNSw2LDUsNl0sXG4gICAgWzUsNiw1LDYsNSw2LDUsNiw1LDYsNSw2XSxcbiAgICBbNSw2LDUsNiw1LDYsNSw2LDUsNiw1LDZdXG4gIF0sXG4gIFwid2VhdmluZ1wiOiBbXG4gICAgWzUsNiw1LDYsNSw2LDUsNiw1LDYsNSw2XSxcbiAgICBbNSw2LDUsNiw1LDYsNSw2LDUsNiw1LDZdLFxuICAgIFs1LDYsNSw2LDUsNiw1LDYsNSw2LDUsNl0sXG4gICAgWzUsNiw1LDYsNSw2LDUsNiw1LDYsNSw2XSxcbiAgICBbNSw2LDUsNiw1LDYsNSw2LDUsNiw1LDZdLFxuICAgIFs1LDYsNSw2LDUsNiw1LDYsNSw2LDUsNl0sXG4gICAgWzUsNiw1LDYsNSw2LDUsNiw1LDYsNSw2XSxcbiAgICBbNSw2LDUsNiw1LDYsNSw2LDUsNiw1LDZdXG4gIF0sXG4gIFwid2VmdF9jb2xvclwiOiBcIiM3NmE1YWZcIlxufVxuIiwiLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4vLyBleHRlbmRzICdjaGVjaycgZnVuY3Rpb25hbGl0eVxuLy8gY2hlY2sodXNlcklkLCBOb25FbXB0eVN0cmluZyk7XG5Ob25FbXB0eVN0cmluZyA9IE1hdGNoLldoZXJlKGZ1bmN0aW9uICh4KSB7XG4gIGNoZWNrKHgsIFN0cmluZyk7XG4gIHJldHVybiB4Lmxlbmd0aCA+IDA7XG59KTtcbiIsIi8vIGdlbmVyYWwgcGFyYW1ldGVycyB0aGF0IGRvIG5vdCBhZmZlY3Qgc2VjdXJpdHlcbk1ldGVvci5teV9wYXJhbXMgPSB7IC8vIG5hbWVzcGFjZSBmb3IgcGFyYW1ldGVyc1xuICB1bmRvX3N0YWNrX2xlbmd0aDogMTAsXG4gIHNwZWNpYWxfc3R5bGVzX251bWJlcjogMTYsIC8vIGN1cnJlbnRseSB1cCB0byAxNiBzcGVjaWFsIHN0eWxlcyBhbGxvd2luZyAzIG11bHRpcGxlIHR1cm5zIGFuZCA0IG90aGVyIHNpbmdsZSBzdHlsZXNcbiAgcGF0dGVybl90aHVtYm5haWxfd2lkdGg6IDI0OCwgLy8gdGlsZWQgcGF0dGVybiB0aHVtYm5haWxzXG4gIHBhdHRlcm5fdGh1bWJuYWlsX3JtYXJnaW46MTYsIC8vIHJpZ2h0IG1hcmdpblxuICBtYXhfcmVjZW50czogMTIsXG4gIG1heF9ob21lX3RodW1ibmFpbHM6IDEyLFxuICBtYXhfYXV0b190dXJuczogNDgsXG4gIG51bWJlcl9vZl9wYWNrczogMywgLy8gcGFja3MgaW4gc2ltdWxhdGlvbiBwYXR0ZXJuLCBtYW51YWwgbW9kZVxuICBkZWZhdWx0X3BhdHRlcm5fbmFtZTogXCJOZXcgcGF0dGVyblwiLFxuICBkZWZhdWx0X3NwZWNpYWxfc3R5bGVzOiBbXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI0ZGRkZGRlwiLFxuICAgICAgXCJuYW1lXCI6IFwiZm9yd2FyZF8yXCIsXG4gICAgICBcIndhcnBcIjogXCJmb3J3YXJkXCIsXG4gICAgICBcImltYWdlXCI6IFwiL2ltYWdlcy9zcGVjaWFsX2ZvcndhcmRfMi5zdmdcIixcbiAgICAgIFwic3R5bGVcIjogXCJTMVwiXG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjRkZGRkZGXCIsXG4gICAgICBcIm5hbWVcIjogXCJiYWNrd2FyZF8yXCIsXG4gICAgICBcIndhcnBcIjogXCJiYWNrd2FyZFwiLFxuICAgICAgXCJpbWFnZVwiOiBcIi9pbWFnZXMvc3BlY2lhbF9iYWNrd2FyZF8yLnN2Z1wiLFxuICAgICAgXCJzdHlsZVwiOiBcIlMyXCJcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNGRkZGRkZcIixcbiAgICAgIFwibmFtZVwiOiBcImZvcndhcmRfM1wiLFxuICAgICAgXCJ3YXJwXCI6IFwiZm9yd2FyZFwiLFxuICAgICAgXCJpbWFnZVwiOiBcIi9pbWFnZXMvc3BlY2lhbF9mb3J3YXJkXzMuc3ZnXCIsXG4gICAgICBcInN0eWxlXCI6IFwiUzNcIlxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI0ZGRkZGRlwiLFxuICAgICAgXCJuYW1lXCI6IFwiYmFja3dhcmRfM1wiLFxuICAgICAgXCJ3YXJwXCI6IFwiYmFja3dhcmRcIixcbiAgICAgIFwiaW1hZ2VcIjogXCIvaW1hZ2VzL3NwZWNpYWxfYmFja3dhcmRfMy5zdmdcIixcbiAgICAgIFwic3R5bGVcIjogXCJTNFwiXG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjRkZGRkZGXCIsXG4gICAgICBcIm5hbWVcIjogXCJmb3J3YXJkXzRcIixcbiAgICAgIFwid2FycFwiOiBcImZvcndhcmRcIixcbiAgICAgIFwiaW1hZ2VcIjogXCIvaW1hZ2VzL3NwZWNpYWxfZm9yd2FyZF80LnN2Z1wiLFxuICAgICAgXCJzdHlsZVwiOiBcIlM1XCJcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNGRkZGRkZcIixcbiAgICAgIFwibmFtZVwiOiBcImJhY2t3YXJkXzRcIixcbiAgICAgIFwid2FycFwiOiBcImJhY2t3YXJkXCIsXG4gICAgICBcImltYWdlXCI6IFwiL2ltYWdlcy9zcGVjaWFsX2JhY2t3YXJkXzQuc3ZnXCIsXG4gICAgICBcInN0eWxlXCI6IFwiUzZcIlxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI0ZGRkZGRlwiLFxuICAgICAgXCJpbWFnZVwiOiBcIi9pbWFnZXMvc3BlY2lhbF9lbXB0eS5zdmdcIixcbiAgICAgIFwic3R5bGVcIjogXCJTN1wiXG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjRkZGRkZGXCIsXG4gICAgICBcImltYWdlXCI6IFwiXCIsXG4gICAgICBcInN0eWxlXCI6IFwiUzhcIlxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI0JCQkJCQlwiLFxuICAgICAgXCJuYW1lXCI6IFwiYmFja3dhcmRfMl9ncmF5XCIsXG4gICAgICBcIndhcnBcIjogXCJiYWNrd2FyZFwiLFxuICAgICAgXCJpbWFnZVwiOiBcIi9pbWFnZXMvc3BlY2lhbF9iYWNrd2FyZF8yLnN2Z1wiLFxuICAgICAgXCJzdHlsZVwiOiBcIlM5XCJcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNCQkJCQkJcIixcbiAgICAgIFwibmFtZVwiOiBcImZvcndhcmRfMl9ncmF5XCIsXG4gICAgICBcIndhcnBcIjogXCJmb3J3YXJkXCIsXG4gICAgICBcImltYWdlXCI6IFwiL2ltYWdlcy9zcGVjaWFsX2ZvcndhcmRfMi5zdmdcIixcbiAgICAgIFwic3R5bGVcIjogXCJTMTBcIlxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI0JCQkJCQlwiLFxuICAgICAgXCJuYW1lXCI6IFwiYmFja3dhcmRfM19ncmF5XCIsXG4gICAgICBcIndhcnBcIjogXCJiYWNrd2FyZFwiLFxuICAgICAgXCJpbWFnZVwiOiBcIi9pbWFnZXMvc3BlY2lhbF9iYWNrd2FyZF8zLnN2Z1wiLFxuICAgICAgXCJzdHlsZVwiOiBcIlMxMVwiXG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjQkJCQkJCXCIsXG4gICAgICBcIm5hbWVcIjogXCJmb3J3YXJkXzNfZ3JheVwiLFxuICAgICAgXCJ3YXJwXCI6IFwiZm9yd2FyZFwiLFxuICAgICAgXCJpbWFnZVwiOiBcIi9pbWFnZXMvc3BlY2lhbF9mb3J3YXJkXzMuc3ZnXCIsXG4gICAgICBcInN0eWxlXCI6IFwiUzEyXCJcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNCQkJCQkJcIixcbiAgICAgIFwibmFtZVwiOiBcImJhY2t3YXJkXzRfZ3JheVwiLFxuICAgICAgXCJ3YXJwXCI6IFwiYmFja3dhcmRcIixcbiAgICAgIFwiaW1hZ2VcIjogXCIvaW1hZ2VzL3NwZWNpYWxfYmFja3dhcmRfNC5zdmdcIixcbiAgICAgIFwic3R5bGVcIjogXCJTMTNcIlxuICAgIH0sXG4gICAge1xuICAgICAgXCJiYWNrZ3JvdW5kX2NvbG9yXCI6IFwiI0JCQkJCQlwiLFxuICAgICAgXCJuYW1lXCI6IFwiZm9yd2FyZF80X2dyYXlcIixcbiAgICAgIFwid2FycFwiOiBcImZvcndhcmRcIixcbiAgICAgIFwiaW1hZ2VcIjogXCIvaW1hZ2VzL3NwZWNpYWxfZm9yd2FyZF80LnN2Z1wiLFxuICAgICAgXCJzdHlsZVwiOiBcIlMxNFwiXG4gICAgfSxcbiAgICB7XG4gICAgICBcImJhY2tncm91bmRfY29sb3JcIjogXCIjRkZGRkZGXCIsXG4gICAgICBcIm5hbWVcIjogXCJpZGxlXCIsXG4gICAgICBcImltYWdlXCI6IFwiL2ltYWdlcy9zcGVjaWFsX2lkbGUuc3ZnXCIsXG4gICAgICBcInN0eWxlXCI6IFwiUzE1XCJcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiYmFja2dyb3VuZF9jb2xvclwiOiBcIiNGRkZGRkZcIixcbiAgICAgIFwiaW1hZ2VcIjogXCJcIixcbiAgICAgIFwic3R5bGVcIjogXCJTMTZcIlxuICAgIH1cbiAgXVxufVxuIiwiLy8gc2xpbmdzaG90IGltYWdlIHVwbG9hZGVyXG4vLyBwdXRzIGZpbGVzIGluIGFuIEFXUyAoQW1hem9uIFdlYiBTZXJ2aWNlcykgYnVja2V0XG5cbmlmIChNZXRlb3IuaXNDbGllbnQpIHtcbiAgdXBsb2FkZXIgPSBuZXcgUmVhY3RpdmVWYXIoKTtcblxuICB2YXIgY3VycmVudFVzZXJJZCA9IE1ldGVvci51c2VySWQoKTtcbiAgU2Vzc2lvbi5zZXQoJ3VwbG9hZF9zdGF0dXMnLCAnbm90IHN0YXJ0ZWQnKTtcblxuICBUZW1wbGF0ZS5pbWFnZV91cGxvYWRlci5ldmVudHMoeydjaGFuZ2UgLnVwbG9hZEZpbGUnOiBmdW5jdGlvbihldmVudCwgdGVtcGxhdGUpe1xuICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgIHZhciBwYXR0ZXJuX2lkID0gUm91dGVyLmN1cnJlbnQoKS5wYXJhbXMuX2lkO1xuICAgICAgdmFyIGZpbGUgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndXBsb2FkRmlsZScpLmZpbGVzWzBdO1xuICAgICAgXG4gICAgICBNZXRlb3IubXlfZnVuY3Rpb25zLnVwbG9hZF9wYXR0ZXJuX2ltYWdlKGZpbGUsIHBhdHRlcm5faWQpO1xuICAgIH1cbiAgfSk7XG5cbiAgTWV0ZW9yLnN1YnNjcmliZSgnaW1hZ2VzJyk7XG59XG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgU2xpbmdzaG90LmZpbGVSZXN0cmljdGlvbnMoXCJteUltYWdlVXBsb2Fkc1wiLCB7XG4gICAgYWxsb3dlZEZpbGVUeXBlczogW1wiaW1hZ2UvcG5nXCIsIFwiaW1hZ2UvanBlZ1wiLCBcImltYWdlL2dpZlwiXSxcbiAgICBtYXhTaXplOiAyICogMTAyNCAqIDEwMjQsXG4gIH0pO1xuXG4gIFNsaW5nc2hvdC5jcmVhdGVEaXJlY3RpdmUoXCJteUltYWdlVXBsb2Fkc1wiLCBTbGluZ3Nob3QuUzNTdG9yYWdlLCB7XG4gICAgQVdTQWNjZXNzS2V5SWQ6IE1ldGVvci5zZXR0aW5ncy5wcml2YXRlLkFXU0FjY2Vzc0tleUlkLFxuICAgIEFXU1NlY3JldEFjY2Vzc0tleTogTWV0ZW9yLnNldHRpbmdzLnByaXZhdGUuQVdTU2VjcmV0QWNjZXNzS2V5LFxuICAgIGJ1Y2tldDogTWV0ZW9yLnNldHRpbmdzLnByaXZhdGUuQVdTQnVja2V0LFxuICAgIGFjbDogXCJwdWJsaWMtcmVhZFwiLFxuICAgIHJlZ2lvbjogTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5BV1NSZWdpb24sXG5cbiAgICBhdXRob3JpemU6IGZ1bmN0aW9uIChmaWxlLCBjb250ZXh0KSB7XG4gICAgICBcbiAgICAgIC8vIFVzZXIgbXVzdCBiZSBsb2dnZWQgaW5cbiAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgdmFyIG1lc3NhZ2UgPSBcIllvdSBhcmUgbm90IGxvZ2dlZCBpbi5cIjtcbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIm5vdC1hdXRob3JpemVkXCIsIG1lc3NhZ2UpO1xuICAgICAgfVxuXG4gICAgICAvLyBVc2VyIG11c3QgaGF2ZSB2ZXJpZmllZCB0aGVpciBlbWFpbCBhZGRyZXNzXG4gICAgICB2YXIgdXNlciA9IE1ldGVvci51c2Vycy5maW5kT25lKHtfaWQ6IHRoaXMudXNlcklkfSwgeyBmaWVsZHM6IHtlbWFpbHM6IDF9fSk7XG4gICAgICBpZiAoIXVzZXIuZW1haWxzWzBdLnZlcmlmaWVkKSB7XG4gICAgICAgIHZhciBtZXNzYWdlID0gXCJZb3VyIGVtYWlsIGFkZHJlc3MgaXMgbm90IHZlcmlmaWVkLlwiO1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibm90LWF1dGhvcml6ZWRcIiwgbWVzc2FnZSk7XG4gICAgICB9XG5cbiAgICAgIC8vIFVzZXIgbXVzdCBvd24gdGhlIHBhdHRlcm5cbiAgICAgIHZhciBwYXR0ZXJuID0gUGF0dGVybnMuZmluZE9uZSh7X2lkOiBjb250ZXh0LnBhdHRlcm5faWR9LCB7IGZpZWxkczoge2NyZWF0ZWRfYnk6IDF9fSk7XG4gICAgICBpZiAocGF0dGVybi5jcmVhdGVkX2J5ICE9IHRoaXMudXNlcklkKVxuICAgICAge1xuICAgICAgICB2YXIgbWVzc2FnZSA9IFwiWW91IGRpZCBub3QgY3JlYXRlIHRoaXMgcGF0dGVybi5cIjtcbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIm5vdC1hdXRob3JpemVkXCIsIG1lc3NhZ2UpO1xuICAgICAgfVxuXG4gICAgICAvLyBjaGVjayBmb3IgdG9vIG1hbnkgaW1hZ2UgdXBsb2FkcyB0b28gZmFzdFxuICAgICAgdmFyIGRvY3VtZW50X2lkID0gTWV0ZW9yLmNhbGwoJ2dldF9hY3Rpb25zX2xvZycpO1xuXG4gICAgICB2YXIgZGJfZG9jdW1lbnQgPSBBY3Rpb25zTG9nLmZpbmRPbmUoe19pZDogZG9jdW1lbnRfaWR9LCB7ZmllbGRzOiB7IGltYWdlX3VwbG9hZGVkOiAxLCBsb2NrZWQ6IDEgfX0gKTtcblxuICAgICAgdmFyIGV2ZW50X2xvZyA9IGRiX2RvY3VtZW50LmltYWdlX3VwbG9hZGVkO1xuXG4gICAgICBpZiAoZGJfZG9jdW1lbnQubG9ja2VkKVxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcImFjY291bnQtbG9ja2VkXCIsIFwiWW91ciBhY2NvdW50IGhhcyBiZWVuIGxvY2tlZCwgcGxlYXNlIGNvbnRhY3QgYW4gYWRtaW5pc3RyYXRvclwiKTtcbiAgICBcbiAgICAgIHZhciBudW1iZXJfb2ZfZW50cmllcyA9IGV2ZW50X2xvZy5sZW5ndGg7XG4gICAgICB2YXIgdGltZV9zaW5jZV9sYXN0X2FjdGlvbiA9IG1vbWVudCgpLnZhbHVlT2YoKSAtIGV2ZW50X2xvZ1swXTtcblxuICAgICAgLy8gdHJ5IHRvIGRldGVjdCBhdXRvbWF0ZWQgaW1hZ2UgdXBsb2Fkc1xuICAgICAgLy8gQSBodW1hbiBzaG91bGRuJ3QgYmUgYWJsZSB0byB1cGxvYWQgMTAgaW1hZ2VzIGluIDIgc2Vjb25kc1xuICAgICAgdmFyIGxhc3RfMTBfYWN0aW9uc19pbiA9IGV2ZW50X2xvZ1swXSAtIGV2ZW50X2xvZ1s5XTtcbiAgICAgIGlmIChsYXN0XzEwX2FjdGlvbnNfaW4gPCAyMDAwKVxuICAgICAge1xuICAgICAgICBBY3Rpb25zTG9nLnVwZGF0ZSgge19pZDogZG9jdW1lbnRfaWR9LCB7IGxvY2tlZDogdHJ1ZSB9ICk7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJhY2NvdW50LWxvY2tlZFwiLCBcIllvdXIgYWNjb3VudCBoYXMgYmVlbiBsb2NrZWQsIHBsZWFzZSBjb250YWN0IGFuIGFkbWluaXN0cmF0b3JcIik7XG4gICAgICB9XG5cbiAgICAgIHZhciBsYXN0XzVfYWN0aW9uc19pbiA9IGV2ZW50X2xvZ1swXSAtIGV2ZW50X2xvZ1s0XTtcbiAgICAgIGlmIChsYXN0XzVfYWN0aW9uc19pbiA8IDIwMDApXG4gICAgICB7XG4gICAgICAgIC8vIERvbid0IGFsbG93IGFub3RoZXIgYXR0ZW1wdCBmb3IgNSBtaW51dGVzXG4gICAgICAgIGlmICh0aW1lX3NpbmNlX2xhc3RfYWN0aW9uIDwgKDYwICogMTAwMCAqIDUpKVxuICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJ0b28tbWFueS1yZXF1ZXN0c1wiLCBcIlBsZWFzZSB3YWl0IDUgbWlucyBiZWZvcmUgcmV0cnlpbmdcIik7XG5cbiAgICAgICAgLy8gaXQncyBiZWVuIGF0IGxlYXN0IDUgbWlucyBzbyBjb25zaWRlciBhbGxvd2luZyBhbm90aGVyIGltYWdlIHVwbG9hZFxuICAgICAgICBlbHNlXG4gICAgICAgIHtcbiAgICAgICAgICB2YXIgcHJldmlvdXNfNV9hY3Rpb25zX2luID0gZXZlbnRfbG9nWzRdIC0gZXZlbnRfbG9nWzldO1xuICAgICAgICAgIGlmIChwcmV2aW91c181X2FjdGlvbnNfaW4gPCAyMDAwKVxuICAgICAgICAgIHtcbiAgICAgICAgICAgIC8vIGlmIHRoZSA1IHByZXZpb3VzIGFjdGlvbnMgd2VyZSBpbiAyIHNlY29uZHMsIHdhaXQgMzAgbWludXRlc1xuICAgICAgICAgICAgLy8gdGhpcyBsb29rcyBsaWtlIGFuIGF1dG9tYXRpYyBwcm9jZXNzIHRoYXQgaGFzIHRyaWVkIGNvbnRpbnVhbGx5XG4gICAgICAgICAgICBpZiAodGltZV9zaW5jZV9sYXN0X2FjdGlvbiA8ICg2MCAqIDEwMDAgKiAzMCArIDQwMDApKVxuICAgICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwidG9vLW1hbnktcmVxdWVzdHNcIiwgXCJQbGVhc2Ugd2FpdCAzMCBtaW5zIGJlZm9yZSByZXRyeWluZ1wiKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gcmVjb3JkIHRoZSBhY3Rpb24gaW4gdGhlIGxvZ1xuICAgICAgQWN0aW9uc0xvZy51cGRhdGUoIHtfaWQ6IGRvY3VtZW50X2lkfSwgeyAkcHVzaDogeyBpbWFnZV91cGxvYWRlZDoge1xuICAgICAgICAkZWFjaDogW21vbWVudCgpLnZhbHVlT2YoKV0sXG4gICAgICAgICRwb3NpdGlvbjogMCBcbiAgICAgIH19fSApO1xuICA7XG4gICAgICAvLyByZW1vdmUgdGhlIG9sZGVzdCBsb2cgZW50cnkgaWYgdG9vIG1hbnkgc3RvcmVkXG4gICAgICBpZiAobnVtYmVyX29mX2VudHJpZXMgPiBNZXRlb3Iuc2V0dGluZ3MucHJpdmF0ZS5pbWFnZV91cGxvYWRzX251bV90b19sb2cpXG4gICAgICB7XG4gICAgICAgIEFjdGlvbnNMb2cudXBkYXRlKCB7X2lkOiBkb2N1bWVudF9pZH0sIHsgJHBvcDogeyBpbWFnZV91cGxvYWRlZDogMSB9fSApO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9LFxuXG4gICAga2V5OiBmdW5jdGlvbiAoZmlsZSkge1xuICAgICAgdmFyIHBhcnRzID0gZmlsZS5uYW1lLnNwbGl0KFwiLlwiKTsgLy8gZmluZCB0aGUgZmlsZSBleHRlbnNpb25cbiAgICAgIHZhciBleHRlbnNpb24gPSBwYXJ0cy5wb3AoKTtcbiAgICAgIHZhciBuYW1lID0gcGFydHMuam9pbihcIlwiKTsgLy8gZmluZCB0aGUgbmFtZVxuICAgICAgdmFyIG5hbWUgPSBuYW1lLnNsaWNlKDAsMzApICsgXCItXCIgKyBtb21lbnQoKS52YWx1ZU9mKCkudG9TdHJpbmcoKSArIFwiLlwiICsgZXh0ZW5zaW9uOyAvLyB1c2UgdGhlIGZpcnN0IDMwIGNoYXJzIG9mIHRoZSBuYW1lLCBwbHVzIHRpbWVzdGFtcCwgcGx1cyBmaWxlIGV4dGVuc2lvbiwgdG8gbWFrZSBhIG1lYW5pbmdmdWwgbmFtZSB0aGF0IGlzIHVuaXF1ZSB0byB0aGlzIHVzZXJcbiAgICAgIHJldHVybiBNZXRlb3IudXNlcklkKCkgKyBcIi9cIiArIG5hbWU7XG4gICAgfSxcbiAgfSk7XG59XG4iLCJSb3V0ZXIuY29uZmlndXJlKHtcbiAgbGF5b3V0VGVtcGxhdGU6ICdtYWluX2xheW91dCcsXG4gIGZhc3RSZW5kZXI6IHRydWUsXG4gIGxvYWRpbmdUZW1wbGF0ZTogJ2xvYWRpbmcnXG59KTtcblxuLy8gd2FpdE9uIG1ha2VzIGluaXRpYWwgcGFnZSByZW5kZXIgdmVyeSBzbG93LCBtYXliZSAxNSBzZWNvbmRzLiBPbiBwYWdlcyBsaWtlIEhvbWUgdGhhdCBsaXN0IHBhdHRlcm5zLCBpdCdzIGJldHRlciB0byBzZWUgdGhlIHBhZ2Ugc29vbmVyIGFuZCB3YXRjaCB0aGUgcGF0dGVybnMgYXBwZWFyLlxuXG5Sb3V0ZXIucm91dGUoJy8nLCB7XG4gIG5hbWU6ICdob21lJyxcbiAgdGVtcGxhdGU6ICdob21lJ1xufSk7XG5cblJvdXRlci5yb3V0ZSgnL2Fib3V0Jywge1xuICBuYW1lOiAnYWJvdXQnLFxuICB0ZW1wbGF0ZTogJ2Fib3V0J1xufSk7XG5cblJvdXRlci5yb3V0ZSgnL3JlY2VudC1wYXR0ZXJucycsIHtcbiAgbmFtZTogJ3JlY2VudF9wYXR0ZXJucycsXG4gIHRlbXBsYXRlOiAncmVjZW50X3BhdHRlcm5zJ1xufSk7XG5cblJvdXRlci5yb3V0ZSgnL25ldy1wYXR0ZXJucycsIHtcbiAgbmFtZTogJ25ld19wYXR0ZXJucycsXG4gIHRlbXBsYXRlOiAnbmV3X3BhdHRlcm5zJ1xufSk7XG5cblJvdXRlci5yb3V0ZSgnL215LXBhdHRlcm5zJywge1xuICBuYW1lOiAnbXlfcGF0dGVybnMnLFxuICB0ZW1wbGF0ZTogJ215X3BhdHRlcm5zJ1xufSk7XG5cblJvdXRlci5yb3V0ZSgnL2FsbC1wYXR0ZXJucycsIHtcbiAgbmFtZTogJ2FsbF9wYXR0ZXJucycsXG4gIHRlbXBsYXRlOiAnYWxsX3BhdHRlcm5zJ1xufSk7XG5cblxuUm91dGVyLnJvdXRlKCcvdXNlcnMnLCB7XG4gIG5hbWU6ICd1c2VycycsXG4gIHRlbXBsYXRlOiAndXNlcnMnXG59KTtcblxuUm91dGVyLnJvdXRlKCcvcGF0dGVybi86X2lkLzptb2RlPycsIHtcbiAgbmFtZTogJ3BhdHRlcm4nLFxuICBkYXRhOiBmdW5jdGlvbigpe1xuICAgIHZhciBwYXR0ZXJuX2lkID0gdGhpcy5wYXJhbXMuX2lkO1xuXG4gICAgcmV0dXJuIFBhdHRlcm5zLmZpbmRPbmUoeyBfaWQ6IHBhdHRlcm5faWQgfSwge2ZpZWxkczoge3dlYXZpbmc6IDAsIHRocmVhZGluZzogMCwgb3JpZW50YXRpb246IDB9fSk7XG4gIH0sXG4gIHdhaXRPbjogZnVuY3Rpb24oKXtcbiAgICB2YXIgcGF0dGVybl9pZCA9IHRoaXMucGFyYW1zLl9pZDtcbiAgICB2YXIgcGFyYW1zID0ge1xuICAgICAgcGF0dGVybl9pZDogcGF0dGVybl9pZCxcbiAgICB9O1xuXG4gICAgcmV0dXJuIFsgIFxuICAgICAgTWV0ZW9yLnN1YnNjcmliZSgncGF0dGVybicsIHBhcmFtcykgXG4gICAgXTtcbiAgfSxcbiAgYWN0aW9uOiBmdW5jdGlvbigpIHtcbiAgICB2YXIgcGF0dGVybl9pZCA9IHRoaXMucGFyYW1zLl9pZDtcblxuICAgIGlmIChQYXR0ZXJucy5maW5kKHsgX2lkOiBwYXR0ZXJuX2lkfSkuY291bnQoKSA9PSAwKVxuICAgIHtcbiAgICAgIHRoaXMubGF5b3V0KCdtYWluX2xheW91dCcpO1xuICAgICAgdGhpcy5yZW5kZXIoXCJwYXR0ZXJuX25vdF9mb3VuZFwiKTtcbiAgICAgIHRoaXMucmVuZGVyKG51bGwsIHt0bzogJ2Zvb3Rlcid9KTsgLy8geWllbGQgcmVnaW9ucyBtdXN0IGJlIG1hbnVhbGx5IGNsZWFyZWRcbiAgICB9XG4gXG4gICAgZWxzZSBpZiAodGhpcy5wYXJhbXMubW9kZSA9PSBcIndlYXZpbmdcIilcbiAgICB7XG4gICAgICB0aGlzLnJlbmRlcignd2VhdmVfcGF0dGVybicpO1xuICAgICAgdGhpcy5yZW5kZXIobnVsbCwge3RvOiAnZm9vdGVyJ30pO1xuICAgIH1cblxuICAgIGVsc2UgaWYgKHRoaXMucGFyYW1zLm1vZGUgPT0gXCJwcmludFwiKVxuICAgIHtcbiAgICAgIHRoaXMubGF5b3V0KCdwcmludF9sYXlvdXQnKTtcbiAgICAgIHRoaXMucmVuZGVyKCdwcmludF9wYXR0ZXJuJyk7XG4gICAgICB0aGlzLnJlbmRlcihudWxsLCB7dG86ICdmb290ZXInfSk7XG4gICAgfVxuXG4gICAgZWxzZVxuICAgIHtcbiAgICAgIHRoaXMucmVuZGVyKCd2aWV3X3BhdHRlcm4nKTtcblxuICAgICAgaWYgKE1ldGVvci5teV9mdW5jdGlvbnMuY2FuX2VkaXRfcGF0dGVybihwYXR0ZXJuX2lkKSlcbiAgICAgICAgdGhpcy5yZW5kZXIoJ3N0eWxlc19wYWxldHRlJywge3RvOiAnZm9vdGVyJ30pO1xuXG4gICAgICBlbHNlXG4gICAgICAgIHRoaXMucmVuZGVyKG51bGwsIHt0bzogJ2Zvb3Rlcid9KTtcbiAgICB9XG4gICAgICAgICBcbiAgfVxufSk7XG5cblJvdXRlci5yb3V0ZSgnL3VzZXIvOl9pZCcsIHtcbiAgbmFtZTogJ3VzZXInLFxuICBkYXRhOiBmdW5jdGlvbigpe1xuICAgIHZhciB1c2VyX2lkID0gdGhpcy5wYXJhbXMuX2lkO1xuXG4gICAgcmV0dXJuIE1ldGVvci51c2Vycy5maW5kT25lKHsgX2lkOiB1c2VyX2lkIH0pO1xuICB9LFxuICB3YWl0T246IGZ1bmN0aW9uKCl7XG4gICAgdmFyIHVzZXJfaWQgPSB0aGlzLnBhcmFtcy5faWQ7XG4gICAgdmFyIHBhcmFtcyA9IHtcbiAgICAgIHVzZXJfaWQ6IHVzZXJfaWQsXG4gICAgfTtcblxuICAgIHJldHVybiBbICBcbiAgICAgIE1ldGVvci5zdWJzY3JpYmUoJ3VzZXInLCBwYXJhbXMpIFxuICAgIF07XG4gIH0sXG4gIGFjdGlvbjogZnVuY3Rpb24oKSB7XG4gICAgdmFyIHVzZXJfaWQgPSB0aGlzLnBhcmFtcy5faWQ7XG5cbiAgICBpZiAoTWV0ZW9yLnVzZXJzLmZpbmQoeyBfaWQ6IHVzZXJfaWR9KS5jb3VudCgpID09IDApXG4gICAgICB0aGlzLnJlbmRlcihcInVzZXJfbm90X2ZvdW5kXCIpO1xuICAgIFxuICAgIGVsc2VcbiAgICAgIHRoaXMucmVuZGVyKFwidXNlclwiKTtcbiAgfVxufSk7XG5cblJvdXRlci5yb3V0ZSgnL2FjY291bnQtc2V0dGluZ3MnLCB7XG4gIG5hbWU6ICdhY2NvdW50X3NldHRpbmdzJyxcbiAgZGF0YTogZnVuY3Rpb24oKSB7XG4gICAgdmFyIHVzZXJfaWQgPSBNZXRlb3IudXNlcklkKCk7XG5cbiAgICByZXR1cm4gTWV0ZW9yLnVzZXJzLmZpbmRPbmUoeyBfaWQ6IHVzZXJfaWQgfSk7XG4gIH0sXG4gIHdhaXRPbjogZnVuY3Rpb24oKXtcbiAgICB2YXIgdXNlcl9pZCA9IE1ldGVvci51c2VySWQoKTtcblxuICAgIHZhciBwYXJhbXMgPSB7XG4gICAgICB1c2VyX2lkOiB1c2VyX2lkLFxuICAgIH07XG5cbiAgICByZXR1cm4gWyAgXG4gICAgICBNZXRlb3Iuc3Vic2NyaWJlKCd1c2VyJywgcGFyYW1zKSBcbiAgICBdO1xuICB9LFxuICBhY3Rpb246IGZ1bmN0aW9uKCkge1xuICAgIC8vIHZhciB1c2VyX2lkID0gdGhpcy5wYXJhbXMuX2lkO1xuICAgIHRoaXMucmVuZGVyKFwiYWNjb3VudF9zZXR0aW5nc1wiKTtcbiAgfVxufSlcbiIsIk1ldGVvci5zdGFydHVwKGZ1bmN0aW9uICgpIHtcbiAgcHJvY2Vzcy5lbnYuTUFJTF9VUkwgPSBNZXRlb3Iuc2V0dGluZ3NbJ3ByaXZhdGUnXS5NQUlMX1VSTDtcbiAgcHJvY2Vzcy5lbnYuUk9PVF9VUkwgPSBNZXRlb3Iuc2V0dGluZ3NbJ3ByaXZhdGUnXS5ST09UX1VSTDtcblxuICAvLyBBY2NvdW50c1xuICBBY2NvdW50cy5jb25maWcoe1xuICAgIHNlbmRWZXJpZmljYXRpb25FbWFpbDogdHJ1ZSBcbiAgfSk7XG5cbiAgQWNjb3VudHMuZW1haWxUZW1wbGF0ZXMuc2l0ZU5hbWUgPSBcIlR3aXN0ZWQgVGhyZWFkc1wiO1xuICBBY2NvdW50cy5lbWFpbFRlbXBsYXRlcy5mcm9tID0gXCJUd2lzdGVkIFRocmVhZHMgPG5vLXJlcGx5QHR3aXN0ZWR0aHJlYWRzLm9yZz5cIjtcbiAgQWNjb3VudHMuZW1haWxUZW1wbGF0ZXMudmVyaWZ5RW1haWwuc3ViamVjdCA9IGZ1bmN0aW9uICh1c2VyKSB7XG4gICAgICByZXR1cm4gXCJWZXJpZnkgeW91ciBlbWFpbCBhZGRyZXNzXCI7XG4gIH07XG4gIEFjY291bnRzLmVtYWlsVGVtcGxhdGVzLnZlcmlmeUVtYWlsLnRleHQgPSBmdW5jdGlvbiAodXNlciwgdXJsKSB7XG4gICAgIHJldHVybiBcIkhlbGxvIFwiICsgdXNlci51c2VybmFtZVxuICAgICAgICsgXCIsXFxuXFxuWW91IGhhdmUgcmVnaXN0ZXJlZCBhIG5ldyBlbWFpbCBhZGRyZXNzIG9uIFR3aXN0ZWQgVGhyZWFkcywgdGhlIG9ubGluZSBhcHAgZm9yIHRhYmxldCB3ZWF2aW5nLiBUbyB2ZXJpZnkgeW91ciBlbWFpbCBhZGRyZXNzLCBwbGVhc2UgY2xpY2sgdGhlIGxpbmsgYmVsb3c6XFxuXFxuXCJcbiAgICAgICArIHVybDtcbiAgfTtcblxuICAvLyBtYWtlIHN1cmUgdGhlIGN1cnJlbnQgdXNlciBoYXMgY29ycmVjdCByb2xlIGJhc2VkIG9uIHdoZXRoZXIgdGhlaXIgZW1haWwgYWRkcmVzcyBpcyB2ZXJpZmllZFxuICBNZXRlb3IudXNlcnMuZmluZCgpLm9ic2VydmVDaGFuZ2VzKHtcbiAgICBjaGFuZ2VkOiBmdW5jdGlvbihpZCwgZmllbGRzKSB7XG4gICAgICBNZXRlb3IuY2FsbCgndXBkYXRlX3VzZXJfcm9sZXMnLCBpZCk7XG4gICAgfVxuICB9KTtcblxuICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4gIC8vIE9uZ29pbmcgZGF0YWJhc2UgdXBkYXRlc1xuICAvLyBydW4gdGhpcyBhcyBkZXNpcmVkXG4gIC8vIG1ha2UgcHJpdmF0ZSBhbGwgcGF0dGVybnMgd2l0aCB0aGUgZGVmYXVsdCBuYW1lXG4gIC8qUGF0dGVybnMuZmluZCgpLmZvckVhY2goIGZ1bmN0aW9uKG15RG9jKSB7XG4gICAgaWYgKG15RG9jLm5hbWUgPT0gTWV0ZW9yLm15X3BhcmFtcy5kZWZhdWx0X3BhdHRlcm5fbmFtZSlcbiAgICAgIFBhdHRlcm5zLnVwZGF0ZSh7X2lkOiBteURvYy5faWR9LCB7ICRzZXQ6IHtwcml2YXRlOiB0cnVlfX0pO1xuICB9KTsqL1xuXG4gIC8vIHJlbW92ZSBhbGwgcGF0dGVybnMgYmVjYXVzZSBzb21ldGhpbmcgaGFzIGdvbmUgd3JvbmdcbiAgLypQYXR0ZXJucy5maW5kKCkuZm9yRWFjaCggZnVuY3Rpb24obXlEb2MpIHtcbiAgICAvL2lmIChteURvYy5uYW1lID09IE1ldGVvci5teV9wYXJhbXMuZGVmYXVsdF9wYXR0ZXJuX25hbWUpXG5cbiAgICBQYXR0ZXJucy5yZW1vdmUobXlEb2MuX2lkKTtcbiAgfSk7Ki9cbn0pO1xuXG5BY2NvdW50cy5vbkNyZWF0ZVVzZXIoZnVuY3Rpb24ob3B0aW9ucywgdXNlcikge1xuICAvLyBXZSBzdGlsbCB3YW50IHRoZSBkZWZhdWx0IGhvb2sncyAncHJvZmlsZScgYmVoYXZpb3IuXG4gIHVzZXIucHJvZmlsZSA9IG9wdGlvbnMucHJvZmlsZSB8fCB7fTtcbiAgdXNlci5wcm9maWxlLm5hbWVfc29ydCA9IHVzZXIudXNlcm5hbWUudG9Mb3dlckNhc2UoKTtcbiAgcmV0dXJuIHVzZXI7XG59KTtcblxuIiwiTWV0ZW9yLm1ldGhvZHMoe1xuICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4gIC8vIFBhdHRlcm4gbWFuYWdlbWVudFxuICBzaG93X3BhdHRlcm5fdGFnczogZnVuY3Rpb24oKSB7XG4gICAgLy8gZm9yIGludGVybmFsIHVzZSBvbmx5XG4gICAgY29uc29sZS5sb2coXCJBbGwgdGFncyBcIiArIE1ldGVvci50YWdzLmZpbmQoKS5mZXRjaCgpLm1hcChmdW5jdGlvbih0YWcpIHtyZXR1cm4gdGFnLm5hbWV9KSk7XG4gIH0sXG4gIGNhbl9jcmVhdGVfcGF0dGVybjogZnVuY3Rpb24oKSB7XG4gICAgaWYgKCFNZXRlb3IudXNlcklkKCkpXG4gICAgICByZXR1cm4gZmFsc2U7XG5cbiAgICB2YXIgY291bnQgPSBQYXR0ZXJucy5maW5kKHtjcmVhdGVkX2J5OiBNZXRlb3IudXNlcklkKCl9KS5jb3VudCgpO1xuXG4gICAgaWYgKFJvbGVzLnVzZXJJc0luUm9sZSggTWV0ZW9yLnVzZXJJZCgpLCAndmVyaWZpZWQnLCAndXNlcnMnICkpXG4gICAge1xuICAgICAgaWYgKFJvbGVzLnVzZXJJc0luUm9sZSggTWV0ZW9yLnVzZXJJZCgpLCAncHJlbWl1bScsICd1c2VycycgKSlcbiAgICAgIHtcbiAgICAgICAgaWYgKGNvdW50IDwgTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5tYXhfcGF0dGVybnNfcGVyX3VzZXIucHJlbWl1bSlcbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcblxuICAgICAgICBlbHNlXG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgZWxzZVxuICAgICAge1xuICAgICAgICBpZiAoY291bnQgPCBNZXRlb3Iuc2V0dGluZ3MucHVibGljLm1heF9wYXR0ZXJuc19wZXJfdXNlci52ZXJpZmllZClcbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcblxuICAgICAgICBlbHNlXG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgIH1cbiAgICAvLyBpZiB0aGUgdXNlcidzIGVtYWlsIGFkZHJlc3MgaXMgbm90IHZlcmlmaWVkLCB0aGV5IGNhbiBvbmx5IGNyZWF0ZSAxIHBhdHRlcm5cbiAgICBlbHNlXG4gICAge1xuICAgICAgaWYgKGNvdW50IDwgTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5tYXhfcGF0dGVybnNfcGVyX3VzZXIuZGVmYXVsdClcbiAgICAgICAgcmV0dXJuIHRydWU7XG5cbiAgICAgIGVsc2UgXG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH0sLypcbiAgLy8gdGhpcyBpcyBubyBsb25nZXIgdXNlZCBiZWNhdXNlIHRoZSBmaWxlIHJlYWQgc2VlbWVkIHRvIGZhaWwgc29tZXRpbWVzLiBUaGUgZnVuY3Rpb24gaXMgbGVmdCBpbiBhcyBhIHJlZmVyZW5jZSBmb3IgcmVhZGluZyBhIEpTT04gZmlsZS5cbiAgcmVhZF9kZWZhdWx0X3BhdHRlcm46IGZ1bmN0aW9uKCkge1xuICAgIC8vIHJldHVybiB0aGUgZGVmYXVsdF90dXJuaW5nX3BhdHRlcm4uanNvblxuICAgIGlmICghTWV0ZW9yLnVzZXJJZCgpKSB7XG4gICAgICAvLyBPbmx5IGxvZ2dlZCBpbiB1c2VycyBjYW4gY3JlYXRlIHBhdHRlcm5zXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibm90LWF1dGhvcml6ZWRcIiwgXCJZb3UgbXVzdCBiZSBzaWduZWQgaW4gdG8gcmVhZCBkZWZhdWx0IHBhdHRlcm4gZGF0YVwiKTtcbiAgICB9XG5cbiAgICB0cnkge1xuICAgICAgdmFyIGRhdGEgPSBKU09OLnBhcnNlKEFzc2V0cy5nZXRUZXh0KFwiZGVmYXVsdF9wYXR0ZXJuX2RhdGEuanNvblwiKSk7XG4gICAgcmV0dXJuIGRhdGE7XG4gICAgICBcbiAgICAgIFxuICAgIH1cbiAgICBjYXRjaChlKVxuICAgIHtcbiAgICAgIC8vcmV0dXJuIC0xO1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcImZpbGUtbG9hZC1mYWlsZWRcIiwgXCJGaWxlIGxvYWQgZXJyb3IgaW4gcmVhZF9kZWZhdWx0X3BhdHRlcm5cIik7XG4gICAgfVxuICB9LCovXG4gIG5ld19wYXR0ZXJuX2Zyb21fanNvbjogZnVuY3Rpb24ob3B0aW9ucykge1xuICAgIC8vIG9wdGlvbnNcbiAgICAvKiB7XG4gICAgICBuYW1lOiBcInBhdHRlcm4gbmFtZVwiLCAvL29wdGlvbmFsXG4gICAgICBkYXRhOiBqc29uIGRhdGEgb2JqZWN0LFxuICAgIH0gKi9cblxuICAgIC8vIGlmIG51bWJlcl9vZl90YWJsZXRzIGFuZCBudW1iZXJfb2Zfcm93cyBhcmUgYm90aCBzcGVjaWZpZWQsIGEgYmxhbmsgcGF0dGVybiB3aWxsIGJlIGJ1aWx0IHdpdGggc3R5bGUgMSBmb3IgYWxsIHdlYXZpbmcgYW5kIHRocmVhZGluZyBjZWxsc1xuICAgIC8vY29uc29sZS5sb2coJ25ldyBwYXR0ZXJuIGZyb20gSlNPTiAxJyk7XG4gICAgLy9jb25zb2xlLmxvZyhgb3B0aW9ucyAke0pTT04uc3RyaW5naWZ5KG9wdGlvbnMpfWApO1xuICAgIGNoZWNrKG9wdGlvbnMsIHtcbiAgICAgIGVkaXRfbW9kZTogTWF0Y2guT3B0aW9uYWwoU3RyaW5nKSxcbiAgICAgIG51bWJlcl9vZl90YWJsZXRzOiBNYXRjaC5PcHRpb25hbChTdHJpbmcpLFxuICAgICAgbnVtYmVyX29mX3Jvd3M6IE1hdGNoLk9wdGlvbmFsKFN0cmluZyksXG4gICAgICBuYW1lOiBNYXRjaC5PcHRpb25hbChTdHJpbmcpLFxuICAgICAgZGF0YTogT2JqZWN0LFxuICAgICAgdHdpbGxfZGlyZWN0aW9uOiBNYXRjaC5PcHRpb25hbChTdHJpbmcpLFxuICAgIH0pO1xuXG4gICAgaWYgKCFNZXRlb3IuaXNTZXJ2ZXIpIC8vIG1pbmltb25nbyBjYW5ub3Qgc2ltdWxhdGUgbG9hZGluZyBkYXRhIHdpdGggQXNzZXRzXG4gICAgICAgIHJldHVybjtcblxuICAgIGlmICghTWV0ZW9yLnVzZXJJZCgpKSB7XG4gICAgICAvLyBPbmx5IGxvZ2dlZCBpbiB1c2VycyBjYW4gY3JlYXRlIHBhdHRlcm5zXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibm90LWF1dGhvcml6ZWRcIiwgXCJZb3UgbXVzdCBiZSBzaWduZWQgaW4gdG8gY3JlYXRlIGEgbmV3IHBhdHRlcm5cIik7XG4gICAgfVxuXG4gICAgdmFyIHJlc3VsdCA9IE1ldGVvci5jYWxsKCdjYW5fY3JlYXRlX3BhdHRlcm4nKTtcbiAgICBpZiAoIXJlc3VsdClcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJub3QtYXV0aG9yaXplZFwiLCBcIllvdSBtYXkgbm90IGNyZWF0ZSBhbnkgbW9yZSBwYXR0ZXJuc1wiKTtcblxuICAgIGlmICh0eXBlb2Ygb3B0aW9ucy5kYXRhICE9PSBcInVuZGVmaW5lZFwiKVxuICAgIHtcbiAgICAgIHZhciBkYXRhID0gb3B0aW9ucy5kYXRhO1xuICAgIH1cbiAgICBlbHNlIGlmICh0eXBlb2Ygb3B0aW9ucy5maWxlbmFtZSAhPT0gXCJ1bmRlZmluZWRcIilcbiAgICB7XG4gICAgICB0cnkge1xuICAgICAgICB2YXIgZGF0YSA9IEpTT04ucGFyc2UoQXNzZXRzLmdldFRleHQob3B0aW9ucy5maWxlbmFtZSkpO1xuICAgICAgfVxuICAgICAgY2F0Y2goZSlcbiAgICAgIHtcbiAgICAgICAgLy9yZXR1cm4gLTE7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJmaWxlLWxvYWQtZmFpbGVkXCIsIFwiRmlsZSBsb2FkIGVycm9yIGluIG5ld19wYXR0ZXJuX2Zyb21fanNvblwiKTtcbiAgICAgIH1cbiAgICB9XG4gICAgZWxzZVxuICAgIHtcbiAgICAgIC8vcmV0dXJuIC0xO1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcImZpbGUtbG9hZC1mYWlsZWRcIiwgXCJGaWxlIGxvYWQgZXJyb3IgaW4gbmV3X3BhdHRlcm5fZnJvbV9qc29uXCIpO1xuICAgIH1cblxuICAgIC8vIGNoZWNrIHZlcnNpb25cbiAgICB2YXIgdmVyc2lvbiA9IFswLDBdO1xuICAgIGlmICh0eXBlb2YgZGF0YS52ZXJzaW9uICE9PSBcInVuZGVmaW5lZFwiKVxuICAgIHtcbiAgICAgIHZhciBzcGxpdF92ZXJzaW9uID0gZGF0YS52ZXJzaW9uLnNwbGl0KFwiLlwiKTsgLy8gW21haW4sIHN1YnNpZGlhcnldIGUuZy4gMi4xXG4gICAgICBpZiAodHlwZW9mIHNwbGl0X3ZlcnNpb25bMF0gIT09IFwidW5kZWZpbmVkXCIpXG4gICAgICB7XG4gICAgICAgIHZlcnNpb25bMF0gPSBwYXJzZUludChzcGxpdF92ZXJzaW9uWzBdKTtcblxuICAgICAgICBpZiAodHlwZW9mIHNwbGl0X3ZlcnNpb25bMV0gIT09IFwidW5kZWZpbmVkXCIpXG4gICAgICAgIHtcbiAgICAgICAgICB2ZXJzaW9uWzFdID0gcGFyc2VJbnQoc3BsaXRfdmVyc2lvblsxXSk7XG4gICAgICAgIH1cbiAgICAgIH0gXG4gICAgfVxuXG4gICAgLy8gZWRpdF9tb2RlIFwiZnJlZWhhbmRcIiAoZGVmYXVsdCksIFwic2ltdWxhdGlvblwiIG9yIFwiYnJva2VuX3R3aWxsXCJcbiAgICBpZigob3B0aW9ucy5lZGl0X21vZGUgPT0gXCJcIikgfHwgKHR5cGVvZiBvcHRpb25zLmVkaXRfbW9kZSA9PT0gXCJ1bmRlZmluZWRcIikpXG4gICAgICBvcHRpb25zLmVkaXRfbW9kZSA9IFwiZnJlZWhhbmRcIjsgLy8gZWFybGllciBkYXRhIHZlcnNpb25cblxuICAgIGlmKChkYXRhLmVkaXRfbW9kZSA9PSBcIlwiKSB8fCAodHlwZW9mIGRhdGEuZWRpdF9tb2RlID09PSBcInVuZGVmaW5lZFwiKSlcbiAgICAgIGRhdGEuZWRpdF9tb2RlID0gb3B0aW9ucy5lZGl0X21vZGU7XG5cbiAgICAvLyBOdW1iZXJzIG9mIHJvd3MgYW5kIHRhYmxldHNcbiAgICAvLyBoYXZlIGJvdGggcm93cyBhbmQgdGFibGV0cyBiZWVuIHNwZWNpZmllZCBhcyBwb3NpdGl2ZSBpbnRlZ2VycyBsZXNzIHRoYW4gMTAwP1xuICAgIHZhciBidWlsZF9uZXcgPSB0cnVlOyAvLyB3aGV0aGVyIHRvIGJ1aWxkIGEgYmxhbmsgcGF0dGVybiB1c2luZyBhIHNwZWNpZmllZCBudW1iZXIgb2YgdGFibGV0cyBhbmQgcm93c1xuICAgIGlmICgodHlwZW9mIG9wdGlvbnMubnVtYmVyX29mX3RhYmxldHMgIT09IFwidW5kZWZpbmVkXCIpICYmICh0eXBlb2Ygb3B0aW9ucy5udW1iZXJfb2Zfcm93cyAhPT0gXCJ1bmRlZmluZWRcIikpXG4gICAge1xuICAgICAgdmFyIHRhYmxldHMgPSBwYXJzZUludChvcHRpb25zLm51bWJlcl9vZl90YWJsZXRzKTtcblxuICAgICAgaWYgKGlzTmFOKHRhYmxldHMpKVxuICAgICAgICBidWlsZF9uZXcgPSBmYWxzZTtcblxuICAgICAgZWxzZSBpZiAoKHRhYmxldHMgPDEpIHx8ICh0YWJsZXRzID4gMTAwKSlcbiAgICAgICAgYnVpbGRfbmV3ID0gZmFsc2U7XG5cbiAgICAgIHZhciByb3dzID0gcGFyc2VJbnQob3B0aW9ucy5udW1iZXJfb2Zfcm93cyk7XG5cbiAgICAgIGlmICgocm93cyA8MSkgfHwgKHJvd3MgPiAxMDApKVxuICAgICAgICBpZiAob3B0aW9ucy5lZGl0X21vZGUgIT0gXCJzaW11bGF0aW9uXCIpIC8vIHNpbXVsYXRpb24gcGF0dGVybiBidWlsZHMgaXRzIG93biB3ZWF2aW5nIGNoYXJ0XG4gICAgICAgICAgYnVpbGRfbmV3ID0gZmFsc2U7XG4gICAgfVxuICAgIGVsc2VcbiAgICB7XG4gICAgICBidWlsZF9uZXcgPSBmYWxzZTtcbiAgICB9XG5cbiAgICBpZiAoYnVpbGRfbmV3KVxuICAgIHtcbiAgICAgIC8vIGJ1aWxkIHBhdHRlcm4gZGF0YVxuICAgICAgc3dpdGNoKG9wdGlvbnMuZWRpdF9tb2RlKSB7XG4gICAgICAgIGNhc2UgXCJmcmVlaGFuZFwiOlxuICAgICAgICAgIGRhdGEucHJldmlld19yb3RhdGlvbiA9IFwibGVmdFwiO1xuICAgICAgICAgIGJyZWFrO1xuXG4gICAgICAgIGNhc2UgXCJzaW11bGF0aW9uXCI6XG4gICAgICAgICAgZGF0YS5wcmV2aWV3X3JvdGF0aW9uID0gXCJ1cFwiO1xuICAgICAgICAgIGJyZWFrO1xuXG4gICAgICAgIGNhc2UgXCJicm9rZW5fdHdpbGxcIjpcbiAgICAgICAgICBkYXRhLnByZXZpZXdfcm90YXRpb24gPSBcInVwXCI7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICB9XG5cbiAgICAgIC8vIHdlYXZpbmdcbiAgICAgIGRhdGEud2VhdmluZyA9IG5ldyBBcnJheSgpO1xuXG4gICAgICBmb3IgKHZhciBpPTA7IGk8b3B0aW9ucy5udW1iZXJfb2Zfcm93czsgaSsrKVxuICAgICAge1xuICAgICAgICBkYXRhLndlYXZpbmdbaV0gPSBuZXcgQXJyYXkoKTtcbiAgICAgICAgZm9yICh2YXIgaj0wOyBqPG9wdGlvbnMubnVtYmVyX29mX3RhYmxldHM7IGorKylcbiAgICAgICAge1xuICAgICAgICAgIGRhdGEud2VhdmluZ1tpXVtqXSA9ICgoaiAlIDIpID09IDApID8gNSA6NjtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAob3B0aW9ucy5lZGl0X21vZGUgPT0gXCJicm9rZW5fdHdpbGxcIikge1xuICAgICAgICBkYXRhLndlYXZpbmdfc3RhcnRfcm93ID0gMTtcbiAgICAgIH1cblxuICAgICAgLy8gdGhyZWFkaW5nXG4gICAgICBkYXRhLnRocmVhZGluZyA9IG5ldyBBcnJheShvcHRpb25zLm51bWJlcl9vZl9yb3dzKTtcblxuICAgICAgLy8gZGVmYXVsdCB0aHJlYWRpbmcgaXMgc3R5bGUgMSBmb3IgYmFja2dyb3VuZCwgc3R5bGUgMiBmb3IgZm9yZWdyb3VuZFxuICAgICAgY29uc3QgYnJva2VuX3R3aWxsX3RocmVhZGluZyA9IFtcbiAgICAgICAgWzIsMiwxLDJdLFxuICAgICAgICBbMiwxLDEsMV0sXG4gICAgICAgIFsxLDEsMiwxXSxcbiAgICAgICAgWzEsMiwyLDJdXG4gICAgICBdO1xuXG4gICAgICBmb3IgKHZhciBpPTA7IGk8NDsgaSsrKVxuICAgICAge1xuICAgICAgICBkYXRhLnRocmVhZGluZ1tpXSA9IG5ldyBBcnJheShvcHRpb25zLm51bWJlcl9vZl90YWJsZXRzKTtcbiAgICAgICAgZm9yICh2YXIgaj0wOyBqPG9wdGlvbnMubnVtYmVyX29mX3RhYmxldHM7IGorKylcbiAgICAgICAge1xuICAgICAgICAgIGlmIChkYXRhLmVkaXRfbW9kZSA9PSBcImZyZWVoYW5kXCIpXG4gICAgICAgICAgICBkYXRhLnRocmVhZGluZ1tpXVtqXSA9ICgoaiAlIDIpID09IDApID8gNSA6NjsgLy8gbWFudWFsbHkgc2V0IHRocmVhZGluZyB0byBzaG93IHdhcnAgZGlyZWN0aW9uXG5cbiAgICAgICAgICBlbHNlIGlmIChkYXRhLmVkaXRfbW9kZSA9PSBcInNpbXVsYXRpb25cIilcbiAgICAgICAgICAgIGRhdGEudGhyZWFkaW5nW2ldW2pdID0gMjsgLy8gcGxhaW4geWVsbG93IGluIGRlZmF1bHQgcGF0dGVyblxuXG4gICAgICAgICAgLy8gdHdvIGxpZ2h0LCB0d28gZGFyaywgb2Zmc2V0IGFsb25nIHRhYmxldHNcbiAgICAgICAgICBlbHNlIGlmIChkYXRhLmVkaXRfbW9kZSA9PSBcImJyb2tlbl90d2lsbFwiKVxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGRhdGEudGhyZWFkaW5nW2ldW2pdID0gYnJva2VuX3R3aWxsX3RocmVhZGluZ1tpXVtqJTRdO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBvcmllbnRhdGlvblxuICAgICAgZGF0YS5vcmllbnRhdGlvbiA9IG5ldyBBcnJheShudW1iZXJfb2ZfdGFibGV0cyk7XG4gICAgICBmb3IgKHZhciBpPTA7IGk8b3B0aW9ucy5udW1iZXJfb2ZfdGFibGV0czsgaSsrKVxuICAgICAge1xuICAgICAgICBpZiAoZGF0YS5lZGl0X21vZGUgPT0gXCJicm9rZW5fdHdpbGxcIilcbiAgICAgICAgICBkYXRhLm9yaWVudGF0aW9uW2ldID0gXCJTXCI7XG4gICAgICAgIGVsc2VcbiAgICAgICAgIGRhdGEub3JpZW50YXRpb25baV0gPSAoaSAlIDIgPT0gMCkgPyBcIlNcIiA6IFwiWlwiO1xuICAgICAgfVxuICAgIH1cbiAgICBlbHNlIGlmICh0eXBlb2YgZGF0YS50aHJlYWRpbmdbMF0gPT09IFwidW5kZWZpbmVkXCIpIC8vIG5vIHJvd3Mgb2YgdGhyZWFkaW5nIGhhdmUgYmVlbiBkZWZpbmVkXG4gICAge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIm5vLXRocmVhZGluZy1kYXRhXCIsIFwiZXJyb3IgY3JlYXRpbmcgcGF0dGVybiBmcm9tIEpTT04uIE5vIHRocmVhZGluZyBkYXRhXCIpO1xuICAgIH1cblxuICAgIHZhciBudW1iZXJfb2Zfcm93cyA9IGRhdGEud2VhdmluZy5sZW5ndGg7XG4gICAgdmFyIG51bWJlcl9vZl90YWJsZXRzID0gZGF0YS50aHJlYWRpbmdbMF0ubGVuZ3RoOyAvLyB0aGVyZSBtYXkgYmUgbm8gd2VhdmluZyByb3dzIGJ1dCB0aGVyZSBtdXN0IGJlIHRocmVhZGluZ1xuXG4gICAgLy8gdHJ5IHRvIHByZXZlbnQgaHVnZSBwYXR0ZXJucyB0aGF0IHdvdWxkIGZpbGwgdXAgdGhlIGRhdGFiYXNlXG4gICAgaWYgKG51bWJlcl9vZl9yb3dzID4gTWV0ZW9yLnNldHRpbmdzLnByaXZhdGUubWF4X3BhdHRlcm5fcm93cylcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJ0b28tbWFueS1yb3dzXCIsIFwiZXJyb3IgY3JlYXRpbmcgcGF0dGVybiBmcm9tIEpTT04uIFRvbyBtYW55IHJvd3MuXCIpO1xuXG4gICAgaWYgKG51bWJlcl9vZl90YWJsZXRzID4gTWV0ZW9yLnNldHRpbmdzLnByaXZhdGUubWF4X3BhdHRlcm5fdGFibGV0cylcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJ0b28tbWFueS10YWJsZXRzXCIsIFwiZXJyb3IgY3JlYXRpbmcgcGF0dGVybiBmcm9tIEpTT04uIFRvbyBtYW55IHRhYmxldHMuXCIpO1xuXG4gICAgaWYob3B0aW9ucy5uYW1lID09IFwiXCIpXG4gICAgICBvcHRpb25zLm5hbWUgPSBNZXRlb3IubXlfcGFyYW1zLmRlZmF1bHRfcGF0dGVybl9uYW1lO1xuXG4gICAgZGF0YS5uYW1lID0gb3B0aW9ucy5uYW1lO1xuXG4gICAgLy8gdGFnc1xuICAgIGlmICh0eXBlb2YgZGF0YS50YWdzID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICBkYXRhLnRhZ3MgPSBbXTtcbiAgICB9XG5cbiAgICBpZiAoZGF0YS5lZGl0X21vZGUgPT0gXCJicm9rZW5fdHdpbGxcIikge1xuICAgICAgZGF0YS50YWdzLnB1c2goJzMvMSBicm9rZW4gdHdpbGwnKTtcbiAgICB9XG5cbiAgICB2YXIgZGVzY3JpcHRpb24gPVwiXCI7XG4gICAgaWYgKHR5cGVvZiBkYXRhLmRlc2NyaXB0aW9uICE9PSBcInVuZGVmaW5lZFwiKVxuICAgICAgZGVzY3JpcHRpb24gPSBkYXRhLmRlc2NyaXB0aW9uO1xuXG4gICAgdmFyIHdlYXZpbmdfbm90ZXMgPSBcIlwiO1xuICAgIGlmICh0eXBlb2YgZGF0YS53ZWF2aW5nX25vdGVzICE9PSBcInVuZGVmaW5lZFwiKVxuICAgICAgd2VhdmluZ19ub3RlcyA9IGRhdGEud2VhdmluZ19ub3RlcztcblxuICAgIHZhciB3ZWZ0X2NvbG9yID0gTWV0ZW9yLnNldHRpbmdzLnByaXZhdGUuZGVmYXVsdF93ZWZ0X2NvbG9yO1xuICAgIGlmICh0eXBlb2YgZGF0YS53ZWZ0X2NvbG9yICE9PSBcInVuZGVmaW5lZFwiKVxuICAgICAgd2VmdF9jb2xvciA9IGRhdGEud2VmdF9jb2xvcjtcblxuICAgIGlmICh0eXBlb2YgZGF0YS5wcmV2aWV3X3JvdGF0aW9uID09PSBcInVuZGVmaW5lZFwiKVxuICAgICAgZGF0YS5wcmV2aWV3X3JvdGF0aW9uID0gXCJsZWZ0XCI7XG5cbiAgICB2YXIgdGhyZWFkaW5nX25vdGVzID0gXCJcIjtcbiAgICBpZiAodHlwZW9mIGRhdGEudGhyZWFkaW5nX25vdGVzICE9PSBcInVuZGVmaW5lZFwiKVxuICAgICAgdGhyZWFkaW5nX25vdGVzID0gZGF0YS50aHJlYWRpbmdfbm90ZXM7XG5cbiAgICB2YXIgcGF0dGVybl9pZCA9IFBhdHRlcm5zLmluc2VydCh7XG4gICAgICBuYW1lOiBkYXRhLm5hbWUsXG4gICAgICBlZGl0X21vZGU6IGRhdGEuZWRpdF9tb2RlLFxuICAgICAgZGVzY3JpcHRpb246IGRlc2NyaXB0aW9uLFxuICAgICAgd2VhdmluZ19ub3Rlczogd2VhdmluZ19ub3RlcyxcbiAgICAgIHByZXZpZXdfcm90YXRpb246IGRhdGEucHJldmlld19yb3RhdGlvbixcbiAgICAgIHdlZnRfY29sb3I6IHdlZnRfY29sb3IsXG4gICAgICB0aHJlYWRpbmdfbm90ZXM6IHRocmVhZGluZ19ub3RlcyxcbiAgICAgIHByaXZhdGU6IHRydWUsIC8vIHBhdHRlcm5zIGFyZSBwcml2YXRlIGJ5IGRlZmF1bHQgc28gdGhlIHVzZXIgY2FuIGVkaXQgdGhlbSBiZWZvcmUgcmV2ZWFsaW5nIHRoZW0gdG8gdGhlIHdvcmxkXG4gICAgICBudW1iZXJfb2Zfcm93czogbnVtYmVyX29mX3Jvd3MsXG4gICAgICBudW1iZXJfb2ZfdGFibGV0czogbnVtYmVyX29mX3RhYmxldHMsXG4gICAgICBjcmVhdGVkX2F0OiBtb21lbnQoKS52YWx1ZU9mKCksICAgICAgICAgICAgLy8gY3VycmVudCB0aW1lXG4gICAgICBjcmVhdGVkX2J5OiBNZXRlb3IudXNlcklkKCksICAgICAgICAgICAvLyBfaWQgb2YgbG9nZ2VkIGluIHVzZXJcbiAgICAgIGNyZWF0ZWRfYnlfdXNlcm5hbWU6IE1ldGVvci51c2VyKCkudXNlcm5hbWUgIC8vIHVzZXJuYW1lIG9mIGxvZ2dlZCBpbiB1c2VyXG4gICAgfSk7XG5cbiAgICBpZiAoZGF0YS53ZWF2aW5nX3N0YXJ0X3Jvdykge1xuICAgIFBhdHRlcm5zLnVwZGF0ZSh7X2lkOiBwYXR0ZXJuX2lkfSwgeyRzZXQ6IHt3ZWF2aW5nX3N0YXJ0X3JvdzogZGF0YS53ZWF2aW5nX3N0YXJ0X3Jvd319KTtcbiAgICB9XG5cbiAgICAvLyBUYWdzXG4gICAgZm9yICh2YXIgaT0wOyBpPGRhdGEudGFncy5sZW5ndGg7IGkrKylcbiAgICB7XG4gICAgICBQYXR0ZXJucy5hZGRUYWcoZGF0YS50YWdzW2ldLCB7IF9pZDogcGF0dGVybl9pZCB9KTtcbiAgICB9XG5cbiAgICAvLyBTdHlsZXNcbiAgICB2YXIgc3R5bGVzX2FycmF5ID0gW107XG5cbiAgICBpZiAoZGF0YS5lZGl0X21vZGUgPT0gXCJzaW11bGF0aW9uXCIgfHwgZGF0YS5lZGl0X21vZGUgPT0gXCJicm9rZW5fdHdpbGxcIikgLy8gcGFsZXR0ZSBzaG93cyA3IHJlZ3VsYXIgc3R5bGVzIGZvciB0aHJlYWRpbmcuIFRoZSBvdGhlciAzMiBhcmUgdXNlZCB0byBhdXRvbWF0aWNhbGx5IGJ1aWxkIHRoZSB3ZWF2aW5nIGNoYXJ0OiA0IHBlciB0aHJlYWRpbmcgc3R5bGVzIHRvIHNob3cgUy9aIGFuZCB0dXJuIGZvcndhcmRzLCBiYWNrd2FyZHNcbiAgICAvLyBpbiAzLzEgYnJva2VuIHR3aWxsIG9ubHkgdHdvIHRocmVhZCBjb2xvdXJzIG1heSBiZSBzZXQgYnV0IGl0J3MgZWFzaWVyIHRvIHN0aWNrIHdpdGggdGhlIHNhbWUgc3R5bGVzXG4gICAge1xuICAgICAgdmFyIHN0eWxlcztcblxuICAgICAgaWYgKHR5cGVvZiBkYXRhLnNpbXVsYXRpb25fc3R5bGVzICE9PSBcInVuZGVmaW5lZFwiKVxuICAgICAgICBzdHlsZXMgPSBkYXRhLnNpbXVsYXRpb25fc3R5bGVzOyAvLyBuZXcgcGF0dGVyblxuICAgICAgZWxzZSBpZiAodHlwZW9mIGRhdGEuc3R5bGVzICE9PSBcInVuZGVmaW5lZFwiKVxuICAgICAgICBzdHlsZXMgPSBkYXRhLnN0eWxlczsgLy8gY29weSBvZiBleGlzdGluZyBwYXR0ZXJuIEpTT05cbiAgICAgIGVsc2VcbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIm5vLXN0eWxlcy1kYXRhXCIsIFwiZXJyb3IgY3JlYXRpbmcgcGF0dGVybiBmcm9tIEpTT04uIE5vIHN0eWxlcyBkYXRhLlwiKTtcblxuICAgICAgZm9yICh2YXIgaT0wOyBpPHN0eWxlcy5sZW5ndGg7IGkrKylcbiAgICAgIHtcbiAgICAgICAgc3R5bGVzX2FycmF5W2ldID0gc3R5bGVzW2ldO1xuICAgICAgfVxuICAgIH1cbiAgICBlbHNlIGlmIChkYXRhLmVkaXRfbW9kZSA9PSBcImZyZWVoYW5kXCIpIC8vIDMyIHZpc2libGUgc3R5bGVzIGZvciBtYW51YWxseSBkcmF3aW5nIHRocmVhZGluZyBhbmQgd2VhdmluZyBjaGFydHNcbiAgICB7XG4gICAgICBmb3IgKHZhciBpPTA7IGk8MzI7IGkrKykgLy8gY3JlYXRlIDMyIHN0eWxlc1xuICAgICAge1xuICAgICAgICBzdHlsZXNfYXJyYXlbaV0gPSBkYXRhLnN0eWxlc1tpXTtcblxuICAgICAgICAvLyB2ZXJzaW9uIDEgaGFzIHN0eWxlLmJhY2t3YXJkX3N0cm9rZSwgc3R5bGUuZm9yd2FyZF9zdHJva2VcbiAgICAgICAgLy8gY29udmVydCB0byAyK1xuICAgICAgICAvLyBzdHlsZS5zdHJva2UgXCJmb3J3YXJkXCIgXCJiYWNrd2FyZFwiIFwibm9uZSAob3RoZXIgdmFsdWVzIHBvc3NpYmxlIGluIDIrKVxuICAgICAgICBcbiAgICAgICAgaWYgKGRhdGEuc3R5bGVzW2ldLmJhY2t3YXJkX3N0cm9rZSlcbiAgICAgICAgICBkYXRhLnN0eWxlc1tpXS53YXJwID0gXCJiYWNrd2FyZFwiO1xuICAgICAgICAgIFxuICAgICAgICBpZiAoZGF0YS5zdHlsZXNbaV0uZm9yd2FyZF9zdHJva2UpIC8vIGlmIGJvdGggZGVmaW5lZCwgY2hvb3NlIGZvcndhcmRcbiAgICAgICAgICBkYXRhLnN0eWxlc1tpXS53YXJwID0gXCJmb3J3YXJkXCI7XG4gICAgICAgICAgXG4gICAgICAgIGRlbGV0ZSBkYXRhLnN0eWxlc1tpXS5iYWNrd2FyZF9zdHJva2U7XG4gICAgICAgIGRlbGV0ZSBkYXRhLnN0eWxlc1tpXS5mb3J3YXJkX3N0cm9rZTtcblxuICAgICAgICBpZiAodHlwZW9mIGRhdGEuc3R5bGVzW2ldLndhcnAgPT09IFwidW5kZWZpbmVkXCIpXG4gICAgICAgICAgZGF0YS5zdHlsZXNbaV0ud2FycCA9IFwibm9uZVwiO1xuICAgICAgfVxuICAgIH1cblxuXG4gICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDoge3N0eWxlczogSlNPTi5zdHJpbmdpZnkoc3R5bGVzX2FycmF5KX19KTtcblxuICAgIC8vIFNwZWNpYWwgc3R5bGVzXG4gICAgdmFyIHNwZWNpYWxfc3R5bGVzX2FycmF5ID0gW107XG4gICAgaWYgKHR5cGVvZiBkYXRhLnNwZWNpYWxfc3R5bGVzID09PSBcInVuZGVmaW5lZFwiKVxuICAgICAgZGF0YS5zcGVjaWFsX3N0eWxlcyA9IFtdO1xuXG4gICAgZm9yICh2YXIgaT0wOyBpPE1ldGVvci5teV9wYXJhbXMuc3BlY2lhbF9zdHlsZXNfbnVtYmVyOyBpKyspXG4gICAge1xuICAgICAgc3BlY2lhbF9zdHlsZXNfYXJyYXlbaV0gPSBkYXRhLnNwZWNpYWxfc3R5bGVzW2ldO1xuICAgIH1cbiAgICBQYXR0ZXJucy51cGRhdGUoe19pZDogcGF0dGVybl9pZH0sIHskc2V0OiB7c3BlY2lhbF9zdHlsZXM6IEpTT04uc3RyaW5naWZ5KHNwZWNpYWxfc3R5bGVzX2FycmF5KX19KTtcblxuICAgIC8vIFBhdHRlcm5cbiAgICB2YXIgd2VhdmluZyA9IG5ldyBBcnJheShudW1iZXJfb2Zfcm93cyk7XG4gICAgZm9yICh2YXIgaT0wOyBpPG51bWJlcl9vZl9yb3dzOyBpKyspXG4gICAge1xuICAgICAgd2VhdmluZ1tpXSA9IG5ldyBBcnJheShudW1iZXJfb2ZfdGFibGV0cyk7XG5cbiAgICAgIGZvciAodmFyIGo9MDsgajxudW1iZXJfb2ZfdGFibGV0czsgaisrKVxuICAgICAge1xuICAgICAgICB3ZWF2aW5nW2ldW2pdID0gZGF0YS53ZWF2aW5nW2ldW2pdO1xuICAgICAgfVxuICAgIH1cblxuICAgIFBhdHRlcm5zLnVwZGF0ZSh7X2lkOiBwYXR0ZXJuX2lkfSwgeyRzZXQ6IHt3ZWF2aW5nOiBKU09OLnN0cmluZ2lmeSh3ZWF2aW5nKX19KTtcblxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAgIGlmIChkYXRhLmVkaXRfbW9kZSA9PSBcInNpbXVsYXRpb25cIilcbiAgICB7XG4gICAgICAvLyBhdXRvIG9yIG1hbnVhbC4gTmV3IHBhdHRlcm5zIGRlZmF1bHQgdG8gXCJmcmVlaGFuZFwiLiBQYXR0ZXJucyBmcm9tIEpTT04gbWF5IGJlIGVpdGhlci5cbiAgICAgIGlmKChkYXRhLnNpbXVsYXRpb25fbW9kZSA9PSBcIlwiKSB8fCAodHlwZW9mIGRhdGEuc2ltdWxhdGlvbl9tb2RlID09PSBcInVuZGVmaW5lZFwiKSlcbiAgICAgICAgZGF0YS5zaW11bGF0aW9uX21vZGUgPSBcImF1dG9cIjtcblxuICAgICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDoge3NpbXVsYXRpb25fbW9kZTogZGF0YS5zaW11bGF0aW9uX21vZGV9fSk7XG5cbiAgICAgIC8vIGF1dG8gYW5kIG1hbnVhbCB0dXJuIHNlcXVlbmNlcyBleGlzdCBzbyB0aGUgdXNlciBjYW4gc3dpdGNoIGJldHdlZW4gdGhlbSB3aXRob3V0IGxvc2luZyBkYXRhXG4gICAgICAvLyB0cmFjayBjdXJyZW50IHJvdGF0aW9uIG9mIGVhY2ggdGFibGV0XG4gICAgICBpZih0eXBlb2YgZGF0YS5wb3NpdGlvbl9vZl9BID09PSBcInVuZGVmaW5lZFwiKVxuICAgICAge1xuICAgICAgICBkYXRhLnBvc2l0aW9uX29mX0EgPSBuZXcgQXJyYXkoKTtcbiAgICAgICAgZm9yICh2YXIgaT0wOyBpPG51bWJlcl9vZl90YWJsZXRzOyBpKyspXG4gICAgICAgIHtcbiAgICAgICAgICBkYXRhLnBvc2l0aW9uX29mX0EucHVzaCgwKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBQYXR0ZXJucy51cGRhdGUoe19pZDogcGF0dGVybl9pZH0sIHskc2V0OiB7cG9zaXRpb25fb2ZfQTogSlNPTi5zdHJpbmdpZnkoZGF0YS5wb3NpdGlvbl9vZl9BKX19KTtcblxuICAgICAgLy8gYXV0b190dXJuX3NlcXVlbmNlIGUuZy4gRkZGRkJCQkJcbiAgICAgIGlmKHR5cGVvZiBkYXRhLmF1dG9fdHVybl9zZXF1ZW5jZSA9PT0gXCJ1bmRlZmluZWRcIilcbiAgICAgICAgZGF0YS5hdXRvX3R1cm5fc2VxdWVuY2UgPSBbXCJGXCIsXCJGXCIsXCJGXCIsXCJGXCIsXCJCXCIsXCJCXCIsXCJCXCIsXCJCXCJdOyAvLyBkZWZhdWx0IHRvIDQgZm9yd2FyZCwgNCBiYWNrXG5cbiAgICAgIFBhdHRlcm5zLnVwZGF0ZSh7X2lkOiBwYXR0ZXJuX2lkfSwgeyRzZXQ6IHthdXRvX3R1cm5fc2VxdWVuY2U6IGRhdGEuYXV0b190dXJuX3NlcXVlbmNlfX0pO1xuXG4gICAgICAvLyBtYW51YWxfd2VhdmluZ190dXJucywgNCBwYWNrcyBlYWNoIHRhYmxldCB0dXJuZWQgaW5kaXZpZHVhbGx5XG4gICAgICAvLyBjcmVhdGUgcm93IDAgd2hpY2ggaXMgbmV2ZXIgd292ZW4sIGl0IGlzIGEgZGVmYXVsdCBhbmQgd29ya2luZyByb3dcbiAgICAgIC8vIGFjdHVhbCB3ZWF2aW5nIGJlZ2lucyB3aXRoIHJvdyAxLCAyLi4uXG4gICAgICBpZigoZGF0YS5tYW51YWxfd2VhdmluZ190dXJucyA9PSBcIlwiKSB8fCAodHlwZW9mIGRhdGEubWFudWFsX3dlYXZpbmdfdHVybnMgPT09IFwidW5kZWZpbmVkXCIpKVxuICAgICAgICBkYXRhLm1hbnVhbF93ZWF2aW5nX3R1cm5zID0gW107XG5cbiAgICAgICAgdmFyIG5ld190dXJuID0ge1xuICAgICAgICAgIHRhYmxldHM6IFtdLCAvLyBmb3IgZWFjaCB0YWJsZXQsIHRoZSBwYWNrIG51bWJlclxuICAgICAgICAgIHBhY2tzOiBbXSAvLyB0dXJuaW5nIGluZm8gZm9yIGVhY2ggcGFja1xuICAgICAgICB9XG5cbiAgICAgICAgZm9yICh2YXIgaT0xOyBpPD1NZXRlb3IubXlfcGFyYW1zLm51bWJlcl9vZl9wYWNrczsgaSsrKVxuICAgICAgICB7XG4gICAgICAgICAgdmFyIHBhY2sgPSB7XG4gICAgICAgICAgICBwYWNrX251bWJlcjogaSxcbiAgICAgICAgICAgIG51bWJlcl9vZl90dXJuczogMVxuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoaSA9PSAyKSB7XG4gICAgICAgICAgICBwYWNrLmRpcmVjdGlvbiA9IFwiQlwiOyAvLyBzdWdnZXN0ZWQgdXNhZ2UgaXMgcGFjayAxIEYsIHBhY2sgMiBCLiBQYWNrIDMgRiBmb3IgYm9yZGVycy5cbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcGFjay5kaXJlY3Rpb24gPSBcIkZcIjtcbiAgICAgICAgICB9XG4gICAgICAgICAgbmV3X3R1cm4ucGFja3MucHVzaChwYWNrKTtcbiAgICAgICAgfVxuICAgICAgICAgIFxuICAgICAgICBmb3IgKHZhciBqPTA7IGo8bnVtYmVyX29mX3RhYmxldHM7IGorKylcbiAgICAgICAge1xuICAgICAgICAgIG5ld190dXJuLnRhYmxldHMucHVzaCgxKTsgLy8gYWxsIHRhYmxldHMgc3RhcnQgaW4gcGFjayAxXG4gICAgICAgIH1cblxuICAgICAgICBkYXRhLm1hbnVhbF93ZWF2aW5nX3R1cm5zWzBdID0gbmV3X3R1cm47XG4gICAgICAgIFBhdHRlcm5zLnVwZGF0ZSh7X2lkOiBwYXR0ZXJuX2lkfSwgeyRzZXQ6IHttYW51YWxfd2VhdmluZ190dXJuczogSlNPTi5zdHJpbmdpZnkoZGF0YS5tYW51YWxfd2VhdmluZ190dXJucyl9fSk7XG5cbiAgICAgIC8qXG4gICAgICA0IHBhY2tzLCBlYWNoIHRhYmxldCBpbiBvbmUgcGFja1xuICAgICAgZm9yIGVhY2ggcGFjaywgZWFjaCBwaWNrOiB0dXJuIGRpcmVjdGlvbiwgbnVtYmVyIG9mIHR1cm5zIDAsMSwyLDNcbiAgICAgIGV4cG9ydCBKU09OLCBpbXBvcnQgSlNPTlxuXG4gICAgICB1c2UgdGhpcyB0byBidWlsZCB3ZWF2aW5nIGNoYXJ0IGR5bmFtaWNhbGx5XG4gICAgICAqL1xuICAgIH0gZWxzZSBpZiAoZGF0YS5lZGl0X21vZGUgPT0gXCJicm9rZW5fdHdpbGxcIikge1xuXG4gICAgICBpZiAodHlwZW9mIG9wdGlvbnMudHdpbGxfZGlyZWN0aW9uICE9PSBcInVuZGVmaW5lZFwiKVxuICAgICAge1xuICAgICAgICAvLyBuZXcgcGF0dGVyblxuICAgICAgICB2YXIgdHdpbGxfZGlyZWN0aW9uID0gb3B0aW9ucy50d2lsbF9kaXJlY3Rpb247XG5cbiAgICAgICAgLy8gMy8xIHR3aWxsIG11c3QgaGF2ZSBhbiBldmVuIG51bWJlciBvZiByb3dzXG4gICAgICAgIGlmIChvcHRpb25zLm51bWJlcl9vZl9yb3dzICUgMiA9PSAxKVxuICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJvZGQtdHdpbGwtcm93c1wiLCBcImVycm9yIGNyZWF0aW5nIHBhdHRlcm4gZnJvbSBKU09OLiAzLzEgYnJva2VuIHR3aWxsIHBhdHRlcm4gbXVzdCBoYXZlIGV2ZW4gbnVtYmVyIG9mIHJvd3NcIik7XG5cbiAgICAgICAgdmFyIHR3aWxsX3BhdHRlcm5fY2hhcnQgPSBbXTtcbiAgICAgICAgLy8gY29ycmVzcG9uZHMgdG8gRGF0YSBpbiBHVFQgcGF0dGVybi4gVGhpcyBpcyB0aGUgY2hhcnQgc2hvd2luZyB0aGUgdHdvLWNvbG91ciBkZXNpZ24uXG5cbiAgICAgICAgdmFyIHR3aWxsX2NoYW5nZV9jaGFydCA9IFtdO1xuICAgICAgICAvLyBjb3JyZXNwb25kcyB0byBMb25nRmxvYXRzIGluIEdUVCBwYXR0ZXJuLiBUaGlzIGlzIHRoZSBjaGFydCBzaG93aW5nICdiYWNrc3RlcHMnIGluIHRoZSB0dXJuaW5nIHNjaGVkdWxlIHRvIGFkanVzdCBmb3Igc21vb3RoIGRpYWdvbmFsIGVkZ2VzLlxuXG4gICAgICAgIC8vIHNldCB1cCBhIHBsYWluIGNoYXJ0IGZvciBlYWNoLCB0aGlzIHdpbGwgZ2l2ZSBqdXN0IGJhY2tncm91bmQgdHdpbGxcbiAgICAgICAgLy8gY2hhcnRzIGhhdmUgYW4gZXh0cmEgcm93IGF0IHRoZSBlbmRcbiAgICAgICAgLy8gdGhpcyBleHRyYSByb3cgaXMgbm90IHNob3duIGluIHByZXZpZXcgb3Igd2VhdmluZyBjaGFydCBidXQgaXMgdXNlZCB0byBkZXRlcm1pbmUgdGhlIGxhc3QgZXZlbiByb3dcbiAgICAgICAgZm9yICh2YXIgaT0wOyBpPChvcHRpb25zLm51bWJlcl9vZl9yb3dzIC8gMikgKyAxOyBpKyspXG4gICAgICAgIHtcbiAgICAgICAgICB0d2lsbF9wYXR0ZXJuX2NoYXJ0W2ldID0gbmV3IEFycmF5KCk7XG4gICAgICAgICAgdHdpbGxfY2hhbmdlX2NoYXJ0W2ldID0gbmV3IEFycmF5KCk7XG5cbiAgICAgICAgICBmb3IgKHZhciBqPTA7IGo8b3B0aW9ucy5udW1iZXJfb2ZfdGFibGV0czsgaisrKVxuICAgICAgICAgIHtcbiAgICAgICAgICAgIHR3aWxsX3BhdHRlcm5fY2hhcnRbaV1bal0gPSBcIi5cIjtcbiAgICAgICAgICAgIHR3aWxsX2NoYW5nZV9jaGFydFtpXVtqXSA9IFwiLlwiO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgZWxzZSBpZiAodHlwZW9mIG9wdGlvbnMuZGF0YS50d2lsbF9kaXJlY3Rpb24gIT09IFwidW5kZWZpbmVkXCIpXG4gICAgICB7XG4gICAgICAgIC8vIGxvYWRlZCBmcm9tIEpTT04gZmlsZVxuICAgICAgICB2YXIgdHdpbGxfZGlyZWN0aW9uID0gb3B0aW9ucy5kYXRhLnR3aWxsX2RpcmVjdGlvbjtcblxuICAgICAgICB2YXIgdHdpbGxfcGF0dGVybl9jaGFydCA9IEpTT04ucGFyc2Uob3B0aW9ucy5kYXRhLnR3aWxsX3BhdHRlcm5fY2hhcnQpO1xuICAgICAgICAvLyBjb3JyZXNwb25kcyB0byBEYXRhIGluIEdUVCBwYXR0ZXJuLiBUaGlzIGlzIHRoZSBjaGFydCBzaG93aW5nIHRoZSB0d28tY29sb3VyIGRlc2lnbi5cblxuICAgICAgICB2YXIgdHdpbGxfY2hhbmdlX2NoYXJ0ID0gSlNPTi5wYXJzZShvcHRpb25zLmRhdGEudHdpbGxfY2hhbmdlX2NoYXJ0KTtcbiAgICAgICAgLy8gY29ycmVzcG9uZHMgdG8gTG9uZ0Zsb2F0cyBpbiBHVFQgcGF0dGVybi4gVGhpcyBpcyB0aGUgY2hhcnQgc2hvd2luZyAnYmFja3N0ZXBzJyBpbiB0aGUgdHVybmluZyBzY2hlZHVsZSB0byBhZGp1c3QgZm9yIHNtb290aCBkaWFnb25hbCBlZGdlcy5cbiAgICAgIH1cbiAgICAgIGVsc2VcbiAgICAgIHtcbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIm5vLXR3aWxsLWRpcmVjdGlvblwiLCBcImVycm9yIGNyZWF0aW5nIHBhdHRlcm4gZnJvbSBKU09OLiBObyB0d2lsbCBkaXJlY3Rpb24gZm9yIDMvMSBicm9rZW4gdHdpbGwgcGF0dGVyblwiKTtcbiAgICAgIH1cblxuICAgICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDoge3R3aWxsX2RpcmVjdGlvbjogdHdpbGxfZGlyZWN0aW9ufX0pO1xuICAgICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDoge3R3aWxsX3BhdHRlcm5fY2hhcnQ6IEpTT04uc3RyaW5naWZ5KHR3aWxsX3BhdHRlcm5fY2hhcnQpfX0pO1xuICAgICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDoge3R3aWxsX2NoYW5nZV9jaGFydDogSlNPTi5zdHJpbmdpZnkodHdpbGxfY2hhbmdlX2NoYXJ0KX19KTtcbiAgICB9XG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG5cbiAgICAvLyBUaHJlYWRpbmdcbiAgICB2YXIgdGhyZWFkaW5nID0gbmV3IEFycmF5KDQpO1xuICAgIGZvciAodmFyIGk9MDsgaTwgNDsgaSsrKVxuICAgIHtcbiAgICAgIHRocmVhZGluZ1tpXSA9IG5ldyBBcnJheShudW1iZXJfb2ZfdGFibGV0cyk7XG5cbiAgICAgIGZvciAodmFyIGo9MDsgajxudW1iZXJfb2ZfdGFibGV0czsgaisrKVxuICAgICAge1xuICAgICAgICB0aHJlYWRpbmdbaV1bal0gPSBkYXRhLnRocmVhZGluZ1tpXVtqXTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBQYXR0ZXJucy51cGRhdGUoe19pZDogcGF0dGVybl9pZH0sIHskc2V0OiB7dGhyZWFkaW5nOiBKU09OLnN0cmluZ2lmeSh0aHJlYWRpbmcpfX0pO1xuXG4gICAgLy8gT3JpZW50YXRpb25cbiAgICB2YXIgb3JpZW50YXRpb24gPSBuZXcgQXJyYXkobnVtYmVyX29mX3RhYmxldHMpO1xuICAgIGZvciAodmFyIGk9MDsgaTxudW1iZXJfb2ZfdGFibGV0czsgaSsrKVxuICAgIHtcbiAgICAgIG9yaWVudGF0aW9uW2ldID0gZGF0YS5vcmllbnRhdGlvbltpXTtcbiAgICB9XG5cbiAgICAvLyBjb3VudCBwdWJsaWMgcGF0dGVybnMgYXMgYSBzYWZldHkgY2hlY2sgKG5ldyBwYXR0ZXJucyBhcmUgcHJpdmF0ZSBieSBkZWZhdWx0IHNvIGl0IHNob3VsZG4ndCBtYWtlIGFueSBkaWZmZXJlbmNlKS5cbiAgICBNZXRlb3IuY2FsbChcImNvdW50X3B1YmxpY19wYXR0ZXJuc1wiLCBNZXRlb3IudXNlcklkKCkpO1xuXG4gICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDoge29yaWVudGF0aW9uOiBKU09OLnN0cmluZ2lmeShvcmllbnRhdGlvbil9fSk7XG4gICAgdmFyIHBhdHRlcm4gPSBQYXR0ZXJucy5maW5kT25lKHtfaWQ6IHBhdHRlcm5faWR9KTtcblxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4gICAgLy9cbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuXG4gICAgcmV0dXJuIHBhdHRlcm5faWQ7XG4gIH0sXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgLy8gTmV3OiBjcmVhdGUgY29sbGVjdGlvbiBkYXRhIGZyb20gYW4gZXhpc3RpbmcgZHluYW1pYyBhcnJheXNcbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICBjcmVhdGVfbmV3X2RhdGFfZnJvbV9hcnJheXM6IGZ1bmN0aW9uKHBhdHRlcm5faWQsIHdlYXZpbmdfZGF0YSkge1xuICAgIGNoZWNrKHBhdHRlcm5faWQsIFN0cmluZyk7XG4gICAgY2hlY2sod2VhdmluZ19kYXRhLCBBcnJheSk7XG5cbiAgICB2YXIgcGF0dGVybiA9IFBhdHRlcm5zLmZpbmRPbmUoe19pZDogcGF0dGVybl9pZH0sIHtmaWVsZHM6IHtjcmVhdGVkX2J5OiAxfX0pO1xuXG4gICAgaWYgKHBhdHRlcm4uY3JlYXRlZF9ieSAhPSBNZXRlb3IudXNlcklkKCkpXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibm90LWF1dGhvcml6ZWRcIiwgXCJZb3UgY2FuIG9ubHkgY3JlYXRlIGRhdGEgZm9yIHBhdHRlcm5zIHRoYXQgeW91IGNyZWF0ZWRcIik7XG4gIH0sXG4gIHhtbDJqczogZnVuY3Rpb24oZGF0YSkge1xuICAgIC8vIHVzZSB4bWwyanMgcGFja2FnZSB0byBjb252ZXJ0IFhNTCB0byBKU09OXG4gICAgLy8gc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9MZW9uaWRhcy1mcm9tLVhJVi9ub2RlLXhtbDJqcyBmb3IgZG9jdW1lbnRhdGlvbiBvZiB4bWwyanNcbiAgICBjaGVjayhkYXRhLCBTdHJpbmcpO1xuXG4gICAgdmFyIGNvbnZlcnRBc3luY1RvU3luYyAgPSBNZXRlb3Iud3JhcEFzeW5jKCB4bWwyanMucGFyc2VTdHJpbmcgKSxcbiAgICAgIHJlc3VsdE9mQXN5bmNUb1N5bmMgPSBjb252ZXJ0QXN5bmNUb1N5bmMoIGRhdGEsIHt9ICk7IC8vIHt9IHdvdWxkIGJlICd0aGlzJyBjb250ZXh0IGlmIHJlcXVpcmVkXG4gICAgcmV0dXJuIHJlc3VsdE9mQXN5bmNUb1N5bmM7XG5cbiAgICAvKlxuICAgIHBhY2thZ2U6XG4gICAgaHR0cHM6Ly9naXRodWIuY29tL3BlZXJsaWJyYXJ5L21ldGVvci14bWwyanNcbiAgICBtZXRlb3IgYWRkIHBlZXJsaWJyYXJ5OnhtbDJqc1xuXG4gICAgdXNhZ2U6XG4gICAgaHR0cHM6Ly9naXRodWIuY29tL0xlb25pZGFzLWZyb20tWElWL25vZGUteG1sMmpzXG5cbiAgICB3cmFwYXN5bmMgdHV0b3JpYWw6XG4gICAgaHR0cHM6Ly90aGVtZXRlb3JjaGVmLmNvbS9zbmlwcGV0cy9zeW5jaHJvbm91cy1tZXRob2RzLyN0bWMtdXNpbmctd3JhcGFzeW5jXG5cbiAgICAvLyB1c2FnZSBmcm9tIGNsaWVudDpcbiAgICB2YXIgZGF0YSA9IFwiPHJvb3Q+SGVsbG8geG1sMmpzISBOZXcyPC9yb290PlwiO1xuICAgIE1ldGVvci5jYWxsKCd4bWwyanMnLGRhdGEsIGZ1bmN0aW9uKGVycm9yLCByZXN1bHQpe1xuICAgICAgaWYgKCFlcnJvcikge1xuICAgICAgY29uc29sZS5sb2coXCJnb3QgeG1sIFwiICsgSlNPTi5zdHJpbmdpZnkocmVzdWx0KSk7XG4gICAgICB9XG4gICAgICBlbHNlIHtcbiAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xuICAgICAgfVxuICAgIH0pXG4gICAgKi9cbiAgfSxcbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAvLyBNb2RpZnkgcGF0dGVybnNcbiAgcmVtb3ZlX3BhdHRlcm46IGZ1bmN0aW9uKHBhdHRlcm5faWQpIHtcbiAgICBjaGVjayhwYXR0ZXJuX2lkLCBTdHJpbmcpO1xuXG4gICAgaWYgKCFNZXRlb3IuaXNTZXJ2ZXIpIC8vIGF0dGVtcHQgdG8gYXZvaWQgZXJyb3IgXCJzZXJ2ZXIgc2VudCBhZGQgZm9yIGV4aXN0aW5nIGlkXCJcbiAgICAgICAgcmV0dXJuO1xuXG4gICAgdmFyIHBhdHRlcm4gPSBQYXR0ZXJucy5maW5kT25lKHtfaWQ6IHBhdHRlcm5faWR9LCB7ZmllbGRzOiB7Y3JlYXRlZF9ieTogMX19KTtcblxuICAgIGlmIChwYXR0ZXJuLmNyZWF0ZWRfYnkgIT0gTWV0ZW9yLnVzZXJJZCgpKVxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIm5vdC1hdXRob3JpemVkXCIsIFwiWW91IGNhbiBvbmx5IHJlbW92ZSBwYXR0ZXJucyB0aGF0IHlvdSBjcmVhdGVkXCIpO1xuXG4gICAgLy8gcmVtb3ZlIGZyb20gUGF0dGVybnMgY29sbGVjdGlvblxuICAgIFBhdHRlcm5zLnJlbW92ZShwYXR0ZXJuX2lkKTtcblxuICAgIC8vIHJlbW92ZSBmcm9tIFJlY2VudCBQYXR0ZXJucyBsaXN0XG4gICAgdmFyIHJlY2VudF9wYXR0ZXJucyA9ICh0eXBlb2YgTWV0ZW9yLnVzZXIoKS5wcm9maWxlLnJlY2VudF9wYXR0ZXJucyA9PT0gXCJ1bmRlZmluZWRcIikgPyBbXSA6IE1ldGVvci51c2VyKCkucHJvZmlsZS5yZWNlbnRfcGF0dGVybnM7XG5cbiAgICB2YXIgaW5kZXggPSAtMTtcbiAgICBmb3IgKHZhciBpPTA7IGkgPCByZWNlbnRfcGF0dGVybnMubGVuZ3RoOyBpKyspXG4gICAge1xuICAgICAgaWYgKHJlY2VudF9wYXR0ZXJuc1tpXS5wYXR0ZXJuX2lkID09IHBhdHRlcm5faWQpXG4gICAgICB7XG4gICAgICAgIGluZGV4ID0gaTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKGluZGV4ID4gLTEpIHtcbiAgICAgIHJlY2VudF9wYXR0ZXJucy5zcGxpY2UoaW5kZXgsIDEpO1xuICAgIH1cblxuICAgIHZhciB1cGRhdGUgPSB7fTtcbiAgICB1cGRhdGVbXCJwcm9maWxlLnJlY2VudF9wYXR0ZXJuc1wiXSA9IHJlY2VudF9wYXR0ZXJucztcblxuICAgIE1ldGVvci51c2Vycy51cGRhdGUoe19pZDogTWV0ZW9yLnVzZXJJZCgpfSwgeyRzZXQ6IHVwZGF0ZX0pO1xuXG4gICAgLy8gdXBkYXRlIGNvdW50IG9mIHB1YmxpYyBwYXR0ZXJuc1xuICAgIE1ldGVvci5jYWxsKFwiY291bnRfcHVibGljX3BhdHRlcm5zXCIsIE1ldGVvci51c2VySWQoKSk7XG5cbiAgICAvLyByZW1vdmUgYXNzb2NpYXRlZCBpbWFnZXMgZnJvbSBBV1NcbiAgICBJbWFnZXMuZmluZCh7dXNlZF9ieTogcGF0dGVybl9pZH0pLm1hcChmdW5jdGlvbihpbWFnZSkge1xuICAgICAgTWV0ZW9yLmNhbGwoXCJyZW1vdmVfaW1hZ2VcIiwgaW1hZ2UuX2lkKTtcbiAgICB9KTtcblxuICAgIC8vIHVwZGF0ZSBjb2xsZWN0aW9uIHRoYXQgbGlzdHMgYXNzb2NpYXRlZCBpbWFnZXNcbiAgICBJbWFnZXMucmVtb3ZlKHt1c2VkX2J5OiBwYXR0ZXJuX2lkfSk7XG4gIH0sXG4gIHNldF9wcml2YXRlOiBmdW5jdGlvbiAocGF0dGVybl9pZCwgc2V0X3RvX3ByaXZhdGUpIHtcbiAgICBjaGVjayhwYXR0ZXJuX2lkLCBTdHJpbmcpO1xuICAgIGNoZWNrKHNldF90b19wcml2YXRlLCBCb29sZWFuKTtcblxuICAgIHZhciBwYXR0ZXJuID0gUGF0dGVybnMuZmluZE9uZSh7X2lkOiBwYXR0ZXJuX2lkfSwge2ZpZWxkczoge2NyZWF0ZWRfYnk6IDF9fSk7XG5cbiAgICBpZiAocGF0dGVybi5jcmVhdGVkX2J5ICE9IE1ldGVvci51c2VySWQoKSlcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJub3QtYXV0aG9yaXplZFwiLCBcIllvdSBjYW4gb25seSBjaGFuZ2UgdGhlIHByaXZhY3kgb24gYSBwYXR0ZXJuIHlvdSBjcmVhdGVkXCIpO1xuIFxuICAgIFBhdHRlcm5zLnVwZGF0ZShwYXR0ZXJuX2lkLCB7ICRzZXQ6IHsgcHJpdmF0ZTogc2V0X3RvX3ByaXZhdGUgfSB9KTtcbiAgICBNZXRlb3IuY2FsbChcImNvdW50X3B1YmxpY19wYXR0ZXJuc1wiLCBwYXR0ZXJuLmNyZWF0ZWRfYnkpO1xuICB9LFxuICBjb3VudF9wdWJsaWNfcGF0dGVybnM6IGZ1bmN0aW9uICh1c2VyX2lkKSB7XG4gICAgLy8gbWFpbnRhaW4gYSBjb3VudCBvZiB0aGUgdXNlcidzIHB1YmxpYyBwYXR0ZXJucywgc28gd2UgY2FuIGVhc2lseSBzZWUgd2hpY2ggdXNlcnMgaGF2ZSBwdWJsaWMgcGF0dGVybnNcbiAgICB2YXIgbnVtID0gUGF0dGVybnMuZmluZCh7XG4gICAgJGFuZDogW1xuICAgICAgeyBwcml2YXRlOiB7JG5lOiB0cnVlfSB9LFxuICAgICAgeyBjcmVhdGVkX2J5OiB1c2VyX2lkIH1cbiAgICBdfSkuY291bnQoKTtcblxuICAgIHZhciBwcm9maWxlID0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUoeyBfaWQ6IHVzZXJfaWR9KS5wcm9maWxlO1xuICAgIGlmICh0eXBlb2YgcHJvZmlsZSA9PT0gXCJ1bmRlZmluZWRcIilcbiAgICAgIHByb2ZpbGUgPSB7fTtcbiAgICBcbiAgICBwcm9maWxlW1wicHVibGljX3BhdHRlcm5zX2NvdW50XCJdID0gbnVtO1xuXG4gICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZSh7X2lkOiB1c2VyX2lkfSwgeyRzZXQ6IHtwcm9maWxlOiBwcm9maWxlfX0pO1xuICB9LFxuICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4gIC8vIFN0cmluZ2lmeSBwYXR0ZXJuIGRhdGEgYW5kIHNhdmUgaXRcbiAgc2F2ZV93ZWF2aW5nX3RvX2RiOiBmdW5jdGlvbihwYXR0ZXJuX2lkLCB0ZXh0LCBudW1iZXJfb2Zfcm93cywgbnVtYmVyX29mX3RhYmxldHMpXG4gIHtcbiAgICBjaGVjayhwYXR0ZXJuX2lkLCBTdHJpbmcpO1xuICAgIGNoZWNrKHRleHQsIFN0cmluZyk7XG4gICAgY2hlY2sobnVtYmVyX29mX3Jvd3MsIE51bWJlcik7XG4gICAgY2hlY2sobnVtYmVyX29mX3RhYmxldHMsIE51bWJlcik7XG5cbiAgICB2YXIgcGF0dGVybiA9IFBhdHRlcm5zLmZpbmRPbmUoe19pZDogcGF0dGVybl9pZH0sIHtmaWVsZHM6IHtjcmVhdGVkX2J5OiAxIH19KTtcblxuICAgIGlmIChwYXR0ZXJuLmNyZWF0ZWRfYnkgIT0gTWV0ZW9yLnVzZXJJZCgpKVxuICAgICAgICAvLyBPbmx5IHRoZSBvd25lciBjYW4gZWRpdCBhIHBhdHRlcm5cbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIm5vdC1hdXRob3JpemVkXCIsIFwiWW91IGNhbiBvbmx5IGVkaXQgY2VsbHMgaW4gYSBwYXR0ZXJuIHlvdSBjcmVhdGVkXCIpO1xuXG4gICAgLy8gdHJ5IHRvIHByZXZlbnQgaHVnZSBwYXR0ZXJucyB0aGF0IHdvdWxkIGZpbGwgdXAgdGhlIGRhdGFiYXNlXG4gICAgaWYgKG51bWJlcl9vZl9yb3dzID4gTWV0ZW9yLnNldHRpbmdzLnByaXZhdGUubWF4X3BhdHRlcm5fcm93cylcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJ0b28tbWFueS1yb3dzXCIsIFwiZXJyb3Igc2F2aW5nIHBhdHRlcm4uIFRvbyBtYW55IHJvd3MuXCIpO1xuXG4gICAgaWYgKG51bWJlcl9vZl90YWJsZXRzID4gTWV0ZW9yLnNldHRpbmdzLnByaXZhdGUubWF4X3BhdHRlcm5fdGFibGV0cylcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJ0b28tbWFueS10YWJsZXRzXCIsIFwiZXJyb3Igc2F2aW5nIHBhdHRlcm4uIFRvbyBtYW55IHRhYmxldHMuXCIpO1xuXG4gICAgLy8gU2F2ZSB0aGUgaW5kaXZpZHVhbCBjZWxsIGRhdGFcbiAgICAvLyB2YXIgcGF0dGVybiA9IFBhdHRlcm5zLmZpbmRPbmUoe19pZDogcGF0dGVybl9pZH0pOyAvLyBUT0RPIHJlbW92ZVxuXG4gICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDogeyB3ZWF2aW5nOiB0ZXh0fX0pO1xuXG4gICAgLy8gUmVjb3JkIHRoZSBudW1iZXIgb2Ygcm93c1xuICAgIFBhdHRlcm5zLnVwZGF0ZSh7X2lkOiBwYXR0ZXJuX2lkfSwgeyRzZXQ6IHtudW1iZXJfb2Zfcm93czogbnVtYmVyX29mX3Jvd3N9fSk7XG5cbiAgICAvLyBSZWNvcmQgdGhlIG51bWJlciBvZiB0YWJsZXRzXG4gICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDoge251bWJlcl9vZl90YWJsZXRzOiBudW1iZXJfb2ZfdGFibGV0c319KTtcblxuICAgIC8vIFJlY29yZCB0aGUgZWRpdCB0aW1lXG4gICAgTWV0ZW9yLmNhbGwoXCJzYXZlX3BhdHRlcm5fZWRpdF90aW1lXCIsIHBhdHRlcm5faWQpO1xuICB9LFxuICBzYXZlX251bWJlcl9vZl90YWJsZXRzOiBmdW5jdGlvbihwYXR0ZXJuX2lkLCBudW1iZXJfb2ZfdGFibGV0cylcbiAge1xuICAgIGNoZWNrKHBhdHRlcm5faWQsIFN0cmluZyk7XG4gICAgY2hlY2sobnVtYmVyX29mX3RhYmxldHMsIE51bWJlcik7XG5cbiAgICBQYXR0ZXJucy51cGRhdGUoe19pZDogcGF0dGVybl9pZH0sIHskc2V0OiB7bnVtYmVyX29mX3RhYmxldHM6IG51bWJlcl9vZl90YWJsZXRzfX0pO1xuICB9LFxuICBzYXZlX3ByZXZpZXdfYXNfdGV4dDogZnVuY3Rpb24ocGF0dGVybl9pZCwgZGF0YSlcbiAge1xuICAgIGNoZWNrKHBhdHRlcm5faWQsIFN0cmluZyk7XG4gICAgY2hlY2soZGF0YSwgU3RyaW5nKTtcblxuICAgIFBhdHRlcm5zLnVwZGF0ZSh7X2lkOiBwYXR0ZXJuX2lkfSwgeyRzZXQ6IHthdXRvX3ByZXZpZXc6IGRhdGF9fSk7XG4gIH0sXG4gIHJvdGF0ZV9wcmV2aWV3OiBmdW5jdGlvbihwYXR0ZXJuX2lkKVxuICB7XG4gICAgY2hlY2socGF0dGVybl9pZCwgU3RyaW5nKTtcblxuICAgIHZhciBwYXR0ZXJuID0gUGF0dGVybnMuZmluZE9uZSh7X2lkOiBwYXR0ZXJuX2lkfSwge2ZpZWxkczoge2NyZWF0ZWRfYnk6IDEsIHByZXZpZXdfcm90YXRpb246IDEgfX0pO1xuXG4gICAgaWYgKHR5cGVvZiBwYXR0ZXJuLnByZXZpZXdfcm90YXRpb24gPT09IFwidW5kZWZpbmVkXCIpIC8vIG9sZCBwYXR0ZXJuLCBuZWVkcyB2YWx1ZSBzZXR0aW5nXG4gICAge1xuICAgICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDoge3ByZXZpZXdfcm90YXRpb246IFwibGVmdFwifX0pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChwYXR0ZXJuLmNyZWF0ZWRfYnkgIT0gTWV0ZW9yLnVzZXJJZCgpKVxuICAgICAgICAvLyBPbmx5IHRoZSBvd25lciBjYW4gZWRpdCBhIHBhdHRlcm5cbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIm5vdC1hdXRob3JpemVkXCIsIFwiWW91IGNhbiBvbmx5IGVkaXQgYSBwYXR0ZXJuIHlvdSBjcmVhdGVkXCIpOyAgICAgIFxuXG4gICAgaWYgKHR5cGVvZiBwYXR0ZXJuLnByZXZpZXdfcm90YXRpb24gPT09IFwidW5kZWZpbmVkXCIpXG4gICAgICBQYXR0ZXJucy51cGRhdGUoe19pZDogcGF0dGVybl9pZH0sIHskc2V0OiB7cHJldmlld19yb3RhdGlvbjogXCJsZWZ0XCJ9fSk7XG5cbiAgICBzd2l0Y2gocGF0dGVybi5wcmV2aWV3X3JvdGF0aW9uKVxuICAgIHtcbiAgICAgIGNhc2UgXCJsZWZ0XCI6XG4gICAgICAgIFBhdHRlcm5zLnVwZGF0ZSh7X2lkOiBwYXR0ZXJuX2lkfSwgeyRzZXQ6IHtwcmV2aWV3X3JvdGF0aW9uOiBcInJpZ2h0XCJ9fSk7XG4gICAgICAgIGJyZWFrO1xuXG4gICAgICBjYXNlIFwicmlnaHRcIjpcbiAgICAgICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDoge3ByZXZpZXdfcm90YXRpb246IFwibGVmdFwifX0pO1xuICAgICAgICBicmVhaztcblxuICAgICAgZGVmYXVsdDpcbiAgICAgICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDoge3ByZXZpZXdfcm90YXRpb246IFwibGVmdFwifX0pO1xuICAgIH1cbiAgfSxcbiAgc2V0X3ByZXZpZXdfb3JpZW50YXRpb246IGZ1bmN0aW9uKHBhdHRlcm5faWQsIHJvdGF0aW9uKSB7XG4gICAgY2hlY2socGF0dGVybl9pZCwgU3RyaW5nKTtcbiAgICBjaGVjayhyb3RhdGlvbiwgU3RyaW5nKTtcblxuICAgIHZhciBwYXR0ZXJuID0gUGF0dGVybnMuZmluZE9uZSh7X2lkOiBwYXR0ZXJuX2lkfSwge2ZpZWxkczoge2NyZWF0ZWRfYnk6IDEsIHByZXZpZXdfcm90YXRpb246IDEgfX0pO1xuXG4gICAgaWYgKHBhdHRlcm4uY3JlYXRlZF9ieSAhPSBNZXRlb3IudXNlcklkKCkpXG4gICAgICAgIC8vIE9ubHkgdGhlIG93bmVyIGNhbiBlZGl0IGEgcGF0dGVyblxuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibm90LWF1dGhvcml6ZWRcIiwgXCJZb3UgY2FuIG9ubHkgZWRpdCBhIHBhdHRlcm4geW91IGNyZWF0ZWRcIik7XG5cbiAgICBQYXR0ZXJucy51cGRhdGUoe19pZDogcGF0dGVybl9pZH0sIHskc2V0OiB7cHJldmlld19yb3RhdGlvbjogcm90YXRpb259fSk7XG5cbiAgfSxcbiAgc2F2ZV90aHJlYWRpbmdfdG9fZGI6IGZ1bmN0aW9uKHBhdHRlcm5faWQsIHRleHQpXG4gIHtcbiAgICBjaGVjayhwYXR0ZXJuX2lkLCBTdHJpbmcpO1xuICAgIGNoZWNrKHRleHQsIFN0cmluZyk7XG5cbiAgICB2YXIgcGF0dGVybiA9IFBhdHRlcm5zLmZpbmRPbmUoe19pZDogcGF0dGVybl9pZH0sIHtmaWVsZHM6IHtjcmVhdGVkX2J5OiAxIH19KTtcblxuICAgIGlmIChwYXR0ZXJuLmNyZWF0ZWRfYnkgIT0gTWV0ZW9yLnVzZXJJZCgpKVxuICAgICAgICAvLyBPbmx5IHRoZSBvd25lciBjYW4gZWRpdCBhIHBhdHRlcm5cbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIm5vdC1hdXRob3JpemVkXCIsIFwiWW91IGNhbiBvbmx5IGVkaXQgY2VsbHMgaW4gYSBwYXR0ZXJuIHlvdSBjcmVhdGVkXCIpO1xuXG4gICAgLy8gU2F2ZSB0aGUgaW5kaXZpZHVhbCBjZWxsIGRhdGFcbiAgICBQYXR0ZXJucy51cGRhdGUoe19pZDogcGF0dGVybl9pZH0sIHskc2V0OiB7IHRocmVhZGluZzogdGV4dH19KTtcblxuICAgIC8vIFJlY29yZCB0aGUgZWRpdCB0aW1lXG4gICAgTWV0ZW9yLmNhbGwoXCJzYXZlX3BhdHRlcm5fZWRpdF90aW1lXCIsIHBhdHRlcm5faWQpO1xuXG4gICAgcmV0dXJuO1xuICB9LFxuICBzYXZlX3dlZnRfY29sb3JfdG9fZGI6IGZ1bmN0aW9uKHBhdHRlcm5faWQsIHRleHQpXG4gIHtcbiAgICBjaGVjayhwYXR0ZXJuX2lkLCBTdHJpbmcpO1xuICAgIGNoZWNrKHRleHQsIFN0cmluZyk7XG5cbiAgICB2YXIgcGF0dGVybiA9IFBhdHRlcm5zLmZpbmRPbmUoe19pZDogcGF0dGVybl9pZH0sIHtmaWVsZHM6IHtjcmVhdGVkX2J5OiAxIH19KTtcblxuICAgIGlmIChwYXR0ZXJuLmNyZWF0ZWRfYnkgIT0gTWV0ZW9yLnVzZXJJZCgpKVxuICAgICAgICAvLyBPbmx5IHRoZSBvd25lciBjYW4gZWRpdCBhIHBhdHRlcm5cbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIm5vdC1hdXRob3JpemVkXCIsIFwiWW91IGNhbiBvbmx5IGVkaXQgY2VsbHMgaW4gYSBwYXR0ZXJuIHlvdSBjcmVhdGVkXCIpO1xuXG4gICAgLy8gU2F2ZSB0aGUgaW5kaXZpZHVhbCBjZWxsIGRhdGFcbiAgICBQYXR0ZXJucy51cGRhdGUoe19pZDogcGF0dGVybl9pZH0sIHskc2V0OiB7IHdlZnRfY29sb3I6IHRleHR9fSk7XG5cbiAgICAvLyBSZWNvcmQgdGhlIGVkaXQgdGltZVxuICAgIE1ldGVvci5jYWxsKFwic2F2ZV9wYXR0ZXJuX2VkaXRfdGltZVwiLCBwYXR0ZXJuX2lkKTtcbiAgfSxcbiAgc2F2ZV9vcmllbnRhdGlvbl90b19kYjogZnVuY3Rpb24ocGF0dGVybl9pZCwgdGV4dClcbiAge1xuICAgIGNoZWNrKHBhdHRlcm5faWQsIFN0cmluZyk7XG4gICAgY2hlY2sodGV4dCwgU3RyaW5nKTtcblxuICAgIHZhciBwYXR0ZXJuID0gUGF0dGVybnMuZmluZE9uZSh7X2lkOiBwYXR0ZXJuX2lkfSwge2ZpZWxkczoge2NyZWF0ZWRfYnk6IDEgfX0pO1xuXG4gICAgaWYgKHBhdHRlcm4uY3JlYXRlZF9ieSAhPSBNZXRlb3IudXNlcklkKCkpXG4gICAgICAgIC8vIE9ubHkgdGhlIG93bmVyIGNhbiBlZGl0IGEgcGF0dGVyblxuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibm90LWF1dGhvcml6ZWRcIiwgXCJZb3UgY2FuIG9ubHkgZWRpdCBjZWxscyBpbiBhIHBhdHRlcm4geW91IGNyZWF0ZWRcIik7XG5cbiAgICAvLyBTYXZlIHRoZSBpbmRpdmlkdWFsIGNlbGwgZGF0YVxuICAgIFBhdHRlcm5zLnVwZGF0ZSh7X2lkOiBwYXR0ZXJuX2lkfSwgeyRzZXQ6IHsgb3JpZW50YXRpb246IHRleHR9fSk7XG5cbiAgICAvLyBSZWNvcmQgdGhlIGVkaXQgdGltZVxuICAgIE1ldGVvci5jYWxsKFwic2F2ZV9wYXR0ZXJuX2VkaXRfdGltZVwiLCBwYXR0ZXJuX2lkKTtcbiAgfSxcbiAgc2F2ZV9zdHlsZXNfdG9fZGI6IGZ1bmN0aW9uKHBhdHRlcm5faWQsIHRleHQpXG4gIHtcbiAgICBjaGVjayhwYXR0ZXJuX2lkLCBTdHJpbmcpO1xuICAgIGNoZWNrKHRleHQsIFN0cmluZyk7XG5cbiAgICB2YXIgcGF0dGVybiA9IFBhdHRlcm5zLmZpbmRPbmUoe19pZDogcGF0dGVybl9pZH0sIHtmaWVsZHM6IHtjcmVhdGVkX2J5OiAxIH19KTtcblxuICAgIGlmIChwYXR0ZXJuLmNyZWF0ZWRfYnkgIT0gTWV0ZW9yLnVzZXJJZCgpKVxuICAgICAgICAvLyBPbmx5IHRoZSBvd25lciBjYW4gZWRpdCBhIHBhdHRlcm5cbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIm5vdC1hdXRob3JpemVkXCIsIFwiWW91IGNhbiBvbmx5IGVkaXQgc3R5bGVzIGluIGEgcGF0dGVybiB5b3UgY3JlYXRlZFwiKTtcblxuICAgIC8vIFNhdmUgdGhlIGluZGl2aWR1YWwgY2VsbCBkYXRhXG4gICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDogeyBzdHlsZXM6IHRleHR9fSk7XG5cbiAgICAvLyBSZWNvcmQgdGhlIGVkaXQgdGltZVxuICAgIE1ldGVvci5jYWxsKFwic2F2ZV9wYXR0ZXJuX2VkaXRfdGltZVwiLCBwYXR0ZXJuX2lkKTtcbiAgfSxcbiAgc2F2ZV9tYW51YWxfd2VhdmluZ190dXJuczogZnVuY3Rpb24ocGF0dGVybl9pZCwgdGV4dClcbiAge1xuICAgIGNoZWNrKHBhdHRlcm5faWQsIFN0cmluZyk7XG4gICAgY2hlY2sodGV4dCwgdGV4dCk7XG5cbiAgICB2YXIgcGF0dGVybiA9IFBhdHRlcm5zLmZpbmRPbmUoe19pZDogcGF0dGVybl9pZH0sIHtmaWVsZHM6IHtjcmVhdGVkX2J5OiAxIH19KTtcblxuICAgIGlmIChwYXR0ZXJuLmNyZWF0ZWRfYnkgIT0gTWV0ZW9yLnVzZXJJZCgpKVxuICAgICAgICAvLyBPbmx5IHRoZSBvd25lciBjYW4gZWRpdCBhIHBhdHRlcm5cbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIm5vdC1hdXRob3JpemVkXCIsIFwiWW91IGNhbiBvbmx5IGVkaXQgbWF1YWwgd2VhdmluZyB0dXJucyBpbiBhIHBhdHRlcm4geW91IGNyZWF0ZWRcIik7XG5cbiAgICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDoge21hbnVhbF93ZWF2aW5nX3R1cm5zOiB0ZXh0fX0pOyAgIFxuICB9LFxuICByZXN0b3JlX3BhdHRlcm46IGZ1bmN0aW9uKGRhdGEpXG4gIHtcbiAgICBjaGVjayhkYXRhLCBPYmplY3QpO1xuXG4gICAgdmFyIHBhdHRlcm4gPSBQYXR0ZXJucy5maW5kT25lKHtfaWQ6IGRhdGEuX2lkfSwge2ZpZWxkczoge2NyZWF0ZWRfYnk6IDEgfX0pO1xuXG4gICAgaWYgKHBhdHRlcm4uY3JlYXRlZF9ieSAhPSBNZXRlb3IudXNlcklkKCkpXG4gICAgICAgIC8vIE9ubHkgdGhlIG93bmVyIGNhbiBlZGl0IGEgcGF0dGVyblxuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibm90LWF1dGhvcml6ZWRcIiwgXCJZb3UgY2FuIG9ubHkgcmVzdG9yZSBhIHBhdHRlcm4geW91IGNyZWF0ZWRcIik7XG5cbiAgICAvLyByZWNvbnN0cnVjdCB0aGUgcGF0dGVybiBhY2NvcmRpbmcgdG8gdGhlIGRhdGEsIGUuZy4gZm9yIHVuZG9cbiAgICBNZXRlb3IuY2FsbCgnc2F2ZV93ZWF2aW5nX3RvX2RiJywgZGF0YS5faWQsIEpTT04uc3RyaW5naWZ5KGRhdGEud2VhdmluZyksIGRhdGEubnVtYmVyX29mX3Jvd3MsIGRhdGEubnVtYmVyX29mX3RhYmxldHMpO1xuICAgIE1ldGVvci5jYWxsKCdzYXZlX3RocmVhZGluZ190b19kYicsIGRhdGEuX2lkLCBKU09OLnN0cmluZ2lmeShkYXRhLnRocmVhZGluZykpO1xuICAgIE1ldGVvci5jYWxsKCdzYXZlX29yaWVudGF0aW9uX3RvX2RiJywgZGF0YS5faWQsIEpTT04uc3RyaW5naWZ5KGRhdGEub3JpZW50YXRpb24pKTtcbiAgICBNZXRlb3IuY2FsbCgnc2F2ZV9zdHlsZXNfdG9fZGInLCBkYXRhLl9pZCwgSlNPTi5zdHJpbmdpZnkoZGF0YS5zdHlsZXMpKTtcbiAgICBQYXR0ZXJucy51cGRhdGUoe19pZDogZGF0YS5faWR9LCB7JHVuc2V0OiB7YXV0b19wcmV2aWV3OiBcIlwifX0pOyAvLyBwcmV2aWV3IG11c3QgYmUgcmUtcmVhZCBmcm9tIHRoZSBIVE1MIGFmdGVyIGl0IGhhcyBiZWVuIGJ1aWx0XG4gICAgcmV0dXJuO1xuICB9LFxuICB1cGRhdGVfYWZ0ZXJfdGFibGV0X2NoYW5nZTogZnVuY3Rpb24oZGF0YSkgLy8gcmVxdWlyZWQgdG8gcmVzdG9yZSByZWFjdGl2aXR5IGFmdGVyIHRhYmxldHMgaGF2ZSBiZWVuIGFkZGVkIG9yIHJlbW92ZWRcbiAgLy8gaXQgc2VlbXMgdG8gYmUgbmVjZXNzYXJ5IHRvIGNoYW5nZSB0aGUgZGF0YWJhc2VcbiAge1xuICAgIGNoZWNrKGRhdGEsIE9iamVjdCk7XG5cbiAgICBNZXRlb3IuY2FsbCgnc2F2ZV93ZWF2aW5nX3RvX2RiJywgZGF0YS5faWQsIEpTT04uc3RyaW5naWZ5KGRhdGEud2VhdmluZyksIGRhdGEubnVtYmVyX29mX3Jvd3MsIGRhdGEubnVtYmVyX29mX3RhYmxldHMpO1xuXG4gICAgdmFyIHBhdHRlcm4gPSBQYXR0ZXJucy5maW5kT25lKHtfaWQ6IGRhdGEuX2lkfSwge2ZpZWxkczoge2NyZWF0ZWRfYnk6IDEgfX0pO1xuXG4gICAgaWYgKHBhdHRlcm4uY3JlYXRlZF9ieSAhPSBNZXRlb3IudXNlcklkKCkpXG4gICAgICAgIC8vIE9ubHkgdGhlIG93bmVyIGNhbiBlZGl0IGEgcGF0dGVyblxuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibm90LWF1dGhvcml6ZWRcIiwgXCJZb3UgY2FuIG9ubHkgcmVzdG9yZSBhIHBhdHRlcm4geW91IGNyZWF0ZWRcIik7XG5cbiAgICByZXR1cm47XG4gIH0sXG4gIHNhdmVfcGF0dGVybl9lZGl0X3RpbWU6IGZ1bmN0aW9uKHBhdHRlcm5faWQpXG4gIHtcbiAgICBjaGVjayhwYXR0ZXJuX2lkLCBTdHJpbmcpO1xuXG4gICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDoge3BhdHRlcm5fZWRpdGVkX2F0OiBtb21lbnQoKS52YWx1ZU9mKCl9fSk7XG4gIH0sXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgLy8gRWRpdCBvdGhlciBwYXR0ZXJuIHByb3BlcnRpZXNcbiAgdG9nZ2xlX2hvbGVfaGFuZGVkbmVzczogZnVuY3Rpb24ocGF0dGVybl9pZClcbiAge1xuICAgIGNoZWNrKHBhdHRlcm5faWQsIFN0cmluZyk7XG5cbiAgICB2YXIgcGF0dGVybiA9IFBhdHRlcm5zLmZpbmRPbmUoe19pZDogcGF0dGVybl9pZH0sIHtmaWVsZHM6IHtjcmVhdGVkX2J5OiAxLCBob2xlX2hhbmRlZG5lc3M6IDF9fSk7XG5cbiAgICBpZiAocGF0dGVybi5jcmVhdGVkX2J5ICE9IE1ldGVvci51c2VySWQoKSlcbiAgICAgIC8vIE9ubHkgdGhlIG93bmVyIGNhbiBlZGl0IGEgcGF0dGVyblxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIm5vdC1hdXRob3JpemVkXCIsIFwiWW91IGNhbiBvbmx5IGVkaXQgaG9sZSBoYW5kZWRuZXNzIGZvciBhIHBhdHRlcm4geW91IGNyZWF0ZWRcIik7XG5cbiAgICAvLyBkZWZhdWx0IGlzIGNsb2Nrd2lzZSBpZiBub3Qgb3RoZXJ3aXNlIHNwZWNpZmllZFxuICAgIHZhciBuZXdfdmFsdWUgPSBcImFudGljbG9ja3dpc2VcIjtcbiAgICBpZiAocGF0dGVybi5ob2xlX2hhbmRlZG5lc3MgPT0gXCJhbnRpY2xvY2t3aXNlXCIpXG4gICAgICBuZXdfdmFsdWUgPSBcImNsb2Nrd2lzZVwiO1xuXG4gICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDoge2hvbGVfaGFuZGVkbmVzczogbmV3X3ZhbHVlfX0pO1xuICB9LFxuICBhZGRfcGF0dGVybl90aHVtYm5haWw6IGZ1bmN0aW9uKHBhdHRlcm5faWQsIGZpbGVPYmopXG4gIHtcbiAgICBjb25zb2xlLmxvZyhcImFkZF9wYXR0ZXJuX3RodW1ibmFpbFwiKTtcbiAgICBjb25zb2xlLmxvZyhcImZpbGVPYmoga2V5cyBcIiArIE9iamVjdC5rZXlzKGZpbGVPYmopKTtcbiAgfSxcbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAvLyBFZGl0IHN0eWxlc1xuICBzZXRfcGF0dGVybl9jZWxsX3N0eWxlOiBmdW5jdGlvbihwYXR0ZXJuX2lkLCByb3csIHRhYmxldCwgbmV3X3N0eWxlKVxuICB7XG4gICAgY2hlY2socGF0dGVybl9pZCwgU3RyaW5nKTtcbiAgICBjaGVjayhyb3csIE51bWJlcik7XG4gICAgY2hlY2sodGFibGV0LCBOdW1iZXIpO1xuICAgIGNoZWNrKG5ld19zdHlsZSwgTnVtYmVyKTtcblxuICAgIGlmIChNZXRlb3IuaXNTZXJ2ZXIpXG4gICAge1xuICAgICAgdmFyIHBhdHRlcm4gPSBQYXR0ZXJucy5maW5kT25lKHtfaWQ6IHBhdHRlcm5faWR9LCB7ZmllbGRzOiB7Y3JlYXRlZF9ieTogMX19KTtcblxuICAgICAgaWYgKHBhdHRlcm4uY3JlYXRlZF9ieSAhPSBNZXRlb3IudXNlcklkKCkpXG4gICAgICAgIC8vIE9ubHkgdGhlIG93bmVyIGNhbiBlZGl0IGEgcGF0dGVyblxuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibm90LWF1dGhvcml6ZWRcIiwgXCJZb3UgY2FuIG9ubHkgZWRpdCBjZWxscyBpbiBhIHBhdHRlcm4geW91IGNyZWF0ZWRcIik7XG5cbiAgICAgIC8vIFRoaXMgY29uc3RydWN0aW9uIGFsbG93cyB2YXJpYWJsZSBwcm9wZXJ0aWVzIG9mIHRoZSBkb2N1bWVudCB0byBiZSBzZXRcbiAgICAgIHZhciB1cGRhdGUgPSB7fTtcbiAgICAgIHVwZGF0ZVtcIndlYXZpbmcuXCIgKyByb3cgKyBcIi5cIiArIHRhYmxldCArIFwiLnN0eWxlXCJdID0gbmV3X3N0eWxlO1xuICAgICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDogdXBkYXRlfSk7XG4gICAgfVxuICB9LFxuICBzZXRfdGhyZWFkaW5nX2NlbGxfc3R5bGU6IGZ1bmN0aW9uKHBhdHRlcm5faWQsIGhvbGUsIHRhYmxldCwgbmV3X3N0eWxlKVxuICB7XG4gICAgY2hlY2socGF0dGVybl9pZCwgU3RyaW5nKTtcbiAgICBjaGVjayhob2xlLCBOdW1iZXIpO1xuICAgIGNoZWNrKHRhYmxldCwgTnVtYmVyKTtcbiAgICBjaGVjayhuZXdfc3R5bGUsIE51bWJlcik7XG5cbiAgICBpZiAoTWV0ZW9yLmlzU2VydmVyKVxuICAgIHtcbiAgICAgIHZhciBwYXR0ZXJuID0gUGF0dGVybnMuZmluZE9uZSh7X2lkOiBwYXR0ZXJuX2lkfSwge2ZpZWxkczoge2NyZWF0ZWRfYnk6IDF9fSk7XG5cbiAgICAgIGlmIChwYXR0ZXJuLmNyZWF0ZWRfYnkgIT0gTWV0ZW9yLnVzZXJJZCgpKSB7XG4gICAgICAgIC8vIE9ubHkgdGhlIG93bmVyIGNhbiBlZGl0IGEgcGF0dGVyblxuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibm90LWF1dGhvcml6ZWRcIiwgXCJZb3UgY2FuIG9ubHkgZWRpdCB0aHJlYWRpbmcgaW4gYSBwYXR0ZXJuIHlvdSBjcmVhdGVkXCIpO1xuICAgICAgfVxuXG4gICAgICAvLyBUaGlzIGNvbnN0cnVjdGlvbiBhbGxvd3MgdmFyaWFibGUgcHJvcGVydGllcyBvZiB0aGUgZG9jdW1lbnQgdG8gYmUgc2V0XG4gICAgICB2YXIgdXBkYXRlID0ge307XG4gICAgICB1cGRhdGVbXCJ0aHJlYWRpbmcuXCIgKyBob2xlICsgXCIuXCIgKyB0YWJsZXQgKyBcIi5zdHlsZVwiXSA9IG5ld19zdHlsZTtcbiAgICAgIFBhdHRlcm5zLnVwZGF0ZSh7X2lkOiBwYXR0ZXJuX2lkfSwgeyRzZXQ6IHVwZGF0ZX0pO1xuICAgIH1cbiAgfSxcblxuICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAvLyBTaW11bGF0aW9uIHBhdHRlcm5zXG4gIHVwZGF0ZV9zaW11bGF0aW9uX21vZGU6IGZ1bmN0aW9uKHBhdHRlcm5faWQsIHNpbXVsYXRpb25fbW9kZSkge1xuICAgIHZhciBwYXR0ZXJuID0gUGF0dGVybnMuZmluZE9uZSh7X2lkOiBwYXR0ZXJuX2lkfSwge2ZpZWxkczoge2NyZWF0ZWRfYnk6IDEsIHNpbXVsYXRpb25fbW9kZTogMX19KTtcblxuICAgIGlmIChwYXR0ZXJuLmNyZWF0ZWRfYnkgIT0gTWV0ZW9yLnVzZXJJZCgpKVxuICAgICAgLy8gT25seSB0aGUgb3duZXIgY2FuIGVkaXQgYSBwYXR0ZXJuXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibm90LWF1dGhvcml6ZWRcIiwgXCJZb3UgY2FuIG9ubHkgdXBkYXRlIHNpbXVsYXRpb24gbW9kZSBmb3IgYSBwYXR0ZXJuIHlvdSBjcmVhdGVkXCIpO1xuXG4gICAgaWYgKHBhdHRlcm4uc2ltdWxhdGlvbl9tb2RlID09IHNpbXVsYXRpb25fbW9kZSlcbiAgICAgIHJldHVybjtcblxuICAgIFBhdHRlcm5zLnVwZGF0ZSh7X2lkOiBwYXR0ZXJuX2lkfSwgeyRzZXQ6IHtzaW11bGF0aW9uX21vZGU6IHNpbXVsYXRpb25fbW9kZX19KTtcblxuICAgIFBhdHRlcm5zLnVwZGF0ZSh7X2lkOiBwYXR0ZXJuX2lkfSwgeyRzZXQ6IHt3ZWF2aW5nOiBcIltdXCJ9fSk7XG4gICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDoge251bWJlcl9vZl9yb3dzOiAwfX0pO1xuXG4gIH0sXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgLy8gTWFudWFsIHNpbXVsYXRpb25cbiAgdXBkYXRlX2F1dG9fd2VhdmluZzogZnVuY3Rpb24ocGF0dGVybl9pZCwgZGF0YSlcbiAge1xuICAgIGNoZWNrKGRhdGEsIE9iamVjdCk7XG5cbiAgICBQYXR0ZXJucy51cGRhdGUoe19pZDogcGF0dGVybl9pZH0sIHskc2V0OiB7d2VhdmluZzogZGF0YS53ZWF2aW5nfX0pO1xuICAgICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDoge251bWJlcl9vZl9yb3dzOiBkYXRhLm51bWJlcl9vZl9yb3dzfX0pO1xuICAgICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDoge3Bvc2l0aW9uX29mX0E6IGRhdGEucG9zaXRpb25fb2ZfQX19KTtcbiAgICAgIFBhdHRlcm5zLnVwZGF0ZSh7X2lkOiBwYXR0ZXJuX2lkfSwgeyRzZXQ6IHthdXRvX3R1cm5fdGhyZWFkczogZGF0YS5hdXRvX3R1cm5fdGhyZWFkc319KTtcbiAgfSxcbiAgdXBkYXRlX21hbnVhbF93ZWF2aW5nOiBmdW5jdGlvbihwYXR0ZXJuX2lkLCBkYXRhKVxuICB7XG4gICAgY2hlY2socGF0dGVybl9pZCwgU3RyaW5nKTtcbiAgICBjaGVjayhkYXRhLCBPYmplY3QpO1xuXG4gICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDoge3Bvc2l0aW9uX29mX0E6IEpTT04uc3RyaW5naWZ5KGRhdGEucG9zaXRpb25fb2ZfQSl9fSk7XG4gICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDoge3dlYXZpbmc6IEpTT04uc3RyaW5naWZ5KGRhdGEud2VhdmluZyl9fSk7XG4gICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDoge251bWJlcl9vZl9yb3dzOiBkYXRhLndlYXZpbmcubGVuZ3RofX0pO1xuICAgIFBhdHRlcm5zLnVwZGF0ZSh7X2lkOiBwYXR0ZXJuX2lkfSwgeyRzZXQ6IHttYW51YWxfd2VhdmluZ190dXJuczogSlNPTi5zdHJpbmdpZnkoZGF0YS5tYW51YWxfd2VhdmluZ190dXJucyl9fSk7XG4gICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDoge21hbnVhbF93ZWF2aW5nX3RocmVhZHM6IGRhdGEubWFudWFsX3dlYXZpbmdfdGhyZWFkc319KTtcbiAgfSxcbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgLy8gYXV0byBzaW11bGF0aW9uIHBhdHRlcm4gVUlcbiAgc2V0X2F1dG9fbnVtYmVyX29mX3R1cm5zOiBmdW5jdGlvbihwYXR0ZXJuX2lkLCBhdXRvX3R1cm5fc2VxdWVuY2UpXG4gIHtcbiAgICBjaGVjayhwYXR0ZXJuX2lkLCBTdHJpbmcpO1xuICAgIGNoZWNrKGF1dG9fdHVybl9zZXF1ZW5jZSwgW1N0cmluZ10pO1xuXG4gICAgdmFyIG51bV9hdXRvX3R1cm5zID0gYXV0b190dXJuX3NlcXVlbmNlLmxlbmd0aFxuXG4gICAgaWYgKChudW1fYXV0b190dXJucyA8IDEpIHx8IChudW1fYXV0b190dXJucyA+IE1ldGVvci5teV9wYXJhbXMubWF4X2F1dG9fdHVybnMpKVxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIm5vdC12YWxpZFwiLCBcIk51bWJlciBvZiB0dXJucyBleGNlZWRzIHRoZSBhbGxvd2VkIG1heGltdW1cIik7XG5cbiAgICBpZiAobnVtX2F1dG9fdHVybnMgPCAxKVxuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibm90LXZhbGlkXCIsIFwiWW91IGNhbm5vdCBoYXZlIDAgdHVybnMgaW4gdGhlIHNlcXVlbmNlXCIpO1xuXG4gICAgdmFyIHBhdHRlcm4gPSBQYXR0ZXJucy5maW5kT25lKHtfaWQ6IHBhdHRlcm5faWR9LCB7ZmllbGRzOiB7Y3JlYXRlZF9ieTogMSwgYXV0b190dXJuX3NlcXVlbmNlOiAxfX0pO1xuXG4gICAgaWYgKHBhdHRlcm4uY3JlYXRlZF9ieSAhPSBNZXRlb3IudXNlcklkKCkpXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibm90LWF1dGhvcml6ZWRcIiwgXCJZb3UgY2FuIG9ubHkgdXBkYXRlIG51bWJlciBvZiB0dXJucyBmb3IgYSBwYXR0ZXJuIHlvdSBjcmVhdGVkXCIpO1xuXG4gICAgICBQYXR0ZXJucy51cGRhdGUoe19pZDogcGF0dGVybl9pZH0sIHskc2V0OiB7YXV0b190dXJuX3NlcXVlbmNlOiBhdXRvX3R1cm5fc2VxdWVuY2V9fSk7XG4gIH0sXG4gIHRvZ2dsZV90dXJuX2RpcmVjdGlvbjogZnVuY3Rpb24ocGF0dGVybl9pZCwgdHVybl9udW1iZXIpIHtcbiAgICAvLyB0b2dnbGUgZGlyZWN0aW9uIG9mIGEgdHVybiBvZiBhdXRvIHR1cm5pbmcsIGZvciBzaW11bGF0aW9uIHBhdHRlcm5cbiAgICBjaGVjayhwYXR0ZXJuX2lkLCBTdHJpbmcpO1xuICAgIGNoZWNrKHR1cm5fbnVtYmVyLCBOdW1iZXIpO1xuXG4gICAgdmFyIHBhdHRlcm4gPSBQYXR0ZXJucy5maW5kT25lKHtfaWQ6IHBhdHRlcm5faWR9LCB7ZmllbGRzOiB7Y3JlYXRlZF9ieTogMSwgYXV0b190dXJuX3NlcXVlbmNlOiAxfX0pO1xuXG4gICAgaWYgKHBhdHRlcm4uY3JlYXRlZF9ieSAhPSBNZXRlb3IudXNlcklkKCkpXG4gICAgICAvLyBPbmx5IHRoZSBvd25lciBjYW4gZWRpdCBhIHBhdHRlcm5cbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJub3QtYXV0aG9yaXplZFwiLCBcIllvdSBjYW4gb25seSB1cGRhdGUgdHVybiBkaXJlY3Rpb24gZm9yIGEgcGF0dGVybiB5b3UgY3JlYXRlZFwiKTtcblxuICAgIHZhciBhdXRvX3R1cm5fc2VxdWVuY2UgPSBwYXR0ZXJuLmF1dG9fdHVybl9zZXF1ZW5jZTtcbiAgICB2YXIgZGlyZWN0aW9uID0gYXV0b190dXJuX3NlcXVlbmNlW3R1cm5fbnVtYmVyIC0gMV07XG5cbiAgICBpZiAoZGlyZWN0aW9uID09IFwiRlwiKVxuICAgICAgZGlyZWN0aW9uID0gXCJCXCI7XG5cbiAgICBlbHNlXG4gICAgICBkaXJlY3Rpb24gPSBcIkZcIjtcblxuICAgIGF1dG9fdHVybl9zZXF1ZW5jZVt0dXJuX251bWJlciAtIDFdID0gZGlyZWN0aW9uO1xuXG4gICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDoge2F1dG9fdHVybl9zZXF1ZW5jZTogYXV0b190dXJuX3NlcXVlbmNlfX0pO1xuXG4gICAgLy8gUmVjb3JkIHRoZSBlZGl0IHRpbWVcbiAgICBNZXRlb3IuY2FsbChcInNhdmVfcGF0dGVybl9lZGl0X3RpbWVcIiwgcGF0dGVybl9pZCk7XG4gIH0sXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4gIC8vIEJyb2tlbiB0d2lsbFxuICB1cGRhdGVfdHdpbGxfcGF0dGVybl9jaGFydDogZnVuY3Rpb24ocGF0dGVybl9pZCwgZGF0YSlcbiAge1xuICAgIGNoZWNrKHBhdHRlcm5faWQsIFN0cmluZyk7XG4gICAgY2hlY2soZGF0YSwgT2JqZWN0KTtcblxuICAgIFBhdHRlcm5zLnVwZGF0ZSh7X2lkOiBwYXR0ZXJuX2lkfSwgeyRzZXQ6IHt0d2lsbF9wYXR0ZXJuX2NoYXJ0OiBKU09OLnN0cmluZ2lmeShkYXRhLnR3aWxsX3BhdHRlcm5fY2hhcnQpfX0pO1xuXG4gICAgLy8gUmVjb3JkIHRoZSBlZGl0IHRpbWVcbiAgICBNZXRlb3IuY2FsbChcInNhdmVfcGF0dGVybl9lZGl0X3RpbWVcIiwgcGF0dGVybl9pZCk7XG4gIH0sXG4gIHVwZGF0ZV90d2lsbF9jaGFuZ2VfY2hhcnQ6IGZ1bmN0aW9uKHBhdHRlcm5faWQsIGRhdGEpXG4gIHtcbiAgICBjaGVjayhwYXR0ZXJuX2lkLCBTdHJpbmcpO1xuICAgIGNoZWNrKGRhdGEsIE9iamVjdCk7XG5cbiAgICBQYXR0ZXJucy51cGRhdGUoe19pZDogcGF0dGVybl9pZH0sIHskc2V0OiB7dHdpbGxfY2hhbmdlX2NoYXJ0OiBKU09OLnN0cmluZ2lmeShkYXRhLnR3aWxsX2NoYW5nZV9jaGFydCl9fSk7XG5cbiAgICAvLyBSZWNvcmQgdGhlIGVkaXQgdGltZVxuICAgIE1ldGVvci5jYWxsKFwic2F2ZV9wYXR0ZXJuX2VkaXRfdGltZVwiLCBwYXR0ZXJuX2lkKTtcbiAgfSxcbiAgdXBkYXRlX3R3aWxsX2NoYXJ0czogZnVuY3Rpb24ocGF0dGVybl9pZCwgZGF0YSwgbnVtYmVyX29mX3Jvd3MsIG51bWJlcl9vZl90YWJsZXRzKSB7XG4gICAgY2hlY2socGF0dGVybl9pZCwgU3RyaW5nKTtcbiAgICBjaGVjayhkYXRhLCBPYmplY3QpO1xuICAgIGNoZWNrKG51bWJlcl9vZl9yb3dzLCBOdW1iZXIpO1xuICAgIGNoZWNrKG51bWJlcl9vZl90YWJsZXRzLCBOdW1iZXIpO1xuXG4gICAgdmFyIHBhdHRlcm4gPSBQYXR0ZXJucy5maW5kT25lKHtfaWQ6IHBhdHRlcm5faWR9LCB7ZmllbGRzOiB7Y3JlYXRlZF9ieTogMSB9fSk7XG5cbiAgICBpZiAocGF0dGVybi5jcmVhdGVkX2J5ICE9IE1ldGVvci51c2VySWQoKSlcbiAgICAgICAgLy8gT25seSB0aGUgb3duZXIgY2FuIGVkaXQgYSBwYXR0ZXJuXG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJub3QtYXV0aG9yaXplZFwiLCBcIllvdSBjYW4gb25seSBlZGl0IGNlbGxzIGluIGEgcGF0dGVybiB5b3UgY3JlYXRlZFwiKTtcblxuICAgIC8vIHRyeSB0byBwcmV2ZW50IGh1Z2UgcGF0dGVybnMgdGhhdCB3b3VsZCBmaWxsIHVwIHRoZSBkYXRhYmFzZVxuICAgIGlmIChudW1iZXJfb2Zfcm93cyA+IE1ldGVvci5zZXR0aW5ncy5wcml2YXRlLm1heF9wYXR0ZXJuX3Jvd3MpXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwidG9vLW1hbnktcm93c1wiLCBcImVycm9yIHNhdmluZyBwYXR0ZXJuLiBUb28gbWFueSByb3dzLlwiKTtcblxuICAgIGlmIChudW1iZXJfb2ZfdGFibGV0cyA+IE1ldGVvci5zZXR0aW5ncy5wcml2YXRlLm1heF9wYXR0ZXJuX3RhYmxldHMpXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwidG9vLW1hbnktdGFibGV0c1wiLCBcImVycm9yIHNhdmluZyBwYXR0ZXJuLiBUb28gbWFueSB0YWJsZXRzLlwiKTtcblxuICAgIFBhdHRlcm5zLnVwZGF0ZSh7X2lkOiBwYXR0ZXJuX2lkfSwgeyRzZXQ6IHt0d2lsbF9wYXR0ZXJuX2NoYXJ0OiBKU09OLnN0cmluZ2lmeShkYXRhLnR3aWxsX3BhdHRlcm5fY2hhcnQpfX0pO1xuICAgIFBhdHRlcm5zLnVwZGF0ZSh7X2lkOiBwYXR0ZXJuX2lkfSwgeyRzZXQ6IHt0d2lsbF9jaGFuZ2VfY2hhcnQ6IEpTT04uc3RyaW5naWZ5KGRhdGEudHdpbGxfY2hhbmdlX2NoYXJ0KX19KTtcblxuICAgIGlmIChkYXRhLm9yaWVudGF0aW9uKSB7XG4gICAgICBQYXR0ZXJucy51cGRhdGUoe19pZDogcGF0dGVybl9pZH0sIHskc2V0OiB7b3JpZW50YXRpb246IEpTT04uc3RyaW5naWZ5KGRhdGEub3JpZW50YXRpb24pfX0pO1xuICAgIH1cblxuICAgIGlmIChkYXRhLnRocmVhZGluZykge1xuICAgICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IHBhdHRlcm5faWR9LCB7JHNldDoge3RocmVhZGluZzogSlNPTi5zdHJpbmdpZnkoZGF0YS50aHJlYWRpbmcpfX0pO1xuICAgIH1cblxuICAgIC8vIGNvcGllZCBmcm9tIHNhdmVfd2VhdmluZ190b19kYlxuICAgIFBhdHRlcm5zLnVwZGF0ZSh7X2lkOiBwYXR0ZXJuX2lkfSwgeyRzZXQ6IHsgd2VhdmluZzogSlNPTi5zdHJpbmdpZnkoZGF0YS53ZWF2aW5nKX19KTtcblxuICAgIC8vIFJlY29yZCB0aGUgbnVtYmVyIG9mIHJvd3NcbiAgICBQYXR0ZXJucy51cGRhdGUoe19pZDogcGF0dGVybl9pZH0sIHskc2V0OiB7bnVtYmVyX29mX3Jvd3M6IG51bWJlcl9vZl9yb3dzfX0pO1xuXG4gICAgLy8gUmVjb3JkIHRoZSBudW1iZXIgb2YgdGFibGV0c1xuICAgIFBhdHRlcm5zLnVwZGF0ZSh7X2lkOiBwYXR0ZXJuX2lkfSwgeyRzZXQ6IHtudW1iZXJfb2ZfdGFibGV0czogbnVtYmVyX29mX3RhYmxldHN9fSk7XG5cbiAgICAvLyBSZWNvcmQgdGhlIGVkaXQgdGltZVxuICAgIE1ldGVvci5jYWxsKFwic2F2ZV9wYXR0ZXJuX2VkaXRfdGltZVwiLCBwYXR0ZXJuX2lkKTtcblxuICB9LFxuICBzZXRfd2VhdmluZ19zdGFydF9yb3c6IGZ1bmN0aW9uKHBhdHRlcm5faWQsIHJvd19udW1iZXIpIHtcbiAgICBjaGVjayhwYXR0ZXJuX2lkLCBTdHJpbmcpO1xuICAgIGNoZWNrKHJvd19udW1iZXIsIE51bWJlcik7XG5cbiAgICB2YXIgcGF0dGVybiA9IFBhdHRlcm5zLmZpbmRPbmUoe19pZDogcGF0dGVybl9pZH0sIHtmaWVsZHM6IHtjcmVhdGVkX2J5OiAxLCBlZGl0X21vZGU6IDEsIHdlYXZpbmdfc3RhcnRfcm93OiAxLCBudW1iZXJfb2Zfcm93czogMSB9fSk7XG5cbiAgICBpZiAocGF0dGVybi5jcmVhdGVkX2J5ICE9IE1ldGVvci51c2VySWQoKSlcbiAgICAgICAgLy8gT25seSB0aGUgb3duZXIgY2FuIGVkaXQgYSBwYXR0ZXJuXG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJub3QtYXV0aG9yaXplZFwiLCBcIllvdSBjYW4gb25seSBlZGl0IHR3aWxsIHN0YXJ0IHJvdyBpbiBhIHBhdHRlcm4geW91IGNyZWF0ZWRcIik7XG5cbiAgICBpZiAocGF0dGVybi5lZGl0X21vZGUgIT09IFwiYnJva2VuX3R3aWxsXCIpXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibm90LWF1dGhvcml6ZWRcIiwgXCJZb3UgY2FuIG9ubHkgc2V0IHR3aWxsIHN0YXJ0IHJvdyBpbiBhIGJyb2tlbiB0d2lsbCBwYXR0ZXJuXCIpO1xuXG4gICAgcm93X251bWJlciA9IE1hdGguZmxvb3Iocm93X251bWJlcik7XG5cbiAgICBpZiAocm93X251bWJlciA8IDEpXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibm90LWF1dGhvcml6ZWRcIiwgXCJCcm9rZW4gdHdpbGwgc3RhcnQgcm93IG11c3QgYmUgYXQgbGVhc3QgMVwiKTtcblxuICAgIGlmIChyb3dfbnVtYmVyID4gcGF0dGVybi5udW1iZXJfb2Zfcm93cylcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJub3QtYXV0aG9yaXplZFwiLCBcIkJyb2tlbiB0d2lsbCBzdGFydCByb3cgY2Fubm90IGJlIGdyZWF0ZXIgdGhhbiBudW1iZXIgb2Ygcm93c1wiKTtcblxuICAgIC8vIFJlY29yZCB0aGUgbnVtYmVyIG9mIHRhYmxldHNcbiAgICBQYXR0ZXJucy51cGRhdGUoe19pZDogcGF0dGVybl9pZH0sIHskc2V0OiB7d2VhdmluZ19zdGFydF9yb3c6IHJvd19udW1iZXJ9fSk7XG5cbiAgICAvLyBSZWNvcmQgdGhlIGVkaXQgdGltZVxuICAgIE1ldGVvci5jYWxsKFwic2F2ZV9wYXR0ZXJuX2VkaXRfdGltZVwiLCBwYXR0ZXJuX2lkKTtcbiAgfSxcbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgLy8gUmVjZW50IHBhdHRlcm5zXG4gIGFkZF90b19yZWNlbnRfcGF0dGVybnM6IGZ1bmN0aW9uKHBhdHRlcm5faWQpIHtcbiAgICAvLyBBZGQgYSBwYXR0ZXJuIHRvIHRoZSBSZWNlbnRfUGF0dGVybnMgbGlzdCBpbiB0aGUgdXNlcidzIHByb2ZpbGVcbiAgICAvLyBJZiBpdCdzIGFscmVhZHkgaW4gdGhlIGxpc3QsIHVwZGF0ZSB0aGUgYWNjZXNzZWRfYXQgdGltZVxuICAgIGNoZWNrKHBhdHRlcm5faWQsIFN0cmluZyk7XG5cbiAgICBpZiAoIU1ldGVvci51c2VySWQoKSkgLy8gdXNlciBpcyBub3Qgc2lnbmVkIGluXG4gICAgICByZXR1cm47XG5cbiAgICBpZiAodHlwZW9mIFBhdHRlcm5zLmZpbmRPbmUoe19pZDogcGF0dGVybl9pZH0sIHtmaWVsZHM6IHtfaWQ6IDF9fSwge2xpbWl0OiAxfSkgPT09IFwidW5kZWZpbmVkXCIpXG4gICAgICByZXR1cm47IC8vIHRoZSBwYXR0ZXJuIGRvZXNuJ3QgZXhpc3RcblxuICAgIC8vIGNyZWF0ZSBhbiBlbXB0eSBhcnJheSBpZiB0aGVyZSBpcyBubyBleGlzdGluZyBsaXN0IG9mIHJlY2VudCBwYXR0ZXJucyBmb3IgdGhpcyB1c2VyXG4gICAgdmFyIHJlY2VudF9wYXR0ZXJucyA9ICh0eXBlb2YgTWV0ZW9yLnVzZXIoKS5wcm9maWxlLnJlY2VudF9wYXR0ZXJucyA9PT0gXCJ1bmRlZmluZWRcIikgPyBbXSA6IE1ldGVvci51c2VyKCkucHJvZmlsZS5yZWNlbnRfcGF0dGVybnM7XG5cbiAgICB2YXIgcmVjZW50X3BhdHRlcm4gPSB7XG4gICAgICBwYXR0ZXJuX2lkOiBwYXR0ZXJuX2lkLFxuICAgICAgYWNjZXNzZWRfYXQ6IG1vbWVudCgpLnZhbHVlT2YoKSwgICAgICAgICAgICAvLyBjdXJyZW50IHRpbWVcbiAgICAgIGN1cnJlbnRfd2VhdmVfcm93OiAxLFxuICAgIH1cblxuICAgIC8vIGlzIHRoZSBwYXR0ZXJuIGFscmVhZHkgaW4gdGhlIGxpc3Q/XG4gICAgdmFyIGluZGV4ID0gLTE7XG4gICAgZm9yICh2YXIgaT0wOyBpIDwgcmVjZW50X3BhdHRlcm5zLmxlbmd0aDsgaSsrKVxuICAgIHtcbiAgICAgIGlmIChyZWNlbnRfcGF0dGVybnNbaV0ucGF0dGVybl9pZCA9PSBwYXR0ZXJuX2lkKVxuICAgICAge1xuICAgICAgICBpbmRleCA9IGk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIHRoZSBwYXR0ZXJuIGlzIG5vdCBpbiB0aGUgbGlzdCwgc28gYWRkIGl0XG4gICAgaWYgKGluZGV4ID09PSAtMSlcbiAgICB7XG4gICAgICByZWNlbnRfcGF0dGVybnMudW5zaGlmdChyZWNlbnRfcGF0dGVybik7XG5cbiAgICAgIC8vIGRvbid0IHN0b3JlIHRvbyBtYW55IHBhdHRlcm5zXG4gICAgICBpZiAocmVjZW50X3BhdHRlcm5zLmxlbmd0aCA+IE1ldGVvci5teV9wYXJhbXMubWF4X3JlY2VudHMpXG4gICAgICAgIHJlY2VudF9wYXR0ZXJucy5wb3AoKTtcbiAgICB9XG4gICAgLy8gdGhlIHBhdHRlcm4gaXMgaW4gdGhlIGxpc3QsIHNvIHVwZGF0ZSBpdFxuICAgIGVsc2Uge1xuICAgICAgLy8gbm90ZSB0aGUgY3VycmVudCB3ZWF2ZSByb3dcbiAgICAgIHZhciBzdG9yZWRfd2VhdmVfcm93ID0gcmVjZW50X3BhdHRlcm5zW2luZGV4XS5jdXJyZW50X3dlYXZlX3JvdztcbiAgICAgIGlmICh0eXBlb2Ygc3RvcmVkX3dlYXZlX3JvdyA9PT0gXCJudW1iZXJcIilcbiAgICAgICAgcmVjZW50X3BhdHRlcm4uY3VycmVudF93ZWF2ZV9yb3cgPSBzdG9yZWRfd2VhdmVfcm93O1xuXG4gICAgICAvLyByZW1vdmUgdGhlIGV4aXN0aW5nIG9jY3VyZW5jZSBvZiB0aGUgcGF0dGVyblxuICAgICAgcmVjZW50X3BhdHRlcm5zLnNwbGljZShpbmRleCwgMSk7ICBcblxuICAgICAgLy8gYW5kIGFkZCB0aGUgcGF0dGVybiBhcyB0aGUgbW9zdCByZWNlbnQgaS5lLiBmaXJzdCBlbGVtZW50XG4gICAgICByZWNlbnRfcGF0dGVybnMudW5zaGlmdChyZWNlbnRfcGF0dGVybik7XG4gICAgfVxuXG4gICAgdmFyIHVwZGF0ZSA9IHt9O1xuICAgIHVwZGF0ZVtcInByb2ZpbGUucmVjZW50X3BhdHRlcm5zXCJdID0gcmVjZW50X3BhdHRlcm5zO1xuXG4gICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZSh7X2lkOiBNZXRlb3IudXNlcklkKCl9LCB7JHNldDogdXBkYXRlfSk7XG4gIH0sXG4gIG1haW50YWluX3JlY2VudF9wYXR0ZXJuczogZnVuY3Rpb24oKSB7XG4gICAgLy8gcmVtb3ZlIGFueSBwYXR0ZXJucyB0aGF0IG5vIGxvbmdlciBleGlzdCBvciBhcmUgbm93IGhpZGRlbiBmcm9tIHRoZSB1c2VyXG4gICAgdmFyIHJlY2VudF9wYXR0ZXJucyA9ICh0eXBlb2YgTWV0ZW9yLnVzZXIoKS5wcm9maWxlLnJlY2VudF9wYXR0ZXJucyA9PT0gXCJ1bmRlZmluZWRcIikgPyBbXSA6IE1ldGVvci51c2VyKCkucHJvZmlsZS5yZWNlbnRfcGF0dGVybnM7XG5cbiAgICAvLyBkb24ndCBzdG9yZSB0b28gbWFueSBwYXR0ZXJuc1xuICAgIHJlY2VudF9wYXR0ZXJucyA9IHJlY2VudF9wYXR0ZXJucy5zbGljZSgwLCBNZXRlb3IubXlfcGFyYW1zLm1heF9yZWNlbnRzKTtcblxuICAgIHZhciB1cGRhdGUgPSB7fTtcbiAgICB1cGRhdGVbXCJwcm9maWxlLnJlY2VudF9wYXR0ZXJuc1wiXSA9IHJlY2VudF9wYXR0ZXJucztcblxuICAgIE1ldGVvci51c2Vycy51cGRhdGUoe19pZDogTWV0ZW9yLnVzZXJJZCgpfSwgeyRzZXQ6IHVwZGF0ZX0pO1xuICB9LFxuICBzZXRfY3VycmVudF93ZWF2ZV9yb3c6IGZ1bmN0aW9uKHBhdHRlcm5faWQsIGluZGV4KSB7XG4gICAgY2hlY2socGF0dGVybl9pZCwgU3RyaW5nKTtcbiAgICBjaGVjayhpbmRleCwgTnVtYmVyKTtcblxuICAgIGlmICghTWV0ZW9yLnVzZXJJZCgpKVxuICAgICAgcmV0dXJuO1xuXG4gICAgaWYgKGluZGV4IDwgMSlcbiAgICAgIHJldHVybjtcblxuICAgIHZhciBwYXR0ZXJuID0gUGF0dGVybnMuZmluZE9uZSh7X2lkOiBwYXR0ZXJuX2lkfSwgeyBmaWVsZHM6IHsgX2lkIDogMSB9fSk7XG5cbiAgICBpZiAodHlwZW9mIHBhdHRlcm4gPT09IFwidW5kZWZpbmVkXCIpXG4gICAgICByZXR1cm47XG5cbiAgICB2YXIgbnVtYmVyX29mX3Jvd3MgPSBwYXR0ZXJuLm51bWJlcl9vZl9yb3dzO1xuXG4gICAgaWYgKGluZGV4ID4gbnVtYmVyX29mX3Jvd3MpXG4gICAgICByZXR1cm47XG5cblxuICAgIHZhciByZWNlbnRfcGF0dGVybnMgPSAodHlwZW9mIE1ldGVvci51c2VyKCkucHJvZmlsZS5yZWNlbnRfcGF0dGVybnMgPT09IFwidW5kZWZpbmVkXCIpID8gW10gOiBNZXRlb3IudXNlcigpLnByb2ZpbGUucmVjZW50X3BhdHRlcm5zO1xuXG4gICAgZm9yICh2YXIgaT0wOyBpIDwgcmVjZW50X3BhdHRlcm5zLmxlbmd0aDsgaSsrKVxuICAgIHtcbiAgICAgIGlmIChyZWNlbnRfcGF0dGVybnNbaV0ucGF0dGVybl9pZCA9PSBwYXR0ZXJuX2lkKVxuICAgICAge1xuICAgICAgICByZWNlbnRfcGF0dGVybnNbaV0uY3VycmVudF93ZWF2ZV9yb3cgPSBpbmRleDsgICBcbiAgICAgICAgdmFyIHVwZGF0ZSA9IHt9O1xuICAgICAgICB1cGRhdGVbXCJwcm9maWxlLnJlY2VudF9wYXR0ZXJuc1wiXSA9IHJlY2VudF9wYXR0ZXJucztcbiAgICAgICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZSh7X2lkOiBNZXRlb3IudXNlcklkKCl9LCB7JHNldDogdXBkYXRlfSk7ICAgXG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybjtcbiAgfSxcbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAvLyB1cGxvYWRlZCBpbWFnZXNcbiAgLy8gSXMgdGhlcmUgYWxyZWFkeSBhbiBpbWFnZSB3aXRoIHRoaXMga2V5P1xuICBkb2VzX2ltYWdlX2V4aXN0OiBmdW5jdGlvbihrZXksIGNiKSB7XG5cbiAgICAgLy8gY2hlY2sgaWYgdGhlIGltYWdlIGFscmVhZHkgZXhpc3RzIGluIHRoZSBTMyBidWNrZXRcbiAgICB2YXIgczMgPSBuZXcgQVdTLlMzKHtcbiAgICAgIGFjY2Vzc0tleUlkOiBNZXRlb3Iuc2V0dGluZ3MucHJpdmF0ZS5BV1NBY2Nlc3NLZXlJZCxcbiAgICAgIHNlY3JldEFjY2Vzc0tleTogTWV0ZW9yLnNldHRpbmdzLnByaXZhdGUuQVdTU2VjcmV0QWNjZXNzS2V5Ly8sXG4gICAgfSk7XG5cbiAgICB2YXIgcGFyYW1zID0ge1xuICAgICAgQnVja2V0OiBNZXRlb3Iuc2V0dGluZ3MucHJpdmF0ZS5BV1NCdWNrZXQsIC8vICdteWJ1Y2tldCdcbiAgICAgIEtleToga2V5IC8vICdpbWFnZXMvbXlpbWFnZS5qcGcnXG4gICAgfTtcblxuICAgIHZhciBteV9mbiA9IE1ldGVvci53cmFwQXN5bmMoczMuaGVhZE9iamVjdCwgczMpO1xuICAgIHZhciByZXN1bHRzID0gbXlfZm4ocGFyYW1zLCBmdW5jdGlvbihlcnIsIGRhdGEpIHtcblxuICAgICAgaWYgKGVycilcbiAgICAgIHtcbiAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwib2JqZWN0IGRvZXMgbm90IGV4aXN0IHdpdGgga2V5IFwiICsga2V5KTtcblxuICAgICAgfSBlbHNlXG4gICAgICB7XG4gICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgcmV0dXJuIHJlc3VsdHM7XG4gICAgLy8gY2FsbGJhY2sgZG9lc24ndCBzZWVtIHRvIHdvcmssIHJlc3VsdHMgaGFzIG5vIGRhdGEgYW5kIGFwcGVhcnMgYmVmb3JlIGNhbGxiYWNrXG4gIH0sXG4gIC8vIFNsaW5nc2hvdCBoYXMgYWRkZWQgYSBuZXcgaW1hZ2UgdG8gQW1hem9uIFMzLiBOb3cgbG9nIGluIGl0IHRoZSBJbWFnZXMgY29sbGVjdGlvbi5cbiAgdXBsb2FkX3BhdHRlcm5faW1hZ2U6IGZ1bmN0aW9uKGRvd25sb2FkVXJsLCBwYXR0ZXJuX2lkLCByb2xlLCB3aWR0aCwgaGVpZ2h0KXtcbiAgICBjaGVjayhkb3dubG9hZFVybCwgTm9uRW1wdHlTdHJpbmcpO1xuICAgIGNoZWNrKHBhdHRlcm5faWQsIE5vbkVtcHR5U3RyaW5nKTtcbiAgICBjaGVjayhyb2xlLCBOb25FbXB0eVN0cmluZyk7XG4gICAgY2hlY2sod2lkdGgsIE51bWJlcik7XG4gICAgY2hlY2soaGVpZ2h0LCBOdW1iZXIpO1xuXG4gICAgdmFyIHVzZXIgPSBNZXRlb3IudXNlcigpO1xuICAgIGlmICghTWV0ZW9yLnVzZXJJZCgpKVxuICAgICAgcmV0dXJuO1xuXG4gICAgaWYgKCF1c2VyLmVtYWlsc1swXS52ZXJpZmllZClcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJub3QtYXV0aG9yaXplZFwiLCBcIllvdSBjYW4gb25seSB1cGxvYWQgaW1hZ2VzIGlmIHlvdSBoYXZlIGEgdmVyaWZpZWQgZW1haWwgYWRkcmVzc1wiKTtcblxuICAgIHZhciBwYXR0ZXJuID0gUGF0dGVybnMuZmluZE9uZSh7X2lkOiBwYXR0ZXJuX2lkfSwgeyBmaWVsZHM6IHtjcmVhdGVkX2J5OiAxfX0pO1xuXG4gICAgaWYgKHBhdHRlcm4uY3JlYXRlZF9ieSAhPSBNZXRlb3IudXNlcklkKCkpXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibm90LWF1dGhvcml6ZWRcIiwgXCJZb3UgY2FuIG9ubHkgdXBsb2FkIGltYWdlcyBmb3IgcGF0dGVybnMgeW91IGNyZWF0ZWRcIik7IFxuICAgIFxuICAgIHZhciBjb3VudCA9IEltYWdlcy5maW5kKHsgdXNlZF9ieTogcGF0dGVybl9pZCB9KS5jb3VudCgpO1xuXG4gICAgaWYgKFJvbGVzLnVzZXJJc0luUm9sZSggTWV0ZW9yLnVzZXJJZCgpLCAncHJlbWl1bScsICd1c2VycycgKSlcbiAgICB7XG4gICAgICBpZiAoY291bnQgPj0gTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5tYXhfaW1hZ2VzX3Blcl9wYXR0ZXJuLnByZW1pdW0pXG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJsaW1pdC1yZWFjaGVkXCIsIFwiWW91IGNhbm5vdCB1cGxvYWQgYW55IG1vcmUgaW1hZ2VzIGZvciB0aGlzIHBhdHRlcm5cIik7XG4gICAgfVxuICAgIGVsc2VcbiAgICB7XG4gICAgICBpZiAoY291bnQgPj0gTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5tYXhfaW1hZ2VzX3Blcl9wYXR0ZXJuLnZlcmlmaWVkKVxuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibGltaXQtcmVhY2hlZFwiLCBcIllvdSBjYW5ub3QgdXBsb2FkIGFueSBtb3JlIGltYWdlcyBmb3IgdGhpcyBwYXR0ZXJuXCIpO1xuICAgIH1cblxuICAgIHZhciBidWNrZXQgPSBNZXRlb3Iuc2V0dGluZ3MucHJpdmF0ZS5BV1NCdWNrZXQ7XG4gICAgdmFyIHJlZ2lvbiA9IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuQVdTUmVnaW9uO1xuXG4gICAgLy8gRmluZCB0aGUga2V5IGJ5IHN0cmlwcGluZyBvdXQgdGhlIGZpcnN0IHBhcnQgb2YgdGhlIGltYWdlIHVybFxuICAgIHZhciBrZXkgPSBkb3dubG9hZFVybC5yZXBsYWNlKCdodHRwczovLycgKyBidWNrZXQgKyBcIi5zMy1cIiArIHJlZ2lvbiArICcuYW1hem9uYXdzLmNvbS8nLCAnJyk7IC8vIHVzZWQgdG8gZGVsZXRlIHRoZSBvYmplY3QgZnJvbSBBV1NcblxuICAgIGlmIChJbWFnZXMuZmluZCh7a2V5OmtleX0pLmNvdW50KCkgPT0gMClcbiAgICB7XG4gICAgICAvLyBhZGQgdGhlIG5ldyBvYmplY3QgdG8gdGhlIEltYWdlcyBjb2xsZWN0aW9uXG4gICAgICB2YXIgaW1hZ2VfaWQgPSBJbWFnZXMuaW5zZXJ0KHtcbiAgICAgICAgICB1cmw6IGRvd25sb2FkVXJsLFxuICAgICAgICAgIGtleToga2V5LFxuICAgICAgICAgIGNyZWF0ZWRfYXQ6IG1vbWVudCgpLnZhbHVlT2YoKSwgICAgICAgICAgICAvLyBjdXJyZW50IHRpbWVcbiAgICAgICAgICBjcmVhdGVkX2J5OiBNZXRlb3IudXNlcklkKCksICAgICAgICAgICAvLyBfaWQgb2YgbG9nZ2VkIGluIHVzZXJcbiAgICAgICAgICBjcmVhdGVkX2J5X3VzZXJuYW1lOiBNZXRlb3IudXNlcigpLnVzZXJuYW1lLCAgLy8gdXNlcm5hbWUgb2YgbG9nZ2VkIGluIHVzZXJcbiAgICAgICAgICB1c2VkX2J5OiBwYXR0ZXJuX2lkLFxuICAgICAgICAgIHJvbGU6IHJvbGUsXG4gICAgICAgICAgd2lkdGg6IHdpZHRoLFxuICAgICAgICAgIGhlaWdodDogaGVpZ2h0XG4gICAgICAgfSk7XG4gICAgICByZXR1cm4gaW1hZ2VfaWQ7XG4gICAgfVxuICAgIGVsc2VcbiAgICB7XG4gICAgICAvLyB1cGxvYWRpbmcgYSBuZXcgdmVyc2lvbiBvZiBhbiBleGlzdGluZyBmaWxlLCBqdXN0IHVwZGF0ZSBcImNyZWF0ZWRfYXRcIlxuICAgICAgdmFyIGltYWdlX2lkID0gSW1hZ2VzLmZpbmRPbmUoe2tleTprZXl9LCB7ZmllbGRzOiB7X2lkOjF9fSk7XG4gICAgICBJbWFnZXMudXBkYXRlKHtfaWQ6IGltYWdlX2lkfSwgeyRzZXQ6XG4gICAgICAgIHtcbiAgICAgICAgICBjcmVhdGVkX2F0OiBtb21lbnQoKS52YWx1ZU9mKClcbiAgICAgICAgfX0pO1xuICAgIH1cbiAgfSxcbiAgbWFrZV9wcmV2aWV3OiBmdW5jdGlvbihpbWFnZV9pZCkge1xuICAgIGNoZWNrKGltYWdlX2lkLCBOb25FbXB0eVN0cmluZyk7XG5cbiAgICAvLyBEb2VzIHRoZSB1c2VyIGhhdmUgcGVybWlzc2lvbiB0byByZW1vdmUgdGhpcyBpbWFnZT9cbiAgICB2YXIgaW1hZ2UgPSBJbWFnZXMuZmluZE9uZSh7ICdfaWQnOiBpbWFnZV9pZCB9KTtcblxuICAgIGlmICh0eXBlb2YgaW1hZ2UgPT09IFwidW5kZWZpbmVkXCIpXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibm90LWZvdW5kXCIsIFwiSW1hZ2Ugbm90IGZvdW5kOiBcIiArIGltYWdlX2lkKTtcblxuICAgIGlmIChpbWFnZS5jcmVhdGVkX2J5ICE9IE1ldGVvci51c2VySWQoKSlcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJub3QtYXV0aG9yaXplZFwiLCBcIllvdSBjYW4gb25seSByZW1vdmUgYW4gaW1hZ2UgeW91IHVwbG9hZGVkXCIpO1xuXG4gICAgaWYgKGltYWdlLnJvbGUgPT0gXCJwcmV2aWV3XCIpXG4gICAgICByZXR1cm4gdHJ1ZTtcblxuICAgIGVsc2VcbiAgICB7XG4gICAgICB2YXIgcGF0dGVybl9pZCA9IGltYWdlLnVzZWRfYnk7XG4gICAgICB0cnkge1xuICAgICAgICB2YXIgY3VycmVudF9wcmV2aWV3X2lkID0gSW1hZ2VzLmZpbmRPbmUoe3VzZWRfYnk6cGF0dGVybl9pZCwgcm9sZTpcInByZXZpZXdcIn0pLl9pZDsgLy8gcmVtb3ZlIGFueSBleGlzdGluZyBwcmV2aWV3IGltYWdlXG4gICAgICAgIEltYWdlcy51cGRhdGUoe19pZDpjdXJyZW50X3ByZXZpZXdfaWR9LCB7JHNldDoge3JvbGU6XCJpbWFnZVwifX0pO1xuICAgICAgfVxuICAgICAgY2F0Y2goZXJyKSB7XG4gICAgICAgIC8vIG5vIGV4aXN0aW5nIHByZXZpZXcsIG5vdGhpbmcgdG8gZG8gaGVyZVxuICAgICAgfVxuXG4gICAgICBJbWFnZXMudXBkYXRlKHtfaWQ6aW1hZ2VfaWR9LCB7JHNldDoge3JvbGU6XCJwcmV2aWV3XCJ9fSk7XG4gICAgfVxuICB9LFxuICBzZXRfaW1hZ2VfZGltZW5zaW9uczogZnVuY3Rpb24oaW1hZ2VfaWQsIHdpZHRoLCBoZWlnaHQpIHtcbiAgICBjaGVjayhpbWFnZV9pZCwgTm9uRW1wdHlTdHJpbmcpO1xuICAgIGNoZWNrKHdpZHRoLCBOdW1iZXIpO1xuICAgIGNoZWNrKGhlaWdodCwgTnVtYmVyKTtcblxuICAgIC8vIERvZXMgdGhlIHVzZXIgaGF2ZSBwZXJtaXNzaW9uIHRvIGVkaXQgdGhpcyBpbWFnZT9cbiAgICB2YXIgaW1hZ2UgPSBJbWFnZXMuZmluZE9uZSh7ICdfaWQnOiBpbWFnZV9pZCB9KTtcblxuICAgIGlmICh0eXBlb2YgaW1hZ2UgPT09IFwidW5kZWZpbmVkXCIpXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibm90LWZvdW5kXCIsIFwiSW1hZ2Ugbm90IGZvdW5kOiBcIiArIGltYWdlX2lkKTtcblxuICAgIGlmIChpbWFnZS5jcmVhdGVkX2J5ICE9IE1ldGVvci51c2VySWQoKSlcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJub3QtYXV0aG9yaXplZFwiLCBcIllvdSBjYW4gb25seSBlZGl0IGFuIGltYWdlIHlvdSB1cGxvYWRlZFwiKTtcblxuICAgIC8vIGxhbmRzY2FwZSBvciBwb3J0cmFpdFxuXG4gICAgLy8gY29uc3RyYWluIHNpemVcblxuICAgIHZhciBuZXdfd2lkdGggPSB3aWR0aDtcbiAgICB2YXIgbmV3X2hlaWdodCA9IGhlaWdodDtcblxuICAgIEltYWdlcy51cGRhdGUoe19pZDogaW1hZ2VfaWR9LCB7JHNldDoge3dpZHRoOiBuZXdfd2lkdGgsIGhlaWdodDogbmV3X2hlaWdodH19KTtcblxuICB9LFxuICByZW1vdmVfaW1hZ2U6IGZ1bmN0aW9uKGltYWdlX2lkKSB7XG4gICAgY2hlY2soaW1hZ2VfaWQsIE5vbkVtcHR5U3RyaW5nKTtcblxuICAgIC8vIERvZXMgdGhlIHVzZXIgaGF2ZSBwZXJtaXNzaW9uIHRvIHJlbW92ZSB0aGlzIGltYWdlP1xuICAgIHZhciBpbWFnZSA9IEltYWdlcy5maW5kT25lKHsgJ19pZCc6IGltYWdlX2lkIH0pO1xuXG4gICAgaWYgKHR5cGVvZiBpbWFnZSA9PT0gXCJ1bmRlZmluZWRcIilcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJub3QtZm91bmRcIiwgXCJJbWFnZSBub3QgZm91bmQ6IFwiICsgaW1hZ2VfaWQpO1xuXG4gICAgaWYgKGltYWdlLmNyZWF0ZWRfYnkgIT0gTWV0ZW9yLnVzZXJJZCgpKVxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIm5vdC1hdXRob3JpemVkXCIsIFwiWW91IGNhbiBvbmx5IHJlbW92ZSBhbiBpbWFnZSB5b3UgdXBsb2FkZWRcIik7XG5cbiAgICAvLyBjaGVjayBmb3IgdG9vIG1hbnkgaW1hZ2UgcmVtb3ZhbHMgdG9vIGZhc3RcbiAgICB2YXIgZG9jdW1lbnRfaWQgPSBNZXRlb3IuY2FsbCgnZ2V0X2FjdGlvbnNfbG9nJyk7XG5cbiAgICB2YXIgZGJfZG9jdW1lbnQgPSBBY3Rpb25zTG9nLmZpbmRPbmUoe19pZDogZG9jdW1lbnRfaWR9LCB7ZmllbGRzOiB7IGltYWdlX3JlbW92ZWQ6IDEsIGxvY2tlZDogMSB9fSApO1xuXG4gICAgdmFyIGV2ZW50X2xvZyA9IGRiX2RvY3VtZW50LmltYWdlX3JlbW92ZWQ7XG5cbiAgICBpZiAoZGJfZG9jdW1lbnQubG9ja2VkKVxuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJhY2NvdW50LWxvY2tlZFwiLCBcIllvdXIgYWNjb3VudCBoYXMgYmVlbiBsb2NrZWQsIHBsZWFzZSBjb250YWN0IGFuIGFkbWluaXN0cmF0b3JcIik7XG4gIFxuICAgIHZhciBudW1iZXJfb2ZfZW50cmllcyA9IGV2ZW50X2xvZy5sZW5ndGg7XG4gICAgdmFyIHRpbWVfc2luY2VfbGFzdF9hY3Rpb24gPSBtb21lbnQoKS52YWx1ZU9mKCkgLSBldmVudF9sb2dbMF07XG5cbiAgICAvLyB0cnkgdG8gZGV0ZWN0IGF1dG9tYXRlZCBpbWFnZSByZW1vdmVzXG4gICAgLy8gQSBodW1hbiBzaG91bGRuJ3QgYmUgYWJsZSB0byByZW1vdmVzIDEwIGltYWdlcyBpbiAyIHNlY29uZHNcbiAgICB2YXIgbGFzdF8xMF9hY3Rpb25zX2luID0gZXZlbnRfbG9nWzBdIC0gZXZlbnRfbG9nWzldO1xuICAgIGlmIChsYXN0XzEwX2FjdGlvbnNfaW4gPCAyMDAwKVxuICAgIHtcbiAgICAgIEFjdGlvbnNMb2cudXBkYXRlKCB7X2lkOiBkb2N1bWVudF9pZH0sIHsgbG9ja2VkOiB0cnVlIH0gKTtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJhY2NvdW50LWxvY2tlZFwiLCBcIllvdXIgYWNjb3VudCBoYXMgYmVlbiBsb2NrZWQsIHBsZWFzZSBjb250YWN0IGFuIGFkbWluaXN0cmF0b3JcIik7XG4gICAgfVxuXG4gICAgdmFyIGxhc3RfNV9hY3Rpb25zX2luID0gZXZlbnRfbG9nWzBdIC0gZXZlbnRfbG9nWzRdO1xuICAgICAgaWYgKGxhc3RfNV9hY3Rpb25zX2luIDwgMjAwMClcbiAgICAgIHtcbiAgICAgICAgLy8gRG9uJ3QgYWxsb3cgYW5vdGhlciBhdHRlbXB0IGZvciA1IG1pbnV0ZXNcbiAgICAgICAgaWYgKHRpbWVfc2luY2VfbGFzdF9hY3Rpb24gPCAoNjAgKiAxMDAwICogNSkpXG4gICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcInRvby1tYW55LXJlcXVlc3RzXCIsIFwiUGxlYXNlIHdhaXQgNSBtaW5zIGJlZm9yZSByZXRyeWluZ1wiKTtcblxuICAgICAgICAvLyBpdCdzIGJlZW4gYXQgbGVhc3QgNSBtaW5zIHNvIGNvbnNpZGVyIGFsbG93aW5nIGFub3RoZXIgaW1hZ2UgdXBsb2FkXG4gICAgICAgIGVsc2VcbiAgICAgICAge1xuICAgICAgICAgIHZhciBwcmV2aW91c181X2FjdGlvbnNfaW4gPSBldmVudF9sb2dbNF0gLSBldmVudF9sb2dbOV07XG4gICAgICAgICAgaWYgKHByZXZpb3VzXzVfYWN0aW9uc19pbiA8IDIwMDApXG4gICAgICAgICAge1xuICAgICAgICAgICAgLy8gaWYgdGhlIDUgcHJldmlvdXMgYWN0aW9ucyB3ZXJlIGluIDIgc2Vjb25kcywgd2FpdCAzMCBtaW51dGVzXG4gICAgICAgICAgICAvLyB0aGlzIGxvb2tzIGxpa2UgYW4gYXV0b21hdGljIHByb2Nlc3MgdGhhdCBoYXMgdHJpZWQgY29udGludWFsbHlcbiAgICAgICAgICAgIGlmICh0aW1lX3NpbmNlX2xhc3RfYWN0aW9uIDwgKDYwICogMTAwMCAqIDMwICsgNDAwMCkpXG4gICAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJ0b28tbWFueS1yZXF1ZXN0c1wiLCBcIlBsZWFzZSB3YWl0IDMwIG1pbnMgYmVmb3JlIHJldHJ5aW5nXCIpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyByZWNvcmQgdGhlIGFjdGlvbiBpbiB0aGUgbG9nXG4gICAgICBBY3Rpb25zTG9nLnVwZGF0ZSgge19pZDogZG9jdW1lbnRfaWR9LCB7ICRwdXNoOiB7IGltYWdlX3JlbW92ZWQ6IHtcbiAgICAgICAgJGVhY2g6IFttb21lbnQoKS52YWx1ZU9mKCldLFxuICAgICAgICAkcG9zaXRpb246IDAgXG4gICAgICB9fX0gKTtcbiAgO1xuICAgICAgLy8gcmVtb3ZlIHRoZSBvbGRlc3QgbG9nIGVudHJ5IGlmIHRvbyBtYW55IHN0b3JlZFxuICAgICAgaWYgKG51bWJlcl9vZl9lbnRyaWVzID4gTWV0ZW9yLnNldHRpbmdzLnByaXZhdGUuaW1hZ2VfcmVtb3ZlX251bV90b19sb2cpXG4gICAgICB7XG4gICAgICAgIEFjdGlvbnNMb2cudXBkYXRlKCB7X2lkOiBkb2N1bWVudF9pZH0sIHsgJHBvcDogeyBpbWFnZV9yZW1vdmVkOiAxIH19ICk7XG4gICAgICB9XG5cbiAgICB2YXIgczMgPSBuZXcgQVdTLlMzKHtcbiAgICAgIGFjY2Vzc0tleUlkOiBNZXRlb3Iuc2V0dGluZ3MucHJpdmF0ZS5BV1NBY2Nlc3NLZXlJZCxcbiAgICAgIHNlY3JldEFjY2Vzc0tleTogTWV0ZW9yLnNldHRpbmdzLnByaXZhdGUuQVdTU2VjcmV0QWNjZXNzS2V5Ly8sXG4gICAgfSk7XG5cbiAgICB2YXIgcGFyYW1zID0ge1xuICAgICAgQnVja2V0OiBNZXRlb3Iuc2V0dGluZ3MucHJpdmF0ZS5BV1NCdWNrZXQsIC8vICdteWJ1Y2tldCdcbiAgICAgIEtleTogaW1hZ2Uua2V5IC8vICdpbWFnZXMvbXlpbWFnZS5qcGcnXG4gICAgfTtcbiAgICBcbiAgICBzMy5kZWxldGVPYmplY3QocGFyYW1zLCBNZXRlb3IuYmluZEVudmlyb25tZW50KGZ1bmN0aW9uIChlcnJvciwgZGF0YSl7XG4gICAgICBpZiAoIWVycm9yKSB7XG4gICAgICAgIEltYWdlcy5yZW1vdmUoe19pZDogaW1hZ2VfaWR9KTtcbiAgICAgIH1cbiAgICB9KSk7XG4gIH0sXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgLy8gRWRpdCBwYXR0ZXJuIHByb3BlcnRpZXNcbiAgdXBkYXRlX3RleHRfcHJvcGVydHk6IGZ1bmN0aW9uKGNvbGxlY3Rpb24sIG9iamVjdF9pZCwgcHJvcGVydHksIHZhbHVlKVxuICB7XG4gICAgLy8gdXNlZCBieSB0aGUgZWRpdGFibGVfZmllbGQgdGVtcGxhdGVcbiAgICAvLyB0aGlzIGZ1bmN0aW9uIHVwZGF0ZXMgc3BlY2lmaWVkIHRleHQgcHJvcGVydGllcyBvZiBzcGVjaWZpZWQgY29sbGVjdGlvbnMuIEl0IGRlbGliZXJhdGVseSBjaGVja3MgZm9yIGtub3duIGNvbGxlY3Rpb25zIGFuZCBwcm9wZXJ0aWVzIHRvIGF2b2lkIHVuZXhwZWN0ZWQgZGF0YWJhc2UgY2hhbmdlcy5cbiAgICBjaGVjayhvYmplY3RfaWQsIE5vbkVtcHR5U3RyaW5nKTtcbiAgICBjaGVjayhjb2xsZWN0aW9uLCBOb25FbXB0eVN0cmluZyk7XG4gICAgY2hlY2socHJvcGVydHksIE5vbkVtcHR5U3RyaW5nKTtcbiAgICBjaGVjayh2YWx1ZSwgU3RyaW5nKTtcblxuICAgIGlmICh2YWx1ZS5sZW5ndGggPiA2MDAwKVxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIm5vdC1hdXRob3JpemVkXCIsIFwiVmFsdWUgaXMgdG9vIGxvbmdcIik7XG5cbiAgICBpZiAoY29sbGVjdGlvbiA9PSBcInBhdHRlcm5zXCIpXG4gICAge1xuICAgICAgdmFyIHBhdHRlcm4gPSBQYXR0ZXJucy5maW5kT25lKHtfaWQ6IG9iamVjdF9pZH0sIHsgZmllbGRzOiB7Y3JlYXRlZF9ieTogMX19KTtcblxuICAgICAgaWYgKHBhdHRlcm4uY3JlYXRlZF9ieSAhPSBNZXRlb3IudXNlcklkKCkpXG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJub3QtYXV0aG9yaXplZFwiLCBcIllvdSBjYW4gb25seSB1cGRhdGUgcGF0dGVybnMgeW91IGNyZWF0ZWRcIik7XG5cbiAgICAgIHN3aXRjaCAocHJvcGVydHkpXG4gICAgICB7XG4gICAgICAgIGNhc2UgXCJuYW1lXCI6XG4gICAgICAgIGNhc2UgXCJkZXNjcmlwdGlvblwiOlxuICAgICAgICBjYXNlIFwid2VhdmluZ19ub3Rlc1wiOlxuICAgICAgICBjYXNlIFwidGhyZWFkaW5nX25vdGVzXCI6XG4gICAgICAgICAgaWYgKChwcm9wZXJ0eSA9PSBcIm5hbWVcIikgJiYgKHZhbHVlID09IFwiXCIpKVxuICAgICAgICAgICAgcmV0dXJuOyAvLyBwYXR0ZXJuIG11c3QgaGF2ZSBhIG5hbWVcblxuICAgICAgICAgIHZhciB1cGRhdGUgPSB7fTtcbiAgICAgICAgICB1cGRhdGVbcHJvcGVydHldID0gdmFsdWU7IC8vIHRoaXMgY29uc3RydWN0aW9uIGlzIG5lY2Vzc2FyeSB0byBoYW5kbGUgYSB2YXJpYWJsZSBwcm9wZXJ0eSBuYW1lXG4gICAgICAgICAgUGF0dGVybnMudXBkYXRlKHtfaWQ6IG9iamVjdF9pZH0sIHskc2V0OiB1cGRhdGV9KTtcbiAgICAgICAgICBcbiAgICAgICAgICAvLyBSZWNvcmQgdGhlIGVkaXQgdGltZVxuICAgICAgICAgIE1ldGVvci5jYWxsKFwic2F2ZV90ZXh0X2VkaXRfdGltZVwiLCBvYmplY3RfaWQpO1xuICAgICAgICAgIHJldHVybjtcblxuICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibm90LWF1dGhvcml6ZWRcIiwgXCJVbmtub3duIHByb3BlcnR5XCIpO1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmIChjb2xsZWN0aW9uID09IFwiaW1hZ2VzXCIpXG4gICAge1xuICAgICAgdmFyIGltYWdlID0gSW1hZ2VzLmZpbmRPbmUoe19pZDogb2JqZWN0X2lkfSk7XG4gICAgICB2YXIgcGF0dGVybiA9IFBhdHRlcm5zLmZpbmRPbmUoe19pZDogaW1hZ2UudXNlZF9ieX0pXG5cbiAgICAgIGlmIChwYXR0ZXJuLmNyZWF0ZWRfYnkgIT0gTWV0ZW9yLnVzZXJJZCgpKVxuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwibm90LWF1dGhvcml6ZWRcIiwgXCJZb3UgY2FuIG9ubHkgdXBkYXRlIHBhdHRlcm5zIHlvdSBjcmVhdGVkXCIpO1xuICAgICAgLy8gKioqIFRPRE8gY2hlY2sgdXNlciBjYW4gZWRpdCBwYXR0ZXJuXG4gICAgICBzd2l0Y2ggKHByb3BlcnR5KVxuICAgICAge1xuICAgICAgICBjYXNlIFwiY2FwdGlvblwiOlxuICAgICAgICAgIHZhciB1cGRhdGUgPSB7fTtcbiAgICAgICAgICB1cGRhdGVbcHJvcGVydHldID0gdmFsdWU7IC8vIHRoaXMgY29uc3RydWN0aW9uIGlzIG5lY2Vzc2FyeSB0byBoYW5kbGUgYSB2YXJpYWJsZSBwcm9wZXJ0eSBuYW1lXG4gICAgICAgICAgSW1hZ2VzLnVwZGF0ZSh7X2lkOiBvYmplY3RfaWR9LCB7JHNldDogdXBkYXRlfSk7XG4gICAgICAgICAgcmV0dXJuO1xuXG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIm5vdC1hdXRob3JpemVkXCIsIFwiVW5rbm93biBwcm9wZXJ0eVwiKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAoY29sbGVjdGlvbiA9PSBcInVzZXJzXCIpXG4gICAge1xuICAgICAgLy8gb25seSB0aGUgdXNlciBjYW4gdXBkYXRlIHRoZWlyIG93biBwcm9maWxlXG4gICAgICBpZiAob2JqZWN0X2lkICE9IE1ldGVvci51c2VySWQoKSlcbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIm5vdC1hdXRob3JpemVkXCIsIFwiWW91IGNhbiBvbmx5IGNoYW5nZSB5b3VyIG93biB1c2VyIGRldGFpbHNcIik7XG5cbiAgICAgIHN3aXRjaCAocHJvcGVydHkpXG4gICAgICB7XG4gICAgICAgIGNhc2UgXCJkZXNjcmlwdGlvblwiOlxuICAgICAgICAgIC8vIGNvcnJlY3QgZm9yIG1lIGhhdmluZyBtZXNzZWQgdXAgcHJvZmlsZXMgYnkgc2V0dGluZyB0aGVtIGFzIGEgdGV4dCBzdHJpbmcgbm90IGtub3dpbmcgaXQgYWxyZWFkeSBleGlzdGVkXG4gICAgICAgICAgLy8gcHJvZmlsZSBpcyBhbiBvYmplY3QgdG8gd2hpY2ggZWRpdGFibGUgcHJvcGVydGllcyBtYXkgYmUgYWRkZWRcbiAgICAgICAgICB2YXIgcHJvZmlsZSA9IE1ldGVvci51c2Vycy5maW5kT25lKHsgX2lkOiBvYmplY3RfaWR9KS5wcm9maWxlO1xuICAgICAgICAgIGlmICh0eXBlb2YgcHJvZmlsZSA9PT0gXCJ1bmRlZmluZWRcIilcbiAgICAgICAgICAgIHByb2ZpbGUgPSB7fTtcbiAgICAgICAgICBcbiAgICAgICAgICBwcm9maWxlW3Byb3BlcnR5XSA9IHZhbHVlO1xuXG4gICAgICAgICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZSh7X2lkOiBvYmplY3RfaWR9LCB7JHNldDoge3Byb2ZpbGU6IHByb2ZpbGV9fSk7XG4gICAgICAgICAgcmV0dXJuO1xuXG4gICAgICAgIGNhc2UgXCJlbWFpbF9hZGRyZXNzXCI6XG4gICAgICAgICAgaWYgKHZhbHVlID09IFwiXCIpXG4gICAgICAgICAgICByZXR1cm47XG5cbiAgICAgICAgICB2YXIgb2xkX2VtYWlscyA9IE1ldGVvci51c2Vycy5maW5kT25lKHsgX2lkOiBvYmplY3RfaWR9KS5lbWFpbHM7XG4gICAgICAgICAgaWYgKG9sZF9lbWFpbHMpIC8vIHVzZXIgbWF5IGhhdmUgbm8gZW1haWxzXG4gICAgICAgICAgICB2YXIgc3RhcnRfbnVtYmVyID0gb2xkX2VtYWlscy5sZW5ndGg7XG4gICAgICAgICAgZWxzZVxuICAgICAgICAgICAgdmFyIHN0YXJ0X251bWJlciA9IDA7XG5cbiAgICAgICAgICBBY2NvdW50cy5hZGRFbWFpbChvYmplY3RfaWQsIHZhbHVlKTsgLy8gSSBiZWxpZXZlIHRoaXMgcnVucyBzeW5jaHJvbm91c2x5IGJlY2F1c2UgaXQgaXMgYmVpbmcgY2FsbGVkIG9uIHRoZSBzZXJ2ZXJcblxuICAgICAgICAgIC8vIElmIGFkZEVtYWlsIGRvZXNuJ3QgdGhyb3cgYW4gZXJyb3IsIHdlIGNhbiBhc3N1bWUgdGhhdCBlaXRoZXIgdGhlIG5ldyBlbWFpbCB3YXMgYWRkZWQsIG9yIGl0IHJlcGxhY2VkIG9uZSB0aGF0IHdhcyBpZGVudGljYWwgYXBhcnQgZnJvbSBjYXNlIC0gaW4gdGhlIGxhdHRlciBjYXNlLCB2ZXJpZmljYXRpb24gc3RhdHVzIGlzIHVuY2hhbmdlZC4gU28gdGhlIHVzZXIgc2hvdWxkIGhhdmUgYW4gZW1haWwgYWRkcmVzcy5cbiAgICAgICAgICB2YXIgbmV3X2VtYWlscyA9IE1ldGVvci51c2Vycy5maW5kT25lKHsgX2lkOiBvYmplY3RfaWR9KS5lbWFpbHM7XG4gICAgICAgICAgaWYgKG5ld19lbWFpbHMpXG4gICAgICAgICAgICB2YXIgZW5kX251bWJlciA9IG5ld19lbWFpbHMubGVuZ3RoO1xuICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgIHZhciBlbmRfbnVtYmVyID0gMDtcblxuICAgICAgICAgIGlmIChlbmRfbnVtYmVyID4gc3RhcnRfbnVtYmVyKSAvLyBlbWFpbCB3YXMgc3VjY2Vzc2Z1bGx5IGFkZGVkXG4gICAgICAgICAge1xuICAgICAgICAgICAgLy8gcmVtb3ZlIGFueSBvdGhlciBlbWFpbCBhZGRyZXNzZXMgLSB1c2VyIHNob3VsZCBvbmx5IGhhdmUgb25lLlxuICAgICAgICAgICAgZm9yICh2YXIgaT0wOyBpPG5ld19lbWFpbHMubGVuZ3RoOyBpKyspXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlmIChuZXdfZW1haWxzW2ldLmFkZHJlc3MgIT0gdmFsdWUpXG4gICAgICAgICAgICAgICAgQWNjb3VudHMucmVtb3ZlRW1haWwob2JqZWN0X2lkLCBuZXdfZW1haWxzW2ldLmFkZHJlc3MpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy9BY2NvdW50cy5zZW5kVmVyaWZpY2F0aW9uRW1haWwob2JqZWN0X2lkKTtcbiAgICAgICAgICAgIE1ldGVvci5jYWxsKCdzZW5kVmVyaWZpY2F0aW9uRW1haWwnLCBvYmplY3RfaWQpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHJldHVybjtcblxuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJub3QtYXV0aG9yaXplZFwiLCBcIlVua25vd24gcHJvcGVydHlcIik7XG4gICAgICB9XG4gICAgfVxuICB9LFxuICBzYXZlX3RleHRfZWRpdF90aW1lOiBmdW5jdGlvbihwYXR0ZXJuX2lkKVxuICB7XG4gICAgY2hlY2socGF0dGVybl9pZCwgU3RyaW5nKTtcbiAgICBQYXR0ZXJucy51cGRhdGUoe19pZDogcGF0dGVybl9pZH0sIHskc2V0OiB7dGV4dF9lZGl0ZWRfYXQ6IG1vbWVudCgpLnZhbHVlT2YoKX19KTtcbiAgfSxcblxuICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4gIC8vIHVzZXIgYWNjb3VudCBtYW5hZ2VtZW50XG4gIHNlbmRWZXJpZmljYXRpb25FbWFpbCh1c2VySWQsIGVtYWlsKVxuICB7XG4gICAgY2hlY2sodXNlcklkLCBOb25FbXB0eVN0cmluZyk7XG4gICAgY2hlY2soZW1haWwsIE1hdGNoLk9wdGlvbmFsKFN0cmluZykpO1xuXG4gICAgaWYgKHVzZXJJZCAhPSBNZXRlb3IudXNlcklkKCkpXG4gICAgICAvLyBPbmx5IHRoZSBvd25lciBjYW4gcmVxdWVzdCBhIHZlcmlmaWNhdGlvbiBlbWFpbFxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIm5vdC1hdXRob3JpemVkXCIsIFwiWW91IGNhbiBvbmx5IHJlcXVlc3QgdmVyaWZpY2F0aW9uIGVtYWlscyBmb3IgeW91ciBvd24gZW1haWwgYWRkcmVzc2VzXCIpO1xuXG4gICAgLy8gY2hlY2sgZm9yIHRoZSB1c2VyIGhhdmluZyByZXF1ZXN0ZWQgdG9vIG1hbnkgZW1haWxzIGluIHRvbyBzaG9ydCBhIHRpbWVcbiAgICB2YXIgZG9jdW1lbnRfaWQgPSBNZXRlb3IuY2FsbCgnZ2V0X2FjdGlvbnNfbG9nJyk7XG5cbiAgICB2YXIgZGJfZG9jdW1lbnQgPSBBY3Rpb25zTG9nLmZpbmRPbmUoe19pZDogZG9jdW1lbnRfaWR9LCB7ZmllbGRzOiB7IHZlcmlmaWNhdGlvbl9lbWFpbF9zZW50OiAxLCBsb2NrZWQ6IDEgfX0gKTtcblxuICAgIHZhciBldmVudF9sb2cgPSBkYl9kb2N1bWVudC52ZXJpZmljYXRpb25fZW1haWxfc2VudDtcblxuICAgIGlmIChkYl9kb2N1bWVudC5sb2NrZWQpXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiYWNjb3VudC1sb2NrZWRcIiwgXCJZb3VyIGFjY291bnQgaGFzIGJlZW4gbG9ja2VkLCBwbGVhc2UgY29udGFjdCBhbiBhZG1pbmlzdHJhdG9yXCIpO1xuICAgIFxuICAgIHZhciBudW1iZXJfb2ZfZW50cmllcyA9IGV2ZW50X2xvZy5sZW5ndGg7XG4gICAgdmFyIHRpbWVfc2luY2VfbGFzdF9hY3Rpb24gPSBtb21lbnQoKS52YWx1ZU9mKCkgLSBldmVudF9sb2dbMF07XG4gICAgXG4gICAgLy8gdHJ5IHRvIGRldGVjdCBhdXRvbWF0ZWQgZW1haWwgc2VuZFxuICAgIC8vIElmIHRoZSBsYXN0IDUgYWN0aW9ucyBpbiBhIHNwYWNlIG9mIDEgc2Vjb25kXG4gICAgdmFyIGxhc3RfNV9hY3Rpb25zX2luID0gZXZlbnRfbG9nWzBdIC0gZXZlbnRfbG9nWzRdO1xuICAgIGlmIChsYXN0XzVfYWN0aW9uc19pbiA8IDIwMDApXG4gICAge1xuICAgICAgLy8gRG9uJ3QgYWxsb3cgYW5vdGhlciBhdHRlbXB0IGZvciA1IG1pbnV0ZXNcbiAgICAgIGlmICh0aW1lX3NpbmNlX2xhc3RfYWN0aW9uIDwgKDYwICogMTAwMCAqIDUpKVxuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwidG9vLW1hbnktcmVxdWVzdHNcIiwgXCJQbGVhc2Ugd2FpdCA1IG1pbnMgYmVmb3JlIHJldHJ5aW5nXCIpO1xuXG4gICAgICAvLyBpdCdzIGJlZW4gYXQgbGVhc3QgNSBtaW5zIHNvIGNvbnNpZGVyIGFsbG93aW5nIGFub3RoZXIgZW1haWxcbiAgICAgIGVsc2VcbiAgICAgIHtcbiAgICAgICAgdmFyIGxhc3RfMTBfYWN0aW9uc19pbiA9IGV2ZW50X2xvZ1swXSAtIGV2ZW50X2xvZ1s5XTtcbiAgICAgICAgaWYgKGxhc3RfMTBfYWN0aW9uc19pbiA8ICg2MCAqIDEwMDAgKiA1KSlcbiAgICAgICAge1xuICAgICAgICAgIC8vIGlmIHRoZSBsYXN0IDEwIGFjdGlvbnMgaW4gNSBtaW51dGVzIDQgc2Vjb25kcywgd2FpdCAzMCBtaW51dGVzXG4gICAgICAgICAgLy8gdGhpcyBsb29rcyBsaWtlIGFuIGF1dG9tYXRpYyBwcm9jZXNzIHRoYXQgaGFzIHRyaWVkIGNvbnRpbnVhbGx5XG4gICAgICAgICAgaWYgKHRpbWVfc2luY2VfbGFzdF9hY3Rpb24gPCAoNjAgKiAxMDAwICogMzAgKyA0MDAwKSlcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJ0b28tbWFueS1yZXF1ZXN0c1wiLCBcIlBsZWFzZSB3YWl0IDMwIG1pbnMgYmVmb3JlIHJldHJ5aW5nXCIpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gdHJ5IHRvIHByZXZlbnQgc2VuZGluZyB0b28gbWFueSBlbWFpbHMgaWYgdGhlIHVzZXIgaGl0cyB0aGUgYnV0dG9uIHJlcGVhdGVkbHlcbiAgICAvLyBJZiB0aGUgbGFzdCAzIGFjdGlvbnMgaW4gYSBzcGFjZSBvZiAxIG1pbnV0ZSwgd2FpdCA1IG1pbnV0ZXNcbiAgICB2YXIgbGFzdF8zX2FjdGlvbnNfaW4gPSBldmVudF9sb2dbMF0gLSBldmVudF9sb2dbMl07XG4gICAgaWYgKGxhc3RfM19hY3Rpb25zX2luIDwgNjAwMDApXG4gICAge1xuICAgICAgLy8gRG9uJ3QgYWxsb3cgYW5vdGhlciBhdHRlbXB0IGZvciA1IG1pbnV0ZXNcbiAgICAgIGlmICh0aW1lX3NpbmNlX2xhc3RfYWN0aW9uIDwgKDYwICogMTAwMCAqIDUpKVxuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwidG9vLW1hbnktcmVxdWVzdHNcIiwgXCJQbGVhc2Ugd2FpdCA1IG1pbnMgYmVmb3JlIHJldHJ5aW5nXCIpO1xuICAgIH1cblxuICAgIC8vIExvY2sgdGhlIHVzZXIncyBhY2NvdW50IGlmIDIwIGVtYWlscyByZXF1ZXN0ZWQgaW4gMzAgbWludXRlc1xuICAgIHZhciBsYXN0XzIwX2FjdGlvbnNfaW4gPSBldmVudF9sb2dbMF0gLSBldmVudF9sb2dbMjldO1xuICAgIGlmIChsYXN0XzIwX2FjdGlvbnNfaW4gPCA2MCAqIDEwMDAgKiAzMClcbiAgICB7XG4gICAgICBBY3Rpb25zTG9nLnVwZGF0ZSgge19pZDogZG9jdW1lbnRfaWR9LCB7IGxvY2tlZDogdHJ1ZSB9ICk7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiYWNjb3VudC1sb2NrZWRcIiwgXCJZb3VyIGFjY291bnQgaGFzIGJlZW4gbG9ja2VkLCBwbGVhc2UgY29udGFjdCBhbiBhZG1pbmlzdHJhdG9yXCIpO1xuICAgIH1cblxuICAgIC8vIHNlbmQgdGhlIGVtYWlsXG4gICAgLy8gcmVjb3JkIHRoZSBhY3Rpb24gaW4gdGhlIGxvZ1xuICAgIEFjdGlvbnNMb2cudXBkYXRlKCB7X2lkOiBkb2N1bWVudF9pZH0sIHsgJHB1c2g6IHsgdmVyaWZpY2F0aW9uX2VtYWlsX3NlbnQ6IHtcbiAgICAgICRlYWNoOiBbbW9tZW50KCkudmFsdWVPZigpXSxcbiAgICAgICRwb3NpdGlvbjogMCBcbiAgICB9fX0gKTtcblxuICAgIC8vIHJlbW92ZSB0aGUgb2xkZXN0IGxvZyBlbnRyeSBpZiB0b28gbWFueSBzdG9yZWRcbiAgICBpZiAobnVtYmVyX29mX2VudHJpZXMgPiBNZXRlb3Iuc2V0dGluZ3MucHJpdmF0ZS52ZXJpZmljYXRpb25fZW1haWxzX251bV90b19sb2cpXG4gICAgICAgIEFjdGlvbnNMb2cudXBkYXRlKCB7X2lkOiBkb2N1bWVudF9pZH0sIHsgJHBvcDogeyB2ZXJpZmljYXRpb25fZW1haWxfc2VudDogMSB9fSApO1xuXG4gICAgaWYgKHR5cGVvZiBlbWFpbCAhPT0gXCJzdHJpbmdcIilcbiAgICAgIEFjY291bnRzLnNlbmRWZXJpZmljYXRpb25FbWFpbChNZXRlb3IudXNlcklkKCksIGVtYWlsKTtcblxuICAgIGVsc2VcbiAgICAgIEFjY291bnRzLnNlbmRWZXJpZmljYXRpb25FbWFpbChNZXRlb3IudXNlcklkKCkpO1xuICB9LFxuICAvLyBtYWtlIHN1cmUgdGhlIHVzZXIgaGFzIHRoZSBjb3JyZWN0IHJvbGUgZGVwZW5kaW5nIG9uIHdoZXRoZXIgdGhlaXIgZW1haWwgYWRkcmVzcyBpcyB2ZXJpZmllZFxuICB1cGRhdGVfdXNlcl9yb2xlcyhpZClcbiAge1xuICAgIGNoZWNrKGlkLCBTdHJpbmcpO1xuXG4gICAgaWYgKE1ldGVvci51c2Vycy5maW5kKHtfaWQ6IGlkfSkuY291bnQoKSA9PSAwKVxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIm5vdC1mb3VuZFwiLCBcIlVzZXIgd2lkdGggaWQgXCIgKyBpZCArIFwibm90IGZvdW5kXCIpO1xuICAgIHZhciB1c2VyID0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUoe19pZDogaWR9KTtcblxuICAgIHRyeSB7XG4gICAgICBpZiAodXNlci5lbWFpbHNbMF0udmVyaWZpZWQpXG4gICAgICB7XG4gICAgICAgIFJvbGVzLmFkZFVzZXJzVG9Sb2xlcyhpZCwgWyd2ZXJpZmllZCddLCAndXNlcnMnKTtcbiAgICAgIH1cbiAgICAgIGVsc2VcbiAgICAgIHtcbiAgICAgICAgUm9sZXMucmVtb3ZlVXNlcnNGcm9tUm9sZXMoaWQsIFsndmVyaWZpZWQnXSwgJ3VzZXJzJyk7XG4gICAgICB9XG4gICAgfVxuICAgIGNhdGNoKGVycikge1xuXG4gICAgfVxuICB9LFxuICAvLyByZXR1cm4gdGhlIGFjdGlvbiBsb2cgZm9yIHRoZSBjdXJyZW50IHVzZXJcbiAgLy8gYWRkIGEgYmxhbmsgaWYgbm9uZSBleGlzdHNcbiAgZ2V0X2FjdGlvbnNfbG9nKClcbiAge1xuICAgIGlmIChBY3Rpb25zTG9nLmZpbmQoIHt1c2VyX2lkOiBNZXRlb3IudXNlcklkKCl9ICkuY291bnQoKSA9PSAwKVxuICAgICAgcmV0dXJuIEFjdGlvbnNMb2cuaW5zZXJ0KHtcbiAgICAgICAgdXNlcl9pZDogTWV0ZW9yLnVzZXJJZCgpLFxuICAgICAgICB1c2VybmFtZTogTWV0ZW9yLnVzZXIoKS51c2VybmFtZSxcbiAgICAgICAgdmVyaWZpY2F0aW9uX2VtYWlsX3NlbnQ6IFtdLFxuICAgICAgICBpbWFnZV91cGxvYWRlZDogW10sXG4gICAgICAgIGltYWdlX3JlbW92ZWQ6IFtdXG4gICAgICB9KTtcbiAgICBcbiAgICBlbHNlXG4gICAgICByZXR1cm4gQWN0aW9uc0xvZy5maW5kT25lKCB7dXNlcl9pZDogTWV0ZW9yLnVzZXJJZCgpfSApLl9pZDtcbiAgfSxcbiAgXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgLy8gSU1QT1JUQU5UISEgT25seSB3b3JrcyBpZiBcImRlYnVnXCJcbiAgLy8gTWV0ZW9yLmNhbGwoXCJkZWJ1Z192YWxpZGF0ZV9lbWFpbFwiLCBNZXRlb3IudXNlcklkKCksIHRydWUpXG4gIGRlYnVnX3ZhbGlkYXRlX2VtYWlsKHVzZXJfaWQsIHZhbGlkYXRlZClcbiAge1xuICAgIGlmICghTWV0ZW9yLnNldHRpbmdzLnByaXZhdGUuZGVidWcpXG4gICAgICByZXR1cm47XG5cbiAgICB2YXIgZW1haWxzID0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUoeyBfaWQ6IHVzZXJfaWR9KS5lbWFpbHM7XG4gICAgZW1haWxzWzBdW1widmVyaWZpZWRcIl0gPSB2YWxpZGF0ZWQ7XG4gICAgdmFyIHVwZGF0ZSA9IHt9O1xuICAgIHVwZGF0ZVtcImVtYWlsc1wiXSA9IGVtYWlscztcbiAgICBNZXRlb3IudXNlcnMudXBkYXRlKHtfaWQ6IHVzZXJfaWR9LCB7JHNldDogdXBkYXRlfSk7XG4gIH1cbn0pO1xuIiwiICAvLyB3aXRoIGZhc3RyZW5kZXIsIHBhcmFtcyBhcmUgcGFzc2VkIGluIGFzIGFuIG9iamVjdC5cblxuICAvLyB0aGVyZSBpcyBhIHN1YnNjcmlwdGlvbiB0aGF0IHBhc3NlcyBpbiBbXSBhcyBwYXJhbXMgYW5kIEkgY2FuJ3QgZmluZCB3aGVyZSBpdCBpcyBjYWxsZWQuIFRoZSBjdXJyZW50IHZlcnNpb24gb2YgTWF0Y2ggYXZvaWRzIGVycm9yIHdoZW4gdGhpcyBlbXB0eSBhcnJheSBpcyBwYXNzZWQgaW4sIGFuZCBldmVyeXRoaW5nIHNlZW1zIHRvIHdvcmsuIFRoZSBpc3N1ZSBvY2N1cnMgYXQgZmlyc3QgbG9hZCBvciBwYWdlIHJlZnJlc2gsIG5vdCBvbiBuYXZpZ2F0aW5nIHJvdXRlcy5cblxuICAvLyBpZiAodHlwZW9mIHBhcmFtcyAhPT0gXCJ1bmRlZmluZWRcIikgY29uc29sZS5sb2coYGkgJHtwYXJhbXMuaX1gKTsgLy8gdGVzdCByYXRlIGxpbWl0IERPIE5PVCBTSElQIFRISVNcblxuICAvLyBmYXN0cmVuZGVyIGNhdXNlcyB0aGUgcHJvZHVjdGlvbiBzZXJ2ZXIgdG8gc2hvdyBcImluY29tcGxldGUgcmVzcG9uc2UgZnJvbSBhcHBsaWNhdGlvblwiIGVycm9yLiBBIHdvcmthcm91bmQgaXMgdG8gbW9kaWZ5IHRoZSBjb3JlIHBhY2thZ2UgbWluaWZpZXIuanMgdG8gcmVzZXJ2ZSBrZXl3b3Jkc1xuICAvLyBodHRwczovL2dpdGh1Yi5jb20vYWJlY2tzL21ldGVvci1mYXN0LXJlbmRlci9pc3N1ZXMvMlxuXG4gIC8vIHVwZGF0ZTogbWV0ZW9yIC0tcHJvZHVjdGlvbiAtLXNldHRpbmdzIHNldHRpbmdzLmpzb24gc2hvdWxkIHNpbXVsYXRlIHRoZSBtaW5pZmljYXRpb24gbG9jYWxseSB3aGVyZSB0aGUgc2VydmVyIG91dHB1dCBjYW4gYmUgdmlld2VkLiBIb3dldmVyIHRoZSBhcHAgZG9lcyBub3QgY3Jhc2gsIGl0IGp1c3QgZ2VuZXJhdGVzIHRoZSBzYW1lIE1hdGNoIGZhaWx1cmUgaW4gcHVibGlzaC5qcy5cblxuLy8gRGF0YSBmb3Igc2VhcmNoXG5NZXRlb3IucHVibGlzaCgnc2VhcmNoX3BhdHRlcm5zJywgZnVuY3Rpb24oKXtcblxuICBmaWVsZHMgPSB7XG4gICAgX2lkOiAxLFxuICAgIGNyZWF0ZWRfYnlfdXNlcm5hbWU6IDEsXG4gICAgbmFtZTogMSxcbiAgICBuYW1lX3NvcnQ6IDEsXG4gICAgbnVtYmVyX29mX3RhYmxldHM6IDEsXG4gICAgdGFnczogMSxcbiAgfVxuXG4gIGlmICh0aGlzLnVzZXJJZClcbiAgICByZXR1cm4gUGF0dGVybnMuZmluZChcbiAgICAgIHtcbiAgICAgICAgJG9yOiBbXG4gICAgICAgICAgeyBwcml2YXRlOiB7JG5lOiB0cnVlfSB9LFxuICAgICAgICAgIHsgY3JlYXRlZF9ieTogdGhpcy51c2VySWQgfSxcbiAgICAgICAgXVxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgZmllbGRzOiBmaWVsZHMsXG4gICAgICB9XG4gICAgKTtcbiAgZWxzZVxuICAgIHJldHVybiBQYXR0ZXJucy5maW5kKFxuICAgICAgeyBwcml2YXRlOiB7JG5lOiB0cnVlfSB9LFxuICAgICAge1xuICAgICAgICBmaWVsZHM6IGZpZWxkcyxcbiAgICAgIH1cbiAgICApO1xufSk7XG5cbk1ldGVvci5wdWJsaXNoKCdzZWFyY2hfdXNlcnMnLCBmdW5jdGlvbigpe1xuXG4gIHZhciB1cGRhdGUgPSB7fTtcbiAgdXBkYXRlW1wicHJvZmlsZS5wdWJsaWNfcGF0dGVybnNfY291bnRcIl0gPSB7JGd0OiAwfTsgLy8gdGhpcyBjb25zdHJ1Y3Rpb24gaXMgcmVxdWlyZWQgdG8gcXVlcnkgYSBjaGlsZCBwcm9wZXJ0eVxuXG4gIGlmICh0aGlzLnVzZXJJZClcbiAgICByZXR1cm4gTWV0ZW9yLnVzZXJzLmZpbmQoXG4gICAgICB7JG9yOiBbdXBkYXRlLCB7X2lkOiB0aGlzLnVzZXJJZH1dfSxcbiAgICAgIHtmaWVsZHM6IHtcbiAgICAgICAgX2lkOiAxLFxuICAgICAgICBwcm9maWxlOiAxLFxuICAgICAgICB1c2VybmFtZTogMSxcbiAgICAgIH19LFxuICAgICk7XG4gIGVsc2VcbiAgICByZXR1cm4gTWV0ZW9yLnVzZXJzLmZpbmQoXG4gICAgICB7JG9yOiBbdXBkYXRlXX0sXG4gICAgICB7ZmllbGRzOiB7XG4gICAgICAgIF9pZDogMSxcbiAgICAgICAgcHJvZmlsZTogMSxcbiAgICAgICAgdXNlcm5hbWU6IDEsXG4gICAgICB9fSxcbiAgICApO1xufSk7XG5cbi8vIFNpbmdsZSBwYXR0ZXJuXG5NZXRlb3IucHVibGlzaCgncGF0dGVybicsIGZ1bmN0aW9uKHBhcmFtcyl7XG4gIGNoZWNrKHBhcmFtcywgT2JqZWN0KTtcbiAgY2hlY2socGFyYW1zLnBhdHRlcm5faWQsIFN0cmluZyk7XG5cbiAgaWYgKHRoaXMudXNlcklkKVxuICAgIHJldHVybiBQYXR0ZXJucy5maW5kKFxuICAgICAgeyAkYW5kOiBcbiAgICAgICAgW1xuICAgICAgICAgIHsgX2lkOiBwYXJhbXMucGF0dGVybl9pZCB9LCBcbiAgICAgICAgICB7ICRvcjogW1xuICAgICAgICAgICAgeyBwcml2YXRlOiB7JG5lOiB0cnVlfSB9LFxuICAgICAgICAgICAgeyBjcmVhdGVkX2J5OiB0aGlzLnVzZXJJZCB9XG4gICAgICAgICAgXX1cbiAgICAgICAgXVxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgbGltaXQ6IDFcbiAgICAgIH1cbiAgICApO1xuICBlbHNlXG4gICAgcmV0dXJuIFBhdHRlcm5zLmZpbmQoXG4gICAgICB7ICRhbmQ6IFxuICAgICAgICBbXG4gICAgICAgICAgeyBfaWQ6IHBhcmFtcy5wYXR0ZXJuX2lkIH0sXG4gICAgICAgICAgeyBwcml2YXRlOiB7JG5lOiB0cnVlfSB9LFxuICAgICAgICBdXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBsaW1pdDogMVxuICAgICAgfVxuICAgICk7XG59KTtcblxuLy8gUmVjZW50IFBhdHRlcm5zIGZvciBIb21lIHBhZ2Vcbk1ldGVvci5wdWJsaXNoKCdyZWNlbnRfcGF0dGVybnMnLCBmdW5jdGlvbihwYXJhbXMpe1xuICBjaGVjayhwYXJhbXMsIE9iamVjdCk7XG5cbiAgdmFyIHBhdHRlcm5faWRzID0gdHlwZW9mIHBhcmFtcy5wYXR0ZXJuX2lkcyA9PT0gXCJ1bmRlZmluZWRcIiA/IFtdIDogcGFyYW1zLnBhdHRlcm5faWRzO1xuXG4gIHZhciBmaWVsZHMgPSB7XG4gICAgX2lkOiAxLFxuICAgIGF1dG9fcHJldmlldzogMSxcbiAgICBjcmVhdGVkX2F0OiAxLFxuICAgIGNyZWF0ZWRfYnk6IDEsXG4gICAgY3JlYXRlZF9ieV91c2VybmFtZTogMSxcbiAgICBkZXNjcmlwdGlvbjogMSxcbiAgICBuYW1lOiAxLFxuICAgIG5hbWVfc29ydDogMSxcbiAgICBudW1iZXJfb2ZfdGFibGV0czogMSxcbiAgICBwcml2YXRlOiAxLFxuICB9XG5cbiAgaWYgKHRoaXMudXNlcklkKVxuICAgIHJldHVybiBQYXR0ZXJucy5maW5kKFxuICAgICAgeyAkYW5kOiBcbiAgICAgICAgW1xuICAgICAgICAgIHsgX2lkOiB7JGluOnBhcmFtcy5wYXR0ZXJuX2lkc319LCBcbiAgICAgICAgICB7ICRvcjogW1xuICAgICAgICAgICAgeyBwcml2YXRlOiB7JG5lOiB0cnVlfSB9LFxuICAgICAgICAgICAgeyBjcmVhdGVkX2J5OiB0aGlzLnVzZXJJZCB9XG4gICAgICAgICAgXX1cbiAgICAgICAgXVxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgbGltaXQ6IE1ldGVvci5teV9wYXJhbXMubWF4X3JlY2VudHMsXG4gICAgICAgIGZpZWxkczogZmllbGRzLFxuICAgICAgfVxuICAgICk7XG4gIGVsc2VcbiAgICByZXR1cm4gUGF0dGVybnMuZmluZChcbiAgICAgIHsgJGFuZDogXG4gICAgICAgIFtcbiAgICAgICAgICB7IF9pZDogeyRpbjpwYXJhbXMucGF0dGVybl9pZHN9fSwgXG4gICAgICAgICAgeyBwcml2YXRlOiB7JG5lOiB0cnVlfX0sXG4gICAgICAgIF1cbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIGxpbWl0OiBNZXRlb3IubXlfcGFyYW1zLm1heF9yZWNlbnRzLFxuICAgICAgICBmaWVsZHM6IGZpZWxkcyxcbiAgICAgIH1cbiAgICApO1xufSk7XG5cbi8vIE5ldyBQYXR0ZXJucyBmb3IgSG9tZSBwYWdlXG5NZXRlb3IucHVibGlzaCgnbmV3X3BhdHRlcm5zJywgZnVuY3Rpb24oKXtcbiAgdmFyIGZpZWxkcyA9IHtcbiAgICBfaWQ6IDEsXG4gICAgYXV0b19wcmV2aWV3OiAxLFxuICAgIGNyZWF0ZWRfYXQ6IDEsXG4gICAgY3JlYXRlZF9ieTogMSxcbiAgICBjcmVhdGVkX2J5X3VzZXJuYW1lOiAxLFxuICAgIGRlc2NyaXB0aW9uOiAxLFxuICAgIG5hbWU6IDEsXG4gICAgbmFtZV9zb3J0OiAxLFxuICAgIG51bWJlcl9vZl90YWJsZXRzOiAxLFxuICAgIHByaXZhdGU6IDEsXG4gIH1cblxuICBpZiAodGhpcy51c2VySWQpXG4gICAgcmV0dXJuIFBhdHRlcm5zLmZpbmQoXG4gICAgICB7XG4gICAgICAgICRvcjogW1xuICAgICAgICAgIHsgcHJpdmF0ZTogeyRuZTogdHJ1ZX0gfSxcbiAgICAgICAgICB7IGNyZWF0ZWRfYnk6IHRoaXMudXNlcklkIH0sXG4gICAgICAgIF1cbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIGxpbWl0OiBNZXRlb3IubXlfcGFyYW1zLm1heF9ob21lX3RodW1ibmFpbHMsXG4gICAgICAgIHNvcnQ6IHtjcmVhdGVkX2F0OiAtMX0sXG4gICAgICAgIGZpZWxkczogZmllbGRzLFxuICAgICAgfVxuICAgICk7XG4gIGVsc2VcbiAgICByZXR1cm4gUGF0dGVybnMuZmluZChcbiAgICAgIHsgcHJpdmF0ZTogeyRuZTogdHJ1ZX0gfSxcbiAgICAgIHtcbiAgICAgICAgbGltaXQ6IE1ldGVvci5teV9wYXJhbXMubWF4X2hvbWVfdGh1bWJuYWlscyxcbiAgICAgICAgc29ydDoge2NyZWF0ZWRfYXQ6IC0xfSxcbiAgICAgICAgZmllbGRzOiBmaWVsZHMsXG4gICAgICB9XG4gICAgKTtcbn0pO1xuXG4vLyBNeSBQYXR0ZXJucyBmb3IgSG9tZSBwYWdlXG5NZXRlb3IucHVibGlzaCgnbXlfcGF0dGVybnMnLCBmdW5jdGlvbigpe1xuXG4gIHZhciBmaWVsZHMgPSB7XG4gICAgX2lkOiAxLFxuICAgIGF1dG9fcHJldmlldzogMSxcbiAgICBjcmVhdGVkX2F0OiAxLFxuICAgIGNyZWF0ZWRfYnk6IDEsXG4gICAgY3JlYXRlZF9ieV91c2VybmFtZTogMSxcbiAgICBkZXNjcmlwdGlvbjogMSxcbiAgICBuYW1lOiAxLFxuICAgIG5hbWVfc29ydDogMSxcbiAgICBudW1iZXJfb2ZfdGFibGV0czogMSxcbiAgICBwcml2YXRlOiAxLFxuICB9XG5cbiAgaWYgKHRoaXMudXNlcklkKVxuICAgIHJldHVybiBQYXR0ZXJucy5maW5kKFxuICAgICAgeyBjcmVhdGVkX2J5OiB0aGlzLnVzZXJJZCB9LFxuICAgICAgICB7XG4gICAgICAgICAgbGltaXQ6IE1ldGVvci5teV9wYXJhbXMubWF4X2hvbWVfdGh1bWJuYWlscyxcbiAgICAgICAgICBzb3J0OiB7bmFtZV9zb3J0OiAxfSxcbiAgICAgICAgICBmaWVsZHM6IGZpZWxkc1xuICAgICAgICB9XG4gICAgICApO1xuICBlbHNlXG4gICAgcmV0dXJuIFtdO1xuXG59KTtcblxuLy8gQWxsIFBhdHRlcm5zIGZvciBIb21lIHBhZ2Vcbk1ldGVvci5wdWJsaXNoKCdhbGxfcGF0dGVybnMnLCBmdW5jdGlvbigpe1xuXG4gIHZhciBmaWVsZHMgPSB7XG4gICAgX2lkOiAxLFxuICAgIGF1dG9fcHJldmlldzogMSxcbiAgICBjcmVhdGVkX2F0OiAxLFxuICAgIGNyZWF0ZWRfYnk6IDEsXG4gICAgY3JlYXRlZF9ieV91c2VybmFtZTogMSxcbiAgICBkZXNjcmlwdGlvbjogMSxcbiAgICBuYW1lOiAxLFxuICAgIG5hbWVfc29ydDogMSxcbiAgICBudW1iZXJfb2ZfdGFibGV0czogMSxcbiAgICBwcml2YXRlOiAxLFxuICB9XG5cbiAgaWYgKHRoaXMudXNlcklkKVxuICAgIHJldHVybiBQYXR0ZXJucy5maW5kKFxuICAgICAge1xuICAgICAgICAkb3I6IFtcbiAgICAgICAgICB7IHByaXZhdGU6IHskbmU6IHRydWV9IH0sXG4gICAgICAgICAgeyBjcmVhdGVkX2J5OiB0aGlzLnVzZXJJZCB9LFxuICAgICAgICBdXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBsaW1pdDogTWV0ZW9yLm15X3BhcmFtcy5tYXhfaG9tZV90aHVtYm5haWxzLFxuICAgICAgICBzb3J0OiB7bmFtZV9zb3J0OiAxfSxcbiAgICAgICAgZmllbGRzOiBmaWVsZHMsXG4gICAgICB9XG4gICAgKTtcbiAgZWxzZVxuICAgIHJldHVybiBQYXR0ZXJucy5maW5kKFxuICAgICAgeyBwcml2YXRlOiB7JG5lOiB0cnVlfSB9LFxuICAgICAge1xuICAgICAgICBsaW1pdDogTWV0ZW9yLm15X3BhcmFtcy5tYXhfaG9tZV90aHVtYm5haWxzLFxuICAgICAgICBzb3J0OiB7bmFtZV9zb3J0OiAxfSxcbiAgICAgICAgZmllbGRzOiBmaWVsZHMsXG4gICAgICB9XG4gICAgKTtcbn0pO1xuXG4vLyBTaW5nbGUgdXNlclxuTWV0ZW9yLnB1Ymxpc2goJ3VzZXInLCBmdW5jdGlvbihwYXJhbXMpe1xuICBjaGVjayhwYXJhbXMsIE9iamVjdCk7XG4gIGNoZWNrKHBhcmFtcy51c2VyX2lkLCBTdHJpbmcpO1xuXG4gIC8vIHRoZSB1c2VyJ3MgZW1haWxzIHdpbGwgYmUgcmV0dXJuZWQgYnV0IGZvciBvdGhlciB1c2Vycywgb25seSBwdWJsaWMgaW5mb3JtYXRpb24gc2hvdWxkIGJlIHNob3duLlxuICB2YXIgdXBkYXRlID0ge307XG4gIHVwZGF0ZVtcInByb2ZpbGUucHVibGljX3BhdHRlcm5zX2NvdW50XCJdID0geyRndDogMH07IC8vIHRoaXMgY29uc3RydWN0aW9uIGlzIHJlcXVpcmVkIHRvIHF1ZXJ5IGEgY2hpbGQgcHJvcGVydHlcbiAgdXBkYXRlW1wiaWRcIl0gPSBwYXJhbXMudXNlcl9pZDtcblxuICByZXR1cm4gTWV0ZW9yLnVzZXJzLmZpbmQoXG4gICAgeyRvcjogW3VwZGF0ZSwge19pZDogdGhpcy51c2VySWR9XX0sXG4gICAge1xuICAgICAgbGltaXQ6IDEsXG4gICAgICBzb3J0OiB7XCJwcm9maWxlLm5hbWVfc29ydFwiOiAxfSxcbiAgICAgIGZpZWxkczoge19pZDogMSwgdXNlcm5hbWU6IDEsIHByb2ZpbGU6IDF9LFxuICAgIH0sXG4gICk7XG59KTsgXG5cbi8vIFVzZXJzIGZvciBIb21lIHBhZ2Vcbk1ldGVvci5wdWJsaXNoKCd1c2Vyc19ob21lJywgZnVuY3Rpb24odHJpZ2dlcil7XG5cbiAgLy8gc2hvdyB0aGUgY3VycmVudCB1c2VyIGFuZCBhbnkgdXNlcnMgd2hvIGhhdmUgcHVibGljIHBhdHRlcm5zXG4gIGNoZWNrKHRyaWdnZXIsIE1hdGNoLk9wdGlvbmFsKE51bWJlcikpO1xuXG4gIC8vIHRoZSB1c2VyJ3MgZW1haWxzIHdpbGwgYmUgcmV0dXJuZWQgYnV0IGZvciBvdGhlciB1c2Vycywgb25seSBwdWJsaWMgaW5mb3JtYXRpb24gc2hvdWxkIGJlIHNob3duLlxuICB2YXIgdXBkYXRlID0ge307XG4gIHVwZGF0ZVtcInByb2ZpbGUucHVibGljX3BhdHRlcm5zX2NvdW50XCJdID0geyRndDogMH07IC8vIHRoaXMgY29uc3RydWN0aW9uIGlzIHJlcXVpcmVkIHRvIHF1ZXJ5IGEgY2hpbGQgcHJvcGVydHlcblxuICBpZiAodGhpcy51c2VySWQpXG4gICAgcmV0dXJuIE1ldGVvci51c2Vycy5maW5kKFxuICAgICAgeyRvcjogW3VwZGF0ZSwge19pZDogdGhpcy51c2VySWR9XX0sXG4gICAgICB7XG4gICAgICAgIGxpbWl0OiBNZXRlb3IubXlfcGFyYW1zLm1heF9ob21lX3RodW1ibmFpbHMsXG4gICAgICAgIHNvcnQ6IHtcInByb2ZpbGUubmFtZV9zb3J0XCI6IDF9LFxuICAgICAgICBmaWVsZHM6IHtfaWQ6IDEsIHVzZXJuYW1lOiAxLCBwcm9maWxlOiAxfSxcbiAgICAgIH1cbiAgICApO1xuICBlbHNlXG4gICAgcmV0dXJuIE1ldGVvci51c2Vycy5maW5kKFxuICAgICAgeyRvcjogW3VwZGF0ZV19LFxuICAgICAge1xuICAgICAgICBsaW1pdDogTWV0ZW9yLm15X3BhcmFtcy5tYXhfaG9tZV90aHVtYm5haWxzLFxuICAgICAgICBzb3J0OiB7XCJwcm9maWxlLm5hbWVfc29ydFwiOiAxfSxcbiAgICAgICAgZmllbGRzOiB7X2lkOiAxLCB1c2VybmFtZTogMSwgcHJvZmlsZTogMX0sXG4gICAgICB9XG4gICAgKTtcbn0pO1xuXG4vLyBQdWJsaXNoIGltYWdlcyB1cGxvYWRlZCBieSB0aGUgdXNlclxuTWV0ZW9yLnB1Ymxpc2goJ2ltYWdlcycsIGZ1bmN0aW9uKHBhcmFtcykge1xuICByZXR1cm4gSW1hZ2VzLmZpbmQoKTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaCgndGFncycsIGZ1bmN0aW9uKCl7XG4gIC8vIFRoZSBjb2xsZWN0aW9uIGlzIHJlYWRvbmx5IGFuZCBhbGwgdGFncyBzaG91bGQgYmUgcHVibGljXG4gIHJldHVybiBNZXRlb3IudGFncy5maW5kKCk7XG59KTtcblxuLy8gRGVidWcgb25seSAtIHNob3cgbG9nIG9mIHVzZXIgYWN0aW9uc1xuLy8gdG8gYWNjZXNzIHRoaXMsIHN1YnNjcmliZSBpbiB0aGUgY2xpZW50IHdpdGg6XG4vLyBNZXRlb3Iuc3Vic2NyaWJlKCdhY3Rpb25zX2xvZycpXG5NZXRlb3IucHVibGlzaCgnYWN0aW9uc19sb2cnLCBmdW5jdGlvbigpIHtcbiAgaWYgKCFNZXRlb3Iuc2V0dGluZ3MucHJpdmF0ZS5kZWJ1ZylcbiAgICByZXR1cm47XG5cbiAgcmV0dXJuIEFjdGlvbnNMb2cuZmluZCgpO1xufSk7XG4iLCJpZiAoTWV0ZW9yLmlzQ2xpZW50KSB7XG4gIC8vIGNvbmZpZ3VyZSB0aGUgZGVmYXVsdCBhY2NvdW50cy11aSBwYWNrYWdlXG4gIFxuICBBY2NvdW50cy51aS5jb25maWcoe1xuICAgIHBhc3N3b3JkU2lnbnVwRmllbGRzOiBcIlVTRVJOQU1FX0FORF9FTUFJTFwiXG4gIH0pO1xuICBcbiAgU2Vzc2lvbi5zZXQoJ3dpbmRvd193aWR0aCcsICQod2luZG93KS53aWR0aCgpKTtcbiAgU2Vzc2lvbi5zZXQoJ3dpbmRvd19oZWlnaHQnLCAkKHdpbmRvdykuaGVpZ2h0KCkpO1xuXG4gIE1ldGVvci5zdGFydHVwKGZ1bmN0aW9uICgpIHtcblxuICAgIFNlc3Npb24uc2V0KCdjbGlja19sYXRjaCcsIGZhbHNlKTsgLy8gdXNlZCB0byBwcmV2ZW50IGRvdWJsZSBjbGljayBvbiBidXR0b25zXG5cbiAgICBTZXNzaW9uLnNldChcImxvYWRpbmdcIiwgZmFsc2UpO1xuXG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIGZ1bmN0aW9uKCl7XG4gICAgICBTZXNzaW9uLnNldCgnd2luZG93X3dpZHRoJywgJCh3aW5kb3cpLndpZHRoKCkpO1xuICAgICAgU2Vzc2lvbi5zZXQoJ3dpbmRvd19oZWlnaHQnLCAkKHdpbmRvdykuaGVpZ2h0KCkpO1xuICAgICAgU2Vzc2lvbi5zZXQoJ3RodW1ibmFpbHNfaW5fcm93JywgTWV0ZW9yLm15X2Z1bmN0aW9ucy50aHVtYm5haWxzX2luX3JvdygpKTtcbiAgICB9KTtcblxuICAgIFNlc3Npb24uc2V0KCdkaXNwbGF5X21pbl90YWJsZXRzJywgMSk7XG4gIH0pO1xuXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAvLyBlbmFibGUgc2VhcmNoXG4gIFRlbXBsYXRlLmhlYWRlci5jcmVhdGVkID0gZnVuY3Rpb24oKSB7XG4gICAgdGhpcy5zdWJzY3JpYmUoJ3NlYXJjaF9wYXR0ZXJucycpO1xuICAgIHRoaXMuc3Vic2NyaWJlKCdzZWFyY2hfdXNlcnMnKTtcbiAgfVxuXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAvLyBIZWxwZXJzIGZvciB0ZW1wbGF0ZXMgdGhhdCBtYXkgYmUgdXNlZCBvbiBtdWx0aXBsZSBwYWdlc1xuXG4gIC8qICoqKiBMb2FkaW5nIHRlbXBsYXRlICoqKiAqL1xuICBUZW1wbGF0ZS5sb2FkaW5nLnJlbmRlcmVkID0gZnVuY3Rpb24oKSB7XG4gICAgJCgnYm9keScpLmF0dHIoXCJjbGFzc1wiLCBcImxvYWRpbmdcIik7XG4gICAgTWV0ZW9yLm15X2Z1bmN0aW9ucy5pbml0aWFsaXplX3JvdXRlKCk7XG4gIH1cblxuICBUZW1wbGF0ZS5tYWluX2xheW91dC5yZW5kZXJlZCA9IGZ1bmN0aW9uKCkge1xuICAgIC8vIG1haW4gdGVtcGxhdGUgY29udGFpbnMgdGhlIGhlYWRlciBhbmQgd2lkdGggZGl2c1xuICAgICAkKHdpbmRvdykub24oJ3Jlc2l6ZSBvcmllbnRhdGlvbmNoYW5nZScsIGZ1bmN0aW9uKGUpIHtcbiAgICAgIE1ldGVvci5teV9mdW5jdGlvbnMucmVzaXplX3BhZ2UoKTsgIFxuICAgIH0pO1xuXG4gICAgICQoXCIjd2lkdGhcIikub24oJ3Njcm9sbCcsIGZ1bmN0aW9uKGUpIHtcbiAgICAgIE1ldGVvci5teV9mdW5jdGlvbnMucmVzaXplX3BhZ2UoKTsgIFxuICAgIH0pOyBcbiAgIH1cblxuICBUZW1wbGF0ZS5tYWluX2xheW91dC5oZWxwZXJzKHtcbiAgICBsb2FkaW5nOiBmdW5jdGlvbigpe1xuICAgICAgaWYgKFNlc3Npb24uZXF1YWxzKCdsb2FkaW5nJywgdHJ1ZSkpXG4gICAgICAgIHJldHVybiBcImxvYWRpbmdcIjtcbiAgICB9XG4gIH0pO1xuXG4gIC8qICoqKiBIZWxwZXIgZnVuY3Rpb25zIHRoYXQgbWF5IGJlIHVzZWQgYnkgbW9yZSB0aGFuIG9uZSB0ZW1wbGF0ZSAqKiogKi9cbiAgLy8gQWxsb3dzIGEgdGVtcGxhdGUgdG8gY2hlY2sgd2hldGhlciBhIGhlbHBlciB2YWx1ZSBlcXVhbHMgYSBzdHJpbmdcbiAgVUkucmVnaXN0ZXJIZWxwZXIoJ2VxdWFscycsIGZ1bmN0aW9uIChhLCBiKSB7XG4gICAgcmV0dXJuIChhID09PSBiKTtcbiAgfSk7XG5cbiAgVUkucmVnaXN0ZXJIZWxwZXIoJ211bHRpcGx5JywgZnVuY3Rpb24gKGEsIGIpIHtcbiAgICByZXR1cm4gYSpiO1xuICB9KTtcblxuICAvLyBhbGxvd3MgYSB0ZW1wbGF0ZSB0byBjaGVjayB3aGV0aGVyIGEgc2Vzc2lvbiB2YXJpYWJsZSBlcXVhbHMgYSB2YWx1ZVxuICBVSS5yZWdpc3RlckhlbHBlcignc2Vzc2lvbl9lcXVhbHMnLCBmdW5jdGlvbihzZXNzaW9uX3ZhciwgdGVzdF92YWx1ZSl7XG4gICAgaWYgKFNlc3Npb24uZ2V0KHNlc3Npb25fdmFyKSA9PSB0ZXN0X3ZhbHVlKVxuICAgICAgcmV0dXJuIHRydWU7XG4gICAgZWxzZVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICB9KTtcblxuICBVSS5yZWdpc3RlckhlbHBlcignaXNfY29yZG92YScsIGZ1bmN0aW9uICgpIHtcbiAgICBpZihNZXRlb3IuaXNDb3Jkb3ZhKVxuICAgICAgcmV0dXJuIHRydWU7XG4gIH0pO1xuXG4gIFVJLnJlZ2lzdGVySGVscGVyKCdzaG93X2VkaXRhYmxlX2ZpZWxkJywgZnVuY3Rpb24gKGZpZWxkX3ZhbHVlLCBfaWQpIHtcbiAgICAvLyBlZGl0YWJsZSBmaWVsZCBzdWNoIGFzIHBhdHRlcm4gZGVzY3JpcHRpb24gaXMgc2hvd24gaWY6XG4gICAgLy8gdGhlIHVzZXIgY2FuIGVkaXQgdGhlIHBhdHRlcm4sIG9yXG4gICAgLy8gYSBzdHJpbmcgdmFsdWUgZXhpc3RzIGFuZCBpcyBub3QgZW1wdHlcbiAgICBpZiAoTWV0ZW9yLm15X2Z1bmN0aW9ucy5jYW5fZWRpdF9wYXR0ZXJuKF9pZCkpXG4gICAgICByZXR1cm4gdHJ1ZTtcblxuICAgIHJldHVybiBNZXRlb3IubXlfZnVuY3Rpb25zLnN0cmluZ19leGlzdHMoZmllbGRfdmFsdWUpO1xuICB9KTtcblxuICBVSS5yZWdpc3RlckhlbHBlcignc3RyaW5nX2V4aXN0cycsIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgcmV0dXJuIE1ldGVvci5teV9mdW5jdGlvbnMuc3RyaW5nX2V4aXN0cyh2YWx1ZSk7XG4gIH0pO1xuXG4gIC8vIHVzZWQgYnkgY29ubmVjdGlvbl9zdGF0dXMgdGVtcGxhdGUgYW5kIGFsc28gdG8gYXBwbHkgY2xhc3MgdG8gZGl2I3dpZHRoXG4gIFVJLnJlZ2lzdGVySGVscGVyKCdjb25uZWN0aW9uX3N0YXR1cycsIGZ1bmN0aW9uICgpIHtcbiAgICAvKiBtZXRlb3Iuc3RhdHVzKCkuc3RhdHVzIGNhbiBoYXZlIHRoZXNlIHZhbHVlczpcbiAgICAgIGNvbm5lY3RlZFxuICAgICAgY29ubmVjdGluZyAoZGlzY29ubm5lY3RlZCwgdHJ5aW5nIHRvIGNvbm5lY3QpXG4gICAgICBmYWlsZWQgKHBlcm1haW5lbnRseSBmYWlsZWQgZS5nLiBpbmNvbXBhdGlibGUpXG4gICAgICB3YWl0aW5nICh3aWxsIHRyeSB0byByZWNvbm5lY3QpXG4gICAgICBvZmZsaW5lICh1c2VyIGRpc2Nvbm5lY3RlZCB0aGUgY29ubmVjdGlvbilcbiAgICAqL1xuXG4gICAgLy8gdGhlcmUgaXMgYSAzIHNlY29uZCBkZWxheSBiZWZvcmUgcmVwb3J0aW5nIGNvbm5lY3Rpb24gbG9zdCwgcGFydGx5IHRvIGF2b2lkIGEgZmFsc2UgJ2Nvbm5lY3Rpb24gbG9zdCcgbWVzc2FnZSB3aGVuIHRoZSBwYWdlIGlzIGZpcnN0IGxvYWRlZC5cblxuICAgIHN3aXRjaCAoTWV0ZW9yLnN0YXR1cygpLnN0YXR1cylcbiAgICB7XG4gICAgICBjYXNlIFwiY29ubmVjdGluZ1wiOiAgLy8gRmFsbHRocm91Z2hcbiAgICAgIGNhc2UgXCJ3YWl0aW5nXCI6XG4gICAgICAgIGlmICh0eXBlb2YgY29ubmVjdGlvbl90aW1lb3V0ID09PSBcInVuZGVmaW5lZFwiKVxuICAgICAgICAgIGNvbm5lY3Rpb25fdGltZW91dCA9IHNldFRpbWVvdXQoZnVuY3Rpb24oKXtcbiAgICAgICAgICAgIFNlc3Npb24uc2V0KFwiY29ubmVjdGlvbl9zdGF0dXNcIiwgXCJ0cnlpbmdfdG9fY29ubmVjdFwiKTtcbiAgICAgICAgICB9LCAzMDAwKTtcbiAgICAgICAgYnJlYWs7XG5cbiAgICAgIGNhc2UgXCJmYWlsZWRcIjogIC8vIEZhbGx0aHJvdWdoXG4gICAgICBjYXNlIFwib2ZmbGluZVwiOlxuICAgICAgICBpZiAodHlwZW9mIGRpc2Nvbm5lY3RlZF90aW1lb3V0ID09PSBcInVuZGVmaW5lZFwiKVxuICAgICAgICAgIGRpc2Nvbm5lY3RlZF90aW1lb3V0ID0gc2V0VGltZW91dChmdW5jdGlvbigpe1xuICAgICAgICAgICAgU2Vzc2lvbi5zZXQoXCJjb25uZWN0aW9uX3N0YXR1c1wiLCBcImRpc2Nvbm5lY3RlZFwiKTtcbiAgICAgICAgICB9LCAzMDAwKTtcbiAgICAgICAgU2Vzc2lvbi5zZXQoXCJjb25uZWN0aW9uX3N0YXR1c1wiLCBcImRpc2Nvbm5lY3RlZFwiKTtcbiAgICAgICAgYnJlYWs7XG5cbiAgICAgIGNhc2UgXCJjb25uZWN0ZWRcIjpcbiAgICAgICAgU2Vzc2lvbi5zZXQoXCJjb25uZWN0ZWRcIiwgdHJ1ZSk7XG4gICAgICAgIGlmICh0eXBlb2YgY29ubmVjdGlvbl90aW1lb3V0ICE9PSBcInVuZGVmaW5lZFwiKVxuICAgICAgICAgIGNsZWFyVGltZW91dChjb25uZWN0aW9uX3RpbWVvdXQpO1xuXG4gICAgICAgIGlmICh0eXBlb2YgZGlzY29ubmVjdGVkX3RpbWVvdXQgIT09IFwidW5kZWZpbmVkXCIpXG4gICAgICAgICAgY2xlYXJUaW1lb3V0KGRpc2Nvbm5lY3RlZF90aW1lb3V0KTtcblxuICAgICAgICBTZXNzaW9uLnNldChcImNvbm5lY3Rpb25fc3RhdHVzXCIsIFwiY29ubmVjdGVkXCIpO1xuICAgICAgICBicmVhaztcblxuICAgICAgZGVmYXVsdDpcbiAgICAgICAgU2Vzc2lvbi5zZXQoXCJjb25uZWN0aW9uX3N0YXR1c1wiLCBcImRpc2Nvbm5lY3RlZFwiKTtcbiAgICAgICAgYnJlYWs7XG4gICAgfVxuICAgIHJldHVybiBTZXNzaW9uLmdldChcImNvbm5lY3Rpb25fc3RhdHVzXCIpO1xuICB9KTtcblxuICBVSS5yZWdpc3RlckhlbHBlcignbm9fd2VhdmluZ19yb3dzJywgZnVuY3Rpb24oKSB7XG4gICAgLy8gY2Fubm90IHJlbW92ZSBhIHJvdyBmcm9tIHBhdHRlcm4sIGFuZFxuICAgIC8vIGNhbm5vdCB2aWV3IGludGVyYWN0aXZlIHdlYXZpbmcgY2hhcnQgYmVjYXVzZSBubyByb3dzIHdvdmVuXG4gICAgLy8gY2FuIG9ubHkgaGFwcGVuIGluIG1hbnVhbCBzaW11bGF0aW9uIHBhdHRlcm5cblxuICAgIC8vIGF2b2lkcyBlcnJvciB3aGVuIHBhdHRlcm4gaXMgcHJpdmF0ZSBhbmQgdXNlciBkb2Vzbid0IGhhdmUgcGVybWlzc2lvbiB0byBzZWUgaXRcbiAgICB2YXIgcGF0dGVybl9pZCA9IFJvdXRlci5jdXJyZW50KCkucGFyYW1zLl9pZDtcbiAgICBpZiAoIU1ldGVvci5teV9mdW5jdGlvbnMucGF0dGVybl9leGlzdHMocGF0dGVybl9pZCkpXG4gICAgICAgIHJldHVybiBcImRpc2FibGVkXCI7XG5cbiAgICB2YXIgcGF0dGVybiA9IFBhdHRlcm5zLmZpbmRPbmUoe19pZDogcGF0dGVybl9pZH0sIHtmaWVsZHM6IHsgbnVtYmVyX29mX3Jvd3M6IDF9fSk7XG5cbiAgICBpZiAocGF0dGVybi5udW1iZXJfb2Zfcm93cyA8IDEpXG4gICAgICByZXR1cm4gXCJkaXNhYmxlZFwiO1xuICB9KTtcblxuICBVSS5yZWdpc3RlckhlbHBlcignaW5jbHVkZXNfaWRsZScsIGZ1bmN0aW9uKCkge1xuICAgIC8vIGRvZXMgdGhlIHBhdHRlcm4gY29udGFpbiBhbnkgaWRsZSB0YWJsZXRzPyBVc2VkIGluIGtleVxuICAgIHZhciBwYXR0ZXJuX2lkID0gUm91dGVyLmN1cnJlbnQoKS5wYXJhbXMuX2lkO1xuICAgIGlmICghTWV0ZW9yLm15X2Z1bmN0aW9ucy5wYXR0ZXJuX2V4aXN0cyhwYXR0ZXJuX2lkKSlcbiAgICAgICAgcmV0dXJuO1xuXG4gICAgdmFyIHBhdHRlcm4gPSBQYXR0ZXJucy5maW5kT25lKHtfaWQ6IHBhdHRlcm5faWR9LCB7ZmllbGRzOiB7IHdlYXZpbmc6IDFcbiAgICB9fSk7XG5cbiAgICBpZiAocGF0dGVybi53ZWF2aW5nLmluZGV4T2YoXCJTMTVcIikgIT0gLTEpIC8vIGlkbGUgdGFibGV0IHNwZWNpYWwgc3R5bGVcbiAgICAgIHJldHVybiB0cnVlO1xuXG4gICAgZWxzZVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICB9KVxuXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgLy8gVXNlZCBpbiBoZWFkZXIgdG8gZGlzcGxheSBjb3JyZWN0IGJ1dHRvbnMgYW5kIHRpdGxlIGRlcGVuZGluZyBvbiByb3V0ZSBhbmQgcGFyYW1zXG4gIC8vIFVzZWQgaW4gbWVudSB0byBkZXRlcm1pbmUgbWVudSBlbnRyaWVzXG4gIFVJLnJlZ2lzdGVySGVscGVyKCdyb3V0ZV9uYW1lJywgZnVuY3Rpb24oKXtcbiAgICByZXR1cm4gUm91dGVyLmN1cnJlbnQoKS5yb3V0ZS5nZXROYW1lKCk7XG4gIH0pO1xuXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgLy8gdHVybiBvZmYgLyBzaG93IG1hbnVhbGx5IGFjdGl2YXRlZCAnTG9hZGluZy4uLicgaW5kaWNhdG9yXG4gIFVJLnJlZ2lzdGVySGVscGVyKCdyZW5kZXJlZF9tYW51YWwnLCBmdW5jdGlvbigpIHtcbiAgICAvLyBjYWxsIHRoaXMgaW4gdGhlIHRlbXBsYXRlIHRvIGhpZGUgXCJsb2FkaW5nLi4uXCJcbiAgICBTZXNzaW9uLnNldChcImxvYWRpbmdcIiwgZmFsc2UpO1xuICAgIHJldHVybiB0cnVlO1xuICB9KTtcblxuICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4gIC8vIFNpbXVsYXRpb24gcGF0dGVybnNcbiAgVUkucmVnaXN0ZXJIZWxwZXIoJ2VkaXRfbW9kZScsIGZ1bmN0aW9uKCkge1xuICAgIGlmIChSb3V0ZXIuY3VycmVudCgpLnJvdXRlLmdldE5hbWUoKSA9PSBcInBhdHRlcm5cIilcbiAgICB7XG4gICAgICByZXR1cm4gU2Vzc2lvbi5nZXQoXCJlZGl0X21vZGVcIik7XG4gICAgfVxuICB9KTtcblxuICBVSS5yZWdpc3RlckhlbHBlcignc2ltdWxhdGlvbl9tb2RlJywgZnVuY3Rpb24oKSB7XG4gICAgaWYgKFJvdXRlci5jdXJyZW50KCkucm91dGUuZ2V0TmFtZSgpID09IFwicGF0dGVyblwiKVxuICAgICAgcmV0dXJuIFNlc3Npb24uZ2V0KFwic2ltdWxhdGlvbl9tb2RlXCIpO1xuICB9KTtcblxuICBVSS5yZWdpc3RlckhlbHBlcignZG9lc19wYXR0ZXJuX3JlcGVhdCcsIGZ1bmN0aW9uKCl7XG4gICAgdmFyIHBhdHRlcm5faWQgPSBSb3V0ZXIuY3VycmVudCgpLnBhcmFtcy5faWQ7XG4gICAgcmV0dXJuIE1ldGVvci5teV9mdW5jdGlvbnMuZG9lc19wYXR0ZXJuX3JlcGVhdChwYXR0ZXJuX2lkKTtcbiAgfSk7XG5cbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAvLyBwcm92aWRlIGxpc3RzIG9mIHBhdHRlcm5zIGluIGRpZmZlcmVudCBjYXRlZ29yaWVzXG4gIC8vIHJlcXVlc3RQYWdlKDEpIHdvcmtzIGFyb3VuZCBhIGJ1ZyBpbiBhbGV0aGVzLXBhZ2VzIGludHJvZHVjZWQgd2l0aCB0aGUgTWV0ZW9yIDEuMyB1cGdyYWRlLCBpbiB3aGljaCBpZiB5b3UgaGF2ZSBtb3JlIHRoYW4gMiBvciAzIHBhZ2luYXRlZCBvYmplY3RzLCBvbmx5IHRoZSBmaXJzdCBmZXcgdGhhdCB3ZXJlIGRlZmluZWQgd2lsbCB3b3JrLlxuICAvLyBodHRwczovL2dpdGh1Yi5jb20vYWxldGhlcy9tZXRlb3ItcGFnZXMvaXNzdWVzLzIwOFxuICBUZW1wbGF0ZS5uZXdfcGF0dGVybnMub25SZW5kZXJlZChmdW5jdGlvbigpIHtcbiAgICBOZXdQYXR0ZXJucy5yZXF1ZXN0UGFnZSgxKTtcbiAgfSk7XG5cbiAgVGVtcGxhdGUubXlfcGF0dGVybnMub25SZW5kZXJlZChmdW5jdGlvbigpIHtcbiAgICBNeVBhdHRlcm5zLnJlcXVlc3RQYWdlKDEpO1xuICB9KTtcblxuICBUZW1wbGF0ZS5hbGxfcGF0dGVybnMub25SZW5kZXJlZChmdW5jdGlvbigpIHtcbiAgICBBbGxQYXR0ZXJucy5yZXF1ZXN0UGFnZSgxKTtcbiAgfSk7XG5cbiAgVGVtcGxhdGUudXNlci5vblJlbmRlcmVkKGZ1bmN0aW9uKCkge1xuICAgIFVzZXJQYXR0ZXJucy5yZXF1ZXN0UGFnZSgxKTtcbiAgfSk7XG5cbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgLy8gdXNlZCB0byBjaGVjayBwYWdlIGlzIHN1ZmZpY2llbnRseSByZW5kZXJlZCBmb3IgbnVtYmVyIG9mIHRodW1ibmFpbHMgdG8gaGF2ZSBiZWVuIGNhbGN1bGF0ZWRcbiAgVUkucmVnaXN0ZXJIZWxwZXIoJ3RodW1ibmFpbHNfaW5fcm93JywgZnVuY3Rpb24oKSB7XG4gICAgcmV0dXJuIFNlc3Npb24uZ2V0KCd0aHVtYm5haWxzX2luX3JvdycpO1xuICB9KTtcblxuICBVSS5yZWdpc3RlckhlbHBlcignYXV0b19wcmV2aWV3X3N2ZycsIGZ1bmN0aW9uKCkge1xuICAgIHZhciBkYXRhID0gdGhpcy5hdXRvX3ByZXZpZXc7XG4gICAgLy9jb25zb2xlLmxvZyhcImRhdGEgXCIgKyBkYXRhKTtcbiAgICB2YXIgc3JjID0gJ2RhdGE6aW1hZ2Uvc3ZnK3htbDtiYXNlNjQsJyArIHdpbmRvdy5idG9hKGRhdGEpO1xuICAgIHJldHVybiBzcmM7XG4gIH0pO1xuXG4gIFVJLnJlZ2lzdGVySGVscGVyKCdteV9wYXR0ZXJucycsIGZ1bmN0aW9uKCl7XG4gICAgaWYgKCFNZXRlb3IudXNlcklkKCkpXG4gICAgICByZXR1cm47XG5cbiAgICB2YXIgb2JqID0ge1xuICAgICAgJ3NvcnQnOiB7ICduYW1lJzogMSB9LFxuICAgICAgJ2xpbWl0JzogU2Vzc2lvbi5nZXQoJ3RodW1ibmFpbHNfaW5fcm93JylcbiAgICB9XG5cbiAgICByZXR1cm4gUGF0dGVybnMuZmluZCh7Y3JlYXRlZF9ieTogTWV0ZW9yLnVzZXJJZCgpfSwgb2JqKTtcbiAgfSk7XG5cbiAgVUkucmVnaXN0ZXJIZWxwZXIoJ25ld19wYXR0ZXJucycsIGZ1bmN0aW9uKCl7XG4gICAgdmFyIG9iaiA9IHtcbiAgICAgICdzb3J0JzogeyAnY3JlYXRlZF9hdCc6IC0xIH0sXG4gICAgICAnbGltaXQnOiBTZXNzaW9uLmdldCgndGh1bWJuYWlsc19pbl9yb3cnKVxuICAgIH1cblxuICAgIHJldHVybiBQYXR0ZXJucy5maW5kKHt9LCBvYmopO1xuICB9KTtcblxuICBVSS5yZWdpc3RlckhlbHBlcignYWxsX3BhdHRlcm5zJywgZnVuY3Rpb24oKXtcbiAgICB2YXIgb2JqID0ge1xuICAgICAgJ3NvcnQnOiB7ICduYW1lJzogMSB9LFxuICAgICAgJ2xpbWl0JzogU2Vzc2lvbi5nZXQoJ3RodW1ibmFpbHNfaW5fcm93JylcbiAgICB9XG5cbiAgICByZXR1cm4gUGF0dGVybnMuZmluZCh7fSwgb2JqKTtcbiAgfSk7XG5cbiAgVUkucmVnaXN0ZXJIZWxwZXIoJ3VzZXJzJywgZnVuY3Rpb24oKXtcbiAgICB2YXIgb2JqID0ge1xuICAgICAgJ3NvcnQnOiB7ICdwcm9maWxlLm5hbWVfc29ydCc6IDEgfSxcbiAgICAgICdsaW1pdCc6IFNlc3Npb24uZ2V0KCd0aHVtYm5haWxzX2luX3JvdycpXG4gICAgfVxuXG4gICAgcmV0dXJuIE1ldGVvci51c2Vycy5maW5kKHt9LCBvYmopO1xuICB9KTtcblxuICAvLyAqKiogaGFzIHRoZSB1c2VyIHBlcm1pc3Npb24gdG8gY3JlYXRlIGEgbmV3IHBhdHRlcm4/ICoqKiAvL1xuICBVSS5yZWdpc3RlckhlbHBlcignY2FuX2NyZWF0ZV9wYXR0ZXJuJywgZnVuY3Rpb24oKXtcbiAgICByZXR1cm4gTWV0ZW9yLm15X2Z1bmN0aW9ucy5jYW5fY3JlYXRlX3BhdHRlcm4oKTtcbiAgfSk7XG5cbiAgVUkucmVnaXN0ZXJIZWxwZXIoJ3ZpZXdfcGF0dGVybl9tb2RlJywgZnVuY3Rpb24oKXtcbiAgICByZXR1cm4gU2Vzc2lvbi5nZXQoJ3ZpZXdfcGF0dGVybl9tb2RlJyk7XG4gIH0pO1xuXG4gIFRlbXBsYXRlLmxlZnRfY29sdW1uLmhlbHBlcnMoe1xuICAgIHNlbGVjdGVkOiBmdW5jdGlvbihpdGVtKSB7XG4gICAgICB2YXIgcm91dGUgPSBSb3V0ZXIuY3VycmVudCgpLnJvdXRlLmdldE5hbWUoKTtcbiAgICAgIHN3aXRjaChpdGVtKVxuICAgICAge1xuICAgICAgICBjYXNlIFwiaG9tZVwiOlxuICAgICAgICBjYXNlIFwicmVjZW50X3BhdHRlcm5zXCI6XG4gICAgICAgIGNhc2UgXCJuZXdfcGF0dGVybnNcIjpcbiAgICAgICAgY2FzZSBcIm15X3BhdHRlcm5zXCI6XG4gICAgICAgIGNhc2UgXCJhbGxfcGF0dGVybnNcIjpcbiAgICAgICAgY2FzZSBcInVzZXJzXCI6XG4gICAgICAgICAgaWYgKHJvdXRlID09IGl0ZW0pXG4gICAgICAgICAgICByZXR1cm4gXCJzZWxlY3RlZFwiO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cbiAgfSk7XG5cbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4gIFRlbXBsYXRlLnNlYXJjaC5oZWxwZXJzKHtcbiAgICBpbmRleGVzOiBmdW5jdGlvbiAoKSB7XG4gICAgICByZXR1cm4gW3BhdHRlcm5zSW5kZXgsIHVzZXJzSW5kZXhdO1xuICAgIH0sXG4gICAgcGF0dGVybnNJbmRleDogZnVuY3Rpb24gKCkge1xuICAgICAgcmV0dXJuIHBhdHRlcm5zSW5kZXg7XG4gICAgfSxcbiAgICB1c2Vyc0luZGV4OiBmdW5jdGlvbiAoKSB7XG4gICAgICByZXR1cm4gdXNlcnNJbmRleDtcbiAgICB9LFxuICAgIGF0dHJpYnV0ZXM6IGZ1bmN0aW9uICgpIHtcbiAgICAgIGlmIChTZXNzaW9uLmdldCgnd2luZG93X3dpZHRoJykgPiA2NTApXG4gICAgICAgIHJldHVybiB7ICdjbGFzcyc6ICdlYXN5LXNlYXJjaC1pbnB1dCcsICdwbGFjZWhvbGRlcic6ICdTZWFyY2guLi4nIH07XG5cbiAgICAgIGVsc2UgaWYgKFNlc3Npb24uZ2V0KCd3aW5kb3dfd2lkdGgnKSA8IDQ2MClcbiAgICAgICAgcmV0dXJuIHsgJ2NsYXNzJzogJ2Vhc3ktc2VhcmNoLWlucHV0JywgJ3BsYWNlaG9sZGVyJzogJycgfTtcblxuICAgICAgZWxzZVxuICAgICAgICByZXR1cm4geyAnY2xhc3MnOiAnZWFzeS1zZWFyY2gtaW5wdXQnLCAncGxhY2Vob2xkZXInOiAnU2VhcmNoLi4uJyB9O1xuICAgIH0sXG4gICAgc2VhcmNoX3Rlcm06IGZ1bmN0aW9uKCkge1xuICAgICAgcmV0dXJuIHBhdHRlcm5zSW5kZXguZ2V0Q29tcG9uZW50RGljdCgpLmdldCgnc2VhcmNoRGVmaW5pdGlvbicpO1xuICAgIH0sXG4gICAgcGF0dGVybl9yZXN1bHRzX2NvdW50OiBmdW5jdGlvbigpIHtcbiAgICAgIHJldHVybiBwYXR0ZXJuc0luZGV4LmdldENvbXBvbmVudERpY3QoKS5nZXQoJ2NvdW50Jyk7XG4gICAgfSxcbiAgICB1c2Vyc19yZXN1bHRzX2NvdW50OiBmdW5jdGlvbigpIHtcbiAgICAgIHJldHVybiB1c2Vyc0luZGV4LmdldENvbXBvbmVudERpY3QoKS5nZXQoJ2NvdW50Jyk7XG4gICAgfSxcbiAgICBjc3NfY2xhc3M6IGZ1bmN0aW9uKCkge1xuICAgICAgaWYgKFNlc3Npb24uZ2V0KCd3aW5kb3dfd2lkdGgnKSA+IDY1MClcbiAgICAgICAgcmV0dXJuIFwid2lkZVwiO1xuXG4gICAgICBlbHNlIGlmIChTZXNzaW9uLmdldCgnd2luZG93X3dpZHRoJykgPCA0NjApXG4gICAgICAgIHJldHVybiBcIm5hcnJvd1wiO1xuICAgIH0sXG4gICAgbW9yZV9wYXR0ZXJuczogZnVuY3Rpb24oKSB7XG4gICAgICBpZiAocGF0dGVybnNJbmRleC5nZXRDb21wb25lbnRNZXRob2RzKCkuaGFzTW9yZURvY3VtZW50cygpKVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9LFxuICAgIG1vcmVfdXNlcnM6IGZ1bmN0aW9uKCkge1xuICAgICAgaWYgKHVzZXJzSW5kZXguZ2V0Q29tcG9uZW50TWV0aG9kcygpLmhhc01vcmVEb2N1bWVudHMoKSlcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICB9KTtcblxuICBUZW1wbGF0ZS5zZWFyY2gub25SZW5kZXJlZChmdW5jdGlvbiAoKSB7XG4gICAgLy8gZG8gbm90IHJlbW92ZSB0aGVzZSBoYW5kbGVycyB3aXRoICQoJ2JvZHknKS5vZmYoXCJjbGlja1wiKSBvciAkKHdpbmRvdykub2ZmKFwia2V5dXBcIiksIGFzIGl0IHByZXZlbnRzIHRoZXNlIGJlaW5nIHJlZ2lzdGVyZWQgb24gYW55IGVsZW1lbnRzIGRpcmVjdGx5IGF0dGFjaGVkIHRvIGJvZHkgc3VjaCBhcyB0aGUgXCJlbWFpbCBqdXN0IHZlcmlmaWVkXCIgZGlhbG9nIGluIGFjY291bnRzLXVpLXVuc3R5bGVkXG4gICAgJCgnYm9keScpLm9uKFwiY2xpY2tcIiwgZnVuY3Rpb24oZXZlbnQpe1xuICAgICAgLy8gY2xvc2UgdGhlIHJlc3VsdHMgbGlzdCBpZiB0aGUgdXNlciBjbGlja3Mgb3V0c2lkZSBpdFxuXG4gICAgICAvLyBpZiB0aGUgcmVzdWx0cyBsaXN0IGlzIHNob3duXG4gICAgICBpZiAoJCgnI3NlYXJjaCAucmVzdWx0cy13cmFwcGVyJykubGVuZ3RoICE9IDApXG4gICAgICB7XG4gICAgICAgIC8vIGRpZCB0aGUgdXNlciBjbGljayBvdXRzaWRlIHRoZSByZXN1bHRzIGxpc3RcbiAgICAgICAgdmFyIHJlc3VsdHNfbGlzdCA9ICQoJy5yZXN1bHRzLXdyYXBwZXInKTtcblxuICAgICAgICBpZiAoIXJlc3VsdHNfbGlzdC5pcyhldmVudC50YXJnZXQpIC8vIGlmIHRoZSB0YXJnZXQgb2YgdGhlIGNsaWNrIGlzbid0IHRoZSBjb250YWluZXIuLi5cbiAgICAgICAgJiYgcmVzdWx0c19saXN0LmhhcyhldmVudC50YXJnZXQpLmxlbmd0aCA9PT0gMCkgLy8gLi4uIG5vciBhIGRlc2NlbmRhbnQgb2YgdGhlIGNvbnRhaW5lclxuICAgICAgICB7XG4gICAgICAgICAgLy8gYnV0IG5vdCBpbiB0aGUgc2VhcmNoIGlucHV0P1xuICAgICAgICAgIHZhciBpbnB1dCA9ICQoJyNzZWFyY2ggLmlucHV0LXdyYXBwZXIgaW5wdXQuZWFzeS1zZWFyY2gtaW5wdXQnKTtcblxuICAgICAgICAgICAgaWYgKCFpbnB1dC5pcyhldmVudC50YXJnZXQpXG4gICAgICAgICAgJiYgaW5wdXQuaGFzKGV2ZW50LnRhcmdldCkubGVuZ3RoID09PSAwKVxuICAgICAgICAgIHtcbiAgICAgICAgICAgIE1ldGVvci5teV9mdW5jdGlvbnMuaGlkZV9zZWFyY2hfcmVzdWx0cygpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuXG4gICAgJCh3aW5kb3cpLm9uKFwia2V5dXBcIiwgZnVuY3Rpb24oZXZlbnQpIHtcbiAgICAgIC8vIGNsb3NlIHRoZSByZXN1bHRzIGxpc3QgaWYgdGhlIHVzZXIgcHJlc3NlcyAnRXNjJ1xuXG4gICAgICAvLyBpZiB0aGUgcmVzdWx0cyBsaXN0IGlzIHNob3duXG4gICAgICBpZiAoJCgnI3NlYXJjaCAucmVzdWx0cy13cmFwcGVyJykubGVuZ3RoICE9IDApXG4gICAgICB7XG4gICAgICAgIGlmIChldmVudC53aGljaCA9PSAyNykgLy8gdXNlciBwcmVzc2VkICdFc2MnXG4gICAgICAgIE1ldGVvci5teV9mdW5jdGlvbnMuaGlkZV9zZWFyY2hfcmVzdWx0cygpO1xuICAgICAgfVxuICAgIH0pXG4gIH0pO1xuXG4gIFRlbXBsYXRlLnNlYXJjaC5ldmVudHMoe1xuICAgICdjbGljayBsaSc6IGZ1bmN0aW9uICgpIHtcbiAgICAgIC8vIGNsZWFyIHRoZSBzZWFyY2ggd2hlbiB5b3Ugc2VsZWN0IGEgcmVzdWx0XG4gICAgICAkKCdpbnB1dC5lYXN5LXNlYXJjaC1pbnB1dCcpLnZhbChcIlwiKTtcbiAgICAgIE1ldGVvci5teV9mdW5jdGlvbnMuaGlkZV9zZWFyY2hfcmVzdWx0cygpO1xuICAgIH0sXG4gICAgJ2NsaWNrICNsb2FkX21vcmVfcGF0dGVybnMnOiBmdW5jdGlvbihldmVudCkge1xuICAgICAgaWYgKHBhdHRlcm5zSW5kZXguZ2V0Q29tcG9uZW50TWV0aG9kcygpLmhhc01vcmVEb2N1bWVudHMoKSlcbiAgICAgICAgcGF0dGVybnNJbmRleC5nZXRDb21wb25lbnRNZXRob2RzKCkubG9hZE1vcmUoOCk7XG4gICAgfSxcbiAgICAnY2xpY2sgI2xvYWRfbW9yZV91c2Vycyc6IGZ1bmN0aW9uKGV2ZW50KSB7XG4gICAgICBpZiAodXNlcnNJbmRleC5nZXRDb21wb25lbnRNZXRob2RzKCkuaGFzTW9yZURvY3VtZW50cygpKVxuICAgICAgICB1c2Vyc0luZGV4LmdldENvbXBvbmVudE1ldGhvZHMoKS5sb2FkTW9yZSg4KTtcbiAgICB9LFxuICAgICdjbGljayAjc2VhcmNoIC5wYXR0ZXJuX3Jlc3VsdHMnOiBmdW5jdGlvbihldmVudCkge1xuICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTsgLy8gdG8gbWFrZSByb3V0ZXIgd29yayBmcm9tIEhvbWUsIG5vdCBzdXJlIHdoeSBidXQgdGhpcyBpcyBuZWNlc3Nhcnkgd2hlbiBub3QgYWxyZWFkeSBpbiBwYXR0ZXJuIHJvdXRlXG4gICAgICBNZXRlb3IubXlfZnVuY3Rpb25zLnNlYXJjaF9yZXN1bHRfY2xpY2tlZCh0aGlzLl9pZCk7XG4gICAgfVxuICB9KTtcblxuICBVSS5yZWdpc3RlckhlbHBlcignaXNfd2VhdmluZycsIGZ1bmN0aW9uKCl7XG4gICAgaWYgKFJvdXRlci5jdXJyZW50KCkucGFyYW1zLm1vZGU9PVwid2VhdmluZ1wiKVxuICAgICAgcmV0dXJuIHRydWU7XG4gIH0pO1xuXG4gIC8vIHRoaXMgY2hlY2tzIG5vdCBvbmx5IHdoZXRoZXIgdXNlcl9pZCBpcyBudWxsIGJ1dCBhbHNvIHdoZXRoZXIgdGhlIHVzZXIgY3VyZW50bHkgaGFzIHBlcm1pc3Npb24gdG8gc2VlIHRoaXMgdXNlclxuICBVSS5yZWdpc3RlckhlbHBlcigndXNlcl9leGlzdHMnLCBmdW5jdGlvbih1c2VyX2lkKXtcbiAgICByZXR1cm4gKE1ldGVvci51c2Vycy5maW5kKHsgX2lkOiB1c2VyX2lkfSkuY291bnQoKSAhPSAwKTtcbiAgfSk7XG5cbiAgVUkucmVnaXN0ZXJIZWxwZXIoJ3BhdHRlcm5fZXhpc3RzJywgZnVuY3Rpb24ocGF0dGVybl9pZCl7XG4gICAgaWYgKFBhdHRlcm5zLmZpbmQoe19pZDogcGF0dGVybl9pZH0sIHtmaWVsZHM6IHtfaWQ6IDF9fSwge2xpbWl0OiAxfSkuY291bnQoKSAhPSAwKVxuICAgICAgcmV0dXJuIHRydWU7XG4gIH0pO1xuXG4gIFVJLnJlZ2lzdGVySGVscGVyKCdhcHBfbmFtZV9pbl9oZWFkZXInLCBmdW5jdGlvbihwYXR0ZXJuX2lkKXtcbiAgICBzd2l0Y2ggKFJvdXRlci5jdXJyZW50KCkucm91dGUuZ2V0TmFtZSgpKVxuICAgIHtcbiAgICAgIGNhc2UgXCJob21lXCI6XG4gICAgICBjYXNlIFwicmVjZW50X3BhdHRlcm5zXCI6XG4gICAgICBjYXNlIFwibmV3X3BhdHRlcm5zXCI6XG4gICAgICBjYXNlIFwibXlfcGF0dGVybnNcIjpcbiAgICAgIGNhc2UgXCJhbGxfcGF0dGVybnNcIjpcbiAgICAgIGNhc2UgXCJ1c2Vyc1wiOlxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgYnJlYWs7XG4gICAgfVxuICAgICAgXG4gIH0pO1xuXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgLy8gbWVudVxuXG4gIFVJLnJlZ2lzdGVySGVscGVyKCdtZW51X29wZW4nLCBmdW5jdGlvbigpXG4gIHtcbiAgICBpZiAoU2Vzc2lvbi5lcXVhbHMoJ21lbnVfb3BlbicsIHRydWUpKVxuICAgICAgcmV0dXJuIFwib3BlblwiO1xuICB9KTtcblxuICBVSS5yZWdpc3RlckhlbHBlcignY2FuX2VkaXRfcGF0dGVybicsIGZ1bmN0aW9uKHBhdHRlcm5faWQpIHtcbiAgICByZXR1cm4gTWV0ZW9yLm15X2Z1bmN0aW9ucy5jYW5fZWRpdF9wYXR0ZXJuKHBhdHRlcm5faWQpO1xuICB9KTtcblxuICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAvLyBNZW51IC0gb3B0aW9ucyBmb3Igc2VsZWN0ZWQgcGF0dGVyblxuICBUZW1wbGF0ZS5tZW51LmhlbHBlcnMoe1xuICAgIHNob3dfbWVudTogZnVuY3Rpb24oc3Vic2NyaXB0aW9uc1JlYWR5LCByb3V0ZV9uYW1lLCBwYXR0ZXJuX2lkKXtcbiAgICAgIHJldHVybiB0cnVlOyAvLyB0aGVyZSBpcyBub3cgYWx3YXlzIGF0IGxlYXN0IG9uZSBtZW51IG9wdGlvblxuICAgICAgLyppZiAoTWV0ZW9yLnVzZXJJZCgpKSAvLyBhY2NvdW50IHNldHRpbmdzIGlzIGF2YWlsYWJsZSB0byBhbnkgc2lnbmVkIGluIHVzZXJcbiAgICAgICAgcmV0dXJuIHRydWU7XG5cbiAgICAgIGlmIChzdWJzY3JpcHRpb25zUmVhZHkgJiYgKHJvdXRlX25hbWUgPT0gXCJwYXR0ZXJuXCIpICYmIChQYXR0ZXJucy5maW5kKHsgX2lkOiBwYXR0ZXJuX2lkfSkuY291bnQoKSAhPSAwKSkgLy8gcHJpbnRlciBmcmllbmRseSB2aWV3IGlzIGF2YWlsYWJsZVxuICAgICAgICByZXR1cm4gdHJ1ZTtcblxuICAgICAgZWxzZVxuICAgICAgICByZXR1cm4gZmFsc2U7Ki9cbiAgICAgICAgICAgIC8qIHNob3cgdGhlIG1lbnUgaWY6XG4gICAgICAgICogdGhlIHVzZXIgaXMgc2lnbmVkIGluIChBY2NvdW50IHNldHRpbmdzKVxuXG4gICAgICAvLyBmaWxlIGxvYWRpbmcgaXMgc3VwcG9ydGVkIGJ5IHRoZSBicm93c2VyIGFuZCB0aGUgdXNlciBpcyBzaWduZWQgaW4sXG4gICAgICAvLyBPUiB0aGUgdXNlciBpcyB2aWV3aW5nIGEgc3BlY2lmaWMgcGF0dGVyblxuICAgICAgLy8gaWYgdGhlIHVzZXIgaXMgbm90IHNpZ25lZCBpbiwgdGhlIG9ubHkgYXZhaWxhYmxlIG1lbnUgb3B0aW9uIGlzIHRvIHZpZXcgdGhlIHByaW50ZXItZnJpZW5kbHkgcGF0dGVyblxuICAgICAgLy8gaW1wb3J0LCBjb3B5IGFuZCBleHBvcnQgcGF0dGVybiBhcmUgb25seSBhdmFpbGFibGUgdG8gdXNlcnMgd2hvIGNhbiBjcmVhdGUgcGF0dGVybnNcbiAgICAgICovXG5cbiAgICAgIC8qaWYgKChNZXRlb3IubXlfZnVuY3Rpb25zLmlzX2ZpbGVfbG9hZGluZ19zdXBwb3J0ZWQoKSAmJiBNZXRlb3IubXlfZnVuY3Rpb25zLmNhbl9jcmVhdGVfcGF0dGVybigpKSB8fCAoc3Vic2NyaXB0aW9uc1JlYWR5ICYmIChyb3V0ZV9uYW1lID09IFwicGF0dGVyblwiKSAmJiAoUGF0dGVybnMuZmluZCh7IF9pZDogcGF0dGVybl9pZH0pLmNvdW50KCkgIT0gMCkpKVxuICAgICAgICByZXR1cm4gdHJ1ZTsqL1xuICAgIH0sXG4gICAgaXNfZmlsZV9sb2FkaW5nX3N1cHBvcnRlZDogZnVuY3Rpb24oKVxuICAgIHtcbiAgICAgIGlmIChNZXRlb3IubXlfZnVuY3Rpb25zLmlzX2ZpbGVfbG9hZGluZ19zdXBwb3J0ZWQoKSAmJiBNZXRlb3IubXlfZnVuY3Rpb25zLmNhbl9jcmVhdGVfcGF0dGVybigpKVxuICAgICAgICByZXR1cm4gdHJ1ZTtcblxuICAgICAgZWxzZVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9KTtcblxuICBUZW1wbGF0ZS5tZW51LmV2ZW50cyh7XG4gICAgJ2NsaWNrICNtZW51X2J1dHRvbic6IGZ1bmN0aW9uKCkge1xuICAgICAgaWYgKFNlc3Npb24uZXF1YWxzKCdtZW51X29wZW4nLCB0cnVlKSlcbiAgICAgICAgU2Vzc2lvbi5zZXQoJ21lbnVfb3BlbicsIGZhbHNlKTtcblxuICAgICAgZWxzZVxuICAgICAgICBTZXNzaW9uLnNldCgnbWVudV9vcGVuJywgdHJ1ZSk7XG4gICAgfSxcbiAgICAnY2xpY2sgI21lbnUgLm1lbnVfbGlzdCB1bCBsaSBhJzogZnVuY3Rpb24oKXtcbiAgICAgIFNlc3Npb24uc2V0KCdtZW51X29wZW4nLCBmYWxzZSk7XG4gICAgfSxcbiAgICAvLyBpbXBvcnQgYSBwYXR0ZXJuIGZyb20gYSBKU09OIGZpbGVcbiAgICAnY2xpY2sgI2ltcG9ydF9wYXR0ZXJuJzogZnVuY3Rpb24oKSB7XG4gICAgICBTZXNzaW9uLnNldCgnc2hvd19pbXBvcnRfcGF0dGVybicsIHRydWUpO1xuICAgIH0sXG4gICAgLy8gY29weSB0aGlzIHBhdHRlcm4gdG8gYSBuZXcgcGF0dGVyblxuICAgIC8vIGlmIHJvdXRlPVwicGF0dGVyblwiLCB0aGUgdGVtcGxhdGUgX2lkIGlzIGEgcGF0dGVybl9pZFxuICAgICdjbGljayAjY29weV9wYXR0ZXJuJzogZnVuY3Rpb24oZXZlbnQsIHRlbXBsYXRlKSB7XG4gICAgICBpZiAoUm91dGVyLmN1cnJlbnQoKS5yb3V0ZS5nZXROYW1lKCkgPT0gXCJwYXR0ZXJuXCIpXG4gICAgICB7XG4gICAgICAgIE1ldGVvci5teV9mdW5jdGlvbnMuY29weV9wYXR0ZXJuKHRlbXBsYXRlLmRhdGEuX2lkKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIC8vIGRpc3BsYXkgdGhpcyBwYXR0ZXJuIGFzIEpTT05cbiAgICAnY2xpY2sgI2V4cG9ydF9wYXR0ZXJuJzogZnVuY3Rpb24oKSB7XG4gICAgICBTZXNzaW9uLnNldCgnc2hvd19wYXR0ZXJuX2FzX3RleHQnLCB0cnVlKTtcbiAgICB9XG4gIH0pO1xuXG4gIC8vIEltcG9ydCBwYXR0ZXJuIGZyb20gZmlsZVxuICAvLyBEaWFsb2cgdG8gY2hvb3NlIHdoaWNoIHR5cGUgb2YgZmlsZSB0byBpbXBvcnRcbiAgVGVtcGxhdGUuaW1wb3J0X3BhdHRlcm5fZGlhbG9nLmhlbHBlcnMoe1xuICAgICdzaG93X2ltcG9ydF9wYXR0ZXJuJzogZnVuY3Rpb24oKSB7XG4gICAgICBpZiAoU2Vzc2lvbi5lcXVhbHMoJ3Nob3dfaW1wb3J0X3BhdHRlcm4nLCB0cnVlKSlcbiAgICAgICAgICByZXR1cm4gXCJ2aXNpYmxlXCI7XG4gICAgfSxcbiAgICAnY2hlY2tlZCc6IGZ1bmN0aW9uKG5hbWUpe1xuICAgICAgaWYgKFNlc3Npb24uZXF1YWxzKCdpbXBvcnRfZmlsZV90eXBlJywgbmFtZSkpXG4gICAgICAgIHJldHVybiBcInRydWVcIjtcbiAgICB9LFxuICAgICdkaXNhYmxlZCc6IGZ1bmN0aW9uKCl7XG4gICAgICBpZiAodHlwZW9mIFNlc3Npb24uZ2V0KCdpbXBvcnRfZmlsZV90eXBlJykgPT09IFwidW5kZWZpbmVkXCIpXG4gICAgICAgIHJldHVybiBcImRpc2FibGVkXCI7XG4gICAgfVxuICB9KTtcblxuICBUZW1wbGF0ZS5pbXBvcnRfcGF0dGVybl9kaWFsb2cuZXZlbnRzKHtcbiAgICAnY2xpY2sgI2ltcG9ydF9wYXR0ZXJuX2RpYWxvZyAuY2xvc2UnOiBmdW5jdGlvbihldmVudCkge1xuICAgICAgU2Vzc2lvbi5zZXQoJ3Nob3dfaW1wb3J0X3BhdHRlcm4nLCBmYWxzZSk7XG4gICAgfSxcbiAgICAnY2xpY2sgI2ltcG9ydF9wYXR0ZXJuX2RpYWxvZyAuY29udGludWUnOiBmdW5jdGlvbihldmVudCkge1xuICAgICAgJCgnI2ZpbGVfcGlja2VyJykudHJpZ2dlcignY2xpY2snKTtcbiAgICAgIFNlc3Npb24uc2V0KCdzaG93X2ltcG9ydF9wYXR0ZXJuJywgZmFsc2UpO1xuICAgIH0sXG4gICAgJ2NoYW5nZSBbbmFtZT1cImZpbGVfdHlwZVwiXSc6IGZ1bmN0aW9uKCl7XG4gICAgICB2YXIgZmlsZV90eXBlcyA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlOYW1lKCdmaWxlX3R5cGUnKTtcbiAgICAgIHZhciBzZWxlY3RlZF90eXBlO1xuICAgICAgZm9yKHZhciBpID0gMDsgaSA8IGZpbGVfdHlwZXMubGVuZ3RoOyBpKyspe1xuICAgICAgICBpZihmaWxlX3R5cGVzW2ldLmNoZWNrZWQpe1xuICAgICAgICAgICAgc2VsZWN0ZWRfdHlwZSA9IGZpbGVfdHlwZXNbaV0udmFsdWU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIFNlc3Npb24uc2V0KCdpbXBvcnRfZmlsZV90eXBlJywgc2VsZWN0ZWRfdHlwZSk7XG4gICAgfVxuICB9KTtcblxuICAvLyBJbXBvcnQgYSBmaWxlXG4gIFRlbXBsYXRlLmltcG9ydF9maWxlX3BpY2tlci5ldmVudHMoe1xuICAnY2hhbmdlIGlucHV0I2ZpbGVfcGlja2VyJzogZnVuY3Rpb24oZXZlbnQpIHtcbiAgICAvLyBDaGVjayBmb3IgdGhlIHZhcmlvdXMgRmlsZSBBUEkgc3VwcG9ydC5cbiAgICBpZiAoTWV0ZW9yLm15X2Z1bmN0aW9ucy5pc19maWxlX2xvYWRpbmdfc3VwcG9ydGVkKCkpXG4gICAge1xuICAgICAgdmFyIGZpbGVzID0gZXZlbnQudGFyZ2V0LmZpbGVzOyAvLyBGaWxlTGlzdCBvYmplY3RcbiAgICAgICBmID0gZmlsZXNbMF07XG4gICAgICAgXG4gICAgICAgIHZhciByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xuXG4gICAgICAgIC8vIENsb3N1cmUgdG8gY2FwdHVyZSB0aGUgZmlsZSBpbmZvcm1hdGlvbi5cbiAgICAgICAgcmVhZGVyLm9ubG9hZCA9IChmdW5jdGlvbih0aGVGaWxlKSB7XG4gICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uKGUpIHtcblxuICAgICAgICAgICAgLy8gZmluZCB0aGUgZmlsZW5hbWUgc28gaXQgY2FuIGJlIHVzZWQgYXMgYSBmYWxsYmFjayBwYXR0ZXJuIG5hbWVcbiAgICAgICAgICAgIC8vIGUuZy4gR1RUIGZpbGVzIGRvbid0IGFsd2F5cyBoYXZlIGEgbmFtZVxuICAgICAgICAgICAgdmFyIGZpbGVuYW1lID0gTWV0ZW9yLm15X2Z1bmN0aW9ucy50cmltX2ZpbGVfZXh0ZW5zaW9uKHRoZUZpbGUubmFtZSk7XG5cbiAgICAgICAgICAgIC8vIGJlIGNhdXRpb3VzIGFib3V0IHVwbG9hZGluZyBsYXJnZSBmaWxlc1xuICAgICAgICAgICAgaWYgKHRoZUZpbGUuc2l6ZSA+IDEwMDAwMDApXG4gICAgICAgICAgICAgIGFsZXJ0KFwiVW5hYmxlIHRvIGxvYWQgYSBmaWxlIGxhcmdlciB0aGFuIDFNQlwiKTtcblxuICAgICAgICAgICAgc3dpdGNoKFNlc3Npb24uZ2V0KCdpbXBvcnRfZmlsZV90eXBlJykpXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGNhc2UgXCJKU09OXCI6XG4gICAgICAgICAgICAgICAgSnNvbk9iaiA9IEpTT04ucGFyc2UoZS50YXJnZXQucmVzdWx0KTtcbiAgICAgICAgICAgICAgICBNZXRlb3IubXlfZnVuY3Rpb25zLmltcG9ydF9wYXR0ZXJuX2Zyb21fanNvbihKc29uT2JqKTtcbiAgICAgICAgICAgICAgICBicmVhaztcblxuICAgICAgICAgICAgICBjYXNlIFwiR1RUXCI6XG4gICAgICAgICAgICAgICAgTWV0ZW9yLm15X2Z1bmN0aW9ucy5pbXBvcnRfcGF0dGVybl9mcm9tX2d0dChlLnRhcmdldC5yZXN1bHQsIGZpbGVuYW1lKTtcbiAgICAgICAgICAgICAgICBicmVhaztcblxuICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIGFsZXJ0KFwiVW5yZWNvZ25pc2VkIGZpbGUgdHlwZSwgY2Fubm90IGltcG9ydCBwYXR0ZXJuXCIpXG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfTtcbiAgICAgICAgfSkoZik7XG5cbiAgICAgICAgLy8gUmVhZCBpbiB0aGUgaW1hZ2UgZmlsZSBhcyBhIGRhdGEgVVJMLlxuICAgICAgICByZWFkZXIucmVhZEFzVGV4dChmKTtcblxuICAgICAgICAvLyByZXNldCB0aGUgZm9ybSBzbyB0aGF0IHRoZSBzYW1lIGZpbGUgY2FuIGJlIGxvYWRlZCB0d2ljZSBpbiBzdWNjZXNzaW9uXG4gICAgICAgICQoZXZlbnQudGFyZ2V0KS53cmFwKCc8Zm9ybT4nKS5jbG9zZXN0KCdmb3JtJykuZ2V0KDApLnJlc2V0KCk7XG4gICAgICAgICQoZXZlbnQudGFyZ2V0KS51bndyYXAoKTtcblxuICAgICAgICAvLyBQcmV2ZW50IGZvcm0gc3VibWlzc2lvblxuICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgIH1cbiAgICB9XG4gIH0pO1xuXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4gIC8vICd2aWV3IHBhdHRlcm4gYXMgdGV4dCcgKGUuZy4gSlNPTikgZGlhbG9nXG4gIFRlbXBsYXRlLnBhdHRlcm5fYXNfdGV4dC5oZWxwZXJzKHtcbiAgICAnc2hvd19wYXR0ZXJuX2FzX3RleHQnOiBmdW5jdGlvbigpIHtcbiAgICAgIGlmIChTZXNzaW9uLmVxdWFscygnc2hvd19wYXR0ZXJuX2FzX3RleHQnLCB0cnVlKSlcbiAgICAgICAgICByZXR1cm4gXCJ2aXNpYmxlXCI7XG4gICAgfSxcbiAgICAncGF0dGVybl9hc19qc29uJzogZnVuY3Rpb24oKSB7XG4gICAgICBpZiAoU2Vzc2lvbi5lcXVhbHMoJ3Nob3dfcGF0dGVybl9hc190ZXh0JywgZmFsc2UpKVxuICAgICAgICAgIHJldHVybjtcblxuICAgICAgdmFyIHBhdHRlcm5faWQgPSB0aGlzLl9pZDtcbiAgICAgIHZhciBwYXR0ZXJuX2FzX3RleHQgPSBKU09OLnN0cmluZ2lmeShNZXRlb3IubXlfZnVuY3Rpb25zLmV4cG9ydF9wYXR0ZXJuX3RvX2pzb24ocGF0dGVybl9pZCksIG51bGwsICdcXHQnKTsgLy8gcHJldHRpZnkgSlNPTiB3aXRoIHRhYnNcblxuICAgICAgLy8gbWFrZSBhcnJheXMgbW9yZSByZWFkYWJsZSBieSByZW1vdmluZyBuZXcgbGluZXMsIHNwYWNlcyBhbmQgdGFicyB3aXRoaW4gdGhlbS4gQnV0IGRvbid0IGFsdGVyIGFycmF5cyBvZiBvYmplY3RzIChzdHlsZXMpLlxuICAgICAgdmFyIG9yaWdpbmFsX2FycmF5cyA9IFtdO1xuICAgICAgdmFyIG5ld19hcnJheXMgPSBbXTtcblxuICAgICAgdmFyIHJlID0gL1xcW1teXFxdW15cXH1dKj9cXF0vZztcbiAgICAgIC8vIGZpbmQgdGV4dCBiZXR3ZWVuIFtdLCBtYXkgY29udGFpbiBuZXcgbGluZXMgaHR0cDovL3N0YWNrb3ZlcmZsb3cuY29tL3F1ZXN0aW9ucy82MTA4NTU1L3JlcGxhY2UtdGV4dC1pbnNpZGUtb2Ytc3F1YXJlLWJyYWNrZXRzXG4gICAgICAvLyBpZ25vcmUgdGV4dCBjb250YWluaW5nIFtdIG9yIHt9LCBpLmUuIG5lc3RlZCBicmFja2V0cyBhbmQgb2JqZWN0cyBpbiBhcnJheXNcbiAgICAgIGZvcihtID0gcmUuZXhlYyhwYXR0ZXJuX2FzX3RleHQpOyBtOyBtID0gcmUuZXhlYyhwYXR0ZXJuX2FzX3RleHQpKXtcbiAgICAgICAgb3JpZ2luYWxfYXJyYXlzLnB1c2gobVswXSk7XG4gICAgICAgIHZhciB0aGlzX2FycmF5ID0gbVswXTtcblxuICAgICAgICAvL3RoaXNfYXJyYXkgPSB0aGlzX2FycmF5LnJlcGxhY2UoLyAvZywnJyk7Ly8gb3JpZ2luYWwsIHdvcmtzIGJ1dCBzdHJpcHMgc3BhY2VzIGZyb20gaW5zaWRlIHN0cmluZ3Mgc3VjaCBhcyB0YWdzXG4gICAgICAgIC8qdGhpc19hcnJheS5yZXBsYWNlKC8oW15cIl0rKXwoXCIoPzpbXlwiXFxcXF18XFxcXC4pK1wiKS8sIGZ1bmN0aW9uKCQwLCAkMSwgJDIpIHtcbiAgICAgICAgICAgIGlmICgkMSkge1xuICAgICAgICAgICAgICAgIHJldHVybiAkMS5yZXBsYWNlKC9cXHMvZywgJycpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gJDI7IFxuICAgICAgICAgICAgfSBcbiAgICAgICAgfSk7Ki8gLy8gd29ya3MgYnV0IGxvbmcsIGZyb20gc2FtZSBzb3VyY2UgYXMgYmVsb3dcblxuICAgICAgICAvLyByZW1vdmUgc3BhY2VzIGV4Y2VwdCBmb3IgdGhvc2UgYmV0d2VlbiBkb3VibGUgcXVvdGVzXG4gICAgICAgIC8vIGh0dHA6Ly9zdGFja292ZXJmbG93LmNvbS9xdWVzdGlvbnMvMTQ1NDAwOTQvamF2YXNjcmlwdC1yZWd1bGFyLWV4cHJlc3Npb24tZm9yLXJlbW92aW5nLWFsbC1zcGFjZXMtZXhjZXB0LWZvci13aGF0LWJldHdlZW4tZG9cbiAgICAgICAgdmFyIHJlZ2V4ID0gL1wiW15cIl0rXCJ8KCApL2c7XG4gICAgICAgIHRoaXNfYXJyYXkucmVwbGFjZShyZWdleCwgZnVuY3Rpb24obSwgZ3JvdXAxKSB7XG4gICAgICAgICAgICBpZiAoZ3JvdXAxID09IFwiXCIgKSByZXR1cm4gbTtcbiAgICAgICAgICAgIGVsc2UgcmV0dXJuIFwiXCI7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHRoaXNfYXJyYXkgPSB0aGlzX2FycmF5LnJlcGxhY2UoL1xcdC9nLCcnKTsgLy9yZW1vdmUgdGFic1xuICAgICAgICB0aGlzX2FycmF5ID0gdGhpc19hcnJheS5yZXBsYWNlKC8oXFxyXFxufFxcbnxcXHIpL2dtLFwiXCIpO1xuICAgICAgICAvLyBsaW5lIGJyZWFrIHJlbW92YWwgaHR0cDovL3d3dy50ZXh0Zml4ZXIuY29tL3R1dG9yaWFscy9qYXZhc2NyaXB0LWxpbmUtYnJlYWtzLnBocFxuICAgICAgICBuZXdfYXJyYXlzLnB1c2godGhpc19hcnJheSk7XG4gICAgICB9XG4gICAgICBmb3IodmFyIGkgPSAwOyBpIDwgb3JpZ2luYWxfYXJyYXlzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHBhdHRlcm5fYXNfdGV4dCA9IHBhdHRlcm5fYXNfdGV4dC5zcGxpdChvcmlnaW5hbF9hcnJheXNbaV0pLmpvaW4obmV3X2FycmF5c1tpXSk7XG4gICAgICAgIC8vIHJlcGxhY2UgdGV4dCBodHRwOi8vc3RhY2tvdmVyZmxvdy5jb20vcXVlc3Rpb25zLzUzMzQzODAvcmVwbGFjaW5nLXRleHQtaW5zaWRlLW9mLWN1cmxleS1icmFjZXMtamF2YXNjcmlwdFxuICAgICAgfVxuICAgICAgcmV0dXJuIHBhdHRlcm5fYXNfdGV4dDtcbiAgICB9XG4gIH0pO1xuXG4gIFRlbXBsYXRlLnBhdHRlcm5fYXNfdGV4dC5ldmVudHMoe1xuICAgICdjbGljayAjcGF0dGVybl9hc190ZXh0IC5jbG9zZSc6IGZ1bmN0aW9uKCkge1xuICAgICAgU2Vzc2lvbi5zZXQoJ3Nob3dfcGF0dGVybl9hc190ZXh0JywgZmFsc2UpO1xuICAgIH0sXG4gICAgJ2NsaWNrICNwYXR0ZXJuX2FzX3RleHQgLnNlbGVjdCc6IGZ1bmN0aW9uKCkge1xuICAgICAgJCgnI3BhdHRlcm5fYXNfdGV4dCB0ZXh0YXJlYScpLnNlbGVjdCgpO1xuICAgIH1cbiAgfSk7XG5cbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAvLyByb3cgYmVpbmcgZWRpdGVkIGluIHNpbXVsYXRpb24gcGF0dGVyblxuICBVSS5yZWdpc3RlckhlbHBlcigncm93X3RvX2VkaXQnLCBmdW5jdGlvbigpIHtcbiAgICByZXR1cm4gU2Vzc2lvbi5nZXQoXCJyb3dfdG9fZWRpdFwiKTtcbiAgfSk7XG5cbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgLy8gcmVhY3RpbmcgdG8gZGF0YWJhc2UgY2hhbmdlc1xuICBUcmFja2VyLmF1dG9ydW4oZnVuY3Rpb24gKGNvbXB1dGF0aW9uKSB7XG4gICAgLy8gZGV0ZWN0IGxvZ2luIC8gbG9nb3V0XG4gICAgdmFyIGN1cnJlbnRVc2VyID0gTWV0ZW9yLnVzZXIoKTtcbiAgICBpZihjdXJyZW50VXNlcil7XG4gICAgICBcbiAgICAgIGlmICghU2Vzc2lvbi5lcXVhbHMoJ3dhc19zaWduZWRfaW4nLCB0cnVlKSlcbiAgICAgIHtcbiAgICAgICAgU2Vzc2lvbi5zZXQoJ3dhc19zaWduZWRfaW4nLCB0cnVlKTtcbiAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbigpeyBNZXRlb3IubXlfZnVuY3Rpb25zLnJlc2l6ZV9wYWdlKCk7fSwgMjApO1xuICAgICAgfVxuICAgIH1cbiAgICBlbHNlIGlmKCFjb21wdXRhdGlvbi5maXJzdFJ1bil7IC8vIGF2b2lkIHVzZWxlc3MgbG9nb3V0IGRldGVjdGlvbiBvbiBhcHAgc3RhcnR1cFxuICAgICAgXG4gICAgICBpZiAoU2Vzc2lvbi5lcXVhbHMoJ3dhc19zaWduZWRfaW4nLCB0cnVlKSlcbiAgICAgIHtcbiAgICAgICAgU2Vzc2lvbi5zZXQoJ3dhc19zaWduZWRfaW4nLCBmYWxzZSk7XG4gICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKXsgTWV0ZW9yLm15X2Z1bmN0aW9ucy5yZXNpemVfcGFnZSgpO30sIDIwKTtcbiAgICAgIH1cbiAgICB9XG4gIH0pO1xuXG4gIFRyYWNrZXIuYXV0b3J1bihmdW5jdGlvbiAoY29tcHV0YXRpb24pIHtcbiAgICAvLyBGaWx0ZXJzXG4gICAgdmFyIG1heCA9IFNlc3Npb24uZ2V0KCdkaXNwbGF5X21heF90YWJsZXRzJyk7XG4gICAgdmFyIG1pbiA9IFNlc3Npb24uZ2V0KCdkaXNwbGF5X21pbl90YWJsZXRzJyk7XG5cbiAgICBpZiAobWluIHx8IG1heClcbiAgICB7XG4gICAgICAvLyBBbGwgUGF0dGVybnNcbiAgICAgIHZhciBmaWx0ZXIgPSBqUXVlcnkuZXh0ZW5kKHt9LCBBbGxQYXR0ZXJucy5maWx0ZXJzKTtcblxuICAgICAgQWxsUGF0dGVybnMuc2V0KHtcbiAgICAgICAgZmlsdGVyczogTWV0ZW9yLm15X2Z1bmN0aW9ucy5zZXRfdGFibGV0c19maWx0ZXIoZmlsdGVyLCBtaW4sIG1heClcbiAgICAgIH0pO1xuXG4gICAgICAvLyBOZXcgUGF0dGVybnNcbiAgICAgIHZhciBmaWx0ZXIgPSBqUXVlcnkuZXh0ZW5kKHt9LCBOZXdQYXR0ZXJucy5maWx0ZXJzKTtcblxuICAgICAgTmV3UGF0dGVybnMuc2V0KHtcbiAgICAgICAgZmlsdGVyczogTWV0ZW9yLm15X2Z1bmN0aW9ucy5zZXRfdGFibGV0c19maWx0ZXIoZmlsdGVyLCBtaW4sIG1heClcbiAgICAgIH0pOyAgXG5cbiAgICAgIC8vIE15IFBhdHRlcm5zXG4gICAgICB2YXIgZmlsdGVyID0galF1ZXJ5LmV4dGVuZCh7fSwgTXlQYXR0ZXJucy5maWx0ZXJzKTtcblxuICAgICAgTXlQYXR0ZXJucy5zZXQoe1xuICAgICAgICBmaWx0ZXJzOiBNZXRlb3IubXlfZnVuY3Rpb25zLnNldF90YWJsZXRzX2ZpbHRlcihmaWx0ZXIsIG1pbiwgbWF4KVxuICAgICAgfSk7XG5cbiAgICAgIC8vIFVzZXIgUGF0dGVybnNcbiAgICAgIHZhciBmaWx0ZXIgPSBqUXVlcnkuZXh0ZW5kKHt9LCBVc2VyUGF0dGVybnMuZmlsdGVycyk7XG5cbiAgICAgIFVzZXJQYXR0ZXJucy5zZXQoe1xuICAgICAgICBmaWx0ZXJzOiBNZXRlb3IubXlfZnVuY3Rpb25zLnNldF90YWJsZXRzX2ZpbHRlcihmaWx0ZXIsIG1pbiwgbWF4KVxuICAgICAgfSk7XG4gICAgfVxuICB9KTtcbn1cblxuIl19
